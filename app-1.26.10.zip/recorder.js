(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const api = window.api;
  const panel = $('#recPanel'), pill = $('#recPill');
  // الافتراضي: صوتي وصوت الجهاز مفعّلان، والكاميرا مغلقة حتى يفعّلها المستخدم
  let opts = { mode: 'lesson', mic: true, micId: '', sys: true, cam: false, camId: '', corner: 'bl', camSize: 'm', v: 2 };

  // ---------- اللوحة ----------
  const prevClose = LP.closePanels;
  LP.closePanels = () => { const a = panel.classList.contains('on'); panel.classList.remove('on'); const b = prevClose(); return a || b; };
  $('[data-rclose]').onclick = () => panel.classList.remove('on');

  let devs = [];
  async function fillDevices() {
    try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach(t => t.stop()); } catch {}
    devs = [];
    try { devs = await navigator.mediaDevices.enumerateDevices(); } catch {}
    const fill = (sel, kind, cur, none) => {
      const list = devs.filter(d => d.kind === kind);
      sel.innerHTML = list.length ? list.map((d, i) => `<option value="${d.deviceId}">${(d.label || (none + ' ' + (i + 1))).replace(/</g, '&lt;')}</option>`).join('')
        : `<option value="">${I18N.t(none === 'مايكروفون' ? 'لا يوجد مايكروفون' : 'لا توجد كاميرا')}</option>`;
      if (cur && list.some(d => d.deviceId === cur)) sel.value = cur;
    };
    fill($('#recMicSel'), 'audioinput', opts.micId, 'مايكروفون');
    fill($('#recCamSel'), 'videoinput', opts.camId, 'كاميرا');
  }

  // ---------- المايكروفون: قياس الصوت ----------
  // المايكروفون الحقيقي يلتقط دائماً ضجيج الغرفة الخفيف؛ الجهاز الخطأ يعطي صمتاً تاماً (نحو −100 ديسيبل)
  const ALIVE_DB = -88;
  const VIRTUAL = /stereo mix|what u hear|wave out|virtual|vb-audio|cable output|voicemeeter|teams|zoom|loopback|mix/i;
  const micStream = (id, raw) => navigator.mediaDevices.getUserMedia({ audio: { ...(id ? { deviceId: { exact: id } } : {}), ...(raw ? { echoCancellation: false, noiseSuppression: false, autoGainControl: false } : {}) } });
  function levelOf(an, buf) { an.getFloatTimeDomainData(buf); let s = 0; for (const x of buf) s += x * x; const rms = Math.sqrt(s / buf.length); return rms > 0 ? 20 * Math.log10(rms) : -120; }
  async function probe(id, ms = 600) {
    let st = null, ctx = null;
    try {
      st = await micStream(id, true); ctx = new AudioContext(); try { await ctx.resume(); } catch {}
      const an = ctx.createAnalyser(); an.fftSize = 2048; ctx.createMediaStreamSource(st).connect(an);
      const buf = new Float32Array(an.fftSize); let max = -120; const t0 = Date.now();
      while (Date.now() - t0 < ms) { await sleep(40); max = Math.max(max, levelOf(an, buf)); }
      return max;
    } catch { return -999; }
    finally { if (st) st.getTracks().forEach(t => t.stop()); if (ctx) ctx.close().catch(() => {}); }
  }
  // يختار مايكروفوناً يلتقط صوتاً فعلاً: المحفوظ أولاً، ثم الافتراضي، ثم الحقيقية، ثم الافتراضية (Stereo Mix وأمثالها)
  let picking = null;
  async function autoMic() {
    const mics = devs.filter(d => d.kind === 'audioinput'); if (!mics.length) return;
    const real = (d) => !VIRTUAL.test(d.label || '');
    const order = [], add = (d) => { if (d && !order.includes(d)) order.push(d); };
    add(mics.find(d => d.deviceId === opts.micId)); add(mics.find(d => d.deviceId === 'default'));
    mics.filter(d => real(d) && d.deviceId !== 'communications').forEach(add); mics.forEach(add);
    const msg = $('#recMicMsg');
    const me = picking = {};
    msg.className = 'rmsg'; msg.textContent = '⏳ ' + I18N.t('جارٍ اختيار المايكروفون…');
    for (const d of order) {
      const db = await probe(d.deviceId);
      if (picking !== me) return;
      if (db > ALIVE_DB) {
        const changed = d.deviceId !== opts.micId;
        opts.micId = d.deviceId; $('#recMicSel').value = d.deviceId; saveOpts();
        msg.className = 'rmsg ok'; msg.textContent = '✓ ' + I18N.t(changed ? 'اختير المايكروفون تلقائياً' : 'المايكروفون يعمل');
        startMeter(); return;
      }
    }
    msg.className = 'rmsg err';
    msg.innerHTML = '⚠ ' + I18N.t('لا يصل صوت من أي مايكروفون. تأكد أن المايكروفون متصل، ومن «السماح لتطبيقات سطح المكتب» في إعدادات الخصوصية في ويندوز.') + ` <button data-priv="mic">${I18N.t('فتح الإعداد')}</button>`;
    wirePriv(msg); startMeter();
  }
  const wirePriv = (el) => el.querySelectorAll('[data-priv]').forEach(b => b.onclick = () => api.openPrivacy && api.openPrivacy(b.dataset.priv));

  // مؤشر حي يتحرك مع الكلام
  let meter = null;
  function stopMeter() { if (meter) { cancelAnimationFrame(meter.raf); meter.st.getTracks().forEach(t => t.stop()); meter.ctx.close().catch(() => {}); meter = null; } $('#recLvl').style.width = '0'; }
  async function startMeter() {
    stopMeter();
    if (!opts.mic || !panel.classList.contains('on')) return;
    try {
      const st = await micStream(opts.micId, false), ctx = new AudioContext(); try { await ctx.resume(); } catch {}
      const an = ctx.createAnalyser(); an.fftSize = 1024; ctx.createMediaStreamSource(st).connect(an);
      const buf = new Float32Array(an.fftSize), m = meter = { st, ctx, raf: 0, quiet: 0 }, t0 = Date.now();
      let peak = -120;
      const loop = () => {
        if (meter !== m) return;
        const db = levelOf(an, buf); peak = Math.max(peak, db);
        $('#recLvl').style.width = Math.max(0, Math.min(100, (db + 70) * 1.8)) + '%';
        if (Date.now() - t0 > 1500 && peak <= ALIVE_DB && !m.told) {
          m.told = 1; const msg = $('#recMicMsg'); msg.className = 'rmsg warn';
          msg.textContent = '⚠ ' + I18N.t('لا يصل صوت من هذا المايكروفون — جرّب اختياراً آخر من القائمة');
        }
        m.raf = requestAnimationFrame(loop);
      };
      loop();
    } catch { const msg = $('#recMicMsg'); msg.className = 'rmsg err'; msg.textContent = '⚠ ' + I18N.t('تعذّر تشغيل المايكروفون المختار — جرّب اختياراً آخر'); }
  }

  // ---------- الكاميرا: تشغيل مع بديل، وسبب واضح عند الفشل ----------
  async function getCam(id) {
    const size = { width: 640, height: 480 };
    try { return await navigator.mediaDevices.getUserMedia({ video: id ? { deviceId: { exact: id }, ...size } : size }); }
    catch (e) {
      if (id && /Overconstrained|NotFound/.test(e.name)) {          // الكاميرا المحفوظة لم تعد موجودة ← الافتراضية
        const st = await navigator.mediaDevices.getUserMedia({ video: size });
        const nid = st.getVideoTracks()[0] && st.getVideoTracks()[0].getSettings().deviceId;
        if (nid) { opts.camId = nid; saveOpts(); }
        return st;
      }
      throw e;
    }
  }
  const camErr = (e) => {
    const n = e && e.name || '';
    if (/NotFound|Overconstrained/.test(n)) return I18N.t('لا توجد كاميرا متصلة بهذا الجهاز.');
    if (/NotAllowed|Security/.test(n)) return I18N.t('ويندوز يمنع البرامج من الكاميرا: فعّل «السماح لتطبيقات سطح المكتب بالوصول إلى الكاميرا».');
    return I18N.t('تعذّر تشغيل الكاميرا: قد تكون مستخدمة في برنامج آخر (Teams أو Zoom) فأغلقه، أو يمنعها ويندوز من إعدادات الخصوصية («السماح لتطبيقات سطح المكتب»).');
  };
  let prev = null;
  function stopPrev() { if (prev) { prev.getTracks().forEach(t => t.stop()); prev = null; } const v = $('#recCamPrev'); if (v) v.srcObject = null; }
  async function startPrev() {
    stopPrev();
    const box = $('#recCamBox'), msg = $('#recCamMsg');
    box.hidden = !opts.cam; msg.className = 'rmsg'; msg.textContent = '';
    if (!opts.cam || !panel.classList.contains('on')) return true;
    try {
      prev = await getCam(opts.camId);
      if (!panel.classList.contains('on')) { stopPrev(); return true; }
      const v = $('#recCamPrev'); v.srcObject = prev; v.play().catch(() => {});
      if (opts.camId) $('#recCamSel').value = opts.camId;
      return true;
    } catch (e) {
      box.hidden = true; msg.className = 'rmsg err';
      msg.innerHTML = '⚠ ' + camErr(e) + ` <button data-priv="cam">${I18N.t('فتح الإعداد')}</button>`;
      wirePriv(msg); return false;
    }
  }
  const paintCam = () => {
    $$('#recCorners button').forEach(b => b.classList.toggle('on', b.dataset.c === opts.corner));
    $$('#recCamSize button').forEach(b => b.classList.toggle('on', b.dataset.v === opts.camSize));
  };
  $$('#recCorners button').forEach(b => b.onclick = () => { opts.corner = b.dataset.c; paintCam(); saveOpts(); });
  $$('#recCamSize button').forEach(b => b.onclick = () => { opts.camSize = b.dataset.v; paintCam(); saveOpts(); });
  // إغلاق اللوحة بأي طريقة: إيقاف المؤشر والمعاينة
  new MutationObserver(() => { if (!panel.classList.contains('on')) { picking = null; stopMeter(); stopPrev(); } }).observe(panel, { attributes: true, attributeFilter: ['class'] });

  function showOpts() {
    $$('#recMode button').forEach(b => b.classList.toggle('on', b.dataset.v === opts.mode));
    $('#recMic').checked = opts.mic; $('#recSys').checked = opts.sys; $('#recCam').checked = opts.cam;
    $('#recMicSel').disabled = !opts.mic; $('#recCamSel').disabled = !opts.cam;
    panel.classList.toggle('micOff', !opts.mic); $('#recCamSel').style.display = opts.cam ? '' : 'none'; paintCam();
    $('#recNote').innerHTML = I18N.t(opts.mode === 'lesson'
      ? '«الدرس فقط»: يسجل منطقة الدرس مع رسمك عليه، بدون الشريط.'
      : '«الشاشة كاملة»: يسجل كل ما يظهر على الشاشة، حتى لو انتقلتِ إلى وورد أو أي برنامج.')
      + '<br>' + I18N.t('عند البدء يسألك البرنامج أين تحفظين الفيديو.');
  }
  const saveOpts = () => api.setSettings({ rec: opts });
  $$('#recMode button').forEach(b => b.onclick = () => { opts.mode = b.dataset.v; showOpts(); saveOpts(); });
  $('#recMic').onchange = e => { opts.mic = e.target.checked; showOpts(); saveOpts(); if (opts.mic) startMeter(); else { stopMeter(); $('#recMicMsg').textContent = ''; } };
  $('#recSys').onchange = e => { opts.sys = e.target.checked; saveOpts(); };
  $('#recCam').onchange = e => { opts.cam = e.target.checked; showOpts(); saveOpts(); startPrev(); };
  $('#recMicSel').onchange = e => { picking = null; opts.micId = e.target.value; saveOpts(); const m = $('#recMicMsg'); m.className = 'rmsg'; m.textContent = ''; startMeter(); };
  $('#recCamSel').onchange = e => { opts.camId = e.target.value; saveOpts(); startPrev(); };

  $('#recBtn').onclick = () => {
    if (rec) { LP.toast(I18N.t('التسجيل يعمل الآن — استخدمي ⏹ في الشريط لإنهائه')); return; }
    LP.closePanels();
    panel.classList.add('on');
    opts.cam = false;                  // الكاميرا مغلقة في كل مرة حتى يفعّلها المستخدم بنفسه
    showOpts();
    fillDevices().then(() => { if (!panel.classList.contains('on')) return; if (opts.mic) autoMic(); startPrev(); });
  };
  // الكاميرا مفعّلة لكنها لا تعمل ← تبقى اللوحة مفتوحة والسبب ظاهر فيها
  $('#recStart').onclick = async () => {
    if (opts.cam) { const ok = prev || await startPrev(); if (!ok) return; }
    panel.classList.remove('on'); start();
  };

  // ---------- التسجيل ----------
  let rec = null;            // { recorder, streams, timer, draw, file, chain, t0, pausedMs, pauseAt }
  const pickMime = () => {
    const c = ['video/mp4;codecs=avc1.42E01F,mp4a.40.2', 'video/mp4;codecs=avc1.4D401F,mp4a.40.2', 'video/mp4;codecs=avc1.42E01F,opus', 'video/mp4',
      'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    return c.find(m => { try { return MediaRecorder.isTypeSupported(m); } catch { return false; } }) || '';
  };
  const desktopVideo = (id) => ({ mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: id, maxWidth: 1920, maxHeight: 1080, maxFrameRate: 30 } });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const fmt = s => { s = Math.floor(s); const h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, x = s % 60;
    return (h ? h + ':' : '') + String(m).padStart(2, '0') + ':' + String(x).padStart(2, '0'); };

  async function countdown() {
    const cd = $('#countdown'), n = $('#cdNum');
    cd.classList.add('on');
    for (const k of [3, 2, 1]) {
      n.textContent = k; n.style.animation = 'none'; void n.offsetWidth; n.style.animation = '';
      await sleep(1000);
    }
    cd.classList.remove('on');
    await sleep(120);                    // حتى يختفي العدّ من الصورة
  }

  async function start() {
    const streams = [];
    const stopAll = () => streams.forEach(s => s.getTracks().forEach(t => t.stop()));
    try {
      const src = await api.recSources();
      const vid = opts.mode === 'lesson' ? src.window : src.screen;
      if (!vid) throw new Error('nosource');
      const desk = await navigator.mediaDevices.getUserMedia({ audio: false, video: desktopVideo(vid) });
      streams.push(desk);

      // الصوت
      const actx = new AudioContext();
      // يبدأ «خلّاط الصوت» صامتاً إن لم يُشغَّل مباشرة بعد ضغطة الزر (بعد العدّ التنازلي) — نشغّله إجبارياً
      try { await actx.resume(); } catch {}
      const dest = actx.createMediaStreamDestination();
      let hasAudio = false, micAn = null;
      if (opts.mic) {
        try {
          const m = await navigator.mediaDevices.getUserMedia({ audio: opts.micId ? { deviceId: { exact: opts.micId }, echoCancellation: true, noiseSuppression: true } : { echoCancellation: true, noiseSuppression: true } });
          streams.push(m); const ms = actx.createMediaStreamSource(m); ms.connect(dest); hasAudio = true;
          micAn = actx.createAnalyser(); micAn.fftSize = 2048; ms.connect(micAn);
        } catch { LP.toast(I18N.t('تعذّر تشغيل المايكروفون — سيكون التسجيل بدون صوتك'), null, null, 3500); }
      }
      if (opts.sys && src.screen) {
        try {
          const sys = await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: 'desktop' } }, video: desktopVideo(src.screen) });
          streams.push(sys); sys.getVideoTracks().forEach(t => t.stop());
          if (sys.getAudioTracks().length) { actx.createMediaStreamSource(new MediaStream(sys.getAudioTracks())).connect(dest); hasAudio = true; }
        } catch { LP.toast(I18N.t('تعذّر تسجيل صوت الجهاز'), null, null, 3000); }
      }

      if ((opts.mic || opts.sys) && (!hasAudio || actx.state !== 'running')) LP.toast(I18N.t('تنبيه: التسجيل سيكون بدون صوت'), null, null, 4000);

      // الكاميرا
      let camV = null;
      if (opts.cam) {
        try {
          const c = await getCam(opts.camId);
          streams.push(c);
          camV = document.createElement('video'); camV.muted = true; camV.playsInline = true; camV.srcObject = c; await camV.play();
        } catch { LP.toast(I18N.t('تعذّر تشغيل الكاميرا'), null, null, 3000); }
      }

      // تجهيز الصورة
      const v = document.createElement('video'); v.muted = true; v.srcObject = desk; await v.play();
      for (let i = 0; i < 40 && !v.videoWidth; i++) await sleep(50);
      const canvas = document.createElement('canvas'), cx = canvas.getContext('2d');
      const crop = () => {
        if (opts.mode !== 'lesson') return { x: 0, y: 0, w: v.videoWidth, h: v.videoHeight };
        const k = v.videoWidth / window.innerWidth, r = $('#stage').getBoundingClientRect();
        return { x: r.left * k, y: r.top * k, w: r.width * k, h: r.height * k };
      };
      const c0 = crop();
      let W = Math.min(1920, Math.round(c0.w)), H = Math.round(W * c0.h / c0.w);
      W -= W % 2; H -= H % 2;
      canvas.width = W; canvas.height = H;
      const draw = () => {
        if (!v.videoWidth) return;
        const c = crop();
        cx.drawImage(v, c.x, c.y, c.w, c.h, 0, 0, W, H);
        if (camV && camV.videoWidth && rec && rec.camOn !== false) {
          const r = Math.round(H * ({ s: 0.09, m: 0.12, l: 0.17 }[opts.camSize] || 0.12)), c2 = opts.corner || 'bl';
          const px = c2[1] === 'l' ? r + 24 : W - r - 24, py = c2[0] === 't' ? r + 24 : H - r - 24;
          cx.save(); cx.beginPath(); cx.arc(px, py, r, 0, Math.PI * 2); cx.closePath(); cx.clip();
          const s = Math.min(camV.videoWidth, camV.videoHeight);
          // صورة معكوسة مثل المرآة
          cx.translate(px * 2, 0); cx.scale(-1, 1);
          cx.drawImage(camV, (camV.videoWidth - s) / 2, (camV.videoHeight - s) / 2, s, s, px - r, py - r, r * 2, r * 2);
          cx.restore();
          cx.beginPath(); cx.arc(px, py, r, 0, Math.PI * 2); cx.lineWidth = 5; cx.strokeStyle = '#fff'; cx.stroke();
        }
      };
      draw();
      const drawT = setInterval(draw, 1000 / 30);
      const out = canvas.captureStream(30);
      if (hasAudio) dest.stream.getAudioTracks().forEach(t => out.addTrack(t));

      const mime = pickMime();
      const ext = mime.startsWith('video/mp4') ? 'mp4' : 'webm';
      const title = (!LP.isWelcome(LP.currentUrl()) && LP.currentTitle()) || I18N.t('شرح');

      const target = await api.recChoose({ name: title, ext });
      if (!target) { stopAll(); clearInterval(drawT); try { actx.close(); } catch {} LP.toast(I18N.t('أُلغي التسجيل')); return; }
      await countdown();
      const file = await api.recBegin(target);
      if (!file) throw new Error('nofile');
      const recorder = new MediaRecorder(out, { mimeType: mime || undefined, videoBitsPerSecond: 5000000, audioBitsPerSecond: 128000 });
      rec = { recorder, streams, drawT, file, chain: Promise.resolve(), t0: Date.now(), pausedMs: 0, pauseAt: 0, actx, stopAll, camOn: true };
      pill.classList.toggle('hasCam', !!camV); pill.classList.remove('camHidden');
      // بعد 3 ثوانٍ: إن كان المايكروفون صامتاً تماماً ننبّه فوراً (بدل اكتشافه بعد انتهاء التسجيل)
      if (micAn) { const an = micAn, buf = new Float32Array(an.fftSize); let peak = -120; const iv = setInterval(() => { peak = Math.max(peak, levelOf(an, buf)); }, 100);
        setTimeout(() => { clearInterval(iv); if (rec && peak <= ALIVE_DB) LP.toast('⚠ ' + I18N.t('لا يصل صوت من المايكروفون — أوقف التسجيل واختر مايكروفوناً آخر من لوحة التسجيل'), null, null, 9000); }, 3000); }
      recorder.ondataavailable = e => {
        if (!e.data || !e.data.size) return;
        const r = rec;
        r.chain = r.chain.then(async () => { await api.recChunk(await e.data.arrayBuffer()); });
      };
      recorder.onstop = finish;
      recorder.start(1000);
      pill.classList.add('on'); pill.classList.remove('paused');
      rec.timer = setInterval(updateTime, 500); updateTime();
      LP.toast(I18N.t('بدأ التسجيل 🔴'), null, null, 1500);
    } catch (e) {
      stopAll();
      LP.toast(I18N.t('تعذّر بدء التسجيل'), null, null, 3000);
      console.error(e);
    }
  }

  function updateTime() {
    if (!rec) return;
    const now = rec.pauseAt || Date.now();
    $('#recTime').textContent = fmt((now - rec.t0 - rec.pausedMs) / 1000);
  }
  function pause() {
    if (!rec) return;
    const r = rec.recorder;
    if (r.state === 'recording') { r.pause(); rec.pauseAt = Date.now(); pill.classList.add('paused'); $('#recPause').textContent = '▶'; api.recPaused(true); }
    else if (r.state === 'paused') { r.resume(); rec.pausedMs += Date.now() - rec.pauseAt; rec.pauseAt = 0; pill.classList.remove('paused'); $('#recPause').textContent = '⏸'; api.recPaused(false); }
    updateTime();
  }
  function stop() {
    if (!rec || rec.stopping) return;
    rec.stopping = true;
    try { rec.recorder.stop(); } catch { finish(); }
  }
  async function finish() {
    const r = rec; if (!r) return;
    clearInterval(r.drawT); clearInterval(r.timer);
    try { await r.chain; } catch {}
    r.stopAll();
    try { r.actx.close(); } catch {}
    const file = await api.recEnd();
    rec = null;
    pill.classList.remove('on', 'paused', 'hasCam', 'camHidden'); $('#recPause').textContent = '⏸';
    if (file) LP.toast(I18N.t('تم حفظ التسجيل ✓'), I18N.t('فتح المجلد'), () => api.recShow(file), 9000);
  }
  $('#recPause').onclick = pause;
  $('#recCamT').onclick = () => { if (!rec) return; rec.camOn = !rec.camOn; pill.classList.toggle('camHidden', !rec.camOn); };
  $('#recCorner').onclick = () => { const seq = ['bl', 'br', 'tr', 'tl']; opts.corner = seq[(seq.indexOf(opts.corner) + 1) % 4]; saveOpts(); };
  $('#recStop').onclick = stop;
  api.onRecStopRequest(stop);

  (async () => { const s = await api.getSettings(); if (s.rec) { opts = { ...opts, ...s.rec }; if (!s.rec.v) { opts.sys = true; opts.cam = false; opts.v = 2; } } })();
})();
