(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let settings = {};
  const save = (patch) => { Object.assign(settings, patch); return api.setSettings(patch); };

  // ================= فتح وإغلاق اللوحات =================
  const panels = ['#appsPanel', '#libPanel', '#wheelPanel', '#toolsPanel'].map(s => $(s));
  function openPanel(p) {
    closeAll();
    p.classList.add('on');
    if (LP.setTool) LP.setTool('mouse');
  }
  function closeAll() {
    let any = false;
    if (pickSlot >= 0) { pickSlot = -1; $('#appsPanel').classList.remove('pick'); }
    panels.forEach(p => { if (p.classList.contains('on')) { p.classList.remove('on'); any = true; } });
    if ($('#timerPop').classList.contains('on')) { $('#timerPop').classList.remove('on'); any = true; if (LP._drawTimer) LP._drawTimer(); }
    return any;
  }
  LP.closePanels = closeAll;
  LP.openPanel = openPanel;
  $$('[data-close]').forEach(b => b.addEventListener('click', closeAll));
  const togglePanel = (p, onOpen) => () => { if (p.classList.contains('on')) closeAll(); else { openPanel(p); onOpen && onOpen(); } };

  // ألوان ثابتة للأيقونات الحرفية
  const palette = ['#e5484d', '#fd7e14', '#f5b400', '#2fb344', '#12b886', '#228be6', '#4c6ef5', '#ae3ec9', '#e64980'];
  const colorFor = (t) => { let h = 0; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return palette[h % palette.length]; };
  const firstLetter = (t) => (String(t).trim().match(/[\p{L}\p{N}]/u) || ['؟'])[0].toUpperCase();

  // ================= البرامج =================
  let isWin = true, installed = [], openWins = [], appsLoading = false, pickSlot = -1;
  const appsBody = $('#appsBody'), appsSearch = $('#appsSearch');

  const defaultFav = /^(microsoft )?(word|teams|powerpoint|excel)\b/i;
  const favs = () => new Set(settings.favApps || []);
  const appKey = (a) => a.name.toLowerCase();

  function matchWindow(a) {
    const t = (a.target || '').toLowerCase();
    const pkg = a.aumid ? a.aumid.split('!')[0].split('_')[0].toLowerCase() : '';
    const nm = a.name.toLowerCase().replace(/^microsoft\s+/, '');
    return openWins.find(w => {
      const p = (w.path || '').toLowerCase();
      if (t && p && p === t) return true;
      if (pkg && p.includes('\\windowsapps\\' + pkg + '_')) return true;
      const title = w.title.toLowerCase();
      return nm.length > 2 && (title.endsWith(' - ' + nm) || title.endsWith(' | ' + nm) || title.endsWith(' - microsoft ' + nm) || title.endsWith('| microsoft ' + nm));
    });
  }

  async function loadApps(refresh) {
    appsLoading = true; renderApps();
    const [w, i] = await Promise.all([
      api.openWindows().catch(() => ({ windows: [] })),
      (installed.length && !refresh) ? Promise.resolve({ ok: true, apps: installed }) : api.installedApps(refresh).catch(() => ({ apps: [] }))
    ]);
    openWins = (w && w.windows) || [];
    installed = (i && i.apps) || [];
    if (!settings.favApps && installed.length) save({ favApps: installed.filter(a => defaultFav.test(a.name)).map(appKey) });
    appsLoading = false; renderApps();
  }

  // تطبيقات أونلاين تفتح كتبويب داخل البرنامج
  const ONLINE = [
    { name: 'وورد أونلاين', l: 'W', c: '#2b579a', v: 'Microsoft', url: 'https://www.office.com/launch/word' },
    { name: 'إكسل أونلاين', l: 'X', c: '#217346', v: 'Microsoft', url: 'https://www.office.com/launch/excel' },
    { name: 'باوربوينت أونلاين', l: 'P', c: '#b7472a', v: 'Microsoft', url: 'https://www.office.com/launch/powerpoint' },
    { name: 'OneDrive', l: 'O', c: '#0f6cbd', v: 'Microsoft', url: 'https://www.office.com/launch/onedrive' },
    { name: 'تيمز أونلاين', l: 'T', c: '#5b5fc7', v: 'Microsoft', url: 'https://teams.microsoft.com' },
    { name: 'Outlook', l: 'O', c: '#0a64ad', v: 'Microsoft', url: 'https://outlook.office.com/mail/' },
    { name: 'مستندات Google', l: 'D', c: '#4285f4', v: 'Google', url: 'https://docs.google.com/document/' },
    { name: 'جداول Google', l: 'S', c: '#0f9d58', v: 'Google', url: 'https://docs.google.com/spreadsheets/' },
    { name: 'عروض Google', l: 'S', c: '#f4b400', v: 'Google', url: 'https://docs.google.com/presentation/' },
    { name: 'Google Drive', l: 'D', c: '#1a73e8', v: 'Google', url: 'https://drive.google.com' },
    { name: 'Gmail', l: 'M', c: '#d93025', v: 'Google', url: 'https://mail.google.com' },
    { name: 'Google Classroom', l: 'C', c: '#188038', v: 'Google', url: 'https://classroom.google.com' }
  ];

  // ---------- الترتيب الأبجدي مثل قائمة ويندوز ----------
  const AR_NORM = { 'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ة': 'ه', 'ى': 'ي', 'ؤ': 'و', 'ئ': 'ي' };
  function groupOf(name) {
    const ch = (String(name).trim().match(/[\p{L}\p{N}]/u) || ['#'])[0];
    if (/\p{N}/u.test(ch)) return '#';
    if (/[a-z]/i.test(ch)) return ch.toUpperCase();
    if (/[؀-ۿ]/.test(ch)) return AR_NORM[ch] || ch;
    return ch.toUpperCase();
  }
  const groupRank = (g) => g === '#' ? 0 : /[A-Z]/.test(g) ? 1 : /[؀-ۿ]/.test(g) ? 2 : 3;
  const byName = (a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base', numeric: true });

  function setIcon(el, file, name) {
    const ic = el.querySelector('.ic');
    ic.style.background = colorFor(name); ic.textContent = firstLetter(name);
    if (file) api.appIcon(file).then(u => { if (u) { ic.style.background = 'none'; ic.innerHTML = `<img src="${u}" alt="">`; } });
  }

  // سطر برنامج: أيقونة صغيرة + الاسم
  function appRow(a, fav) {
    const el = document.createElement('div');
    el.className = 'arow'; el.title = a.name;
    const running = matchWindow(a);
    el.innerHTML = `<span class="ic"></span><span class="nm" dir="auto">${esc(a.name)}</span>
      ${running ? `<span class="run" title="${I18N.t('مفتوح الآن')}"></span>` : ''}
      <button class="star ${fav ? 'on' : ''}" title="${I18N.t(fav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة')}">${fav ? '★' : '☆'}</button>`;
    setIcon(el, a.lnk || a.target, a.name);
    el.querySelector('.star').addEventListener('click', e => {
      e.stopPropagation();
      const f = favs(); const k = appKey(a);
      f.has(k) ? f.delete(k) : f.add(k);
      save({ favApps: [...f] }); renderApps();
    });
    el.addEventListener('click', async () => {
      if (pickSlot >= 0) { await api.pinSlot(pickSlot, { name: a.name, lnk: a.lnk, target: a.target, aumid: a.aumid }); LP.toast(I18N.t('تم تثبيت {name} في الدائرة', { name: a.name })); closeAll(); return; }
      const w = matchWindow(a);
      if (w) { closeAll(); await api.focusWindow(w.hwnd); return; }
      LP.toast(I18N.t('جارٍ فتح {name}…', { name: a.name }));
      const ok = await api.launchApp(a);
      if (ok) closeAll(); else LP.toast(I18N.t('تعذّر فتح {name}', { name: a.name }));
    });
    return el;
  }

  // سطر نافذة مفتوحة
  function winRow(w) {
    const el = document.createElement('div');
    el.className = 'arow wrow'; el.title = w.title;
    el.innerHTML = `<span class="ic">${w.icon ? `<img src="${w.icon}" alt="">` : ''}</span><span class="nm" dir="auto">${esc(w.title)}</span>`;
    if (!w.icon) { const ic = el.querySelector('.ic'); ic.style.background = colorFor(w.title); ic.textContent = firstLetter(w.title); }
    el.addEventListener('click', async () => {
      if (pickSlot >= 0) {
        const inst = installed.find(a => matchWindow(a) === w);
        await api.pinSlot(pickSlot, inst ? { name: inst.name, lnk: inst.lnk, target: inst.target, aumid: inst.aumid, path: w.path } : { path: w.path, title: w.title });
        LP.toast(I18N.t('تم التثبيت في الدائرة')); closeAll(); return;
      }
      closeAll(); const ok = await api.focusWindow(w.hwnd); if (!ok) LP.toast(I18N.t('تعذّر الانتقال إلى هذه النافذة'));
    });
    return el;
  }

  function section(title, count) {
    appsBody.insertAdjacentHTML('beforeend', `<div class="sec">${title}${count !== undefined ? ` <span class="cnt">${count}</span>` : ''}</div>`);
  }
  function listBox(cls) { const g = document.createElement('div'); g.className = 'alist ' + (cls || ''); appsBody.appendChild(g); return g; }

  function renderApps() {
    const q = appsSearch.value.trim().toLowerCase();
    appsBody.innerHTML = '';

    // المفتوحة الآن
    const ws = openWins.filter(w => !q || w.title.toLowerCase().includes(q));
    if (ws.length) {
      section(I18N.t('مفتوحة الآن'), ws.length);
      const g = listBox('compact');
      ws.forEach(w => g.appendChild(winRow(w)));
    }
    // أونلاين (داخل البرنامج كتبويب)
    if (pickSlot < 0) {
      const on = ONLINE.filter(o => !q || o.name.toLowerCase().includes(q) || I18N.t(o.name).toLowerCase().includes(q));
      if (on.length) {
        section('🌐 ' + I18N.t('أونلاين (يفتح داخل البرنامج)'));
        const g = listBox('compact');
        on.forEach(o => {
          const el = document.createElement('div'); el.className = 'arow'; el.title = o.url;
          el.innerHTML = `<span class="ic" style="background:${o.c}">${o.l}</span><span class="nm" dir="auto">${esc(I18N.t(o.name))}</span><span class="vend">${o.v}</span>`;
          el.addEventListener('click', () => { closeAll(); LP.newTab(o.url); });
          g.appendChild(el);
        });
      }
    }
    if (!isWin) { appsBody.insertAdjacentHTML('beforeend', `<div class="empty">${I18N.t('قائمة البرامج المثبتة تعمل على ويندوز.')}</div>`); return; }
    if (appsLoading && !installed.length) {
      appsBody.insertAdjacentHTML('beforeend', `<div class="empty">${I18N.t('جارٍ تحميل قائمة البرامج…')}<br><span class="muted">${I18N.t('(أول مرة فقط قد تأخذ بضع ثوانٍ)')}</span></div>`);
      return;
    }
    const f = favs();
    const match = a => !q || a.name.toLowerCase().includes(q);
    const all = installed.filter(match).sort(byName);

    // المفضلة
    const favApps = all.filter(a => f.has(appKey(a)));
    if (favApps.length) {
      section('⭐ ' + I18N.t('المفضلة'));
      const g = listBox('compact');
      favApps.forEach(a => g.appendChild(appRow(a, true)));
    }

    section(I18N.t('كل البرامج'), all.length);
    if (!all.length) {
      appsBody.insertAdjacentHTML('beforeend', `<div class="empty">${I18N.t(q ? 'لا يوجد برنامج بهذا الاسم.' : 'لم أجد برامج. اضغطي ↻ للتحديث.')}</div>`);
      return;
    }
    // تجميع حسب الحرف الأول
    const groups = new Map();
    for (const a of all) { const k = groupOf(a.name); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(a); }
    const keys = [...groups.keys()].sort((a, b) => groupRank(a) - groupRank(b) || a.localeCompare(b, 'ar'));

    // شريط الحروف للقفز السريع
    if (!q && keys.length > 4) {
      const bar = document.createElement('div'); bar.className = 'letters';
      keys.forEach(k => {
        const b = document.createElement('button'); b.textContent = k;
        b.onclick = () => { const h = appsBody.querySelector(`.lh[data-k="${CSS.escape(k)}"]`); if (h) h.scrollIntoView({ behavior: 'smooth', block: 'start' }); };
        bar.appendChild(b);
      });
      appsBody.appendChild(bar);
    }
    const g = listBox('grouped');
    for (const k of keys) {
      const block = document.createElement('div'); block.className = 'lgrp';
      block.innerHTML = `<div class="lh" data-k="${esc(k)}">${esc(k)}</div>`;
      groups.get(k).forEach(a => block.appendChild(appRow(a, f.has(appKey(a)))));
      g.appendChild(block);
    }
  }

  appsSearch.addEventListener('input', renderApps);
  appsSearch.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeAll(); return; }
    if (e.key === 'Enter') { const first = appsBody.querySelector('.arow'); if (first) first.click(); }
  });
  $('#appsRefresh').onclick = () => loadApps(true);
  LP._testApps = (list, wins) => { isWin = true; installed = list; openWins = wins || []; openPanel($('#appsPanel')); renderApps(); };
  LP.openAppsPicker = (i) => {
    openPanel($('#appsPanel'));
    pickSlot = i;
    $('#appsPanel').classList.add('pick');
    $('#appsPanel h2').dataset.pick = I18N.t('اختاري برنامجاً للدائرة رقم {n}', { n: i + 1 });
    appsSearch.value = ''; loadApps(false);
    setTimeout(() => appsSearch.focus(), 50);
  };
  $('#appsBtn').onclick = togglePanel($('#appsPanel'), () => {
    appsSearch.value = ''; loadApps(false);
    setTimeout(() => appsSearch.focus(), 50);
  });

  // ================= الصفوف =================
  const GRADES = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر', 'الحادي عشر', 'الثاني عشر'];
  LP.gradeLabel = (n) => n ? I18N.t('الصف {g}', { g: I18N.lang === 'ar' ? GRADES[n - 1] : n }) : '';
  LP.parseGrade = (v) => {
    v = String(v ?? '').trim(); if (!v) return 0;
    const d = parseInt(v.replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)), 10);
    if (d >= 1 && d <= 12) return d;
    const w = v.replace(/^(ال)?صف\s*/, '').trim();
    const i = GRADES.findIndex(g => w === g || w === g.replace(/^ال/, '') || w.startsWith(g) || w.startsWith(g.replace(/^ال/, '')));
    return i >= 0 ? i + 1 : 0;
  };
  // صف الفصل: من الإعداد، أو من أول رقم أو كلمة في اسم الفصل (مثل 3/1 أو خامس ج)
  LP.classGrade = (c) => (c && (c.grade || LP.parseGrade(String(c.name || '').split(/[\/\s\-]/)[0]))) || 0;
  LP.gradeOptions = (sel) => `<option value="0">—</option>` + GRADES.map((_, i) => `<option value="${i + 1}" ${+sel === i + 1 ? 'selected' : ''}>${esc(LP.gradeLabel(i + 1))}</option>`).join('');

  // ================= المؤقّت =================
  // نافذة كبيرة في وسط الشاشة، وعند إغلاقها وهو يعمل يبقى ساعة صغيرة (تُسحب إلى أي مكان)
  const tPop = $('#timerPop'), tW = $('#timerW'), tNum = $('#tNum');
  let tTotal = 0, tLeft = 0, tEnd = 0, tRunning = false, tTick = null, lastBeep = -1, tDone = false;
  const tActive = () => tRunning || tLeft > 0 || tDone;
  function openTimer() {
    if (tPop.classList.contains('on')) { closeTimerPop(); return; }
    closeAll(); tPop.classList.add('on'); drawTimer();
    $('#tovSound').checked = settings.timerSound !== false;
  }
  function closeTimerPop() { tPop.classList.remove('on'); drawTimer(); }
  LP.openTimer = openTimer;
  LP.startTimer = (sec) => startTimer(sec);
  $('#timerBtn').onclick = () => openTimer();
  $$('#timerPop .tov-chips [data-m]').forEach(b => b.onclick = () => startTimer(+b.dataset.m * 60));
  $('#tovMin').addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') $('#tStart').click(); });
  $('#tStart').onclick = () => startTimer(Math.max(1, Math.min(120, +$('#tovMin').value || 4)) * 60);
  $('#tovSound').onchange = () => { settings.timerSound = $('#tovSound').checked; api.setSettings({ timerSound: settings.timerSound }); };
  $('#tovX').onclick = closeTimerPop;
  tPop.addEventListener('click', e => { if (e.target === tPop) closeTimerPop(); });

  const fmt = (s) => { s = Math.max(0, Math.ceil(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
  function drawTimer() {
    const warnAt = Math.max(30, tTotal * 0.25);
    const state = tDone ? 'done' : tLeft <= 10 && tLeft > 0 ? 'danger' : tLeft <= warnAt && tLeft > 0 ? 'warn' : '';
    // النافذة الكبيرة
    $('#tovNum').textContent = tDone ? I18N.t('انتهى الوقت!') : fmt(tLeft);
    $('#tovLbl').textContent = tActive() ? I18N.t('مؤقّت {t}', { t: fmt(tTotal) }) : I18N.t('اختاري الوقت');
    $('#tovBar').style.width = (tTotal ? 100 * Math.ceil(tLeft) / tTotal : 100) + '%';
    tPop.dataset.state = state;
    $('#tPause').textContent = I18N.t(tRunning ? 'إيقاف مؤقت' : 'استئناف');
    $('#tPause').disabled = !tActive() || tDone;
    $('#tPause').classList.toggle('pri', tRunning);
    // الساعة الصغيرة
    tNum.textContent = tDone ? I18N.t('انتهى!') : fmt(tLeft);
    tW.dataset.state = state;
    $('#tMiniPause').textContent = tRunning ? '⏸' : '▶';
    const showMini = tActive() && !tPop.classList.contains('on');
    if (showMini && !tW.classList.contains('on')) { tW.classList.add('on'); placeMini(); }
    else if (!showMini && tW.classList.contains('on') && !(document.body.classList.contains('mini') && tActive())) tW.classList.remove('on');
    if (LP.onTimerDraw) LP.onTimerDraw();
  }
  function placeMini() {
    if (document.body.classList.contains('mini')) return;
    if (LP.floatPlace) LP.floatPlace(tW, settings.timerPos, { x: 0.02, y: 0.96 });
  }
  function tick() {
    tLeft = Math.max(0, (tEnd - Date.now()) / 1000);
    const sec = Math.ceil(tLeft);
    if (sec <= 5 && sec > 0 && sec !== lastBeep && settings.timerSound !== false) { lastBeep = sec; beep(880, 0.08, 0.12); }
    if (tLeft <= 0) { finishTimer(); return; }
    // نرسم فقط عندما يتغيّر الرقم الظاهر (مرة في الثانية) — أخف على عرض باوربوينت
    if (sec === lastDrawSec) return;
    lastDrawSec = sec;
    drawTimer();
  }
  let lastDrawSec = -1;
  function startTimer(sec) {
    tTotal = tLeft = sec; tEnd = Date.now() + sec * 1000; tRunning = true; lastBeep = -1; tDone = false;
    if (document.body.classList.contains('mini')) tPop.classList.remove('on');
    clearInterval(tTick); tTick = setInterval(tick, 200);
    drawTimer();
  }
  function finishTimer() {
    clearInterval(tTick); tRunning = false; tLeft = 0; tDone = true;
    drawTimer();
    if (settings.timerSound !== false) chime();
  }
  function pauseToggle() {
    if (!tActive() || tDone) return;
    if (tRunning) { clearInterval(tTick); tRunning = false; tLeft = Math.max(0, (tEnd - Date.now()) / 1000); }
    else { tEnd = Date.now() + tLeft * 1000; tRunning = true; tTick = setInterval(tick, 200); }
    drawTimer();
  }
  function addMinute() {
    if (tDone || !tActive()) { startTimer(60); return; }
    tLeft += 60; tTotal = Math.max(tTotal, tLeft); tEnd += 60000; drawTimer();
  }
  function stopTimer() { clearInterval(tTick); tRunning = false; tLeft = 0; tTotal = 0; tDone = false; tW.classList.remove('on'); drawTimer(); }
  $('#tPause').onclick = pauseToggle;
  $('#tAdd').onclick = addMinute;
  $('#tReset').onclick = () => { clearInterval(tTick); tRunning = false; tDone = false; tLeft = 0; tTotal = 0; drawTimer(); };
  $('#tMiniPause').onclick = pauseToggle;
  $('#tMiniAdd').onclick = addMinute;
  $('#tClose').onclick = stopTimer;
  tNum.onclick = () => { if (document.body.classList.contains('mini')) { pauseToggle(); return; } openTimer(); };
  // سحب الساعة الصغيرة (موحّد مع البطاقات العائمة) ويُحفظ مكانها
  LP.floatDrag(tW, tW.querySelector('.tdrag'), 'timerPos', null, (pos) => { settings.timerPos = pos; });
  new ResizeObserver(() => { if (tW.classList.contains('on')) placeMini(); }).observe($('#stage'));
  LP.timerActive = tActive;
  LP._drawTimer = drawTimer;
  // للساعة الدائرية في العمود الجانبي
  LP.timerState = () => ({ left: Math.ceil(tLeft), total: tTotal, running: tRunning, done: tDone, active: tActive(), warnAt: Math.max(30, tTotal * 0.25) });
  LP.timerCtl = { pause: pauseToggle, add: addMinute, stop: stopTimer, open: () => openTimer() };

  // ---- الأصوات ----
  let actx = null;
  const ac = () => (actx ||= new (window.AudioContext || window.webkitAudioContext)());
  function beep(freq, dur, vol = 0.2, when = 0, type = 'sine') {
    try {
      const a = ac(), o = a.createOscillator(), g = a.createGain(), t = a.currentTime + when;
      o.type = type; o.frequency.value = freq;
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(a.destination); o.start(t); o.stop(t + dur + 0.05);
    } catch {}
  }
  function chime() { [[784, 0], [988, 0.18], [1175, 0.36], [1568, 0.6]].forEach(([f, w]) => beep(f, 0.9, 0.25, w)); setTimeout(() => [[784, 0], [988, 0.18], [1175, 0.36], [1568, 0.6]].forEach(([f, w]) => beep(f, 0.9, 0.2, w)), 1400); }
  const tickSound = () => beep(1800, 0.025, 0.06, 0, 'square');
  function fanfare() { [[523, 0], [659, 0.12], [784, 0.24], [1047, 0.38]].forEach(([f, w]) => beep(f, 0.5, 0.22, w, 'triangle')); }

  // ================= الفصول والأسماء (داخل «أدوات المعلمة») =================
  const namesBox = $('#names'), classSel = $('#classSel');
  const classes = () => { if (!settings.classes || !settings.classes.length) settings.classes = [{ name: I18N.t('فصلي'), students: [] }]; return settings.classes; };
  const curClass = () => classes()[Math.min(settings.classIdx || 0, classes().length - 1)];
  const changed = () => save({ classes: classes() }).then(() => document.dispatchEvent(new Event('lp-classes')));
  function renderClasses() {
    const home = LP.ctxHome ? LP.ctxHome() : '';
    classSel.innerHTML = classes().map((c, i) => [c, i]).filter(([c]) => (c.home || '') === home).map(([c, i]) => `<option value="${i}">${esc(c.name)}</option>`).join('');
    // تابع لـ: شخصي / مدرسة (يظهر فقط لمن انضمت لمدرسة)
    const sch = LP.schools ? LP.schools() : [], hr = $('#classHomeRow');
    hr.style.display = sch.length ? '' : 'none';
    $('#schoolClsRow').style.display = home ? '' : 'none';
    if (sch.length) $('#classHome').innerHTML = [['', '👤 ' + I18N.t('شخصي')], ...sch.map(x => [x.sid, '🏫 ' + x.name])].map(([v, l]) => `<option value="${esc(v)}" ${v === (curClass().home || '') ? 'selected' : ''}>${esc(l)}</option>`).join('');
    classSel.value = String(Math.min(settings.classIdx || 0, classes().length - 1));
    namesBox.value = curClass().students.join('\n');
    $('#classDur').value = curClass().duration || 40;
    $('#classGrade').innerHTML = LP.gradeOptions(LP.classGrade(curClass()));
    $('#classNameShow').textContent = curClass().name || '';
    const s2 = $('#classSel2'); s2.innerHTML = classSel.innerHTML; s2.value = classSel.value;
    const has = classSel.options.length > 0;
    $('#namesFor').textContent = has ? '— ' + I18N.t('فصل «{c}»', { c: curClass().name || '' }) : '';
    $('#stepNames').classList.toggle('off', !has);
    namesInfo();
  }
  // ---------- التبويبات ----------
  const tabsEl = document.querySelectorAll('#toolsPanel .ttabs [data-tt]');
  function showTab(k) {
    tabsEl.forEach(b => b.classList.toggle('on', b.dataset.tt === k));
    document.querySelectorAll('#toolsPanel .tpane').forEach(p => p.classList.toggle('on', p.dataset.pane === k));
    $('#toolsPanel').classList.toggle('tt-classes', k === 'classes');   // اختيار الفصل داخل الخطوة ① بدل أعلى النافذة
    if (k === 'classes' && !curClass().students.length) setTimeout(() => namesBox.focus(), 50);
  }
  tabsEl.forEach(b => b.onclick = () => showTab(b.dataset.tt));
  LP.toolsTab = showTab;
  const namesInfo = (msg) => {
    const n = curClass().students.length;
    $('#namesInfo').textContent = msg || (n ? I18N.t('{n} اسماً في هذا الفصل', { n }) : '');
    $('#ttopInfo').textContent = n ? I18N.t('{n} اسماً في هذا الفصل', { n }) : I18N.t('لا أسماء بعد');
    $('#stepN2').classList.toggle('done', n > 0); $('#stepN2').textContent = n > 0 ? '✓' : '2';
  };
  let saveNamesT;
  const readNames = () => namesBox.value.split('\n').map(x => x.replace(/\t+/g, ' ').replace(/\s+/g, ' ').trim()).filter(Boolean);
  namesBox.addEventListener('input', () => {
    curClass().students = [...new Set(readNames())];
    namesInfo();
    clearTimeout(saveNamesT); saveNamesT = setTimeout(changed, 600);
  });
  namesBox.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') closeAll(); });
  $('#namesSave').onclick = () => {
    const before = curClass().students.length;
    curClass().students = [...new Set(readNames())];
    namesBox.value = curClass().students.join('\n');
    clearTimeout(saveNamesT); changed();
    namesInfo(I18N.t('تم حفظ {n} اسماً ✓', { n: curClass().students.length }));
    if (!before && curClass().students.length) LP.toast(I18N.t('تم حفظ الأسماء — كوّني المجموعات من تبويب «الحصة»'), I18N.t('الحصة'), () => showTab('lesson'), 6000);
  };
  $('#classDur').addEventListener('keydown', e => e.stopPropagation());
  $('#classGrade').addEventListener('change', () => { curClass().grade = +$('#classGrade').value || 0; changed(); });
  $('#classDur').addEventListener('change', () => {
    curClass().duration = Math.max(5, Math.min(180, parseInt($('#classDur').value, 10) || 40));
    $('#classDur').value = curClass().duration; changed();
  });
  classSel.onchange = () => { save({ classIdx: +classSel.value }).then(() => document.dispatchEvent(new Event('lp-classes'))); renderClasses(); };
  $('#classSel2').onchange = () => { classSel.value = $('#classSel2').value; classSel.onchange(); };
  $('#classNewBtn').onclick = () => { const r = $('#classNewRow'); r.hidden = !r.hidden; if (!r.hidden) $('#classNewName').focus(); };
  const newName = $('#classNewName');
  newName.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') $('#classAdd').click(); });
  $('#classAdd').onclick = () => {
    const v = newName.value.trim() || I18N.t('فصل {n}', { n: classes().length + 1 });
    const home = LP.ctxHome ? LP.ctxHome() : '';
    if (classes().some(c => c.name === v && (c.home || '') === home)) { LP.toast(I18N.t('هذا الفصل موجود')); return; }
    const nc = { name: v, students: [] }; if (home) nc.home = home;
    classes().push(nc); newName.value = ''; $('#classNewRow').hidden = true;
    save({ classes: classes(), classIdx: classes().length - 1 }).then(() => document.dispatchEvent(new Event('lp-classes')));
    renderClasses(); namesBox.focus();
  };
  $('#classRename').onclick = () => {
    const box = document.createElement('div'); box.className = 'trow trename';
    box.innerHTML = `<input value="${esc(curClass().name)}"><button class="tb pri">${I18N.t('حفظ')}</button>`;
    $('#classRename').closest('.trow').after(box);
    const inp = box.querySelector('input'); inp.focus(); inp.select();
    const done = ok => {
      const v = inp.value.trim(); box.remove();
      if (!ok || !v || v === curClass().name) return;
      if (classes().some(c => c !== curClass() && c.name === v && (c.home || '') === (curClass().home || ''))) { LP.toast(I18N.t('هذا الفصل موجود')); return; }
      const oldK = LP.classKey(curClass()); curClass().name = v; changed(); renderClasses();
      LP.rekeyClass(oldK, LP.classKey(curClass()));      // المجموعات والنقاط تبقى مع الفصل بعد تغيير اسمه
    };
    box.querySelector('button').onclick = () => done(true);
    inp.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); });
  };
  const sureBtn = (btn, fn) => {
    const label = btn.textContent;
    btn.onclick = () => {
      if (!btn.dataset.sure) {
        btn.dataset.sure = 1; btn.textContent = I18N.t('متأكدة؟ اضغطي مرة أخرى'); btn.classList.add('sure');
        setTimeout(() => { delete btn.dataset.sure; btn.textContent = label; btn.classList.remove('sure'); }, 3000);
        return;
      }
      delete btn.dataset.sure; btn.textContent = label; btn.classList.remove('sure'); fn();
    };
  };
  LP.sureBtn = sureBtn;
  LP.reloadTools = async () => { settings = await api.getSettings(); renderClasses(); };
  sureBtn($('#classDel'), () => {
    const list = classes(); list.splice(Math.min(settings.classIdx || 0, list.length - 1), 1);
    save({ classes: classes(), classIdx: 0 }).then(async () => { if (LP.ensureCtxClass) await LP.ensureCtxClass(); settings = await api.getSettings(); renderClasses(); document.dispatchEvent(new Event('lp-classes')); });
  });
  $('#classHome').addEventListener('change', async () => {
    const idx = Math.min(settings.classIdx || 0, classes().length - 1), to = $('#classHome').value, name = curClass().name;
    await LP.moveClasses([idx], to);
    settings = await api.getSettings(); renderClasses();
    LP.toast(I18N.t('نُقل الفصل «{c}» إلى «{s}»', { c: name, s: LP.ctxName(to) }), null, null, 4000);
  });
  sureBtn($('#tpDelNames'), () => { curClass().students = []; changed(); renderClasses(); });
  async function openTools(tab) {
    settings = await api.getSettings();
    openPanel($('#toolsPanel')); renderClasses();
    document.dispatchEvent(new Event('lp-tools'));
    showTab(typeof tab === 'string' ? tab : curClass().students.length ? 'lesson' : 'classes');
  }
  LP.openTools = openTools;
  LP.openNamesPanel = () => openTools('classes');
  $('#toolsBtn').onclick = () => ($('#toolsPanel').classList.contains('on') ? closeAll() : openTools());

  LP.sound = { beep, tickSound, fanfare };

  // ================= البدء =================
  (async () => {
    settings = await api.getSettings();
    isWin = (await api.platform()) === 'win32';
    if (isWin) setTimeout(() => api.installedApps(false).then(r => { if (r && r.apps) { installed = r.apps; if (!settings.favApps && installed.length) save({ favApps: installed.filter(a => defaultFav.test(a.name)).map(appKey) }); } }), 4000);
  })();
})();
