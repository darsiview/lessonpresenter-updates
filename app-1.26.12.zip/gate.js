// شاشة الدخول: إعداد المديرة، اختيار المعلمة والرمز السري، إضافة معلمة، الضيفة، والاسترجاع بالبريد
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const gate = $('#gate'), box = $('#gBox');
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const palette = ['#e5484d', '#fd7e14', '#f5b400', '#2fb344', '#12b886', '#228be6', '#4c6ef5', '#ae3ec9', '#e64980'];
  const colorFor = (t) => { let h = 0; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return palette[h % palette.length]; };
  const letter = (t) => (String(t).trim().match(/[\p{L}\p{N}]/u) || ['?'])[0].toUpperCase();
  window.LPavatar = (name) => `<span class="gav" style="background:${colorFor(name)}">${esc(letter(name))}</span>`;
  let st = null;

  const ERR = {
    name: 'اكتبي الاسم.',
    email: 'البريد الإلكتروني غير صحيح.',
    pin: 'الرمز السري يجب أن يكون من 4 إلى 12 رقماً.',
    exists: 'هذا البريد مسجّل لمعلمة أخرى.',
    match: 'الرمزان غير متطابقين.',
    wrong: 'الرمز السري غير صحيح.',
    invalid: 'رمز الاسترجاع غير صحيح.',
    expired: 'انتهت صلاحية رمز الاسترجاع. اطلبي رمزاً جديداً.',
    nomailer: 'خدمة البريد غير مضبوطة بعد. اطلبي من المديرة إعادة تعيين رمزك.',
    send: 'تعذّر إرسال الرسالة. تأكدي من الاتصال بالإنترنت.',
    cwrong: 'البريد أو كلمة المرور غير صحيحة.',
    cexists: 'هذا البريد لديه حساب سحابي من قبل. اختاري «الدخول بحساب سحابي».',
    cweak: 'كلمة المرور يجب أن تكون 6 أحرف أو أكثر.',
    cmany: 'محاولات كثيرة. انتظري قليلاً ثم حاولي مرة أخرى.',
    cdisabled: 'هذا الحساب موقوف.',
    coff: 'الحساب السحابي غير مفعّل في هذه النسخة.',
    net: 'لا يوجد اتصال بالإنترنت. إن سبق لكِ الدخول على هذا الجهاز فاختاري اسمكِ من القائمة، أو ادخلي كضيفة.',
    cfail: 'تعذّر الاتصال بالخدمة السحابية. حاولي مرة أخرى.',
    ctaken: 'هذا الحساب السحابي مربوط بحساب آخر على هذا الجهاز.',
    ccancel: 'لم يكتمل الدخول بحساب Google.',
    cexpired: 'انتهت الجلسة. سجّلي الدخول مرة أخرى.'
  };
  window.LPcloudErr = (r) => errMsg(r);
  const errMsg = (r) => r && r.wait ? T('محاولات كثيرة خاطئة. حاولي بعد {s} ثانية.', { s: r.wait }) : T(ERR[r && r.err] || ERR.wrong);

  function show(html, focusSel) {
    box.innerHTML = html;
    box.style.animation = 'none'; void box.offsetWidth; box.style.animation = '';
    const f = box.querySelector(focusSel || 'input');
    if (f) setTimeout(() => f.focus(), 30);
  }
  const field = (id, label, type = 'text', extra = '') =>
    `<div class="gfield"><label for="${id}">${T(label)}</label><input id="${id}" type="${type}" ${extra} autocomplete="off" spellcheck="false"></div>`;
  const pinField = (id, label) => field(id, label, 'password', 'inputmode="numeric" class="pin" maxlength="12"');
  const pwField = (id, label) => field(id, label, 'password', 'class="pin" maxlength="64"');
  const busy = (b, on, txt) => { if (!b) return; if (on) { b.dataset.t = b.textContent; b.textContent = T(txt || 'جارٍ الاتصال…'); } else if (b.dataset.t) b.textContent = b.dataset.t; b.disabled = on; };
  const cloudOn = () => !!(st && st.cloud && st.cloud.configured);
  const qrBtn = (cls) => st && st.cloud && st.cloud.qrReady ? `<button class="gbtn ${cls || 'sec'}" id="gQr">📱 ${T('الدخول بالجوال')}</button>` : '';
  const bindQr = (back) => { const b = $('#gQr'); if (b) b.onclick = () => qrView(back); };
  const googleBtn = () => st && st.cloud && st.cloud.googleReady ? `<button class="gbtn sec ggl" id="gGoogle"><b>G</b> ${T('الدخول بحساب Google')}</button>` : '';
  const onEnter = (fn) => box.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') fn(); }));
  const val = (id) => (box.querySelector('#' + id) || {}).value || '';
  const setErr = (m) => { const e = box.querySelector('.gerr'); if (e) e.textContent = m || ''; };

  // ---------- أول تشغيل ----------
  function setupView() {
    if (!cloudOn()) return localSetupView();
    show(`<h1>👋 ${T('مرحباً بك في عارض الدروس')}</h1>
      <p class="sub">${window.LP_WEB ? T('ادخلي بحسابكِ السحابي لتجدي فصولكِ وبياناتكِ، أو ادخلي كضيفة للاستخدام السريع دون حفظ.') : T('ادخلي بحسابكِ السحابي لتجدي بياناتكِ على كل أجهزتكِ، أو استخدمي البرنامج على هذا الجهاز فقط.')}</p>
      <div class="gcol">
        <button class="gbtn" id="gCloudIn">☁ ${T('الدخول بحساب سحابي')}</button>
        ${qrBtn()}
        <button class="gbtn sec" id="gCloudNew">＋ ${T('إنشاء حساب سحابي جديد')}</button>
        ${googleBtn()}
        ${window.LP_WEB ? '' : `<button class="gbtn sec" id="gLocal">💻 ${T('حساب على هذا الجهاز فقط (دون إنترنت)')}</button>`}
        <button class="gbtn link" id="gGuest">${T('دخول كضيفة')}</button>
      </div>`, 'button');
    $('#gCloudIn').onclick = () => cloudLoginView(setupView);
    $('#gCloudNew').onclick = () => cloudSignupView(setupView);
    if ($('#gLocal')) $('#gLocal').onclick = localSetupView;
    $('#gGuest').onclick = async () => { await api.authGuest(); api.authReload(); };
    bindGoogle(setupView); bindQr(setupView);
  }
  // ---------- أول تشغيل دون إنترنت: إنشاء حساب المديرة على الجهاز ----------
  function localSetupView() {
    show(`<h1>👋 ${T('مرحباً بك في عارض الدروس')}</h1>
      <p class="sub">${T('هذا أول تشغيل للبرنامج. أنشئي حساب المديرة: يستطيع إضافة المعلمات وإعادة رموزهن عند النسيان.')}</p>
      ${field('gName', 'الاسم')}${field('gEmail', 'البريد الإلكتروني', 'email')}
      <div class="ghint" style="margin:-6px 0 12px">${T('يُستخدم البريد لاسترجاع الرمز السري إذا نسيتِه.')}</div>
      ${pinField('gPin', 'الرمز السري (4 أرقام أو أكثر)')}${pinField('gPin2', 'أعيدي كتابة الرمز السري')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('إنشاء حساب المديرة')}</button>${cloudOn() ? `<button class="gbtn sec" id="gBack">${T('رجوع')}</button>` : `<button class="gbtn sec" id="gGuest">${T('دخول كضيفة')}</button>`}</div>
      <div class="ghint" style="margin-top:10px">${T('تستطيعين ربطه بحساب سحابي لاحقاً من «الإعدادات ← حسابي» عند الاتصال بالإنترنت.')}</div>`);
    const go = async () => {
      if (val('gPin') !== val('gPin2')) return setErr(T(ERR.match));
      const r = await api.authSetup({ name: val('gName'), email: val('gEmail'), pin: val('gPin') });
      if (!r.ok) return setErr(errMsg(r));
      api.authReload();
    };
    $('#gGo').onclick = go; onEnter(go);
    if ($('#gBack')) $('#gBack').onclick = setupView;
    if ($('#gGuest')) $('#gGuest').onclick = async () => { await api.authGuest(); api.authReload(); };
  }

  // ---------- الحساب السحابي ----------
  // نتيجة أي دخول سحابي: نجاح، أو طلب ربط حساب قديم بنفس البريد، أو طلب رمز للجهاز (Google)
  function cloudResult(r, retry, back) {
    if (r.ok) { api.authReload(); return true; }
    if (r.need === 'link') { linkOldView(r.user, retry, back); return true; }
    if (r.need === 'pin') { devicePinView(retry, back); return true; }
    if (r.need === 'devpin') { devUnlockView(r.user, retry, back); return true; }
    return false;
  }
  function cloudLoginView(back, email) {
    show(`<h1>☁ ${T('الدخول بحساب سحابي')}</h1>
      <p class="sub">${T('نفس الحساب يعمل على كل أجهزتكِ. بعد أول دخول يعمل على هذا الجهاز حتى دون إنترنت.')}</p>
      ${field('gEmail', 'البريد الإلكتروني', 'email')}${pwField('gPw', 'كلمة المرور')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('دخول')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>
      ${googleBtn() || qrBtn() ? `<div class="gor"><span>${T('أو')}</span></div><div class="grow">${qrBtn()}${googleBtn()}</div>` : ''}
      <div class="grow" style="margin-top:12px;justify-content:space-between"><button class="gbtn link" id="gForgot">${T('نسيت كلمة المرور؟')}</button><button class="gbtn link" id="gNewC">${T('ليس لديّ حساب — إنشاء حساب')}</button></div>`);
    if (email) $('#gEmail').value = email;
    const go = async (linkPin) => {
      const b = $('#gGo'); const em = val('gEmail').trim(), pw = val('gPw');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return setErr(T(ERR.email));
      busy(b, true); setErr('');
      const r = await api.cloudSignin({ email: em, password: pw, linkPin });
      busy(b, false);
      if (!cloudResult(r, (pin) => api.cloudSignin({ email: em, password: pw, linkPin: pin }), () => cloudLoginView(back, em))) setErr(errMsg(r));
    };
    $('#gGo').onclick = () => go(); onEnter(() => go());
    $('#gBack').onclick = back || chooseView;
    $('#gForgot').onclick = () => cloudForgotView(() => cloudLoginView(back, val('gEmail')), val('gEmail'));
    $('#gNewC').onclick = () => cloudSignupView(() => cloudLoginView(back));
    bindGoogle(() => cloudLoginView(back)); bindQr(() => cloudLoginView(back));
  }
  function cloudSignupView(back) {
    show(`<h1>＋ ${T('إنشاء حساب سحابي')}</h1>
      <p class="sub">${T('ستصلكِ رسالة لتأكيد البريد. كلمة المرور نفسها تستخدمينها على كل الأجهزة.')}</p>
      ${field('gName', 'الاسم')}${field('gEmail', 'البريد الإلكتروني', 'email')}
      ${pwField('gPw', 'كلمة المرور (6 أحرف أو أكثر)')}${pwField('gPw2', 'أعيدي كتابة كلمة المرور')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('إنشاء الحساب')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      const name = val('gName').trim(), em = val('gEmail').trim(), pw = val('gPw');
      if (!name) return setErr(T(ERR.name));
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return setErr(T(ERR.email));
      if (pw.length < 6) return setErr(T(ERR.cweak));
      if (pw !== val('gPw2')) return setErr(T('كلمتا المرور غير متطابقتين.'));
      const b = $('#gGo'); busy(b, true); setErr('');
      const r = await api.cloudSignup({ name, email: em, password: pw });
      busy(b, false);
      if (!cloudResult(r, (pin) => api.cloudSignin({ email: em, password: pw, linkPin: pin }), () => cloudLoginView(back, em))) setErr(errMsg(r));
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  function cloudForgotView(back, email) {
    show(`<h1>${T('نسيت كلمة المرور')}</h1>
      <p class="sub">${T('اكتبي بريدكِ، وسنرسل لكِ رابطاً لاختيار كلمة مرور جديدة.')}</p>
      ${field('gEmail', 'البريد الإلكتروني', 'email')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('أرسلي الرابط')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    if (email) $('#gEmail').value = email;
    const go = async () => {
      const em = val('gEmail').trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return setErr(T(ERR.email));
      const b = $('#gGo'); busy(b, true, 'جارٍ الإرسال…');
      const r = await api.cloudForgot(em);
      busy(b, false);
      if (!r.ok) return setErr(errMsg(r));
      show(`<h1>📧 ${T('تحققي من بريدكِ')}</h1>
        <p class="sub">${T('إذا كان البريد مسجّلاً، وصلكِ رابط لاختيار كلمة مرور جديدة. لا تجدينه؟ انظري في مجلد الرسائل غير المرغوب فيها (Spam).')}</p>
        <p class="sub">${T('بعد تغييرها، ادخلي بكلمة المرور الجديدة من «الدخول بحساب سحابي».')}</p>
        <button class="gbtn" id="gBack">${T('رجوع')}</button>`, 'button');
      $('#gBack').onclick = back || chooseView;
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  // يوجد على هذا الجهاز حساب قديم بنفس البريد: نربطه بعد التأكد من رمزه، فتبقى كل دروسه وبياناته
  function linkOldView(u, retry, back) {
    show(`<h1>🔗 ${T('ربط حسابكِ القديم')}</h1>
      <div class="gme">${LPavatar(u.name)}<b>${esc(u.name)}</b></div>
      <p class="sub">${T('على هذا الجهاز حساب قديم بنفس البريد. اكتبي رمزه السري القديم لربطه بحسابكِ السحابي، فتبقى كل دروسكِ وبياناتكِ.')}</p>
      ${pinField('gPin', 'الرمز السري القديم')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('ربط الحساب')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      const b = $('#gGo'); busy(b, true);
      const r = await retry(val('gPin'));
      if (r.ok && r.wait) return;                  // الدخول بالجوال: ننتظر اكتمال تنزيل البيانات
      busy(b, false);
      if (r.ok) return api.authReload();
      setErr(errMsg(r)); $('#gPin').value = '';
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  // الدخول بـ Google لأول مرة على هذا الجهاز: رمز سري للجهاز (للدخول دون إنترنت ولفك القفل)
  function devicePinView(retry, back) {
    show(`<h1>🔒 ${T('رمز سري لهذا الجهاز')}</h1>
      <p class="sub">${T('اختاري رمزاً سرياً تدخلين به على هذا الجهاز دون إنترنت، وتفتحين به القفل بعد عدم الاستخدام.')}</p>
      ${pinField('gPin', 'الرمز السري (4 أرقام أو أكثر)')}${pinField('gPin2', 'أعيدي كتابة الرمز السري')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('حفظ ومتابعة')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      if (val('gPin') !== val('gPin2')) return setErr(T(ERR.match));
      if (!/^\d{4,12}$/.test(val('gPin'))) return setErr(T(ERR.pin));
      const r = await api.cloudGoogle({ again: true, pin: val('gPin') });
      if (!cloudResult(r, (pin) => api.cloudGoogle({ again: true, linkPin: pin }), back)) setErr(errMsg(r));
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  // Google على جهاز سبق الدخول فيه: رمز الجهاز يفتح بياناتها المشفّرة
  function devUnlockView(u, retry, back) {
    show(`<h1>🔒 ${T('رمز هذا الجهاز')}</h1>
      <div class="gme">${LPavatar(u.name)}<b>${esc(u.name)}</b></div>
      <p class="sub">${T('اكتبي الرمز السري الذي اخترتِه لهذا الجهاز لفتح بياناتكِ المحفوظة عليه.')}</p>
      ${pinField('gPin', 'الرمز السري')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('متابعة')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => { const r = await retry(val('gPin')); if (r.ok) return api.authReload(); setErr(errMsg(r)); $('#gPin').value = ''; };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  function bindGoogle(back) {
    const b = $('#gGoogle'); if (!b) return;
    b.onclick = async () => {
      busy(b, true, 'أكملي الدخول في المتصفح…'); setErr('');
      const r = await api.cloudGoogle({});
      busy(b, false);
      if (!cloudResult(r, (pin) => api.cloudGoogle({ again: true, linkPin: pin }), back)) setErr(errMsg(r));
    };
  }

  // ---------- اختيار المعلمة ----------
  function chooseView() {
    const users = st.users.map(u => `<button class="guser" data-id="${u.id}">${LPavatar(u.name)}<span class="gn">${esc(u.name)}</span>${u.cloud ? `<span class="gb cl" title="${T('حساب سحابي')}">☁</span>` : ''}${u.admin ? `<span class="gb">👑 ${T('المديرة')}</span>` : ''}</button>`).join('');
    show(`<h1>${T('من تستخدم البرنامج؟')}</h1><p class="sub">${T('اختاري اسمك ثم اكتبي رمزك السري.')}</p>
      <div class="gusers">${users}</div>
      ${cloudOn() ? `<div class="grow"><button class="gbtn" id="gCloudIn">☁ ${T('الدخول بحساب سحابي')}</button>${qrBtn()}${googleBtn()}</div>` : ''}
      <div class="grow"><button class="gbtn sec" id="gNew">＋ ${T(cloudOn() ? 'معلمة جديدة على هذا الجهاز فقط' : 'إضافة معلمة جديدة')}</button><button class="gbtn sec" id="gGuest">${T('دخول كضيفة')}</button></div>`, 'button');
    if ($('#gCloudIn')) $('#gCloudIn').onclick = () => cloudLoginView(chooseView);
    bindGoogle(chooseView); bindQr(chooseView);
    box.querySelectorAll('.guser').forEach(b => b.onclick = () => pinView(st.users.find(u => u.id === b.dataset.id)));
    $('#gNew').onclick = createView;
    $('#gGuest').onclick = async () => { await api.authGuest(); api.authReload(); };
  }

  function pinView(u) {
    show(`<div class="gme">${LPavatar(u.name)}<div><h1 style="margin:0">${esc(u.name)}</h1>${u.cloud ? `<div class="ghint">☁ ${T('حساب سحابي')}</div>` : ''}</div></div>
      ${u.cloudPw || u.qrOnly ? pwField('gPin', 'كلمة المرور') : pinField('gPin', 'الرمز السري')}
      ${u.qrOnly ? `<div class="ghint" style="margin:-6px 0 10px">${T('دخلتِ هذا الجهاز بالجوال من قبل: كلمة المرور تحتاج إنترنت هنا أول مرة، أو ادخلي بالجوال مرة أخرى.')}</div>${qrBtn()}` : ''}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('دخول')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>
      <div style="margin-top:12px"><button class="gbtn link" id="gForgot">${T(u.cloudPw ? 'نسيت كلمة المرور؟' : 'نسيت الرمز السري؟')}</button></div>`);
    const go = async () => {
      const b = $('#gGo'); busy(b, true, u.qrOnly ? 'جارٍ الاتصال…' : 'جارٍ الدخول…');
      const r = await api.authLogin(u.id, val('gPin'));
      busy(b, false);
      if (!r.ok) { setErr(errMsg(r)); box.querySelector('#gPin').value = ''; return; }
      api.authReload();
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = chooseView;
    $('#gForgot').onclick = () => u.cloudPw || u.qrOnly ? cloudForgotView(() => pinView(u)) : forgotView();
    bindQr(() => pinView(u));
  }

  function createView() {
    show(`<h1>${T('إضافة معلمة جديدة')}</h1><p class="sub">${T('كل معلمة لها حسابها ودروسها وإعداداتها الخاصة.')}</p>
      ${field('gName', 'الاسم')}${field('gEmail', 'البريد الإلكتروني', 'email')}
      ${pinField('gPin', 'الرمز السري (4 أرقام أو أكثر)')}${pinField('gPin2', 'أعيدي كتابة الرمز السري')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('إنشاء الحساب')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      if (val('gPin') !== val('gPin2')) return setErr(T(ERR.match));
      const r = await api.authCreate({ name: val('gName'), email: val('gEmail'), pin: val('gPin') });
      if (!r.ok) return setErr(errMsg(r));
      api.authReload();
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = chooseView;
  }


  // ---------- الدخول بالجوال (باركود) ----------
  let qrBack = null, qrTimer = null;
  async function qrView(back) {
    qrBack = back || chooseView;
    show(`<h1>📱 ${T('الدخول بالجوال')}</h1>
      <div class="qrwrap"><canvas id="gQrC"></canvas><div class="qrexp" id="gQrE"></div></div>
      <ol class="qrsteps">
        <li>${T('افتحي كاميرا جوالكِ ووجّهيها إلى الرمز، ثم افتحي الرابط.')}</li>
        <li>${T('سجّلي الدخول بحسابكِ السحابي (أول مرة فقط على الجوال).')}</li>
        <li>${T('اضغطي «نعم، أدخلني».')}</li>
      </ol>
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`, 'button');
    $('#gBack').onclick = () => { stopQr(); qrBack(); };
    const r = await api.qrStart();
    if (!r.ok) { setErr(T(ERR.coff)); return; }
    try { LPQR.draw($('#gQrC'), r.url, 280); } catch { setErr(T(ERR.cfail)); return; }
    clearInterval(qrTimer);
    const tick = () => { const s = Math.max(0, Math.round((r.exp - Date.now()) / 1000)); const e = $('#gQrE'); if (e) e.textContent = T('يتجدد الرمز بعد {s} ثانية', { s }); };
    tick(); qrTimer = setInterval(tick, 1000);
  }
  function stopQr() { clearInterval(qrTimer); api.qrStop(); }
  api.onQrExpired(() => { if ($('#gQrC')) qrView(qrBack); });
  api.onQrDone((r) => {
    clearInterval(qrTimer);
    if (r.ok) return api.authReload();
    if (r.need === 'link') return linkOldView(r.user, (pin) => api.qrLink(pin), () => qrView(qrBack));
    if ($('#gQrC')) { setErr(errMsg(r)); setTimeout(() => { if ($('#gQrC')) qrView(qrBack); }, 2500); }
    else if (box.querySelector('.gerr')) setErr(errMsg(r));
  });

  // ---------- الاسترجاع بالبريد ----------
  function forgotView() {
    show(`<h1>${T('استرجاع الرمز السري')}</h1>
      <p class="sub">${T('اكتبي بريدك المسجّل، وسنرسل لك رمز استرجاع من 6 أرقام ورابطاً.')}</p>
      ${field('gEmail', 'البريد الإلكتروني', 'email')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('أرسلي الرمز')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      const email = val('gEmail').trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setErr(T(ERR.email));
      const b = $('#gGo'); b.disabled = true; b.textContent = T('جارٍ الإرسال…');
      const r = await api.authForgot(email);
      b.disabled = false; b.textContent = T('أرسلي الرمز');
      if (!r.ok) return setErr(errMsg(r));
      codeView(email);
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = chooseView;
  }
  function codeView(email) {
    show(`<h1>${T('تحققي من بريدك')}</h1>
      <p class="sub">${T('إذا كان البريد مسجّلاً، وصلتك رسالة فيها رمز من 6 أرقام. الرمز صالح 10 دقائق.')}<br>${T('لا تجدينها؟ انظري في مجلد الرسائل غير المرغوب فيها (Spam).')}</p>
      ${field('gCode', 'رمز الاسترجاع', 'text', 'inputmode="numeric" class="pin" maxlength="7"')}
      ${pinField('gPin', 'الرمز السري الجديد')}${pinField('gPin2', 'أعيدي كتابة الرمز السري')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('حفظ الرمز الجديد')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      if (val('gPin') !== val('gPin2')) return setErr(T(ERR.match));
      const r = await api.authReset({ email, code: val('gCode'), pin: val('gPin') });
      if (!r.ok) return setErr(errMsg(r));
      api.authReload();
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = chooseView;
  }
  function linkView({ uid, token }) {
    const u = st.users.find(x => x.id === uid);
    show(`<h1>${T('إعادة تعيين الرمز السري')}</h1>
      ${u ? `<div class="gme">${LPavatar(u.name)}<b>${esc(u.name)}</b></div>` : ''}
      ${pinField('gPin', 'الرمز السري الجديد')}${pinField('gPin2', 'أعيدي كتابة الرمز السري')}
      <div class="gerr"></div>
      <button class="gbtn" id="gGo">${T('حفظ الرمز الجديد')}</button>`);
    const go = async () => {
      if (val('gPin') !== val('gPin2')) return setErr(T(ERR.match));
      const r = await api.authReset({ uid, token, pin: val('gPin') });
      if (!r.ok) return setErr(errMsg(r));
      api.authReload();
    };
    $('#gGo').onclick = go; onEnter(go);
  }

  // ---------- اللغة والإغلاق ----------
  document.querySelectorAll('#gLang button').forEach(b => b.onclick = () => api.setLang(b.dataset.l));
  $('#gClose').onclick = () => api.close();

  // ---------- البدء ----------
  document.addEventListener('lp-auth', async (e) => {
    st = e.detail;
    document.querySelectorAll('#gLang button').forEach(b => b.classList.toggle('on', b.dataset.l === st.lang));
    // اسم المستخدمة في قائمة «المزيد»
    if (st.user) {
      $('#meName').textContent = st.user.name;
      $('#meAv').textContent = letter(st.user.name);
      $('#meAv').style.background = colorFor(st.user.name);
      gate.classList.remove('on');
      return;
    }
    gate.classList.add('on');
    const pr = await api.pendingReset();
    if (pr) return linkView(pr);
    if (st.setup) setupView(); else chooseView();
  });
  api.onResetLink((pr) => { if (!st || st.user) return; gate.classList.add('on'); linkView(pr); });

  // ---------- تبديل المستخدمة وقفل الحسابات ----------
  // الخروج: على جهاز مشترك تختار صاحبة الحساب السحابي إبقاء بياناتها مشفّرة أو مسحها
  async function logout() {
    const s2 = await api.authState(), u = s2.user;
    if (!u || u.guest || !u.cloud || s2.personal || s2.logoutChoice) {
      const r = await api.authLogout();
      if (r && !r.ok && r.pending) outDialog(s2, r.pending);
      return;
    }
    outDialog(s2);
  }
  LP.logout = logout;
  function outDialog(s2, pending) {
    let d = $('#lpOut');
    if (!d) { d = document.createElement('div'); d.id = 'lpOut'; d.dir = I18N.dir(); document.body.appendChild(d); }
    d.innerHTML = `<div class="oBox">
      <h2>🚪 ${T('الخروج من هذا الجهاز')}</h2>
      <p class="sub">${T('هذا ليس جهازكِ الشخصي. ماذا نفعل ببياناتكِ المحفوظة عليه؟ نسختها في السحابة تبقى في الحالتين.')}</p>
      ${pending ? `<div class="oWarn">⚠ ${T('{n} من التعديلات لم تُرفع للسحابة بعد (لا يوجد اتصال). مسحها الآن يُضيّعها.', { n: pending })}</div>` : ''}
      <button class="oOpt" data-w="0"><b>🔒 ${T('احتفظي ببياناتي مشفّرة هنا')}</b><span>${T('لا يستطيع أحد فتحها غيركِ. دخولكِ القادم على هذا الجهاز أسرع ويعمل دون إنترنت.')}</span></button>
      <button class="oOpt del" data-w="1"><b>🗑 ${T(pending ? 'امسحي على أي حال' : 'امسحي بياناتي من هذا الجهاز')}</b><span>${T('مناسب لجهاز تستخدمينه مرة واحدة. تُنزَّل بياناتكِ من السحابة عند دخولكِ القادم.')}</span></button>
      <label class="oRem"><input type="checkbox" id="oRem"> ${T('تذكّري اختياري لهذا الجهاز')}</label>
      <div class="grow" style="justify-content:flex-end"><button class="gbtn sec" id="oCancel">${T('إلغاء')}</button></div></div>`;
    d.classList.add('on');
    $('#oCancel').onclick = () => d.classList.remove('on');
    d.querySelectorAll('.oOpt').forEach(b => b.onclick = async () => {
      d.querySelectorAll('button').forEach(x => x.disabled = true);
      const wipe = b.dataset.w === '1';
      const r = await api.authLogout({ wipe, remember: $('#oRem').checked, force: !!pending });
      if (r && !r.ok && r.pending) outDialog(s2, r.pending);
    });
  }
  $('#switchUser').onclick = logout;
  $('#lockSwitch').onclick = logout;
  // تعديلات وصلت من جهاز آخر أثناء العمل
  api.onCloudRemote(() => LP.toast(T('وصلت تحديثات من جهاز آخر'), T('تحديث'), () => api.authReload(), 12000));
  const unlock = async () => {
    const r = await LP_unlock($('#lockPin').value);
    if (!r.ok) { $('#lockErr').textContent = errMsg(r); $('#lockPin').value = ''; }
    else $('#lockErr').textContent = '';
  };
  $('#lockGo').onclick = unlock;
  $('#lockPin').addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') unlock(); });
})();
