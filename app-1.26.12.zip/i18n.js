// اللغات: العربية (الأصل) والإنجليزية والفرنسية.
// النص العربي هو المفتاح، والترجمات في dict-en / dict-fr.
(function (root) {
  const D = { en: {}, fr: {} };
  let lang = 'ar';
  const LANGS = ['ar', 'en', 'fr'];

  // صيغة المخاطبة (معلم/معلمة، بنين/بنات/مختلط) — في العربية فقط
  const G = () => (typeof module !== 'undefined' && module.exports ? (G._m ||= require('./gender')) : root.LPG);
  function t(s, vars, c) {
    let r = (lang !== 'ar' && D[lang] && D[lang][s]) || s;
    if (lang === 'ar' && G()) r = G().apply(s, r, c);
    if (vars) r = r.replace(/\{(\w+)\}/g, (m, k) => (vars[k] !== undefined ? vars[k] : m));
    return r;
  }
  // ترجمة بلغة محددة (مثل لغة العجلة المستقلة عن لغة البرنامج)
  function tl(l, s, vars, c) {
    let r = (l && l !== 'ar' && D[l] && D[l][s]) || s;
    if ((!l || l === 'ar') && G()) r = G().apply(s, r, c);
    if (vars) r = r.replace(/\{(\w+)\}/g, (m, k) => (vars[k] !== undefined ? vars[k] : m));
    return r;
  }
  function setLang(l) { lang = LANGS.includes(l) ? l : 'ar'; }
  const dir = () => (lang === 'ar' ? 'rtl' : 'ltr');

  // ترجمة عناصر الصفحة الثابتة (النصوص والتلميحات)
  const ATTRS = ['title', 'placeholder', 'data-tip', 'aria-label'];
  function translateDOM(rootEl) {
    if (typeof document === 'undefined') return;
    const g = G(), plain = lang === 'ar' && (!g || (g.ctx.tg === 'f' && g.ctx.cg === 'g'));
    const el = rootEl || document.body;
    const conv = (key) => (lang === 'ar' ? g.apply(key, key) : (D[lang][key] || null));
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode: (x) => (x.parentElement && x.parentElement.closest('[data-noconv]')) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    let n;
    while ((n = walker.nextNode())) {
      // نحفظ النص الأصلي حتى نعيد التحويل عند تغيّر الفصل أو صيغة المستخدم
      const raw = n.__lpo !== undefined ? n.__lpo : n.nodeValue, key = raw.trim();
      if (!key || !/[\u0600-\u06FF]/.test(key)) continue;
      if (plain) { if (n.__lpo !== undefined && n.nodeValue !== raw) n.nodeValue = raw; continue; }
      const tr = conv(key);
      if (tr && tr !== key) { if (n.__lpo === undefined) n.__lpo = raw; n.nodeValue = raw.replace(key, tr); }
      else if (n.__lpo !== undefined) n.nodeValue = raw;
    }
    el.querySelectorAll('*').forEach(e => {
      if (e.closest('[data-noconv]')) return;
      for (const a of ATTRS) {
        const ok = '__lpa_' + a, v0 = e[ok] !== undefined ? e[ok] : e.getAttribute(a);
        if (!v0 || !/[\u0600-\u06FF]/.test(v0)) continue;
        if (plain) { if (e[ok] !== undefined) e.setAttribute(a, v0); continue; }
        const tr = conv(v0.trim());
        if (tr && tr !== v0.trim()) { if (e[ok] === undefined) e[ok] = v0; e.setAttribute(a, tr); }
      }
    });
  }
  function add(l, obj) { Object.assign(D[l], obj); }

  const api = { t, tl, setLang, dir, translateDOM, add, LANGS, get lang() { return lang; }, D };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.I18N = api;
})(typeof window !== 'undefined' ? window : this);
