const { app, BrowserWindow, ipcMain, dialog, shell, desktopCapturer, globalShortcut, screen, session, Menu, powerMonitor } = require('electron');
const APPVER = require('./package.json').version;   // نسخة هذا المجلد (قد يعمل البرنامج من تحديث)
const path = require('path');
const fs = require('fs');
const store = require('./store');          // يحدد مجلد «بيانات» قبل أي شيء
const crypto = require('crypto');
const accounts = require('./accounts');
const I = require('./i18n'); require('./dict');
const T = (s, v) => I.t(s, v);
const { spawn } = require('child_process');
const { pathToFileURL, fileURLToPath } = require('url');

let win = null, floatWin = null, spotWin = null;
// تشغيل الصوت دون انتظار ضغطة (يلزم لتسجيل صوت الدرس والمؤقّت)
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
// أي خطأ غير متوقع يُسجَّل في «سجل-البرنامج.txt» بدل نافذة خطأ تُوقف المعلمة أثناء الحصة
process.on('uncaughtException', (e) => { try { log('uncaught: ' + (e && (e.stack || e.message) || e)); } catch {} });
process.on('unhandledRejection', (e) => { try { log('unhandled: ' + (e && (e.stack || e.message) || e)); } catch {} });
const isWin = process.platform === 'win32';
// نافذة شفافة في منطقة الدرس: يظهر من خلالها عرض باوربوينت الحقيقي (يمكن إيقافها من الإعدادات)
const TRANSP = isWin && (store.global.get().pptEmbed !== false);
// النوافذ الشفافة في ويندوز لا تُكبَّر بشكل صحيح، فنكبّرها بأنفسنا إلى مساحة العمل
let fakeMax = false, preMax = null;
const isMax = () => (TRANSP ? fakeMax : !!(win && win.isMaximized()));
function sendWinState() { if (win && !win.isDestroyed()) win.webContents.send('win-state', { maximized: isMax(), fullscreen: win.isFullScreen() }); }
function doMax() {
  if (!win) return;
  if (!TRANSP) { win.maximize(); return; }
  if (!fakeMax) preMax = win.getBounds();
  fakeMax = true; win.setBounds(screen.getDisplayMatching(win.getBounds()).workArea); sendWinState();
}
function unMax(restore) {
  if (!win) return;
  if (!TRANSP) { if (win.isMaximized()) win.unmaximize(); return; }
  if (!fakeMax) return;
  fakeMax = false; if (restore !== false && preMax) win.setBounds(preMax); preMax = null; sendWinState();
}
const RETURN_KEY = 'Control+Shift+Space';
const SPOT_KEY = 'Control+Alt+S';
const WHEEL_KEY = 'Control+Shift+G';
const SLOTS = 5;

// ======================================================================
// الإعدادات
// ======================================================================
// إعدادات المعلمة الحالية (لكل معلمة ملفها)
function readSettings() { const id = accounts.current(); return id ? store.profiles.get(id) : {}; }
function patchSettings(p) { const id = accounts.current(); if (id) store.profiles.patch(id, p); }
function applyLang() {
  I.setLang(accounts.state().lang);
  // صيغة المخاطبة لرسائل البرنامج (معلم / معلمة). شاشة الدخول تستخدم صيغة آخر مستخدم على هذا الجهاز
  let tg = store.global.get().lastTG === 'f' ? 'f' : 'm';   // غير معروف ← المذكر العام
  try { if (accounts.currentUser()) { tg = readSettings().teacherG === 'f' ? 'f' : 'm'; if (store.global.get().lastTG !== tg) store.global.patch({ lastTG: tg }); } } catch {}
  require('./gender').set({ tg });
}
applyLang();

// ======================================================================
// إظهار النافذة الرئيسية
// ======================================================================
function bringBack() {
  if (!win || win.isDestroyed()) return;
  if (mini) { win.webContents.send('mini:exit-req'); return; }
  if (win.isMinimized()) win.restore();
  win.show();
  win.setAlwaysOnTop(true);
  win.focus();
  win.moveTop();
  setTimeout(() => { if (win && !win.isDestroyed() && !win.isFullScreen()) win.setAlwaysOnTop(false); }, 250);
  if (floatWin && !floatWin.isDestroyed()) setTimeout(() => floatWin && !floatWin.isDestroyed() && floatWin.moveTop(), 300);
}

// ======================================================================
// النافذة الرئيسية
// ======================================================================
function createWindow() {
  win = new BrowserWindow({
    icon: path.join(__dirname, 'app.ico'),
    width: 1280,
    height: 800,
    minWidth: 640,
    minHeight: 420,
    frame: false,
    title: 'عارض الدروس',
    transparent: TRANSP,
    backgroundColor: TRANSP ? '#00000000' : '#1e1f24',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      backgroundThrottling: false        // حتى يستمر التسجيل والمؤقّت والبرنامج في الخلفية
    }
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'index.html'));
  win.once('ready-to-show', () => {
    doMax(); win.show();
    if (store.migratedFrom) {
      log('data migrated from ' + store.migratedFrom);
      dialog.showMessageBox(win, { type: 'info', buttons: [T('حسناً')], title: T('عارض الدروس'),
        message: T('نُقلت بياناتكِ من النسخة السابقة ✓'),
        detail: T('الحسابات والفصول والنقاط والدروس نُسخت من:') + '\n' + store.migratedFrom });
    }
    setTimeout(() => { if (floatWin && !floatWin.isDestroyed()) floatWin.showInactive(); }, 600);
  });

  const sendState = () => {
    if (!win || win.isDestroyed()) return;
    win.webContents.send('win-state', { maximized: isMax(), fullscreen: win.isFullScreen() });
  };
  ['maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen', 'resize'].forEach(e => win.on(e, sendState));
  win.on('focus', () => { lastFgPresenter = true; pushFloat(); if (shows.size) setTimeout(placeAll, 30); });
  win.on('moved', () => {
    if (!TRANSP || !fakeMax || mini || fullShow) return;
    const b = win.getBounds(), wa = screen.getDisplayMatching(b).workArea;
    if (Math.abs(b.x - wa.x) > 4 || Math.abs(b.y - wa.y) > 4 || Math.abs(b.width - wa.width) > 4) { fakeMax = false; preMax = null; sendWinState(); }
  });
  // نوافذ عروض باوربوينت تتبع البرنامج
  let placeT;
  const follow = () => { clearTimeout(placeT); placeT = setTimeout(placeAll, 60); };
  ['move', 'resize', 'maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen'].forEach(e => win.on(e, follow));
  win.on('minimize', () => { for (const sh of shows.values()) helperCall('show', sh.hwnd + ',6', 3000); });
  win.on('moved', () => { if (mini && Date.now() - mini.prog > 400) { const b = win.getBounds(); mini.anchor = { x: b.x, y: b.y }; patchSettings({ miniPos: mini.anchor }); } });
  // عند إرجاع البرنامج من شريط المهام: نرجع نافذة العرض المصغّرة (SW_RESTORE)، ثم نضعها مكانها ونتأكد مرة ثانية
  win.on('restore', () => {
    if (mini) return;
    for (const sh of shows.values()) helperCall('show', sh.hwnd + ',9', 3000);
    setTimeout(placeAll, 250); setTimeout(bringBack, 350);
    setTimeout(() => { if (!mini) { for (const sh of shows.values()) helperCall('show', sh.hwnd + ',4', 3000); placeAll(); } }, 1200);
  });
  win.on('closed', () => {
    win = null;
    if (floatWin && !floatWin.isDestroyed()) floatWin.destroy();
    if (spotWin && !spotWin.isDestroyed()) spotWin.destroy();
  });
  createFloat();
}

// ======================================================================
// مساعد ويندوز (PowerShell يبقى مفتوحاً للسرعة)
// ======================================================================
let helper = null, helperBuf = '', helperSeq = 0;
const pending = new Map();
function startHelper() {
  if (!isWin) return null;
  if (helper && !helper.killed && helper.exitCode === null) return helper;
  const script = path.join(__dirname, 'winhelper.ps1');
  helper = spawn('powershell.exe', ['-NoProfile', '-NoLogo', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], {
    windowsHide: true, stdio: ['pipe', 'pipe', 'pipe']
  });
  helperBuf = '';
  const started = Date.now();
  // سبب توقف المساعد يُكتب في سجل البرنامج (بدل أن يتعطل البرنامج كله)
  let errText = '';
  helper.stderr.setEncoding('utf8');
  helper.stderr.on('data', d => { if (errText.length < 2000) errText += d; });
  helper.stdout.setEncoding('utf8');
  helper.stdout.on('data', chunk => {
    helperBuf += chunk;
    let i;
    while ((i = helperBuf.indexOf('\n')) >= 0) {
      const line = helperBuf.slice(0, i).replace(/\r$/, '').replace(/^﻿/, '');
      helperBuf = helperBuf.slice(i + 1);
      const bar = line.indexOf('|');
      if (bar < 0) continue;
      const id = line.slice(0, bar), json = line.slice(bar + 1);
      const p = pending.get(id);
      if (!p) continue;
      pending.delete(id); clearTimeout(p.timer);
      try { p.resolve(JSON.parse(json)); } catch { p.resolve(null); }
    }
  });
  const h = helper;
  const fail = (why) => {
    if (helper !== h) return;
    for (const p of pending.values()) { clearTimeout(p.timer); p.resolve(null); } pending.clear(); helper = null;
    try { log(`helper stopped after ${Date.now() - started}ms: ${why || ''} ${errText.trim().slice(0, 600)}`); } catch {}
  };
  helper.on('exit', (code) => fail('exit ' + code));
  helper.on('error', (e) => fail('error ' + (e && e.message)));
  helper.stdin.on('error', (e) => fail('stdin ' + (e && e.code)));   // EPIPE: المساعد أُغلق — لا نُسقط البرنامج
  return helper;
}
function helperCall(cmd, arg = '', timeout = 20000) {
  return new Promise(resolve => {
    const h = startHelper();
    if (!h) return resolve(null);
    const id = String(++helperSeq);
    const timer = setTimeout(() => { pending.delete(id); resolve(null); }, timeout);
    pending.set(id, { resolve, timer });
    try { h.stdin.write(`${id}|${cmd}|${String(arg).replace(/[\r\n]/g, ' ')}\n`, 'utf8'); } catch { clearTimeout(timer); pending.delete(id); resolve(null); }
  });
}

// ======================================================================
// الأيقونات
// ======================================================================
const iconCache = new Map();
async function iconOf(file) {
  if (!file) return null;
  if (iconCache.has(file)) return iconCache.get(file);
  let url = null;
  try { const img = await app.getFileIcon(file, { size: 'large' }); if (!img.isEmpty()) url = img.toDataURL(); } catch {}
  iconCache.set(file, url);
  return url;
}

// ======================================================================
// تشغيل برنامج / الانتقال إلى نافذته
// ======================================================================
async function launch(a) {
  try {
    if (a.aumid) {
      spawn('explorer.exe', ['shell:AppsFolder\\' + a.aumid], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
      return true;
    }
    for (const f of [a.lnk, a.target, a.path]) {
      if (!f || !fs.existsSync(f)) continue;
      const err = await shell.openPath(f);
      if (err === '') return true;
      // طريقة بديلة إذا رفض ويندوز الطريقة الأولى
      try { spawn('cmd.exe', ['/c', 'start', '', f], { detached: true, stdio: 'ignore', windowsHide: true }).unref(); return true; } catch {}
    }
  } catch {}
  return false;
}
const focusHwnd = async (hwnd) => !!(hwnd && await helperCall('focus', String(hwnd), 5000));

// ======================================================================
// متابعة البرامج التي تستخدمها المعلمة (لآخر البرامج وللتنقل السريع)
// ======================================================================
const ownExe = process.execPath.toLowerCase();
const skipClasses = /^(Shell_TrayWnd|Shell_SecondaryTrayWnd|Progman|WorkerW|Windows\.UI\.Core\.CoreWindow|ForegroundStaging|MultitaskingViewFrame|XamlExplorerHostIslandWindow|TaskListThumbnailWnd|NotifyIconOverflowWindow|TopLevelWindowForOverflowXamlIsland|#32768)$/;
let recent = [];              // [{key, name, path, hwnd, title}]  الأحدث أولاً
let lastFgPresenter = true;   // هل كانت آخر نافذة أمامية هي برنامج الدروس؟
const descCache = new Map();

async function nameOf(p, title) {
  const base = path.basename(p).replace(/\.exe$/i, '');
  if (/^applicationframehost$/i.test(base)) return title;
  if (/^explorer$/i.test(base)) return T('مستكشف الملفات');
  if (!descCache.has(p)) {
    const d = await helperCall('desc', p, 4000);
    descCache.set(p, (typeof d === 'string' && d.trim()) ? d.trim() : base);
  }
  return descCache.get(p);
}

let polling = false;
async function pollForeground() {
  if (polling) return;
  polling = true;
  try { await pollForegroundInner(); } finally { polling = false; }
}
async function pollForegroundInner() {
  const r = await helperCall('fg', '', 3000);
  if (typeof r !== 'string' || !r) return;
  const [hwndS, p = '', title = '', cls = ''] = r.split('\t');
  const hwnd = Number(hwndS);
  if (!hwnd) return;
  const own = new Set();
  try { if (floatWin) own.add(Number(floatWin.getMediaSourceId().split(':')[1])); } catch {}
  try { if (spotWin) own.add(Number(spotWin.getMediaSourceId().split(':')[1])); } catch {}
  if (own.has(hwnd)) return;
  if (p.toLowerCase() === ownExe) {               // برنامج الدروس نفسه
    if (!lastFgPresenter) { lastFgPresenter = true; pushFloat(); }
    return;
  }
  if (!p || !title || skipClasses.test(cls)) return;
  if ([...shows.values()].some(sh => sh.hwnd === hwnd)) return;
  lastFgPresenter = false;
  let key = p.toLowerCase();
  if (/applicationframehost\.exe$/.test(key)) key += '|' + title;
  const existing = recent.find(x => x.key === key);
  if (existing && recent[0] === existing && existing.hwnd === hwnd) { existing.title = title; pushFloat(); return; }
  const entry = existing || { key, path: p, name: await nameOf(p, title) };
  entry.hwnd = hwnd; entry.title = title;
  recent = [entry, ...recent.filter(x => x !== entry)].slice(0, 15);
  assignSlots(); pushFloat();
}

async function pruneClosed() {
  if (!recent.length) return;
  const open = await helperCall('open', '', 5000);
  if (!Array.isArray(open)) return;
  const set = new Set(open.map(x => String(x).toLowerCase()));
  const before = recent.length;
  recent = recent.filter(r => set.has(r.path.toLowerCase()));
  if (recent.length !== before) { assignSlots(); pushFloat(); }
}

// ======================================================================
// الدوائر الخمس
// ======================================================================
function getSlots() {
  const s = readSettings().floatSlots;
  const arr = Array.isArray(s) ? s.slice(0, SLOTS) : [];
  while (arr.length < SLOTS) arr.push(null);
  return arr;
}
let slotRecent = new Array(SLOTS).fill(null);
// أدوات البرنامج التي يمكن تثبيتها في دوائر الزر العائم (تظهر فوق كل البرامج)
const FLOAT_TOOLS = { wheel: { name: 'العجلة', emoji: '🎡', color: '#f2662a' }, timer: { name: 'المؤقّت', emoji: '⏱', color: '#228be6' },
  goals: { name: 'درس اليوم', emoji: '🎯', color: '#2fb344' }, groups: { name: 'شريط المجموعات والنقاط', emoji: '👥', color: '#ae3ec9' } };
let toolsOut = [];     // مفتاح البرنامج الأخير المعروض في كل دائرة غير مثبتة

function pinMatchesRecent(p, r) {
  if (!p || !r || p.tool) return false;
  const rp = r.path.toLowerCase();
  const pp = (p.path || p.target || '').toLowerCase();
  if (pp && rp === pp) return true;
  if (p.aumid) { const pkg = p.aumid.split('!')[0].split('_')[0].toLowerCase(); if (pkg && rp.includes('\\windowsapps\\' + pkg + '_')) return true; }
  const n1 = (p.name || '').toLowerCase().replace(/^microsoft\s+/, '').trim();
  const n2 = (r.name || '').toLowerCase().replace(/^microsoft\s+/, '').trim();
  return n1 && n1 === n2;
}

function assignSlots() {
  const pins = getSlots();
  const avail = recent.filter(r => !pins.some(p => pinMatchesRecent(p, r)));
  const free = pins.map((p, i) => p ? -1 : i).filter(i => i >= 0);
  const wanted = avail.slice(0, free.length).map(r => r.key);
  // نحافظ على أماكن البرامج الموجودة، والجديد يأخذ مكان ما خرج
  for (let i = 0; i < SLOTS; i++) if (pins[i] || !wanted.includes(slotRecent[i])) slotRecent[i] = null;
  for (const k of wanted) {
    if (slotRecent.includes(k)) continue;
    const i = free.find(j => slotRecent[j] === null);
    if (i !== undefined) slotRecent[i] = k;
  }
}

async function slotView() {
  const pins = getSlots();
  const out = [];
  for (let i = 0; i < SLOTS; i++) {
    const p = pins[i];
    if (p && p.tool) {
      const d = FLOAT_TOOLS[p.tool] || {};
      out.push({ kind: 'tool', name: T(d.name || p.tool), emoji: d.emoji || '★', color: d.color || '#888', running: toolsOut.includes(p.tool) });
    } else if (p) {
      const running = recent.some(r => pinMatchesRecent(p, r));
      out.push({ kind: 'pinned', name: p.name, icon: await iconOf(p.lnk || p.target || p.path), running });
    } else if (slotRecent[i]) {
      const r = recent.find(x => x.key === slotRecent[i]);
      out.push(r ? { kind: 'recent', name: r.name, sub: r.title, icon: await iconOf(r.path), running: true } : { kind: 'empty' });
    } else out.push({ kind: 'empty' });
  }
  return out;
}

let pushT = null;
function pushFloat() {
  clearTimeout(pushT);
  pushT = setTimeout(async () => {
    if (!floatWin || floatWin.isDestroyed()) return;
    const last = recent[0];
    floatWin.webContents.send('float:state', {
      slots: await slotView(),
      presenterActive: lastFgPresenter,
      lastName: last ? last.name : '',
      lastIcon: last ? await iconOf(last.path) : null,
      recording: recState,
      spot: !!spotWin,
      accent: (readSettings().theme || {}).accent || '#f2662a',
      dir: I.dir(),
      txt: { empty: T('دائرة فارغة — اضغطي لاختيار أداة أو برنامج') }
    });
  }, 60);
}

async function openRecent(r) {
  if (await focusHwnd(r.hwnd)) { log('focused ' + r.name); return true; }
  const h = await helperCall('find', r.path, 4000);
  if (h && await focusHwnd(h)) { log('focused (find) ' + r.name); return true; }
  const ok = await launch({ path: r.path });
  log('launch ' + r.name + ' -> ' + ok);
  return ok;
}
async function openSlot(i) {
  const pins = getSlots();
  const p = pins[i];
  log('slot ' + i + ' ' + JSON.stringify(p || slotRecent[i] || null));
  if (p && p.tool) { toolSlot(p.tool); return; }
  if (p) {
    const r = recent.find(x => pinMatchesRecent(p, x));
    if (r && await focusHwnd(r.hwnd)) { log('focused ' + p.name); return; }
    const f = p.path || p.target;
    if (f) { const h = await helperCall('find', f, 4000); if (h && await focusHwnd(h)) { log('focused (find) ' + p.name); return; } }
    const ok = await launch(p);
    log('launch ' + p.name + ' -> ' + ok);
    return;
  }
  const r = recent.find(x => x.key === slotRecent[i]);
  if (r) { await openRecent(r); return; }
  slotMenu(i);
}
// أداة في دائرة: داخل البرنامج تظهر/تختفي في مكانها، وخارجه تظهر فوق كل البرامج
function toolSlot(k) {
  if (!win || win.isDestroyed()) return;
  const inApp = !mini && win.isVisible() && !win.isMinimized() && lastFgPresenter;
  log('tool slot ' + k + ' inApp=' + inApp);
  win.webContents.send('float:tool', { k, inApp });
}
ipcMain.on('win:front', () => bringBack());
ipcMain.on('float:tools-out', (_e, list) => { toolsOut = Array.isArray(list) ? list : []; pushFloat(); });
function pinTool(i, k) {
  const pins = getSlots();
  for (let j = 0; j < SLOTS; j++) if (j !== i && pins[j] && pins[j].tool === k) pins[j] = null;
  pins[i] = { tool: k, name: FLOAT_TOOLS[k].name };
  patchSettings({ floatSlots: pins });
  assignSlots(); pushFloat();
}
function slotMenu(i) {
  const pins = getSlots();
  const r = !pins[i] && slotRecent[i] ? recent.find(x => x.key === slotRecent[i]) : null;
  const items = [];
  if (r) items.push({ label: '📌 ' + T('تثبيت «{name}» في هذه الدائرة', { name: r.name }), click: () => pinSlot(i, { name: r.name, path: r.path }) });
  items.push({ label: T('أداة من البرنامج'), submenu: Object.entries(FLOAT_TOOLS).map(([k, d]) => ({ label: d.emoji + '  ' + T(d.name), type: 'radio', checked: !!(pins[i] && pins[i].tool === k), click: () => pinTool(i, k) })) });
  items.push({ label: T(pins[i] && !pins[i].tool ? 'تغيير البرنامج…' : 'برنامج من الجهاز…'), click: () => pickForSlot(i) });
  if (pins[i]) items.push({ type: 'separator' }, { label: T('إلغاء التثبيت'), click: () => unpinSlot(i) });
  Menu.buildFromTemplate(items).popup({ window: floatWin });
}

function pickForSlot(i) {
  bringBack();
  setTimeout(() => win && !win.isDestroyed() && win.webContents.send('pick-slot', i), 250);
}

async function pinSlot(i, a) {
  const pins = getSlots();
  let entry = { name: a.name || '', lnk: a.lnk || '', target: a.target || '', aumid: a.aumid || '', path: a.path || '' };
  if (!entry.name && entry.path) entry.name = await nameOf(entry.path, a.title || '');
  if (!entry.name) return false;
  // لا نكرر نفس البرنامج في دائرتين مثبتتين
  for (let j = 0; j < SLOTS; j++) if (j !== i && pins[j] && !pins[j].tool && String(pins[j].name || '').toLowerCase() === entry.name.toLowerCase()) pins[j] = null;
  pins[i] = entry;
  patchSettings({ floatSlots: pins });
  assignSlots(); pushFloat();
  return true;
}
function unpinSlot(i) {
  const pins = getSlots(); pins[i] = null;
  patchSettings({ floatSlots: pins });
  assignSlots(); pushFloat();
}

// ======================================================================
// الزر العائم: نافذة صغيرة بحجم الزر، تكبر فقط عند الوقوف عليها لإظهار الدوائر
// ======================================================================
const FS = 64, FW = 300, ANCHOR = 42;  // حجم الزر، وحجم النافذة عند ظهور الدوائر، وبعد الزر عن طرفها
let bubble = null;                      // مركز الزر على الشاشة
let expanded = false;

function clampBubble(cx, cy) {
  const d = screen.getDisplayNearestPoint({ x: Math.round(cx), y: Math.round(cy) }).workArea;
  return {
    x: Math.round(Math.min(Math.max(cx, d.x + 30), d.x + d.width - 30)),
    y: Math.round(Math.min(Math.max(cy, d.y + 30), d.y + d.height - 30)),
    wa: d
  };
}
let floatSize = FS;
function layoutFloat(save) {
  if (!floatWin || floatWin.isDestroyed() || !bubble) return;
  const c = clampBubble(bubble.x, bubble.y);
  bubble = { x: c.x, y: c.y };
  const left = c.x < c.wa.x + c.wa.width / 2, top = c.y < c.wa.y + c.wa.height / 2;
  const anchor = expanded ? { x: left ? ANCHOR : FW - ANCHOR, y: top ? ANCHOR : FW - ANCHOR } : { x: FS / 2, y: FS / 2 };
  floatSize = expanded ? FW : FS;
  // نحدد الحجم صراحةً في كل مرة (هذا يمنع مشكلة كِبر الزر عند سحبه)
  floatWin.setBounds({ x: c.x - anchor.x, y: c.y - anchor.y, width: floatSize, height: floatSize });
  floatWin.webContents.send('float:layout', { anchor, expanded });
  if (save) store.global.patch({ floatCenter: bubble });
}

function createFloat() {
  const wa = screen.getPrimaryDisplay().workArea;
  const gs = store.global.get();
  // مكانه الافتراضي في جهة العمود الجانبي (الساعة والعجلة)، ويبقى قابلاً للسحب
  const sideDefault = () => {
    let side = 'auto'; try { side = readSettings().dockSide || 'auto'; } catch {}
    const right = side === 'auto' ? I.dir() === 'rtl' : side === 'right';
    return { x: right ? wa.x + wa.width - 60 : wa.x + 60, y: wa.y + wa.height - 110 };
  };
  if (gs.floatCenter && gs.floatSide19) bubble = { ...gs.floatCenter };
  else { bubble = sideDefault(); store.global.patch({ floatSide19: 1, floatCenter: bubble }); }
  // لا نضع الزر فوق الشريط السفلي لبرنامج الدروس
  const d = screen.getDisplayNearestPoint(bubble).workArea;
  if (bubble.y > d.y + d.height - 80) bubble.y = d.y + d.height - 80;

  floatWin = new BrowserWindow({
    width: FS, height: FS, x: bubble.x - FS / 2, y: bubble.y - FS / 2,
    frame: false, transparent: true, resizable: false, movable: false,
    alwaysOnTop: true, skipTaskbar: true, show: false,
    hasShadow: false, minimizable: false, maximizable: false, fullscreenable: false,
    title: 'LP-float',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, backgroundThrottling: false }
  });
  floatWin.setAlwaysOnTop(true, 'screen-saver');
  floatWin.setVisibleOnAllWorkspaces(true);
  floatWin.loadFile(path.join(__dirname, 'float.html'));
  floatWin.webContents.on('did-finish-load', () => { layoutFloat(false); assignSlots(); pushFloat(); });
  // ويندوز قد يغيّر الحجم عند تغيّر تكبير الشاشة؛ نعيده فوراً
  floatWin.on('resize', () => {
    const bb = floatWin.getBounds();
    if (bb.width !== floatSize || bb.height !== floatSize) layoutFloat(false);
  });
  screen.on('display-metrics-changed', () => layoutFloat(false));
}

ipcMain.on('float:expand-req', (_e, v) => {
  v = !!v;
  if (v === expanded) return;
  expanded = v; layoutFloat(false);
});
ipcMain.on('float:drag-to', (_e, { x, y, end }) => {
  bubble = { x, y };
  if (expanded) expanded = false;
  layoutFloat(!!end);
});
ipcMain.on('float:click', () => floatClickAction());
async function floatClickAction() {
  // من الدروس → آخر برنامج ، ومن أي برنامج → الدروس
  const presenterFront = (win && !win.isDestroyed() && win.isFocused()) || lastFgPresenter;
  log('click bubble presenterFront=' + presenterFront + ' recent=' + (recent[0] ? recent[0].name : '-'));
  if (presenterFront && recent.length) {
    if (await openRecent(recent[0])) return;
  }
  if (presenterFront) { floatWin && floatWin.webContents.send('float:expand'); return; }
  bringBack();
}

// سجل بسيط لمساعدتنا إذا لم يعمل شيء على جهاز معين (في مجلد «بيانات»)
function log(msg) {
  try {
    const f = path.join(store.ROOT, 'سجل-البرنامج.txt');
    try { if (fs.statSync(f).size > 200000) fs.writeFileSync(f, ''); } catch {}
    fs.appendFileSync(f, new Date().toISOString() + ' ' + msg + '\n');
  } catch {}
}
ipcMain.on('float:slot', (_e, i) => openSlot(i));
ipcMain.on('float:slot-menu', (_e, i) => slotMenu(i));
ipcMain.on('float:bubble-menu', () => {
  const items = [
    { label: T('رجوع إلى الدروس'), click: bringBack },
    { label: T('كشّاف على كل الشاشة'), type: 'checkbox', checked: !!spotWin, click: () => toggleSpot() }
  ];
  if (recState) items.push({ type: 'separator' }, { label: '⏹ ' + T('إنهاء التسجيل وحفظه'), click: () => win && win.webContents.send('rec:stop-request') });
  Menu.buildFromTemplate(items).popup({ window: floatWin });
});

// ======================================================================
// الكشّاف على كل الشاشة
// ======================================================================
let spotTimer = null, spotWheelTimer = null, spotR = 170, spotDisplay = null, spotCtl = null;
ipcMain.on('gspot:size', (_e, d) => { spotR = Math.max(50, Math.min(700, spotR * (d > 0 ? 1.2 : 1 / 1.2))); });
function spotKeys(on) {
  const keys = { 'Escape': () => toggleSpot(false), 'Control+Alt+Up': () => { spotR = Math.min(600, spotR * 1.15); }, 'Control+Alt+Down': () => { spotR = Math.max(50, spotR / 1.15); } };
  for (const [k, fn] of Object.entries(keys)) {
    try { if (on) globalShortcut.register(k, fn); else globalShortcut.unregister(k); } catch {}
  }
}
function toggleSpot(force) {
  const on = force === undefined ? !spotWin : force;
  if (on && !spotWin) {
    const pt = screen.getCursorScreenPoint();
    spotDisplay = screen.getDisplayNearestPoint(pt);
    spotWin = new BrowserWindow({
      ...spotDisplay.bounds,
      frame: false, transparent: true, resizable: false, movable: false, focusable: false,
      alwaysOnTop: true, skipTaskbar: true, show: false, hasShadow: false, fullscreenable: false,
      minimizable: false, maximizable: false, enableLargerThanScreen: true,
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, backgroundThrottling: false }
    });
    spotWin.setAlwaysOnTop(true, 'screen-saver');
    spotWin.setIgnoreMouseEvents(true);
    spotWin.setVisibleOnAllWorkspaces(true);
    spotWin.loadFile(path.join(__dirname, 'spot.html'));
    spotWin.once('ready-to-show', () => {
      if (!spotWin) return;
      spotWin.showInactive();
      if (floatWin && !floatWin.isDestroyed()) floatWin.moveTop();
    });
    spotWin.on('closed', () => { spotWin = null; });
    spotTimer = setInterval(() => {
      if (!spotWin || spotWin.isDestroyed()) return;
      const p = screen.getCursorScreenPoint();
      const d = screen.getDisplayNearestPoint(p);
      if (!spotDisplay || d.id !== spotDisplay.id) { spotDisplay = d; spotWin.setBounds(d.bounds); }
      spotWin.webContents.send('spot:pos', { x: p.x - d.bounds.x, y: p.y - d.bounds.y, r: spotR });
    }, 16);
    spotKeys(true);
    // لوحة − و+ صغيرة في أعلى الشاشة لتغيير الحجم
    const wa = spotDisplay.workArea;
    spotCtl = new BrowserWindow({
      width: 200, height: 56, x: Math.round(wa.x + wa.width / 2 - 100), y: wa.y + 8,
      frame: false, transparent: true, resizable: false, alwaysOnTop: true, skipTaskbar: true, show: false, hasShadow: false,
      minimizable: false, maximizable: false, fullscreenable: false, title: 'LP-spotctl',
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true }
    });
    spotCtl.setAlwaysOnTop(true, 'screen-saver', 2);
    spotCtl.loadFile(path.join(__dirname, 'spotctl.html'));
    spotCtl.once('ready-to-show', () => spotCtl && spotCtl.showInactive());
    spotCtl.on('closed', () => { spotCtl = null; });
    // عجلة الفأرة / حركة الإصبعين تغيّر حجم الكشّاف (Shift + العجلة = تمرير الصفحة كالمعتاد)
    if (isWin) {
      helperCall('wheelstart', '', 4000);
      let busy = false;
      spotWheelTimer = setInterval(async () => {
        if (busy || !spotWin) return; busy = true;
        try {
          const d = await helperCall('wheeltake', '', 2000);
          if (typeof d === 'number' && d) spotR = Math.max(50, Math.min(700, spotR * Math.pow(1.12, d / 120)));
        } finally { busy = false; }
      }, 50);
    }
  } else if (!on && spotWin) {
    clearInterval(spotTimer); spotTimer = null;
    clearInterval(spotWheelTimer); spotWheelTimer = null;
    if (spotCtl && !spotCtl.isDestroyed()) spotCtl.destroy(); spotCtl = null;
    if (isWin) helperCall('wheelstop', '', 4000);
    spotKeys(false);
    const w = spotWin; spotWin = null;
    if (!w.isDestroyed()) w.destroy();
  }
  if (win && !win.isDestroyed()) win.webContents.send('gspot', !!spotWin);
  pushFloat();
}
ipcMain.on('gspot:toggle', () => toggleSpot());

// ======================================================================
// التسجيل
// ======================================================================
let recState = null;        // null أو { paused }
let recFile = null, recFd = null;
function videosDir() {
  let d;
  try { d = app.getPath('videos'); } catch { d = app.getPath('documents'); }
  const sub = path.join(d, T('تسجيلات الدروس'));
  try { fs.mkdirSync(sub, { recursive: true }); return sub; } catch { return d; }
}
const safeName = (n) => String(n || T('درس')).replace(/[\\/:*?"<>|\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || T('درس');
ipcMain.handle('rec:sources', async () => {
  const out = { window: null, screen: null };
  try { out.window = win.getMediaSourceId(); } catch {}
  try {
    const disp = screen.getDisplayMatching(win.getBounds());
    const srcs = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 } });
    const m = srcs.find(s => String(s.display_id) === String(disp.id)) || srcs[0];
    out.screen = m ? m.id : null;
  } catch {}
  return out;
});
// تسأل المعلمة أين تحفظ الفيديو في كل مرة
ipcMain.handle('rec:choose', async (_e, { name, ext }) => {
  const d = new Date();
  const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}.${String(d.getMinutes()).padStart(2, '0')}`;
  const r = await dialog.showSaveDialog(win, {
    title: T('أين تريدين حفظ الفيديو؟'),
    defaultPath: path.join(videosDir(), `${safeName(name)} - ${stamp}.${ext}`),
    filters: [{ name: T('فيديو'), extensions: [ext] }]
  });
  return r.canceled || !r.filePath ? null : r.filePath;
});
ipcMain.handle('rec:begin', (_e, file) => {
  recFile = file;
  try { recFd = fs.openSync(recFile, 'w'); } catch { recFd = null; recFile = null; return null; }
  recState = { paused: false }; pushFloat();
  return recFile;
});
ipcMain.handle('rec:chunk', (_e, buf) => {
  if (recFd === null) return false;
  try { fs.writeSync(recFd, Buffer.from(buf)); return true; } catch { return false; }
});
ipcMain.handle('rec:end', () => {
  const f = recFile;
  try { if (recFd !== null) fs.closeSync(recFd); } catch {}
  recFd = null; recFile = null; recState = null; pushFloat();
  return f;
});
ipcMain.on('rec:paused', (_e, p) => { if (recState) { recState.paused = !!p; pushFloat(); } });
ipcMain.on('rec:show', (_e, f) => { if (f) shell.showItemInFolder(f); });

// ======================================================================
// البرامج المفتوحة والمثبتة (لوحة البرامج)
// ======================================================================
const hiddenTitles = /^(Program Manager|Windows Input Experience|Microsoft Text Input Application|Settings|الإعدادات|NVIDIA GeForce Overlay|Task Switching|Start|Search|LP-float|LP-spot|LP-spotctl|LP-pop)$/i;
ipcMain.handle('apps:open-windows', async () => {
  let sources = [];
  try {
    sources = await desktopCapturer.getSources({ types: ['window'], thumbnailSize: { width: 360, height: 220 }, fetchWindowIcons: true });
  } catch { return { ok: false, windows: [] }; }
  const own = new Set();
  for (const w of [win, floatWin, spotWin]) { try { if (w) own.add(w.getMediaSourceId().split(':')[1]); } catch {} }
  const list = [];
  for (const s of sources) {
    const hwnd = (s.id.split(':')[1] || '');
    if (!s.name || own.has(hwnd) || hiddenTitles.test(s.name.trim())) continue;
    list.push({
      id: s.id, hwnd, title: s.name,
      thumb: s.thumbnail && !s.thumbnail.isEmpty() ? s.thumbnail.toDataURL() : null,
      icon: s.appIcon && !s.appIcon.isEmpty() ? s.appIcon.toDataURL() : null,
      path: ''
    });
  }
  if (isWin && list.length) {
    const paths = await helperCall('paths', list.map(w => w.hwnd).join(','), 8000);
    if (paths) list.forEach(w => { w.path = paths[w.hwnd] || ''; });
  }
  return { ok: true, windows: list.filter(w => w.path.toLowerCase() !== ownExe) };
});
ipcMain.handle('apps:focus', (_e, hwnd) => isWin ? focusHwnd(hwnd) : false);

let installedCache = null;
ipcMain.handle('apps:installed', async (_e, refresh) => {
  if (!isWin) return { ok: false, apps: [] };
  if (installedCache && !refresh) return { ok: true, apps: installedCache };
  const r = await helperCall('apps', '', 60000);
  if (!Array.isArray(r)) return { ok: false, apps: installedCache || [] };
  installedCache = r
    .filter(a => a && a.name)
    .map(a => ({ name: String(a.name), lnk: a.lnk || '', target: a.target || '', aumid: a.aumid || '' }))
    .sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  return { ok: true, apps: installedCache };
});
ipcMain.handle('apps:icon', (_e, file) => iconOf(file));
ipcMain.handle('apps:launch', (_e, a) => launch(a));
ipcMain.handle('apps:pin-slot', (_e, i, a) => pinSlot(i, a));

// ======================================================================
// باوربوينت: العرض الحقيقي يعمل خلف البرنامج، ونعرض بثاً منه داخل الدرس
// ======================================================================
const shows = new Map();          // id → { hwnd, rect }
let pptAvailable = null;
async function pptCheck() {
  if (!isWin) return false;
  if (pptAvailable === null) pptAvailable = !!(await helperCall('pptcheck', '', 8000));
  return pptAvailable;
}
function ownHwnd() {
  try { const b = win.getNativeWindowHandle(); return b.length >= 8 ? Number(b.readBigUInt64LE(0)) : b.readUInt32LE(0); } catch { return 0; }
}
// نضع نافذة العرض بنفس مكان منطقة الدرس وخلف البرنامج مباشرة
async function placeShow(id) {
  const sh = shows.get(id);
  if (!sh || !sh.rect || !win || win.isDestroyed()) return;
  if (win.isMinimized() || mini) return;
  const cb = win.getContentBounds();
  const dip = { x: Math.round(cb.x + sh.rect.x), y: Math.round(cb.y + sh.rect.y), width: Math.max(50, Math.round(sh.rect.width)), height: Math.max(50, Math.round(sh.rect.height)) };
  let px = dip;
  try { px = screen.dipToScreenRect(win, dip); } catch {}
  const ok = await helperCall('place', [sh.hwnd, px.x, px.y, px.width, px.height, ownHwnd()].join(','), 4000);
  if (!sh.logged) { sh.logged = true; log('ppt place hwnd=' + sh.hwnd + ' rect=' + JSON.stringify(px) + ' owner=' + ownHwnd() + ' ok=' + ok); }
}
// إذا صار باوربوينت هو النافذة النشطة (عند الضغط على الشريحة): لا نتصارع معه.
// ترتيب النوافذ تتكفل به «keep» أدناه بهدوء، وهنا فقط نعيد التركيز لبرنامجنا أحياناً (حتى تعمل اختصاراته)،
// بلا رفع فوق كل النوافذ وبلا إعادة وضع النافذة — كان هذا الصراع (مرتين في الثانية) سبب البطء.
let pptGuardBusy = false, refocusAt = 0, refocusTries = [], guardPauseUntil = 0, guardLogAt = 0, guardCount = 0;
setInterval(async () => {
  if (!isWin || !shows.size || pptGuardBusy || !win || win.isDestroyed() || win.isMinimized() || mini) return;
  const now = Date.now();
  if (now < guardPauseUntil || now - refocusAt < 2500) return;
  pptGuardBusy = true;
  try {
    const r = await helperCall('fg', '', 2000);
    const fg = typeof r === 'string' ? Number(r.split('\t')[0]) : 0;
    const p = typeof r === 'string' ? (r.split('\t')[1] || '').toLowerCase() : '';
    const isShow = [...shows.values()].some(sh => sh.hwnd === fg);
    if (isShow || /powerpnt\.exe$/.test(p)) {
      guardCount++;
      if (now - guardLogAt > 60000) { guardLogAt = now; log('ppt is the active window (x' + guardCount + ') → refocus presenter gently'); guardCount = 0; }
      refocusTries = refocusTries.filter(t => now - t < 15000); refocusTries.push(now);
      if (refocusTries.length > 4) { guardPauseUntil = now + 60000; refocusTries = []; log('ppt keeps the focus → leaving it for 60s'); return; }
      refocusAt = now;
      try { win.focus(); } catch {}
    }
  } finally { pptGuardBusy = false; }
}, 700);
const placeAll = () => { for (const id of shows.keys()) placeShow(id); };
// كل ثانية: نافذة العرض يجب أن تبقى ظاهرة وتحت البرنامج مباشرة (وإلا ظهر وورد أو غيره مكان الشريحة)
let keepBusy = false;
setInterval(async () => {
  if (!isWin || !shows.size || keepBusy || !win || win.isDestroyed() || win.isMinimized() || !win.isVisible() || mini) return;
  keepBusy = true;
  try {
    for (const [id, sh] of shows) {
      const r = await helperCall('keep', sh.hwnd + ',' + ownHwnd(), 2000);
      if (r === 2) { log('ppt window was hidden/minimized → restored'); await placeShow(id); }
      else if (r === 1) { sh.keepN = (sh.keepN || 0) + 1; if (!sh.keepAt || Date.now() - sh.keepAt > 60000) { sh.keepAt = Date.now(); log('ppt window order fixed (x' + sh.keepN + ')'); sh.keepN = 0; } }
    }
  } finally { keepBusy = false; }
}, 600);
// قلم باوربوينت نفسه (في وضع العرض الكامل): 1 سهم، 2 قلم، 5 ممحاة
ipcMain.handle('ppt:pointer', (_e, id, type, rgb) => shows.has(id) ? helperCall('pptpointer', id + ',' + type + ',' + (rgb === undefined || rgb === null ? '' : rgb), 4000) : null);
ipcMain.handle('ppt:erase', (_e, id) => shows.has(id) ? helperCall('ppterase', id, 4000) : null);
// وضع العرض الكامل: نافذة البرنامج تغطي الشاشة كلها (فوق شريط المهام) والعرض بملء الشاشة تحتها
let fullShow = null;
ipcMain.on('win:fullshow', (_e, on) => {
  if (!win || win.isDestroyed() || !TRANSP || mini) return;
  if (on && !fullShow) {
    fullShow = { bounds: win.getBounds(), max: fakeMax };
    const d = screen.getDisplayMatching(win.getBounds());
    win.setBounds(d.bounds);
    const wa = d.workArea, b = d.bounds;
    win.webContents.send('fs-inset', { top: wa.y - b.y, left: wa.x - b.x, right: (b.x + b.width) - (wa.x + wa.width), bottom: (b.y + b.height) - (wa.y + wa.height) });
    log('fullshow on ' + JSON.stringify(d.bounds) + ' work=' + JSON.stringify(wa));
  } else if (!on && fullShow) {
    const f = fullShow; fullShow = null;
    if (f.max) { fakeMax = false; doMax(); } else win.setBounds(f.bounds);
    log('fullshow off');
  }
  setTimeout(placeAll, 120);
});
ipcMain.handle('ppt:check', () => pptCheck());
ipcMain.handle('dialog:pick-folder', async () => {
  const r = await dialog.showOpenDialog(win, { title: T('اختاري مجلد العروض'), properties: ['openDirectory'] });
  return r.canceled || !r.filePaths[0] ? null : r.filePaths[0];
});
// هل نسمح بالوسائط الخارجية لهذا العرض؟ (حسب إعداد المعلمة)
function pptEnableMedia(file) {
  const p = readSettings(), mode = p.pptMedia || 'protect';
  if (mode === 'all') return true;
  if (mode !== 'folders') return false;
  const f = path.resolve(file).toLowerCase();
  return (p.pptFolders || []).some(d => { const dd = path.resolve(d).toLowerCase(); return f === dd || f.startsWith(dd.endsWith(path.sep) ? dd : dd + path.sep); });
}
ipcMain.handle('ppt:open', async (_e, file, rect) => {
  if (!(await pptCheck())) return { ok: false, err: 'noppt' };
  if (!TRANSP) { log('ppt embed off → slides as images'); return { ok: false, err: 'noembed' }; }
  const en = pptEnableMedia(file);
  log('ppt open ' + file + ' media=' + (en ? 'enable' : 'protect'));
  const r = await helperCall('pptopen', file + '|' + (en ? 1 : 0), 180000);
  log('ppt open result ' + JSON.stringify(r));
  if (!r || !r.hwnd) {
    // لم نجد نافذة العرض: نغلقه حتى لا يبقى نافذة منفصلة، ويعرض البرنامج البديل
    if (r && r.id) { log('ppt no window → closing show ' + r.id); await helperCall('pptclose', r.id, 8000); }
    return { ok: false, err: 'open' };
  }
  shows.set(r.id, { hwnd: r.hwnd, rect });
  await placeShow(r.id);
  setTimeout(bringBack, 150);
  setTimeout(() => placeShow(r.id), 600);
  setTimeout(() => { placeShow(r.id); bringBack(); }, 1500);
  // العرض الحقيقي يظهر من خلال منطقة شفافة في البرنامج (بدون تصوير)
  return { ok: true, id: r.id, count: r.count, name: r.name, embed: TRANSP };
});
ipcMain.handle('ppt:rect', (_e, id, rect) => { const sh = shows.get(id); if (sh) { sh.rect = rect; placeShow(id); } });
ipcMain.handle('ppt:cmd', async (_e, id, cmd, n) => {
  if (!shows.has(id)) return null;
  if (cmd === 'goto') return helperCall('pptgoto', id + ',' + n, 6000);
  return helperCall('ppt' + cmd, id, 6000);          // next / prev / first / state
});
// الشرائح كصور: تُحفظ في مجلد البرنامج (تُفتح فوراً في المرات القادمة)، وتُحوَّل تدريجياً — العرض يبدأ من أول شريحة جاهزة
const slideJobs = new Map();          // dir → { file, count, want: [], done: Set, running }
function slideCacheDir(file) {
  let st = {}; try { st = fs.statSync(file); } catch {}
  const h = crypto.createHash('md5').update(path.resolve(file).toLowerCase() + '|' + (st.mtimeMs || 0) + '|' + (st.size || 0)).digest('hex').slice(0, 16);
  return path.join(app.getPath('userData'), 'slides-cache', h);
}
function slidesDone(dir, count) { const d = new Set(); try { for (const f of fs.readdirSync(dir)) { const m = /^s(\d+)\.png$/.exec(f); if (m && +m[1] <= count) d.add(+m[1]); } } catch {} return d; }
function pruneSlideCache(keep) {
  try {
    const root = path.join(app.getPath('userData'), 'slides-cache');
    const dirs = fs.readdirSync(root).map(n => { const p = path.join(root, n); let t = 0; try { t = fs.statSync(path.join(p, 'meta.json')).mtimeMs; } catch {} return { p, t }; })
      .sort((a, b) => b.t - a.t);
    for (const d of dirs.slice(40)) if (d.p !== keep && !slideJobs.has(d.p)) fs.rmSync(d.p, { recursive: true, force: true });
  } catch {}
}
async function runSlideJob(dir) {
  const job = slideJobs.get(dir); if (!job || job.running) return;
  job.running = true; let errs = 0; const t0 = Date.now();
  try {
    for (;;) {
      let n = null;
      while (job.want.length) { const w = job.want.shift(); if (!job.done.has(w) && w >= 1 && w <= job.count) { n = w; break; } }
      if (n === null) for (let i = 1; i <= job.count; i++) if (!job.done.has(i)) { n = i; break; }
      if (n === null) break;
      const ok = await helperCall('pptxpart', dir + '|' + n, 60000);
      if (ok === true) { job.done.add(n); errs = 0; }
      else { errs++; log('slide export failed ' + n + ' ' + JSON.stringify(ok)); if (errs >= 3) break; job.done.add(n); job.failed = (job.failed || 0) + 1; }
      if (win && !win.isDestroyed()) win.webContents.send('ppt:slide-ready', { dir, n, done: job.done.size, count: job.count });
    }
  } finally {
    await helperCall('pptxclose', dir, 15000);
    log('slides ready ' + job.done.size + '/' + job.count + ' in ' + Math.round((Date.now() - t0) / 1000) + 's');
    slideJobs.delete(dir);
  }
}
ipcMain.handle('ppt:export', async (_e, file) => {
  if (!(await pptCheck())) return null;
  const dir = slideCacheDir(file);
  let meta = null; try { meta = JSON.parse(fs.readFileSync(path.join(dir, 'meta.json'), 'utf8')); } catch {}
  if (meta && meta.count) {
    const done = slidesDone(dir, meta.count);
    try { fs.utimesSync(path.join(dir, 'meta.json'), new Date(), new Date()); } catch {}
    if (done.size >= meta.count) { log('slides cached ' + dir); return { dir, count: meta.count, ready: [...done] }; }
  }
  if (slideJobs.has(dir)) { const j = slideJobs.get(dir); return { dir, count: j.count, ready: [...j.done] }; }
  log('slides export ' + file);
  const r = await helperCall('pptxopen', file + '|' + dir + '|' + (pptEnableMedia(file) ? 1 : 0), 180000);
  if (!r || !r.count) { log('slides open failed ' + JSON.stringify(r)); return r && r.err ? { err: r.err } : null; }
  try { fs.writeFileSync(path.join(dir, 'meta.json'), JSON.stringify({ count: r.count, file, w: r.w, h: r.h })); } catch {}
  const job = { file, count: r.count, want: [], done: slidesDone(dir, r.count), running: false };
  slideJobs.set(dir, job);
  // الشريحة الأولى قبل أن نبدأ العرض
  if (!job.done.has(1)) { const ok = await helperCall('pptxpart', dir + '|1', 60000); if (ok === true) job.done.add(1); }
  runSlideJob(dir);
  pruneSlideCache(dir);
  return { dir, count: r.count, ready: [...job.done] };
});
ipcMain.on('ppt:export-want', (_e, dir, n) => { const j = slideJobs.get(dir); if (j && !j.done.has(n)) { j.want.unshift(n, n + 1); } });
ipcMain.handle('ppt:close', async (_e, id) => { shows.delete(id); return helperCall('pptclose', id, 15000); });
async function closeAllShows() { for (const id of [...shows.keys()]) { shows.delete(id); await helperCall('pptclose', id, 8000); } }

// ======================================================================
// الروابط والملفات داخل الدروس
// ======================================================================
const docExt = /\.(pdf|pptx?|ppsx?)$/i;
app.on('web-contents-created', (_e, contents) => {
  if (contents.getType() === 'webview') {
    hookLogin(contents);
    contents.setWindowOpenHandler(({ url }) => {
      if (/^https?:|^file:/.test(url)) contents.loadURL(url);
      return { action: 'deny' };
    });
    // ملف PDF أو باوربوينت سُحب إلى داخل الدرس → نفتحه بعارضنا
    contents.on('will-navigate', (e, url) => {
      if (url.startsWith('file:') && docExt.test(decodeURIComponent(url.split('?')[0]))) {
        e.preventDefault();
        try { win.webContents.send('open-path', fileURLToPath(url)); } catch {}
      }
    });
  }
});
// كل جلسات المتصفح: السماح بالكاميرا والمايكروفون، وإظهار البرنامج كمتصفح Chrome عادي (لتسجيل دخول Google)
app.on('session-created', (ses) => {
  try {
    ses.setPermissionRequestHandler((_wc, perm, cb) => cb(['media', 'display-capture', 'fullscreen', 'clipboard-read', 'clipboard-sanitized-write', 'notifications', 'pointerLock'].includes(perm)));
    ses.setUserAgent(ses.getUserAgent().replace(/\s(Electron|lesson-presenter)\/\S+/gi, ''));
  } catch {}
});

// ======================================================================
// أوامر النافذة: تصغير، نصف الشاشة، ملء الشاشة
// ======================================================================
function layout(kind) {
  if (!win) return;
  if (win.isFullScreen()) win.setFullScreen(false);
  const wa = screen.getDisplayMatching(win.getBounds()).workArea;
  if (kind === 'max') { doMax(); return; }
  if (isMax()) unMax(false);
  let b;
  if (kind === 'center') {
    const w = Math.round(wa.width * 0.707), h = Math.round(wa.height * 0.707);
    b = { x: wa.x + Math.round((wa.width - w) / 2), y: wa.y + Math.round((wa.height - h) / 2), width: w, height: h };
  } else if (kind === 'right') b = { x: wa.x + Math.round(wa.width / 2), y: wa.y, width: Math.round(wa.width / 2), height: wa.height };
  else if (kind === 'left') b = { x: wa.x, y: wa.y, width: Math.round(wa.width / 2), height: wa.height };
  if (b) setTimeout(() => win && win.setBounds(b), 30);
}
// ---------- الوضع المصغّر: البطاقات العائمة فوق كل البرامج ----------
// النافذة نفسها تصغر إلى حجم البطاقات وتبقى فوق البرامج، فلا حاجة لمزامنة حالة بين نافذتين
let mini = null;
function clampMini(x, y, w, h) {
  const d = screen.getDisplayNearestPoint({ x: Math.round(x + w / 2), y: Math.round(y + 10) }).workArea;
  return { x: Math.max(d.x, Math.min(Math.round(x), d.x + d.width - w)), y: Math.max(d.y, Math.min(Math.round(y), d.y + d.height - h)), width: w, height: h };
}
ipcMain.handle('mini:enter', (_e, size) => {
  if (!win || win.isDestroyed()) return false;
  const w = Math.max(120, Math.ceil(size.w)), h = Math.max(60, Math.ceil(size.h));
  if (!mini) {
    mini = { bounds: TRANSP ? (fakeMax && preMax ? preMax : win.getBounds()) : win.getNormalBounds(), maximized: isMax(), fullscreen: win.isFullScreen() };
    for (const sh of shows.values()) helperCall('show', sh.hwnd + ',6', 3000);
    try { if (TRANSP) win.setShape([]); } catch {}
    if (mini.fullscreen) win.setFullScreen(false);
    if (mini.maximized) unMax(false);
  }
  const pos = readSettings().miniPos;
  const wa = screen.getDisplayMatching(win.getBounds()).workArea;
  const p0 = mini.anchor || pos;
  const x = p0 ? p0.x : wa.x + wa.width - w - 24, y = p0 ? p0.y : wa.y + 80;
  win.setMinimumSize(100, 50);
  win.setResizable(false);
  mini.anchor = { x, y }; mini.prog = Date.now();
  win.setBounds(clampMini(x, y, w, h));
  // نفس طبقة الزر العائم: لا يغطيها عرض باوربوينت ولا غيره
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true);
  win.show();
  return true;
});
ipcMain.on('mini:size', (_e, size) => {
  if (!mini || !win || win.isDestroyed()) return;
  const b = win.getBounds(), w = Math.max(120, Math.ceil(size.w)), h = Math.max(60, Math.ceil(size.h));
  if (b.width === w && b.height === h) return;
  // نبقي البطاقات في المكان الذي اختارته المعلمة، ونزيحها مؤقتاً فقط إذا كبرت عند حافة الشاشة
  const a = mini.anchor || b; mini.prog = Date.now();
  win.setBounds(clampMini(a.x, a.y, w, h));
  try { win.moveTop(); } catch {}
});
ipcMain.handle('mini:exit', () => {
  if (!mini || !win || win.isDestroyed()) return false;
  const m = mini; mini = null;
  win.setAlwaysOnTop(false);
  win.setVisibleOnAllWorkspaces(false);
  win.setResizable(true);
  win.setMinimumSize(640, 420);
  win.setBounds(m.bounds);
  if (m.maximized) doMax();
  if (m.fullscreen) win.setFullScreen(true);
  for (const sh of shows.values()) helperCall('show', sh.hwnd + ',9', 3000);
  setTimeout(() => { placeAll(); bringBack(); }, 250);
  return true;
});
ipcMain.handle('mini:state', () => !!mini);

// تمرير الفأرة إلى عرض باوربوينت من خلال المنطقة الشفافة
let ignoring = false;
ipcMain.on('win:ignore-mouse', (_e, v) => {
  if (!win || win.isDestroyed() || !TRANSP) return;
  v = !!v; if (v === ignoring) return; ignoring = v;
  win.setIgnoreMouseEvents(v, v ? { forward: true } : undefined);
});
// وضع الإطار: نقصّ مكان شريحة باوربوينت من نافذتنا (لا يبقى فوقها غطاء شفاف يُبطئ رسمها)
let shapeLogged = 0;
ipcMain.on('win:shape', (_e, rects) => {
  if (!win || win.isDestroyed() || !TRANSP) return;
  try {
    const R = mini || !Array.isArray(rects) ? [] : rects.filter(r => r && r.width > 0 && r.height > 0).map(r => ({ x: r.x | 0, y: r.y | 0, width: r.width | 0, height: r.height | 0 }));
    win.setShape(R);
    if (shapeLogged < 3) { shapeLogged++; log('frame shape ' + (R.length ? R.length + ' rects ' + JSON.stringify(R.slice(0, 4)) : 'full') + ' scale=' + screen.getDisplayMatching(win.getBounds()).scaleFactor); }
  } catch (e) { log('setShape failed: ' + e.message); }
});
ipcMain.handle('ppt:embed', () => isWin && store.global.get().pptEmbed !== false);
ipcMain.handle('ppt:set-embed', (_e, on) => { store.global.patch({ pptEmbed: !!on }); return true; });
ipcMain.on('win:minimize', () => win && win.minimize());
ipcMain.on('win:maximize', () => {
  if (!win) return;
  if (win.isFullScreen() || isMax()) layout('center'); else layout('max');
});
ipcMain.on('win:layout-menu', () => {
  Menu.buildFromTemplate([
    { label: '⬛ ' + T('وسط الشاشة'), click: () => layout('center') },
    { label: '◧ ' + T('النصف الأيمن'), click: () => layout('right') },
    { label: '◨ ' + T('النصف الأيسر'), click: () => layout('left') },
    { label: '⬜ ' + T('الشاشة كاملة'), click: () => layout('max') }
  ]).popup({ window: win });
});
ipcMain.on('win:layout', (_e, k) => layout(k));
ipcMain.on('win:fullscreen', () => win && win.setFullScreen(!win.isFullScreen()));
ipcMain.on('win:close', () => win && win.close());

ipcMain.handle('settings:get', () => readSettings());
ipcMain.handle('settings:set', (_e, patch) => { patchSettings(patch); if (patch && 'teacherG' in patch) applyLang(); return readSettings(); });
ipcMain.handle('gender:last', () => (store.global.get().lastTG === 'f' ? 'f' : 'm'));
ipcMain.handle('welcome-url', () => pathToFileURL(path.join(__dirname, 'welcome.html')).href + '?lang=' + I.lang + '&tg=' + require('./gender').ctx.tg);
ipcMain.handle('viewer-url', (_e, file) => pathToFileURL(path.join(__dirname, 'viewer', 'pdfviewer.html')).href + '?lang=' + I.lang + '&tg=' + require('./gender').ctx.tg + '&file=' + encodeURIComponent(pathToFileURL(file).href));
ipcMain.handle('platform', () => process.platform);

ipcMain.handle('open-file', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: T('اختاري ملف الدرس'),
    properties: ['openFile'],
    filters: [
      { name: T('دروس'), extensions: ['pdf', 'pptx', 'ppt', 'ppsx', 'pps', 'html', 'htm', 'png', 'jpg', 'jpeg', 'svg'] },
      { name: T('كل الملفات'), extensions: ['*'] }
    ]
  });
  if (r.canceled || !r.filePaths[0]) return null;
  return { path: r.filePaths[0], url: pathToFileURL(r.filePaths[0]).href };
});

ipcMain.handle('save-png', async (_e, dataUrl, name) => {
  const safe = name ? String(name).replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 80) : '';
  const r = await dialog.showSaveDialog(win, {
    title: T(safe ? 'حفظ الشهادة' : 'حفظ صورة الشاشة'),
    defaultPath: path.join(app.getPath('pictures'), safe ? `${safe}.png` : `${T('درس')}-${Date.now()}.png`),
    filters: [{ name: 'PNG', extensions: ['png'] }]
  });
  if (r.canceled || !r.filePath) return false;
  fs.writeFileSync(r.filePath, Buffer.from(dataUrl.split(',')[1], 'base64'));
  return true;
});

ipcMain.handle('capture', async () => {
  if (!win) return null;
  const img = await win.webContents.capturePage();
  return img.toDataURL();
});

// ======================================================================
// الحسابات
// ======================================================================
const reloadMain = () => { applyLang(); if (win && !win.isDestroyed()) win.reload(); pushFloat(); };
ipcMain.handle('auth:state', () => { const st = accounts.state(); const u = accounts.currentUser(); return { ...st, cloud: cloudState(), logoutChoice: u ? store.device.logoutChoice(u.id) : null, autoOutMin: store.global.get().autoOutMin ?? 30 }; });
ipcMain.handle('auth:logout-choice', (_e, v) => { const u = accounts.currentUser(); if (u) store.device.logoutChoice(u.id, v || null); return true; });
ipcMain.handle('auth:setup', (_e, d) => { if (store.users.all().length) return { ok: false }; cloudReset(); const r = accounts.create(d, true); if (r.ok) applyLang(); return r; });
ipcMain.handle('auth:create', (_e, d) => { cloudReset(); const r = accounts.create(d, false); if (r.ok) applyLang(); return r; });
ipcMain.handle('auth:login', async (_e, id, pin) => {
  cloudReset();
  let r = accounts.login(id, pin);
  if (r.nohash) {                       // دخلت هذا الجهاز بالباركود فقط: كلمة المرور تُتحقق من السحابة (تحتاج إنترنت)
    try {
      const S = await cloud.signIn(r.email, pin);
      const lk = await qrlogin.ensureLk().catch(() => null);
      r = accounts.cloudAttach({ uid: S.uid, email: S.email, name: S.name, password: pin, lk });
      if (!r.ok) { cloud.clear(); return r; }
      cloudPw = String(pin); applyLang(); afterCloud();
      await withTimeout(syncNow(true, false), 12000);
      await withTimeout(vaultAfterLogin(cloudPw), 8000);
      return { ok: true };
    } catch (e) { cloud.clear(); return cerr(e); }
  }
  if (r.ok) {
    applyLang(); const u = accounts.currentUser(); cloudPw = u && u.cloudPw ? String(pin) : null;
    const fresh = accounts.takeFresh();
    if (u && u.cloudUid) { await withTimeout(connectCurrent(fresh), 8000); await withTimeout(vaultAfterLogin(cloudPw), 8000); }
  }
  return r;
});
ipcMain.handle('auth:guest', () => { cloudReset(); accounts.guest(); applyLang(); return { ok: true }; });
ipcMain.handle('auth:unlock', (_e, pin) => accounts.unlock(pin));
// الخروج: نرفع ما لم يُرفع، ثم نحتفظ بالبيانات مشفّرة أو نمسحها من هذا الجهاز (حسب اختيار المعلمة)
async function doLogout(opts = {}) {
  await closeAllShows();
  const u = accounts.currentUser();
  let wipe = false;
  if (u && u.cloudUid && !store.device.isPersonal(u.id)) {
    if (opts.remember) store.device.logoutChoice(u.id, opts.wipe ? 'wipe' : 'keep');
    wipe = opts.wipe !== undefined ? !!opts.wipe : store.device.logoutChoice(u.id) === 'wipe';
  }
  const left = await sync.flush(wipe ? 10000 : 5000);
  if (wipe && left && !opts.force) return { ok: false, pending: left };
  qrlogin.stop(); rtStop();
  await withTimeout(vaultSave(), 6000); vault.end();
  if (wipe) await qrlogin.removeDevice();
  sync.stop(); cloudLogout(); await accounts.logout(wipe);
  reloadMain(); return { ok: true };
}
ipcMain.handle('auth:logout', (_e, opts) => doLogout(opts || {}));
ipcMain.handle('auth:reload', () => { reloadMain(); return true; });
ipcMain.handle('auth:forgot', (_e, email) => accounts.forgot(email));
ipcMain.handle('auth:reset', (_e, d) => { const r = accounts.resetWith(d); if (r.ok) applyLang(); return r; });
ipcMain.handle('me:change-pin', (_e, o, n) => accounts.changePin(o, n));
ipcMain.handle('me:update', (_e, d) => accounts.updateMe(d));
ipcMain.handle('me:personal', (_e, on) => { accounts.setPersonal(on); const u = accounts.currentUser(); if (u) { if (!on) accounts.cloudToken(u.id, null); else afterCloud(); } return accounts.state().personal; });
ipcMain.handle('me:signout-accounts', async () => { await accounts.signOutAccounts(); return true; });
ipcMain.handle('lang:set', (_e, l) => {
  if (!I.LANGS.includes(l)) return false;
  if (accounts.current()) patchSettings({ lang: l });
  else store.global.patch({ lang: l });
  reloadMain();
  return true;
});
ipcMain.handle('admin:users', () => accounts.adminUsers());
ipcMain.handle('admin:reset-pin', (_e, id, pin) => accounts.adminResetPin(id, pin));
ipcMain.handle('admin:delete', (_e, id) => accounts.adminDelete(id));
ipcMain.handle('admin:set-admin', (_e, id, on) => accounts.adminSetAdmin(id, on));
ipcMain.handle('admin:idle', (_e, m) => { accounts.adminSetIdle(m); return accounts.state().idleMin; });
ipcMain.handle('admin:auto-out', (_e, m) => { if (accounts.isAdmin()) store.global.patch({ autoOutMin: Math.max(0, Math.min(240, +m || 0)) }); return store.global.get().autoOutMin ?? 30; });
ipcMain.handle('admin:mailer', (_e, u, p) => accounts.adminSetMailer(u, p));
ipcMain.handle('admin:mailer-info', () => accounts.adminMailerInfo());
ipcMain.handle('admin:test-mail', () => accounts.adminTestMail());
ipcMain.handle('admin:backup', async () => {
  if (!accounts.isAdmin()) return null;
  const r = await dialog.showOpenDialog(win, { title: T('اختاري مكان النسخة الاحتياطية'), properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths[0]) return null;
  try { return store.backupTo(r.filePaths[0]); } catch { return false; }
});
ipcMain.handle('admin:restore', async () => {
  if (!accounts.isAdmin()) return null;
  const r = await dialog.showOpenDialog(win, { title: T('اختاري مجلد النسخة الاحتياطية'), properties: ['openDirectory'] });
  if (r.canceled || !r.filePaths[0]) return null;
  const ok = store.restoreFrom(r.filePaths[0]);
  if (ok) { await accounts.logout(); reloadMain(); }
  return ok;
});
ipcMain.handle('data:where', () => store.ROOT);
ipcMain.handle('app:version', () => APPVER);
const updater = require('./updater');
ipcMain.handle('upd:state', () => ({ ...updater.trialState(), ready: updater.getReady(), cfg: updater.hasConfig() }));
ipcMain.handle('upd:check', async () => { const r = await updater.check(); return { ...r, state: updater.trialState() }; });
ipcMain.handle('upd:restart', () => { app.relaunch(); app.exit(0); });
ipcMain.handle('upd:good', () => updater.markGood());

// القفل بعد مدة عدم الاستخدام (حسابات مايكروسوفت وGoogle فقط)
let idleSent = false, autoOutBusy = false;
setInterval(() => {
  if (!win || win.isDestroyed()) return;
  const cur = accounts.current();
  if (!cur || cur === 'guest') return;
  // الخروج التلقائي بعد مدة طويلة دون استخدام (ليس على «جهازي الشخصي»): تبقى البيانات مشفّرة
  const outMin = store.global.get().autoOutMin ?? 30;
  if (outMin > 0 && !autoOutBusy && !store.device.isPersonal(cur)) {
    let idl = 0; try { idl = powerMonitor.getSystemIdleTime(); } catch {}
    if (idl >= outMin * 60) { autoOutBusy = true; doLogout({ wipe: false }).finally(() => { autoOutBusy = false; }); return; }
  }
  const limit = (store.global.get().idleMin || 10) * 60;
  let idle = 0; try { idle = powerMonitor.getSystemIdleTime(); } catch {}
  if (idle >= limit && !idleSent) { idleSent = true; win.webContents.send('idle-lock'); }
  if (idle < 5) idleSent = false;
}, 5000);
try { powerMonitor.on('lock-screen', () => { if (win && accounts.current() && accounts.current() !== 'guest') win.webContents.send('idle-lock'); }); } catch {}


// ======================================================================
// الحساب السحابي (Firebase)
// ======================================================================
const cloud = require('./cloud');
const sync = require('./sync');
const qrlogin = require('./qrlogin');
const vault = require('./vault');
let cloudPw = null;            // كلمة مرور المعلمة الحالية في الذاكرة فقط (لإعادة الاتصال حين يعود الإنترنت)
let cloudErr = '';             // آخر سبب لتعذّر الاتصال
function cloudState() {
  const u = accounts.currentUser();
  const st = cloud.status();
  const mine = !!(u && u.cloudUid && st.connected && st.uid === u.cloudUid);
  return { configured: st.configured, googleReady: st.googleReady, linked: !!(u && u.cloudUid), google: !!(u && u.cloudUid && !u.cloudPw),
    connected: mine, verified: mine && st.verified, email: u ? (mine ? st.email : u.email) : '', err: mine ? '' : cloudErr, havePw: !!cloudPw,
    sync: sync.state(), qrReady: qrlogin.ready(), realtime: mine && rtOk };
}
sync.onChange(() => sendCloud());
// مزامنة الآن؛ إن وصلت تعديلات من جهاز آخر نخبر الواجهة
async function syncNow(full, notify) {
  try {
    const ch = await sync.run(full);
    if (notify && ch && ch.length && win && !win.isDestroyed()) win.webContents.send('cloud-remote', ch);
    // هل طلبت المعلمة من جوالها إخراج هذا الجهاز؟
    const rv = await qrlogin.checkRevoke();
    if (rv && accounts.currentUser()) { await qrlogin.removeDevice(); doLogout({ wipe: rv === 'wipe', force: true }); }
    return ch || [];
  } catch (e) { cloudErr = e.code || 'cfail'; sendCloud(); return []; }
}
function sendCloud() { if (win && !win.isDestroyed()) win.webContents.send('cloud-state', cloudState()); }
cloud.onChange(() => sendCloud());
function cloudReset() { sync.stop(); cloud.clear(); cloudPw = null; cloudErr = ''; }
function cloudLogout() {
  const u = accounts.currentUser();
  if (u && !store.device.isPersonal(u.id)) accounts.cloudToken(u.id, null);
  cloudReset();
}
// بعد نجاح الاتصال: نحفظ رمز التجديد مشفّراً على «جهازي الشخصي» فقط، ونحدّث ملف المعلمة في السحابة
function afterCloud() {
  const u = accounts.currentUser(), S = cloud.session();
  if (!u || !S || S.uid !== u.cloudUid) return;
  cloudErr = '';
  if (store.device.isPersonal(u.id)) { const t = cloud.seal(S.refreshToken); if (t) accounts.cloudToken(u.id, t); }
  cloud.touchProfile({ app: 'desktop', appVersion: APPVER });
  sync.start(u.id, u.cloudUid);
  vault.begin(u.id, u.cloudUid);
  qrlogin.ensureLk().then(lk => { if (lk && accounts.currentUser() === u) accounts.addQrWrap(lk); }).catch(() => {});
  qrlogin.registerDevice(store.device.isPersonal(u.id));
  rtStart();
  sendCloud();
}
// ---------- الاستماع الفوري (يعمل في الواجهة بأداة Firebase الرسمية) ----------
let rtOk = false, rtT = null, rtWhy = '';
function rtStart() {
  const u = accounts.currentUser(), S = cloud.session();
  if (!win || win.isDestroyed() || !u || !S || S.uid !== u.cloudUid) return;
  let C = {}; try { C = require('./cloud-config.json'); } catch {}
  win.webContents.send('rt', { start: { uid: S.uid, email: S.email, verified: S.verified, idToken: S.idToken, refreshToken: S.refreshToken, exp: S.exp,
    apiKey: C.apiKey, authDomain: C.authDomain, projectId: C.projectId, appId: C.appId, devId: store.device.id() } });
}
// ---------- خزنة الحسابات: فتحها بعد الدخول، وإعادة دخولات مايكروسوفت وقوقل قبل فتح الدروس ----------
const withTimeout = (p, ms) => Promise.race([p, new Promise(r => setTimeout(r, ms))]);
async function vaultAfterLogin(password, vk) {
  const u = accounts.currentUser(); if (!u || !u.cloudUid || !cloud.session()) return;
  try {
    vault.begin(u.id, u.cloudUid);
    if (vk) vault.setVk(vk);
    if (password) await vault.openWithPassword(password); else await vault.pullPasswords();
    if (vault.ready()) { const n = await vault.restoreSession(accounts.partitionOf(u.id)); if (n) log('vault: restored ' + n + ' cookies'); }
  } catch (e) { log('vault: ' + (e && e.message)); }
}
async function vaultSave() {
  const u = accounts.currentUser();
  if (!u || !u.cloudUid || !vault.ready()) return;
  try { await vault.saveSession(accounts.partitionOf(u.id)); } catch (e) { log('vault save: ' + (e && e.message)); }
}
function rtStop() { rtOk = false; if (win && !win.isDestroyed()) win.webContents.send('rt', { stop: true }); }
ipcMain.handle('rt:ready', () => { rtStart(); return true; });
ipcMain.on('rt:event', (_e, m) => {
  if (!m || !accounts.currentUser()) return;
  if (m.type === 'state') { rtOk = !!m.ok; if (!m.ok && m.why !== rtWhy) { rtWhy = m.why; log('realtime off: ' + m.why); } sendCloud(); return; }
  if (m.type === 'meta' && !m.local && sync.hasNewer(m.ts)) { clearTimeout(rtT); rtT = setTimeout(() => syncNow(false, true), 1500); return; }
  if (m.type === 'revoke') { qrlogin.removeDevice(); doLogout({ wipe: m.how === 'wipe', force: true }); }
});
let connecting = false;
async function connectCurrent(full) {
  const u = accounts.currentUser();
  if (!u || !u.cloudUid || connecting || !cloud.configured()) return sendCloud();
  if (cloudState().connected) return syncNow(full, false);
  connecting = true;
  try {
    const tok = cloud.unseal(accounts.cloudToken(u.id));
    let ok = false;
    if (tok) { try { const S = await cloud.resume(tok); ok = S.uid === u.cloudUid; if (!ok) cloud.clear(); } catch (e) { if (e.code !== 'net') accounts.cloudToken(u.id, null); cloudErr = e.code; } }
    if (!ok && cloudPw && u.email) {
      try { const S = await cloud.signIn(u.email, cloudPw); ok = S.uid === u.cloudUid; if (!ok) { cloud.clear(); cloudErr = 'ctaken'; } }
      catch (e) { cloudErr = e.code; if (e.code === 'cwrong') cloudPw = null; }   // تغيّرت كلمة المرور من مكان آخر
    }
    if (ok) { afterCloud(); await syncNow(full, !full && connectCurrent.loaded); }
  } finally { connecting = false; sendCloud(); }
}
// كل دقيقتين: اتصال إن انقطع، ومزامنة إن كان متصلاً (مع الاستماع الفوري: كل 10 دقائق احتياطاً فقط)
let tickN = 0;
setInterval(() => {
  if (!accounts.currentUser()) return;
  tickN++;
  if (!cloudState().connected) { connectCurrent.loaded = true; connectCurrent(); }
  else { if (!rtOk || tickN % 5 === 0) syncNow(false, true); vaultSave(); }
}, 2 * 60 * 1000);
const cerr = (e) => ({ ok: false, err: (e && e.code) || 'cfail' });
const GOOGLE_DONE = `<!doctype html><meta charset="utf-8"><title>OK</title><body style="font-family:Tahoma,Arial;text-align:center;padding:60px;background:#fff8f0">
  <h2 style="color:#2fb344">✓</h2><h3>تم تسجيل الدخول — ارجعي إلى برنامج عارض الدروس</h3><p>You can close this tab.</p></body>`;

ipcMain.handle('cloud:state', () => cloudState());
// ---------- الدخول بالباركود ----------
let pendingQr = null;
const qrSend = (ch, d) => { if (win && !win.isDestroyed()) win.webContents.send(ch, d); };
async function finishQr(r) {
  const vk = pendingQr && pendingQr.vk;
  pendingQr = null; cloudPw = null; applyLang(); afterCloud();
  await withTimeout(syncNow(true, false), 12000);
  await withTimeout(vaultAfterLogin(null, vk), 8000);
  if (win && !win.isDestroyed()) { win.show(); win.focus(); }
  qrSend('qr-done', { ok: true });
}
async function onQrPayload(data, sid) {
  cloudReset();
  try { const S = await cloud.resume(data.rt); if (S.uid !== data.uid) throw new cloud.CloudErr('ctaken'); }
  catch (e) { cloud.clear(); return qrSend('qr-done', cerr(e)); }
  qrlogin.removeQr(sid);
  pendingQr = data;
  const r = accounts.qrAttach(data);
  if (!r.ok) { if (!r.need) { cloud.clear(); pendingQr = null; } return qrSend('qr-done', r); }
  finishQr(r);
}
ipcMain.handle('qr:start', () => {
  if (!qrlogin.ready() || accounts.current()) return { ok: false };
  const r = qrlogin.start(onQrPayload, () => qrSend('qr-expired'));
  return { ok: true, ...r };
});
ipcMain.handle('qr:stop', () => { qrlogin.stop(); return true; });
ipcMain.handle('qr:link', (_e, linkPin) => {
  if (!pendingQr) return { ok: false, err: 'cexpired' };
  const r = accounts.qrAttach({ ...pendingQr, linkPin });
  if (r.ok) finishQr(r);
  return r.ok ? { ok: true, wait: true } : r;
});

ipcMain.handle('auth:cloud-signin', async (_e, d) => {
  cloudPw = null;
  let S; try { S = await cloud.signIn(d.email, d.password); } catch (e) { return cerr(e); }
  const lk = await qrlogin.ensureLk().catch(() => null);
  const r = accounts.cloudAttach({ uid: S.uid, email: S.email, name: S.name, password: d.password, linkPin: d.linkPin, lk });
  if (!r.ok) { if (!r.need) cloud.clear(); return r; }
  cloudPw = String(d.password); applyLang(); afterCloud();
  await withTimeout(syncNow(true, false), 12000);
  await withTimeout(vaultAfterLogin(cloudPw), 8000);
  return { ok: true };
});
ipcMain.handle('auth:cloud-signup', async (_e, d) => {
  if (String(d.password || '').length < 6) return { ok: false, err: 'cweak' };
  let S; try { S = await cloud.signUp(d.name, d.email, d.password); } catch (e) { return cerr(e); }
  const r = accounts.cloudAttach({ uid: S.uid, email: S.email, name: d.name, password: d.password });
  if (!r.ok) { if (!r.need) cloud.clear(); return r; }
  cloudPw = String(d.password); applyLang(); afterCloud();
  await withTimeout(syncNow(true, false), 12000);
  await withTimeout(vaultAfterLogin(cloudPw), 8000);
  return { ok: true };
});
ipcMain.handle('auth:cloud-forgot', async (_e, email) => { try { await cloud.sendReset(email); return { ok: true }; } catch (e) { return cerr(e); } });
// Google: أول نداء يفتح المتصفح، والنداءات التالية (رمز الربط أو رمز الجهاز) تكمل بنفس الجلسة
ipcMain.handle('auth:cloud-google', async (_e, d = {}) => {
  let S = cloud.session();
  if (!d.again || !S) { cloudPw = null; try { S = await cloud.googleSignIn(GOOGLE_DONE); } catch (e) { return cerr(e); } }
  if (win && !win.isDestroyed()) { win.show(); win.focus(); }
  const r = accounts.cloudAttach({ uid: S.uid, email: S.email, name: S.name, linkPin: d.linkPin, pin: d.pin });
  if (!r.ok) { if (!r.need) cloud.clear(); return r; }
  applyLang(); afterCloud();
  await Promise.race([syncNow(true, false), new Promise(res => setTimeout(res, 12000))]);
  return { ok: true };
});
// ربط حساب هذا الجهاز بحساب سحابي (جديد أو موجود)
ipcMain.handle('cloud:link', async (_e, d) => {
  const u = accounts.currentUser(); if (!u) return { ok: false };
  let S;
  try {
    if (d.mode === 'new') { if (String(d.password || '').length < 6) return { ok: false, err: 'cweak' }; S = await cloud.signUp(u.name, d.email, d.password); }
    else if (d.mode === 'google') S = await cloud.googleSignIn(GOOGLE_DONE);
    else S = await cloud.signIn(d.email, d.password);
  } catch (e) { return cerr(e); }
  if (win && !win.isDestroyed()) win.focus();
  const r = accounts.linkCurrent(S.uid, S.email, d.mode === 'google' ? null : d.password);
  if (!r.ok) { cloud.clear(); return r; }
  cloudPw = d.mode === 'google' ? null : String(d.password); afterCloud();
  const ch = await syncNow(false, false);
  await withTimeout(vaultAfterLogin(cloudPw), 8000);
  return { ok: true, changed: ch.length };
});
// إعادة الاتصال يدوياً (مثلاً بعد تغيير كلمة المرور من جهاز آخر)
ipcMain.handle('cloud:connect', async (_e, password) => {
  const u = accounts.currentUser(); if (!u || !u.cloudUid) return { ok: false };
  let S;
  try { S = u.cloudPw ? await cloud.signIn(u.email, password) : await cloud.googleSignIn(GOOGLE_DONE); } catch (e) { cloudErr = e.code; sendCloud(); return cerr(e); }
  if (win && !win.isDestroyed()) win.focus();
  if (S.uid !== u.cloudUid) { cloud.clear(); return { ok: false, err: 'ctaken' }; }
  if (u.cloudPw) { accounts.linkCurrent(S.uid, null, password); cloudPw = String(password); }
  afterCloud(); syncNow(false, true); if (u.cloudPw) vaultAfterLogin(password); return { ok: true };
});
ipcMain.handle('cloud:sync', async () => { if (!cloudState().connected) { await connectCurrent(); return cloudState(); } await syncNow(false, true); return cloudState(); });
ipcMain.handle('cloud:verify', async () => { try { await cloud.sendVerify(); return { ok: true }; } catch (e) { return cerr(e); } });
ipcMain.handle('cloud:refresh', async () => { await cloud.lookup(); return cloudState(); });


// ---------- خزنة الحسابات: الواجهة ----------
ipcMain.handle('vault:state', () => ({ ready: vault.ready(), enabled: vault.enabled(), items: vault.list() }));
ipcMain.handle('vault:forget', async (_e, site, user) => { await vault.forget(site, user); return vault.list(); });
ipcMain.handle('vault:wipe', async () => { await vault.wipeCloud(); return true; });
ipcMain.handle('vault:save-now', async () => { await vaultSave(); return true; });
const offers = new Map(); let offerSeq = 0;
ipcMain.handle('vault:accept', async (_e, id) => { const o = offers.get(id); offers.delete(id); if (!o) return false; return vault.savePassword(o.site, o.u, o.p); });
// التعبئة التلقائية والتقاط كلمات المرور في صفحات دخول مايكروسوفت وقوقل فقط
const LOGIN_SITES = [['microsoft', /^(login\.microsoftonline\.com|login\.live\.com|login\.microsoft\.com)$/i], ['google', /^accounts\.google\.com$/i]];
const siteOf = (url) => { try { const h = new URL(url).hostname; const m = LOGIN_SITES.find(([, r]) => r.test(h)); return m ? m[0] : null; } catch { return null; } };
const FILL = (c, site) => `(function(c,site){
  if (window.__lpFill) { window.__lpFill.c = c; window.__lpFill.scan && window.__lpFill.scan(); return; }
  const st = window.__lpFill = { c, u: '', p: '' };
  const setv = (el, v) => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const vis = (el) => el && el.offsetParent !== null && !el.disabled && !el.readOnly;
  let rt; const report = () => { clearTimeout(rt); rt = setTimeout(() => { if (st.u && st.p) console.log('__LPCRED__' + JSON.stringify({ site, u: st.u, p: st.p })); }, 500); };
  st.scan = () => {
    document.querySelectorAll('input[type=email],input[name=loginfmt],input#identifierId,input[name=identifier],input[autocomplete=username]').forEach(el => {
      if (!vis(el)) return;
      if (!el.__lpw) { el.__lpw = 1; el.addEventListener('input', () => { st.u = el.value.trim(); report(); }); }
      if (st.c && !el.value) { setv(el, st.c.user); }
      if (el.value) st.u = el.value.trim();
    });
    if (!st.u) { const dn = document.querySelector('#displayName,[data-email],#profileIdentifier,[data-profile-identifier]'); if (dn) st.u = (dn.getAttribute('data-email') || dn.textContent || '').trim(); }
    document.querySelectorAll('input[type=password]').forEach(el => {
      if (!vis(el)) return;
      if (!el.__lpw) { el.__lpw = 1; el.addEventListener('input', () => { st.p = el.value; report(); }); }
      if (st.c && !el.value && (!st.u || st.u.toLowerCase() === st.c.user.toLowerCase())) { setv(el, st.c.pass); st.p = st.c.pass; }
    });
  };
  new MutationObserver(() => st.scan()).observe(document.documentElement, { childList: true, subtree: true });
  st.scan();
})(${JSON.stringify(c)}, ${JSON.stringify(site)})`;
function hookLogin(contents) {
  let last = null;
  const inject = () => {
    const site = siteOf(contents.getURL()); if (!site || !accounts.currentUser()) return;
    const c = vault.credsFor(site);
    contents.executeJavaScript(FILL(c ? { user: c.user, pass: c.pass } : null, site)).catch(() => {});
  };
  const offer = () => {
    if (!last || !vault.ready() || !vault.enabled()) { last = null; return; }
    const o = last; last = null;
    if (vault.known(o.site, o.u, o.p)) return;
    const id = String(++offerSeq); offers.set(id, o); setTimeout(() => offers.delete(id), 120000);
    if (win && !win.isDestroyed()) win.webContents.send('vault-offer', { id, site: o.site, user: o.u });
  };
  contents.on('console-message', (_e, _lvl, msg) => {
    if (typeof msg !== 'string' || !msg.startsWith('__LPCRED__') || !siteOf(contents.getURL())) return;
    try { const o = JSON.parse(msg.slice(10)); if (o.u && o.p) last = o; } catch {}
  });
  contents.on('dom-ready', inject);
  contents.on('did-navigate-in-page', inject);
  contents.on('did-navigate', () => { if (!siteOf(contents.getURL())) offer(); });
  contents.on('did-start-navigation', (_e, url, inPage, isMain) => { if (isMain && !inPage && last && !siteOf(url)) setTimeout(offer, 300); });
}


// ======================================================================
// تصدير بياناتي واستيرادها (ملف .lpdata يُنقل إلى أي حساب) + إعادة ربط ملفات الدروس
// ======================================================================
const PARTS = {
  classes: ['classes', 'classIdx'],
  library: ['library', 'mySubject', 'lastSubject', 'lastGrade'],
  points: ['grp', 'lessonNow', 'yearArchive'],
  settings: null            // الباقي (عدا ما يخص هذا الجهاز والحقول الداخلية)
};
const DEVICE_KEYS = /^_|Pos$|^floatSlots$|^pptFolders$|^goalsSize$|^miniPos$|^favApps$|^dockScale$/;
const xenc = (pw, obj) => {
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12), it = 310000;
  const key = crypto.pbkdf2Sync(String(pw), salt, it, 32, 'sha256'), c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const d = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final(), c.getAuthTag()]);
  return { s: salt.toString('base64'), it, iv: iv.toString('base64'), d: d.toString('base64') };
};
const xdec = (pw, e) => {
  const key = crypto.pbkdf2Sync(String(pw), Buffer.from(e.s, 'base64'), e.it, 32, 'sha256'), raw = Buffer.from(e.d, 'base64');
  const c = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64')); c.setAuthTag(raw.subarray(raw.length - 16));
  return JSON.parse(Buffer.concat([c.update(raw.subarray(0, raw.length - 16)), c.final()]).toString('utf8'));
};
function summarize(parts) {
  const cl = (parts.classes && parts.classes.classes) || [];
  return {
    classes: cl.length, students: cl.reduce((n, c) => n + ((c.students || []).filter(Boolean).length), 0),
    lessons: ((parts.library && parts.library.library) || []).length,
    points: !!(parts.points && parts.points.grp && Object.keys(parts.points.grp).length),
    settings: !!(parts.settings && Object.keys(parts.settings).length)
  };
}
// ملف إكسل (.xlsx) من البرنامج: أوراق وصفوف
ipcMain.handle('xlsx:save', async (_e, sheets, o = {}) => {
  try {
    const fname = String(o.name || 'report').replace(/[\\/:*?"<>|]/g, '-') + '.xlsx';
    const r = o.dir ? { filePath: path.join(o.dir, fname) } : await dialog.showSaveDialog(win, { title: T('حفظ ملف إكسل'), defaultPath: path.join(app.getPath('documents'), fname), filters: [{ name: 'Excel', extensions: ['xlsx'] }] });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    fs.writeFileSync(r.filePath, require('./xlsx').build(sheets, o.rtl !== false && I.dir() === 'rtl'));
    if (!o.dir) shell.showItemInFolder(r.filePath);
    return { ok: true, file: r.filePath };
  } catch (e) { log('xlsx failed ' + e.message); return { ok: false, err: e.message }; }
});
ipcMain.handle('dialog:pick-dir', async (_e, title) => {
  const r = await dialog.showOpenDialog(win, { title: title || T('اختاري مجلداً'), defaultPath: app.getPath('documents'), properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths[0] ? null : r.filePaths[0];
});
ipcMain.handle('shell:show', (_e, f) => { try { shell.showItemInFolder(f); } catch {} });
ipcMain.handle('data:export', async (_e, o = {}) => {
  const id = accounts.current(); if (!id || id === 'guest') return { ok: false };
  const p = store.profiles.get(id), want = o.parts || Object.keys(PARTS), out = {};
  const used = new Set(Object.values(PARTS).filter(Boolean).flat());
  for (const k of want) {
    if (!(k in PARTS)) continue;
    const keys = PARTS[k] || Object.keys(p).filter(x => !used.has(x) && !DEVICE_KEYS.test(x));
    out[k] = Object.fromEntries(keys.filter(x => p[x] !== undefined).map(x => [x, p[x]]));
  }
  const u = accounts.currentUser();
  const body = { parts: out, from: u ? u.name : '', exportedAt: Date.now() };
  const file = { format: 'lessonpresenter-data', v: 1, ...(o.password ? { enc: xenc(o.password, body) } : body) };
  const day = new Date().toISOString().slice(0, 10);
  const fname = (o.name || `${T('بياناتي')}-${day}`).replace(/[\\/:*?"<>|]/g, '-') + '.lpdata';
  const r = process.env.LP_TEST_FILE ? { filePath: process.env.LP_TEST_FILE } : o.dir ? { filePath: path.join(o.dir, fname) } : await dialog.showSaveDialog(win, { title: T('حفظ نسخة من بياناتي'), defaultPath: path.join(app.getPath('documents'), fname), filters: [{ name: T('بيانات عارض الدروس'), extensions: ['lpdata'] }] });
  if (r.canceled || !r.filePath) return { ok: false, canceled: true };
  try { fs.writeFileSync(r.filePath, JSON.stringify(file)); if (!process.env.LP_TEST_FILE && !o.dir) shell.showItemInFolder(r.filePath); return { ok: true, file: r.filePath, summary: summarize(out) }; }
  catch (e) { return { ok: false, err: String(e.message || e) }; }
});
let pendingImport = null;
ipcMain.handle('data:import-read', async () => {
  pendingImport = null;
  const r = process.env.LP_TEST_FILE ? { filePaths: [process.env.LP_TEST_FILE] } : await dialog.showOpenDialog(win, { title: T('اختاري ملف البيانات'), properties: ['openFile'], filters: [{ name: T('بيانات عارض الدروس'), extensions: ['lpdata', 'json'] }] });
  if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
  let j; try { j = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8')); } catch { return { ok: false, err: 'bad' }; }
  if (!j || j.format !== 'lessonpresenter-data') return { ok: false, err: 'bad' };
  pendingImport = j;
  if (j.enc) return { ok: true, needPw: true };
  return { ok: true, summary: summarize(j.parts || {}), from: j.from, at: j.exportedAt };
});
ipcMain.handle('data:import-unlock', (_e, pw) => {
  if (!pendingImport || !pendingImport.enc) return { ok: false };
  try { const b = xdec(pw, pendingImport.enc); pendingImport = { format: pendingImport.format, ...b }; return { ok: true, summary: summarize(b.parts || {}), from: b.from, at: b.exportedAt }; }
  catch { return { ok: false, err: 'pw' }; }
});
// دمج: يُضاف الجديد ولا يُحذف شيء — استبدال: يحل الملف محل البيانات الحالية
ipcMain.handle('data:import-apply', (_e, o = {}) => {
  const id = accounts.current(); if (!id || id === 'guest' || !pendingImport || !pendingImport.parts) return { ok: false };
  const src = pendingImport.parts, p = store.profiles.get(id), patch = {}, replace = o.mode === 'replace';
  const want = new Set(o.parts || Object.keys(src));
  const n = { classes: 0, students: 0, lessons: 0 };
  if (want.has('classes') && src.classes) {
    const inc = src.classes.classes || [];
    if (replace) { patch.classes = inc; patch.classIdx = 0; n.classes = inc.length; }
    else {
      const list = JSON.parse(JSON.stringify(p.classes || []));
      for (const c of inc) {
        const ex = list.find(x => x.name === c.name);
        if (!ex) { list.push(c); n.classes++; n.students += (c.students || []).length; continue; }
        const have = new Set(ex.students || []);
        for (const st of c.students || []) if (st && !have.has(st)) { (ex.students ||= []).push(st); have.add(st); n.students++; }
        for (const k of Object.keys(c)) if (ex[k] === undefined) ex[k] = c[k];
      }
      patch.classes = list;
    }
  }
  if (want.has('library') && src.library) {
    const inc = src.library.library || [];
    if (replace) { patch.library = inc; n.lessons = inc.length; }
    else {
      const list = (p.library || []).slice();
      const key = (l) => l.url ? 'u:' + l.url : 'n:' + l.name + '|' + (l.grade || 0);
      const have = new Set(list.map(key));
      for (const l of inc) if (!have.has(key(l))) { list.push({ ...l, id: l.id || Date.now() + Math.random() }); have.add(key(l)); n.lessons++; }
      patch.library = list;
    }
    for (const k of ['mySubject', 'lastSubject', 'lastGrade']) if (src.library[k] !== undefined && (replace || p[k] === undefined)) patch[k] = src.library[k];
  }
  if (want.has('points') && src.points) {
    const inc = src.points.grp || {};
    if (replace) patch.grp = inc;
    else {
      const g = JSON.parse(JSON.stringify(p.grp || {}));
      for (const [cls, d] of Object.entries(inc)) {
        if (!g[cls]) { g[cls] = d; continue; }
        const ids = new Set((g[cls].sessions || []).map(x => x.id));
        g[cls].sessions = [...(g[cls].sessions || []), ...(d.sessions || []).filter(x => !ids.has(x.id))].sort((a, b) => (b.created || 0) - (a.created || 0)).slice(0, 30);
      }
      patch.grp = g;
    }
    if (replace && src.points.lessonNow) patch.lessonNow = src.points.lessonNow;
  }
  if (want.has('settings') && src.settings) for (const [k, v] of Object.entries(src.settings)) if (!DEVICE_KEYS.test(k) && (replace || p[k] === undefined)) patch[k] = v;
  store.profiles.patch(id, patch);
  pendingImport = null;
  return { ok: true, n };
});

// ---------- إعادة ربط ملف درس انتقل مكانه (حرف فلاشة مختلف) ----------
ipcMain.handle('file:locate', (_e, p) => {
  try { if (p && fs.existsSync(p)) return { path: p }; } catch {}
  if (isWin && /^[A-Za-z]:[\\/]/.test(p || '')) {
    const rest = p.slice(2);
    for (const L of 'DEFGHIJKLMNOPQRSTUVWXYZCAB') {
      const c = L + ':' + rest;
      if (c.toUpperCase() === p.toUpperCase()) continue;
      try { if (fs.existsSync(c)) return { path: c, moved: true }; } catch {}
    }
  }
  return { missing: true };
});
ipcMain.handle('file:pick-for', async (_e, name) => {
  const ext = path.extname(name || '').slice(1);
  const r = await dialog.showOpenDialog(win, { title: T('أين هذا الملف؟') + ' — ' + (name || ''), properties: ['openFile'], filters: ext ? [{ name: ext.toUpperCase(), extensions: [ext] }, { name: T('كل الملفات'), extensions: ['*'] }] : [] });
  return r.canceled ? null : r.filePaths[0] || null;
});

// ======================================================================
// مكتبة القسم المشتركة
// ======================================================================
const meName = () => { const u = accounts.currentUser(); return u ? u.name : T('ضيفة'); };
const canEdit = (it) => accounts.isAdmin() || (it.by && it.by === accounts.current());
ipcMain.handle('shared:list', () => {
  store.shared.purgeOld();
  const me = accounts.current(), admin = accounts.isAdmin();
  return store.shared.get().items.map(i => ({ ...i, mine: i.by === me, canEdit: admin || i.by === me }))
    .filter(i => !i.deleted || admin || i.by === me);
});
ipcMain.handle('shared:add', (_e, item) => {
  const cur = accounts.current();
  if (!cur || cur === 'guest') return { ok: false };
  const S = store.shared.get();
  if (S.items.some(i => !i.deleted && i.url === item.url)) return { ok: false, err: 'exists' };
  if (item.url && S.items.some(i => !i.deleted && i.url === item.url)) return { ok: false, err: 'exists' };
  S.items.unshift({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), name: String(item.name || '').slice(0, 160), url: item.url || '', thumb: item.thumb || null,
    subject: item.subject || '', grade: +item.grade || 0, unit: String(item.unit || '').slice(0, 80), goals: Array.isArray(item.goals) ? item.goals.slice(0, 20).map(g => String(g).slice(0, 300)) : [],
    by: cur, byName: meName(), added: Date.now() });
  store.shared.save();
  return { ok: true };
});
ipcMain.handle('shared:add-many', (_e, items) => {
  const cur = accounts.current();
  if (!cur || cur === 'guest' || !Array.isArray(items)) return { ok: false };
  const S = store.shared.get(); let n = 0;
  for (const item of items) {
    S.items.unshift({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8), name: String(item.name || '').slice(0, 160), url: '', thumb: null,
      subject: item.subject || '', grade: +item.grade || 0, unit: String(item.unit || '').slice(0, 80), goals: (item.goals || []).slice(0, 20).map(g => String(g).slice(0, 300)),
      by: cur, byName: meName(), added: Date.now() + (n++) });
  }
  store.shared.save();
  return { ok: true, n };
});
ipcMain.handle('shared:update', (_e, id, patch) => {
  const it = store.shared.get().items.find(i => i.id === id);
  if (!it || !canEdit(it)) return { ok: false };
  if (patch.name !== undefined && String(patch.name).trim()) it.name = String(patch.name).trim().slice(0, 160);
  if (patch.subject !== undefined) it.subject = patch.subject || '';
  if (patch.grade !== undefined) it.grade = +patch.grade || 0;
  if (patch.unit !== undefined) it.unit = String(patch.unit || '').slice(0, 80);
  if (Array.isArray(patch.goals)) it.goals = patch.goals.slice(0, 20).map(g => String(g).slice(0, 300));
  if (typeof patch.url === 'string' && patch.url) it.url = patch.url.slice(0, 2000);
  store.shared.save(); return { ok: true };
});

// ---------- المواد (مشتركة بين كل المعلمات) ----------
const DEFAULT_SUBJECTS = [['الحاسب', '💻', '#228be6'], ['لغتي', '📖', '#2fb344'], ['الرياضيات', '🔢', '#fd7e14'], ['العلوم', '🔬', '#12b886'], ['اللغة الإنجليزية', '🔤', '#ae3ec9'], ['الدراسات الإسلامية', '🕌', '#0ca678'], ['الدراسات الاجتماعية', '🌍', '#e64980'], ['التربية الفنية', '🎨', '#f5b400']];
function subjects() {
  const S = store.shared.get();
  if (!Array.isArray(S.subjects)) { S.subjects = DEFAULT_SUBJECTS.map(([name, icon, color], i) => ({ id: 's' + i, name, icon, color, by: 'system' })); store.shared.save(); }
  return S.subjects;
}
const canEditSubject = (sub) => accounts.isAdmin() || (sub.by && sub.by === accounts.current());
ipcMain.handle('subjects:list', () => subjects().map(x => ({ ...x, canEdit: canEditSubject(x) })));
ipcMain.handle('subjects:add', (_e, d) => {
  const cur = accounts.current(); if (!cur || cur === 'guest') return { ok: false };
  const name = String(d.name || '').trim().slice(0, 40); if (!name) return { ok: false };
  if (subjects().some(x => x.name === name)) return { ok: false, err: 'exists' };
  const sub = { id: 's' + Date.now().toString(36), name, icon: String(d.icon || '📚').slice(0, 4), color: d.color || '#228be6', by: cur };
  subjects().push(sub); store.shared.save(); return { ok: true, id: sub.id };
});
ipcMain.handle('subjects:update', (_e, id, d) => {
  const sub = subjects().find(x => x.id === id); if (!sub || !canEditSubject(sub)) return { ok: false };
  if (d.name && String(d.name).trim()) sub.name = String(d.name).trim().slice(0, 40);
  if (d.icon) sub.icon = String(d.icon).slice(0, 4);
  if (d.color) sub.color = d.color;
  store.shared.save(); return { ok: true };
});
ipcMain.handle('subjects:delete', (_e, id) => {
  const S = store.shared.get(); const sub = subjects().find(x => x.id === id);
  if (!sub || !canEditSubject(sub)) return { ok: false };
  S.subjects = S.subjects.filter(x => x.id !== id);
  for (const it of S.items) if (it.subject === id) it.subject = '';        // الدروس لا تُحذف: تنتقل إلى «غير مصنّفة»
  store.shared.save(); return { ok: true };
});

// ---------- وضع المدرسة (السحابة) ----------
const school = require('./school');
const schoolReady = () => { const u = accounts.currentUser(), S = cloud.session(); return !!(u && u.cloudUid && S && S.uid === u.cloudUid); };
ipcMain.handle('school:call', async (_e, op, ...args) => {
  if (!schoolReady()) return { err: 'cnot' };
  const fn = { create: school.createSchool, join: school.join, info: school.info, members: school.members, roles: school.roles, saveRole: school.saveRole, deleteRole: school.deleteRole,
    setRole: school.setRole, remove: school.removeMember, leave: school.leave, rename: school.rename, requestTransfer: school.requestTransfer, cancelTransfer: school.cancelTransfer, acceptTransfer: school.acceptTransfer, declineTransfer: school.declineTransfer, pendingForMe: school.pendingForMe, newCode: school.newSchoolCode, delete: school.deleteSchool, getData: school.getData, setData: school.setData, getRoster: school.getRoster, setRoster: school.setRoster, delRoster: school.delRoster, listRoster: school.listRoster, getAssign: school.getAssign, listAssign: school.listAssign, setAssign: school.setAssign, requestClass: school.requestClass, getRequest: school.getRequest, listRequests: school.listRequests, delRequest: school.delRequest, approve: school.approve, listNotices: school.listNotices, saveNotice: school.saveNotice, delNotice: school.delNotice, markSeen: school.markSeen, listSeen: school.listSeen }[op];
  if (!fn) return { err: 'op' };
  try { return { ok: true, v: await fn(...args) }; }
  catch (e) { log('school ' + op + ' failed: ' + (e.code || '') + ' ' + (e.detail || e.message || '')); return { err: e.code || 'cfail' }; }
});
ipcMain.handle('school:perms', () => school.PERMS);
// تأكيد هوية صاحبة الحساب قبل قبول الملكية
ipcMain.handle('school:reauth', async (_e, pw) => {
  if (!schoolReady()) return { err: 'cnot' };
  try {
    const S = cloud.session();
    const ok = S.google && !pw ? await cloud.verifyGoogle(GOOGLE_DONE) : await cloud.verifyPassword(pw);
    if (win && !win.isDestroyed()) win.focus();
    return ok ? { ok: true } : { err: 'mismatch' };
  } catch (e) { return { err: e.code === 'cbad' || e.code === 'cwrong' ? 'badpw' : (e.code || 'cfail') }; }
});
// فتح صفحة الخصوصية في ويندوز (الكاميرا / المايكروفون) من رسائل التسجيل
ipcMain.handle('sys:privacy', (_e, k) => shell.openExternal(k === 'mic' ? 'ms-settings:privacy-microphone' : 'ms-settings:privacy-webcam').then(() => true, () => false));
ipcMain.handle('school:who', () => { const S = cloud.session(); return S ? { google: !!S.google, email: S.email } : null; });

// ---------- إكسل: استيراد دفتر الدروس ونموذج فارغ ----------
const xlsx = require('./xlsx');
ipcMain.handle('xlsx:open', async () => {
  const r = await dialog.showOpenDialog(win, { title: T('اختاري ملف إكسل لدفتر الدروس'), properties: ['openFile'], filters: [{ name: 'Excel', extensions: ['xlsx', 'csv', 'txt'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  const f = r.filePaths[0];
  try {
    if (/\.xlsx$/i.test(f)) return { rows: xlsx.readXlsx(fs.readFileSync(f)) };
    const txt = fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '');
    const sep = txt.includes('\t') ? '\t' : (txt.split('\n')[0].includes(';') ? ';' : ',');
    return { rows: txt.split(/\r?\n/).map(l => l.split(sep).map(c => c.replace(/^"|"$/g, '').trim())) };
  } catch (e) { return { err: String(e.message || e) }; }
});
// كل الأوراق (لاستيراد الأسماء): إكسل الحديث xlsx أو CSV/نص
ipcMain.handle('xlsx:open-book', async (_e, title) => {
  const r = process.env.LP_TEST_XLSX ? { filePaths: [process.env.LP_TEST_XLSX] } : await dialog.showOpenDialog(win, { title: title || T('اختاري ملف إكسل'), properties: ['openFile'], filters: [{ name: 'Excel', extensions: ['xlsx', 'xls', 'csv', 'txt'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  const f = r.filePaths[0], base = path.basename(f).replace(/\.[^.]+$/, '');
  try {
    if (/\.xls$/i.test(f)) return { err: 'xls' };
    if (/\.xlsx$/i.test(f)) return { file: base, sheets: xlsx.readBook(fs.readFileSync(f)) };
    const txt = fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '');
    const sep = txt.includes('\t') ? '\t' : (txt.split('\n')[0].includes(';') ? ';' : ',');
    return { file: base, sheets: [{ name: base, rows: txt.split(/\r?\n/).map(l => l.split(sep).map(c => c.replace(/^"|"$/g, '').trim())) }] };
  } catch (e) { return { err: String(e.message || e) }; }
});
ipcMain.handle('xlsx:template', async (_e, rows) => {
  const r = await dialog.showSaveDialog(win, { title: T('حفظ نموذج إكسل'), defaultPath: path.join(app.getPath('documents'), T('نموذج دفتر الدروس') + '.xlsx'), filters: [{ name: 'Excel', extensions: ['xlsx'] }] });
  if (r.canceled || !r.filePath) return false;
  try { fs.writeFileSync(r.filePath, xlsx.writeXlsx(rows, { rtl: I.dir() === 'rtl', widths: [16, 10, 14, 38, 40, 40, 40] })); shell.showItemInFolder(r.filePath); return true; } catch { return false; }
});
ipcMain.handle('file:read-image', async () => {
  const r = await dialog.showOpenDialog(win, { title: T('اختاري صورة'), properties: ['openFile'], filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  try {
    const b = fs.readFileSync(r.filePaths[0]);
    if (b.length > 6 * 1024 * 1024) return { err: 'big' };
    const ext = path.extname(r.filePaths[0]).slice(1).toLowerCase().replace('jpg', 'jpeg');
    return { data: `data:image/${ext};base64,` + b.toString('base64') };
  } catch { return null; }
});
ipcMain.handle('shared:rename', (_e, id, name) => {
  const it = store.shared.get().items.find(i => i.id === id);
  if (!it || !canEdit(it) || !String(name).trim()) return { ok: false };
  it.name = String(name).trim().slice(0, 120); store.shared.save(); return { ok: true };
});
ipcMain.handle('shared:delete', (_e, id) => {
  const it = store.shared.get().items.find(i => i.id === id);
  if (!it || !canEdit(it)) return { ok: false };
  it.deleted = { by: accounts.current(), byName: meName(), at: Date.now() }; store.shared.save(); return { ok: true };
});
ipcMain.handle('shared:restore', (_e, id) => {
  const it = store.shared.get().items.find(i => i.id === id);
  if (!it || !it.deleted || !canEdit(it)) return { ok: false };
  delete it.deleted; store.shared.save(); return { ok: true };
});
ipcMain.handle('shared:purge', (_e, id) => {
  if (!accounts.isAdmin()) return { ok: false };
  const S = store.shared.get();
  S.items = id ? S.items.filter(i => i.id !== id || !i.deleted) : S.items.filter(i => !i.deleted);
  store.shared.save(); return { ok: true };
});

// ======================================================================
// رابط الاسترجاع من البريد (lessonpresenter://reset/?u=..&t=..)
// ======================================================================
function handleLink(argv) {
  const link = (argv || []).find(a => typeof a === 'string' && a.toLowerCase().startsWith('lessonpresenter://'));
  if (!link) return;
  try {
    const u = new URL(link);
    const uid = u.searchParams.get('u'), token = u.searchParams.get('t');
    if (uid && token && accounts.checkResetToken(uid, token)) {
      pendingReset = { uid, token };
      if (win && !win.isDestroyed()) { win.webContents.send('reset-link', pendingReset); bringBack(); }
    }
  } catch {}
}
let pendingReset = null;
ipcMain.handle('auth:pending-reset', () => { const r = pendingReset; pendingReset = null; return r; });

// ======================================================================
// التشغيل
// ======================================================================
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
else {
  app.on('second-instance', (_e, argv) => { bringBack(); handleLink(argv); });
  try {
    if (app.isPackaged) app.setAsDefaultProtocolClient('lessonpresenter');
    else if (process.argv[1]) app.setAsDefaultProtocolClient('lessonpresenter', process.execPath, [path.resolve(process.argv[1])]);
  } catch {}
  // ---------- التحديث وفترة التجربة ----------
  app.whenReady().then(() => {
    try { updater.init(store.ROOT || require('path').dirname(require('electron').app.getPath('userData')), (m) => log(m)); } catch (e) { log('updater init ' + e.message); }
    const run = async () => { const r = await updater.check(); if (r && r.ready && win && !win.isDestroyed()) win.webContents.send('upd:ready', r.ready); };
    setTimeout(run, 15000); setInterval(run, 6 * 3600e3);
  });
  app.whenReady().then(() => { try { log('start v' + APPVER + ' electron ' + process.versions.electron + ' scale ' + screen.getPrimaryDisplay().scaleFactor); } catch {} });
app.whenReady().then(() => {
    handleLink(process.argv);
    createWindow();
    globalShortcut.register(RETURN_KEY, bringBack);
    globalShortcut.register(SPOT_KEY, () => toggleSpot());
    // Ctrl+Shift+G: العجلة الصغيرة فوق كل البرامج
    globalShortcut.register(WHEEL_KEY, () => { if (win && !win.isDestroyed() && accounts.current()) win.webContents.send('mini:wheel-key', win.isFocused() && !mini); });
    if (isWin) {
      setTimeout(() => helperCall('ping', '', 15000), 1500);
      setInterval(pollForeground, 900);
      setInterval(pruneClosed, 4000);
    }
  });
}
// عند الإغلاق: نغلق عروض باوربوينت، ونخرج من حسابات مايكروسوفت وGoogle (إلا على الجهاز الشخصي)
let cleaned = false;
app.on('before-quit', (e) => {
  if (cleaned) return;
  e.preventDefault();
  const done = () => { cleaned = true; app.quit(); };
  const t = setTimeout(done, 8000);
  (async () => { try { await closeAllShows(); } catch {} try { await withTimeout(vaultSave(), 4000); } catch {} try { await accounts.cleanupOnQuit(); } catch {} })().finally(() => { clearTimeout(t); done(); });
});
app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  if (helper) try { helper.kill(); } catch {}
});
app.on('window-all-closed', () => app.quit());
