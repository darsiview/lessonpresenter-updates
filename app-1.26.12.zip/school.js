// وضع المدرسة (السحابة): إنشاء مدرسة برمز، الانضمام، الأعضاء، الأدوار والصلاحيات
// schools/{sid}                 → name, code, owner, gender, created
// schools/{sid}/members/{uid}   → name, email, role ('owner' | 'teacher' | معرّف دور), joined, code (إثبات معرفة الرمز عند الانضمام)
// schools/{sid}/roles/{rid}     → name, perms []
// schools/{sid}/data/{key}      → بيانات المدرسة المشتركة (الهيكل، الأسماء، التقويم…) — لاحقاً
// codes/{CODE}                  → sid   (البحث عن المدرسة برمزها)
const crypto = require('crypto');
const cloud = require('./cloud');
let CFG = {}; try { CFG = require('./cloud-config.json'); } catch {}
const FS = () => process.env.LP_FB_FS || 'https://firestore.googleapis.com/v1';
const base = () => `${FS()}/projects/${CFG.projectId}/databases/(default)/documents`;

const PERMS = ['structure', 'students', 'calendar', 'adminLessons', 'library', 'members', 'reports'];

// ---------- قيم Firestore ----------
function enc(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === 'boolean') return { booleanValue: v };
  if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(enc) } };
  if (typeof v === 'object') return { mapValue: { fields: Object.fromEntries(Object.entries(v).map(([k, x]) => [k, enc(x)])) } };
  return { stringValue: String(v) };
}
function dec(v) {
  if (!v) return null;
  if ('stringValue' in v) return v.stringValue;
  if ('integerValue' in v) return +v.integerValue;
  if ('doubleValue' in v) return +v.doubleValue;
  if ('booleanValue' in v) return v.booleanValue;
  if ('timestampValue' in v) return Date.parse(v.timestampValue);
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(dec);
  if ('mapValue' in v) return Object.fromEntries(Object.entries(v.mapValue.fields || {}).map(([k, x]) => [k, dec(x)]));
  return null;
}
const fields = (o) => ({ fields: Object.fromEntries(Object.entries(o).map(([k, v]) => [k, enc(v)])) });
const docOf = (d) => d && d.fields ? { id: d.name.split('/').pop(), ...Object.fromEntries(Object.entries(d.fields).map(([k, v]) => [k, dec(v)])) } : null;

async function req(method, path, body) {
  const tok = await cloud.idToken();
  let res;
  try {
    res = await fetch(base() + path, { method, signal: AbortSignal.timeout(20000), headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: body ? JSON.stringify(body) : undefined });
  } catch (e) { throw new cloud.CloudErr('net', String(e.message || e)); }
  if (res.status === 404) return null;
  const j = await res.json().catch(() => ({}));
  if (res.status === 409 || (j.error && j.error.status === 'ALREADY_EXISTS')) throw new cloud.CloudErr('exists');
  if (!res.ok) throw new cloud.CloudErr(res.status === 403 ? 'cdenied' : 'cfail', JSON.stringify(j.error || res.status));
  return j;
}
const get = async (p) => docOf(await req('GET', p));
const create = (p, o) => req('PATCH', p + '?currentDocument.exists=false', fields(o));
const update = (p, o) => req('PATCH', p + '?' + Object.keys(o).map(k => 'updateMask.fieldPaths=' + encodeURIComponent(k)).join('&'), fields(o));
const del = (p) => req('DELETE', p);
async function list(p) {
  const out = []; let tok = '';
  do {
    const j = await req('GET', p + '?pageSize=300' + (tok ? '&pageToken=' + encodeURIComponent(tok) : ''));
    for (const d of (j && j.documents) || []) out.push(docOf(d));
    tok = j && j.nextPageToken;
  } while (tok);
  return out;
}

// ---------- الرمز ----------
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // بلا I و O و 0 و 1 (حتى لا تختلط)
const newCode = () => Array.from(crypto.randomBytes(6), b => ALPHA[b % ALPHA.length]).join('');
const normCode = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/O/g, '0').replace(/I/g, '1');
const showCode = (c) => c ? c.slice(0, 3) + '-' + c.slice(3) : '';
const me = () => { const S = cloud.session(); if (!S) throw new cloud.CloudErr('cnot'); return S; };

// ---------- العمليات ----------
async function createSchool({ name, gender }) {
  const S = me();
  const sid = crypto.randomBytes(10).toString('hex');
  let code = '';
  await create(`/schools/${sid}`, { name: String(name || '').trim().slice(0, 80), code: 'pending', owner: S.uid, gender: gender || 'g', created: Date.now() });
  await create(`/schools/${sid}/members/${S.uid}`, { name: S.name || '', email: S.email || '', role: 'owner', joined: Date.now() });
  for (let i = 0; i < 6 && !code; i++) {
    const c = newCode();
    try { await create(`/codes/${c}`, { sid }); code = c; } catch (e) { if (e.code !== 'exists' && e.code !== 'cdenied') throw e; }
  }
  if (!code) throw new cloud.CloudErr('cfail', 'code');
  await update(`/schools/${sid}`, { code });
  return info(sid);
}
async function findByCode(code) {
  const c = normCode(code); if (c.length !== 6) throw new cloud.CloudErr('badcode');
  const d = await get(`/codes/${c}`); if (!d || !d.sid) throw new cloud.CloudErr('badcode');
  return { sid: d.sid, code: c };
}
async function join(code) {
  const S = me(), f = await findByCode(code);
  const ex = await get(`/schools/${f.sid}/members/${S.uid}`).catch(() => null);
  if (!ex) await create(`/schools/${f.sid}/members/${S.uid}`, { name: S.name || '', email: S.email || '', role: 'teacher', joined: Date.now(), code: f.code });
  return info(f.sid);
}
// معلومات المدرسة + دوري وصلاحياتي
async function info(sid) {
  const S = me();
  const sc = await get(`/schools/${sid}`); if (!sc) throw new cloud.CloudErr('gone');
  const m = await get(`/schools/${sid}/members/${S.uid}`); if (!m) throw new cloud.CloudErr('gone');
  let perms = [], roleName = '';
  if (sc.owner === S.uid || m.role === 'owner') perms = PERMS.slice();
  else if (m.role !== 'teacher') { const r = await get(`/schools/${sid}/roles/${m.role}`).catch(() => null); if (r) { perms = (r.perms || []).filter(p => PERMS.includes(p)); roleName = r.name; } }
  return { pendingOwner: sc.pendingOwner || '', pendingAt: sc.pendingAt || 0, pendingBy: sc.pendingBy || '', pendingName: sc.pendingName || '', sid, name: sc.name, code: sc.code, codeShow: showCode(sc.code), gender: sc.gender, owner: sc.owner === S.uid, role: sc.owner === S.uid ? 'owner' : m.role, roleName, perms };
}
const members = (sid) => list(`/schools/${sid}/members`).then(a => a.map(({ code, ...x }) => x));
const roles = (sid) => list(`/schools/${sid}/roles`);
async function saveRole(sid, role) {
  const perms = (role.perms || []).filter(p => PERMS.includes(p)), name = String(role.name || '').trim().slice(0, 40);
  if (!name) throw new cloud.CloudErr('cfail', 'name');
  const id = role.id || 'r' + crypto.randomBytes(5).toString('hex');
  await req('PATCH', `/schools/${sid}/roles/${id}`, fields({ name, perms }));
  return id;
}
async function deleteRole(sid, id) {
  // من كان لها هذا الدور تعود معلمة
  for (const m of await members(sid)) if (m.role === id) await update(`/schools/${sid}/members/${m.id}`, { role: 'teacher' });
  await del(`/schools/${sid}/roles/${id}`);
}
const setRole = (sid, uid, role) => update(`/schools/${sid}/members/${uid}`, { role });
const removeMember = (sid, uid) => del(`/schools/${sid}/members/${uid}`);
async function leave(sid) { const S = me(); await del(`/schools/${sid}/members/${S.uid}`); }
async function rename(sid, o) { const p = {}; if (o.name) p.name = String(o.name).trim().slice(0, 80); if (o.gender) p.gender = o.gender; if (Object.keys(p).length) await update(`/schools/${sid}`, p); }
// نقل الملكية بمصافحة: المالكة تطلب ← المالكة الجديدة توافق بنفسها (بعد التحقق من كلمة مرورها) ← تنتقل
const WEEK = 7 * 864e5;
async function requestTransfer(sid, uid, name) { const S = me(); if (uid === S.uid) return; await update(`/schools/${sid}`, { pendingOwner: uid, pendingName: name || '', pendingBy: S.name || S.email || '', pendingAt: Date.now() }); }
const cancelTransfer = (sid) => update(`/schools/${sid}`, { pendingOwner: '', pendingName: '', pendingBy: '', pendingAt: 0 });
async function acceptTransfer(sid) {
  const S = me(), sc = await get(`/schools/${sid}`);
  if (!sc || sc.pendingOwner !== S.uid || Date.now() - (sc.pendingAt || 0) > WEEK) throw new cloud.CloudErr('expired');
  const old = sc.owner;
  await update(`/schools/${sid}`, { owner: S.uid, pendingOwner: '', pendingName: '', pendingBy: '', pendingAt: 0 });
  await update(`/schools/${sid}/members/${S.uid}`, { role: 'owner' });
  if (old && old !== S.uid) await update(`/schools/${sid}/members/${old}`, { role: 'teacher' }).catch(() => {});
}
const declineTransfer = (sid) => update(`/schools/${sid}`, { pendingOwner: '', pendingName: '', pendingBy: '', pendingAt: 0 });
// طلبات النقل الموجّهة لي في مدارسي
async function pendingForMe(sids) {
  const S = me(), out = [];
  for (const sid of sids || []) { const sc = await get(`/schools/${sid}`).catch(() => null); if (sc && sc.pendingOwner === S.uid && Date.now() - (sc.pendingAt || 0) <= WEEK) out.push({ sid, name: sc.name, by: sc.pendingBy, at: sc.pendingAt }); }
  return out;
}
// رمز جديد (إن انتشر الرمز القديم): القديم يتوقف فوراً
async function newSchoolCode(sid) {
  const sc = await get(`/schools/${sid}`);
  let code = '';
  for (let i = 0; i < 6 && !code; i++) { const c = newCode(); try { await create(`/codes/${c}`, { sid }); code = c; } catch (e) { if (e.code !== 'exists' && e.code !== 'cdenied') throw e; } }
  if (!code) throw new cloud.CloudErr('cfail', 'code');
  await update(`/schools/${sid}`, { code });
  if (sc && sc.code && sc.code !== 'pending') await del(`/codes/${sc.code}`).catch(() => {});
  return showCode(code);
}
async function deleteSchool(sid) {
  const S = me();
  const sc = await get(`/schools/${sid}`);
  for (const r of await roles(sid).catch(() => [])) await del(`/schools/${sid}/roles/${r.id}`).catch(() => {});
  for (const m of await members(sid).catch(() => [])) if (m.id !== S.uid) await del(`/schools/${sid}/members/${m.id}`).catch(() => {});
  if (sc && sc.code) await del(`/codes/${sc.code}`).catch(() => {});
  await del(`/schools/${sid}/members/${S.uid}`).catch(() => {});
  await del(`/schools/${sid}`);
}

// بيانات المدرسة المشتركة (التقويم…): نص JSON واحد في المستند
async function getData(sid, key) {
  const d = await get(`/schools/${sid}/data/${key}`);
  if (!d || !d.json) return null;
  try { return { ...JSON.parse(d.json), updated: d.updated || 0, by: d.by || '' }; } catch { return null; }
}
async function setData(sid, key, obj) {
  const S = me(), { updated, by, ...rest } = obj || {};
  const u = Date.now();
  await req('PATCH', `/schools/${sid}/data/${key}`, fields({ json: JSON.stringify(rest), updated: u, by: S.name || S.email || '' }));
  return u;
}

// ---------- أسماء الفصول، ربط المعلمات، طلبات الربط ----------
const getRoster = (sid, cid) => get(`/schools/${sid}/roster/${cid}`).catch(e => { if (e.code === 'cdenied') return null; throw e; });
async function setRoster(sid, cid, o) { await req('PATCH', `/schools/${sid}/roster/${cid}`, fields({ grade: o.grade || '', stage: o.stage || '', name: o.name || '', names: o.names || [], sg: JSON.stringify(o.sg || {}), updated: Date.now() })); }
const delRoster = (sid, cid) => del(`/schools/${sid}/roster/${cid}`);
const listRoster = (sid) => list(`/schools/${sid}/roster`);
const getAssign = (sid, uid) => get(`/schools/${sid}/assign/${uid || me().uid}`).catch(e => { if (e.code === 'cdenied') return null; throw e; });
const listAssign = (sid) => list(`/schools/${sid}/assign`);
const setAssign = (sid, uid, o) => req('PATCH', `/schools/${sid}/assign/${uid}`, fields({ stages: o.stages || [], grades: o.grades || [], classes: o.classes || [], updated: Date.now() }));
async function requestClass(sid, cid, cname) { const S = me(); await req('PATCH', `/schools/${sid}/requests/${S.uid}_${cid}`, fields({ uid: S.uid, name: S.name || S.email || '', cid, cname: cname || '', at: Date.now() })); }
const getRequest = (sid, cid) => get(`/schools/${sid}/requests/${me().uid}_${cid}`).catch(e => { if (e.code === 'cdenied') return null; throw e; });
const listRequests = (sid) => list(`/schools/${sid}/requests`);
const delRequest = (sid, rid) => del(`/schools/${sid}/requests/${rid}`);
async function approve(sid, rq) {
  const a = (await getAssign(sid, rq.uid)) || {};
  const classes = [...new Set([...(a.classes || []), rq.cid])];
  await setAssign(sid, rq.uid, { stages: a.stages, grades: a.grades, classes });
  await delRequest(sid, rq.id);
}

// ---------- التنبيهات والدروس الإدارية ----------
const listNotices = (sid) => list(`/schools/${sid}/notices`);
async function saveNotice(sid, n) {
  const S = me(), id = n.id || (Date.now().toString(36) + crypto.randomBytes(4).toString('hex'));
  const o = { kind: n.kind === 'lesson' ? 'lesson' : 'msg', title: String(n.title || '').slice(0, 120), body: String(n.body || '').slice(0, 2000), url: String(n.url || '').slice(0, 1000),
    all: !!n.all, stages: n.stages || [], grades: n.grades || [], start: n.start || '', end: n.end || '', by: n.by || S.name || S.email || '', byUid: S.uid, at: n.at || Date.now(), edited: n.id ? Date.now() : 0 };
  await req('PATCH', `/schools/${sid}/notices/${id}`, fields(o));
  return id;
}
async function delNotice(sid, nid) {
  try { for (const x of await list(`/schools/${sid}/notices/${nid}/seen`)) await del(`/schools/${sid}/notices/${nid}/seen/${x.id}`); } catch {}
  await del(`/schools/${sid}/notices/${nid}`);
}
async function markSeen(sid, nid, o) { const S = me(); await req('PATCH', `/schools/${sid}/notices/${nid}/seen/${S.uid}`, fields({ name: o.name || S.name || S.email || '', cls: o.cls || '', shown: !!o.shown, at: Date.now() })); }
const listSeen = (sid, nid) => list(`/schools/${sid}/notices/${nid}/seen`);

module.exports = { listNotices, saveNotice, delNotice, markSeen, listSeen, getRoster, setRoster, delRoster, listRoster, getAssign, listAssign, setAssign, requestClass, getRequest, listRequests, delRequest, approve, getData, setData, PERMS, createSchool, join, info, members, roles, saveRole, deleteRole, setRole, removeMember, leave, rename, requestTransfer, cancelTransfer, acceptTransfer, declineTransfer, pendingForMe, newSchoolCode, deleteSchool, showCode, normCode, _enc: enc, _dec: dec };
