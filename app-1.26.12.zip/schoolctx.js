// مكان العمل: «👤 شخصي» دائماً + كل مدرسة انضمت لها المعلمة (بلا حد).
// الفصول تتبع المكان (classes[].home = معرّف المدرسة، وبلا home = شخصي)، وكل شيء محفوظ في حسابها فقط.
(() => {
  const $ = (s) => document.querySelector(s);
  const api = window.api;
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const COLORS = ['#2563eb', '#9333ea', '#db2777', '#ea580c', '#0891b2', '#16a34a', '#ca8a04', '#4f46e5', '#be123c', '#0d9488'];
  const PERSONAL = '#64748b';
  let prof = {};

  // ---------- أساسيات ----------
  LP.classKey = (c) => c ? (c.home ? c.name + '@' + c.home : c.name) : '';
  LP.schools = () => prof.schools || [];
  LP.ctxHome = () => (prof.ctx && LP.schools().some(s => s.sid === prof.ctx)) ? prof.ctx : '';
  LP.classVisible = (c) => !!c && (c.home || '') === LP.ctxHome();
  LP.schoolOf = (sid) => LP.schools().find(s => s.sid === sid) || null;
  LP.ctxColor = (sid) => sid ? ((LP.schoolOf(sid) || {}).color || COLORS[0]) : PERSONAL;
  LP.ctxName = (sid) => sid ? ((LP.schoolOf(sid) || {}).name || T('مدرسة')) : T('شخصي');
  const nextColor = (list) => COLORS.find(c => !list.some(s => s.color === c)) || COLORS[list.length % COLORS.length];

  async function load() {
    prof = await api.getSettings();
    // من الإصدار 1.21: مدرسة واحدة ← قائمة مدارس
    if (prof.school && prof.school.sid && !(prof.schools || []).length) {
      const schools = [{ ...prof.school, color: COLORS[0] }];
      await api.setSettings({ schools, school: null, ctx: prof.school.sid });
      prof = await api.getSettings();
    }
    return prof;
  }
  LP.reloadCtx = async () => { await load(); updChip(); };

  // الفصل الحالي يجب أن يكون من فصول المكان الحالي
  function fixClasses(p, home) {
    const cls = p.classes || [];
    let vis = cls.map((c, i) => [c, i]).filter(([c]) => (c.home || '') === home);
    if (!vis.length) { const c = { name: T('فصلي'), students: [] }; if (home) c.home = home; cls.push(c); vis = [[c, cls.length - 1]]; }
    const idx = Math.min(p.classIdx || 0, cls.length - 1);
    return { classes: cls, classIdx: vis.some(([, i]) => i === idx) ? idx : vis[0][1] };
  }
  LP.ensureCtxClass = async () => {
    const p = await api.getSettings(), f = fixClasses(p, LP.ctxHome());
    if (f.classes.length !== (p.classes || []).length || f.classIdx !== p.classIdx) await api.setSettings(f);
  };

  async function setCtx(sid) {
    if (LP.groupsFlush) await LP.groupsFlush();
    const p = await api.getSettings(); sid = sid && (p.schools || []).some(s => s.sid === sid) ? sid : '';
    await api.setSettings({ ctx: sid, ...fixClasses(p, sid) });
    prof = await api.getSettings();
    updChip();
    document.dispatchEvent(new Event('lp-classes'));
    document.dispatchEvent(new CustomEvent('lp-ctx', { detail: sid }));
    if ($('#toolsPanel').classList.contains('on') && LP.reloadTools) LP.reloadTools();
  }
  LP.setCtx = setCtx;
  // تحديث دوري وصلاحياتي في المدرسة بهدوء (قد تكون الإدارة غيّرتها)
  async function refreshInfo(sid) {
    if (!sid) return;
    const r = await api.school('info', sid).catch(() => null);
    if (!r) return;
    if (r.err === 'gone') { const n = await LP.schoolLeft(sid); LP.toast(T('لم يعد هذا الحساب عضواً في «{s}»', { s: LP.ctxName(sid) || '' }) + (n ? ' · ' + T('عادت فصولها إلى «شخصي»') : ''), null, null, 6000); return; }
    if (r.ok && r.v) {
      const before = (LP.schoolOf(sid) || {}).role;
      await LP.schoolSaved(r.v); document.dispatchEvent(new Event('lp-cal'));
      if (before === 'owner' && r.v.role !== 'owner') LP.toast(T('تم نقل ملكية «{s}» — أصبحتِ «معلمة» فيها', { s: r.v.name }), null, null, 7000);
    }
  }
  document.addEventListener('lp-ctx', (e) => refreshInfo(e.detail));

  // نقل فصل إلى مكان آخر (شخصي / مدرسة): بياناته (المجموعات والنقاط) تنتقل معه
  async function rekey(p, oldK, newK) {
    const grp = p.grp || {};
    if (oldK !== newK && grp[oldK]) { if (!grp[newK]) grp[newK] = grp[oldK]; delete grp[oldK]; }
    return grp;
  }
  LP.rekeyClass = async (oldK, newK) => {
    if (oldK === newK) return;
    if (LP.groupsFlush) await LP.groupsFlush();
    const p = await api.getSettings(); await api.setSettings({ grp: await rekey(p, oldK, newK) });
    document.dispatchEvent(new Event('lp-classes'));
  };
  async function moveClasses(idxs, home) {
    if (LP.groupsFlush) await LP.groupsFlush();
    const p = await api.getSettings(), cls = p.classes || [];
    let grp = p.grp || {};
    for (const i of idxs) {
      const c = cls[i]; if (!c) continue;
      const oldK = LP.classKey(c);
      if (home) c.home = home; else delete c.home;
      const base = c.name; let n = 2;
      while (cls.some((x, j) => j !== i && (x.home || '') === (home || '') && x.name === c.name)) c.name = `${base} (${n++})`;
      grp = await rekey({ grp }, oldK, LP.classKey(c));
    }
    await api.setSettings({ grp, ...fixClasses({ ...p, classes: cls }, LP.ctxHome()) });
    prof = await api.getSettings();
    document.dispatchEvent(new Event('lp-classes'));
  }
  LP.moveClasses = moveClasses;

  // ---------- قائمة المدارس (تستدعيها نافذة المدرسة) ----------
  LP.schoolSaved = async (info) => {
    const p = await api.getSettings(), list = (p.schools || []).slice();
    const k = list.findIndex(s => s.sid === info.sid), isNew = k < 0;
    const rec = { sid: info.sid, name: info.name, role: info.role, perms: info.perms, color: isNew ? nextColor(list) : list[k].color };
    if (isNew) list.push(rec); else list[k] = rec;
    await api.setSettings({ schools: list });
    prof = await api.getSettings(); updChip();
    return isNew;
  };
  LP.schoolColorSet = async (sid, color) => {
    const p = await api.getSettings(), list = (p.schools || []).map(s => s.sid === sid ? { ...s, color } : s);
    await api.setSettings({ schools: list }); prof = await api.getSettings(); updChip();
  };
  // خروج أو حذف: فصول تلك المدرسة تعود «شخصية» ولا يضيع شيء
  LP.schoolLeft = async (sid) => {
    const p = await api.getSettings();
    const idxs = (p.classes || []).map((c, i) => c.home === sid ? i : -1).filter(i => i >= 0);
    await api.setSettings({ schools: (p.schools || []).filter(s => s.sid !== sid), ctx: p.ctx === sid ? '' : p.ctx });
    prof = await api.getSettings();
    if (idxs.length) await moveClasses(idxs, '');
    await LP.ensureCtxClass();
    updChip();
    document.dispatchEvent(new Event('lp-classes'));
    return idxs.length;
  };

  // بعد الانضمام: أي فصولكِ الشخصية في هذه المدرسة؟ (مرة واحدة)
  LP.askMoveClasses = async (info) => {
    const p = await api.getSettings();
    const mine = (p.classes || []).map((c, i) => ({ c, i })).filter(x => !x.c.home && ((x.c.students || []).length || (p.grp || {})[x.c.name]));
    if (!mine.length) { await setCtx(info.sid); return; }
    const d = document.createElement('div'); d.className = 'gdlg on'; d.id = 'ctxMove';
    d.innerHTML = `<div class="gdlg-card" style="max-width:460px">
      <h3><span class="ctx-dot" style="background:${LP.ctxColor(info.sid)}"></span> ${T('انضممتِ إلى «{s}» 🎉', { s: esc(info.name) })}</h3>
      <p>${T('اختاري فصولكِ التي تُدرّسينها في هذه المدرسة. تنتقل بأسمائها ونقاطها، وتبقى في حسابكِ فقط ولا تراها المدرسة.')}</p>
      <div class="ctx-list">${mine.map(x => `<label><input type="checkbox" value="${x.i}"> <b>${esc(x.c.name)}</b> <small>${T('{n} اسماً', { n: (x.c.students || []).length })}</small></label>`).join('')}</div>
      <p class="tnote">${T('ما لا تختارينه يبقى «شخصياً». ويمكن تغييره لاحقاً من «الفصول والأسماء ← تابع لـ».')}</p>
      <div class="gdlg-row"><button class="pri" data-ok>${T('نقل إلى «{s}»', { s: esc(info.name) })}</button><button data-later>${T('لاحقاً')}</button></div></div>`;
    document.body.appendChild(d);
    const done = async (move) => {
      const idxs = move ? [...d.querySelectorAll('input:checked')].map(x => +x.value) : [];
      d.remove();
      if (idxs.length) await moveClasses(idxs, info.sid);
      await setCtx(info.sid);
      if (idxs.length) LP.toast(T('تم نقل {n} فصول إلى «{s}»', { n: idxs.length, s: info.name }), null, null, 4000);
    };
    d.querySelector('[data-ok]').onclick = () => done(true);
    d.querySelector('[data-later]').onclick = () => done(false);
  };

  // ---------- قائمة الاختيار (للنافذة عند الفتح، وللشريط الملوّن) ----------
  const opts = () => [{ sid: '', name: T('شخصي'), icon: '👤' }, ...LP.schools().map(s => ({ sid: s.sid, name: s.name, icon: '🏫' }))];
  function menu(anchor, onPick, cur) {
    document.querySelectorAll('.ctx-menu').forEach(m => m.remove());
    const m = document.createElement('div'); m.className = 'ctx-menu';
    m.innerHTML = opts().map(o => `<button data-sid="${esc(o.sid)}" class="${o.sid === cur ? 'on' : ''}"><span class="ctx-dot" style="background:${LP.ctxColor(o.sid)}"></span>${o.icon} ${esc(o.name)}${o.sid === cur ? ' ✓' : ''}</button>`).join('')
      + `<hr><button data-manage>👤 ${T('حسابي ومدارسي…')}</button>`;
    document.body.appendChild(m);
    const r = anchor.getBoundingClientRect();
    m.style.top = Math.min(innerHeight - m.offsetHeight - 8, r.bottom + 6) + 'px';
    m.style.left = Math.max(8, Math.min(innerWidth - m.offsetWidth - 8, r.left + r.width / 2 - m.offsetWidth / 2)) + 'px';
    const off = (e) => { if (!m.contains(e.target) && e.target !== anchor) { m.remove(); document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
    m.querySelectorAll('[data-sid]').forEach(b => b.onclick = () => { m.remove(); onPick(b.dataset.sid); });
    m.querySelector('[data-manage]').onclick = () => { m.remove(); document.querySelectorAll('#ctxPick').forEach(x => x.remove()); LP.openAccount && LP.openAccount(); };
    return m;
  }

  // ---------- الشريط الملوّن أعلى البرنامج ----------
  const chip = document.createElement('button'); chip.id = 'gbCtx'; chip.className = 'gb-ctx';
  const barEl = $('#bar'); if (barEl) barEl.prepend(chip);   // الشريط السفلي ظاهر دائماً
  function updChip() {
    const on = LP.schools().length > 0, sid = LP.ctxHome();
    chip.style.display = on ? '' : 'none';
    document.body.classList.toggle('hasCtx', on);
    if (!on) return;
    chip.style.setProperty('--cc', LP.ctxColor(sid));
    chip.innerHTML = `<span class="ctx-dot"></span>${sid ? '🏫' : '👤'} <b>${esc(LP.ctxName(sid))}</b> ▾`;
    chip.title = T('مكان العمل الآن — اضغطي للتبديل');
  }
  chip.onclick = () => menu(chip, (sid) => setCtx(sid), LP.ctxHome());

  // ---------- نافذة صغيرة عند فتح البرنامج (إن كانت منضمة لمدرسة) ----------
  function picker() {
    if (!LP.schools().length || $('#ctxPick')) return;
    let cur = LP.ctxHome();
    const d = document.createElement('div'); d.id = 'ctxPick'; d.className = 'gdlg on';
    d.innerHTML = `<div class="gdlg-card ctx-pick"><button class="ctx-sel" data-sel></button><button class="pri ctx-go" data-go>${T('دخول')} ↵</button></div>`;
    document.body.appendChild(d);
    const sel = d.querySelector('[data-sel]'), go = d.querySelector('[data-go]');
    const paint = () => { sel.style.setProperty('--cc', LP.ctxColor(cur)); sel.innerHTML = `<span class="ctx-dot"></span>${cur ? '🏫' : '👤'} <b>${esc(LP.ctxName(cur))}</b><span class="ctx-car">▾</span>`; };
    paint();
    sel.onclick = () => menu(sel, (sid) => { cur = sid; paint(); go.focus(); }, cur);
    const close = async () => { document.removeEventListener('keydown', key, true); d.remove(); document.querySelectorAll('.ctx-menu').forEach(m => m.remove()); await setCtx(cur); };
    go.onclick = close;
    const key = (e) => { if (!document.body.contains(d)) return document.removeEventListener('keydown', key, true); if (e.key === 'Enter' || e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); } };
    document.addEventListener('keydown', key, true);
    setTimeout(() => go.focus(), 50);
  }
  LP.ctxPicker = picker;

  document.addEventListener('lp-auth', async (e) => {
    document.querySelectorAll('#ctxPick, .ctx-menu').forEach(x => x.remove());
    if (!(e.detail && e.detail.user)) { prof = {}; updChip(); return; }
    await load(); updChip();
    if (LP.schools().length) setTimeout(picker, 400);
  });
  updChip();
})();
