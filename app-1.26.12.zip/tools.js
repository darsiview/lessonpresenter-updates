// أدوات المعلمة: بطاقات «على العجلة» و«المجموعات» و«النقاط ووقت الحصة» و«الشهادات»
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const T = (s, v) => I18N.t(s, v);
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const g = () => LP._groups;
  const open = () => $('#toolsPanel').classList.contains('on');

  async function render() {
    if (!open()) return;
    await g().ensure(false);
    const S = g().S, names = g().roster();
    // على العجلة
    const off = new Set(S ? S.removed : []);
    const on = names.filter(n => !off.has(n));
    $('#twTitle').textContent = T('على العجلة ({n})', { n: on.length });
    $('#twList').innerHTML = !names.length ? `<p class="tnote">${T('لا توجد أسماء بعد. الصقيها في خانة الأسماء.')}</p>`
      : on.map(n => `<span class="twchip">${esc(g().dn(n))}<button data-out="${esc(n)}" title="${T('إخراج من العجلة')}">−</button></span>`).join('')
        + (off.size ? `<div class="twoff">${T('خارج العجلة')}: ${[...off].map(n => `<span class="twchip out">${esc(g().dn(n))}<button data-back="${esc(n)}" title="${T('إرجاع إلى العجلة')}">↺</button></span>`).join('')}</div>` : '');
    $$('#twList [data-out]').forEach(b => b.onclick = () => { g().removeGirl(b.dataset.out); render(); });
    $$('#twList [data-back]').forEach(b => b.onclick = () => { g().returnGirl(b.dataset.back); render(); });
    $('#twAuto').checked = g().autoHide;
    // المجموعات
    const k = S ? S.groups.length : g().defaultCount(names.length);
    $('#tgCount').innerHTML = [2, 3, 4, 5, 6, 7, 8].map(i => `<option value="${i}" ${i === k ? 'selected' : ''}>${i}</option>`).join('');
    paintDots(k);
    $('#tgInfo').textContent = !names.length ? T('أضيفي أسماء الطالبات أولاً، ثم كوّني المجموعات.') : S ? T('تم تكوين {n} مجموعات.', { n: S.groups.length }) : '';
    const GC = LP.session.GCOL;
    // بطاقات المجموعات قابلة للتعديل: الضغط على اسم ثم مجموعة (نقل) أو اسم آخر (تبديل)، أو السحب بالفأرة
    $('#tgPrev').innerHTML = S ? S.groups.map((gr, i) => `<div style="--gc:${GC[i % GC.length]}" data-g="${i}" class="tg-card ${sel && g().groupOf(sel) !== i ? 'target' : ''}"><b style="color:${GC[i % GC.length]}">${esc(LP.session.groupName(i))} · ${S.gpts[i]}</b>
      <span class="tg-names">${gr.map(n => `<button class="tg-n ${n === sel ? 'sel' : ''}" draggable="true" data-n="${esc(n)}">${esc(g().dn(n))}</button>`).join('')}</span></div>`).join('')
      + `<p class="tnote tg-hint">${sel ? '✋ ' + T('«{n}» مختار: الضغط على مجموعة أخرى لنقله إليها، أو على اسم في مجموعة أخرى للتبديل.', { n: esc(g().dn(sel)) }) : '✋ ' + T('لتعديل المجموعات: الضغط على اسم ثم على مجموعة أخرى، أو السحب بالفأرة.')}</p>` : '';
    wireEdit();
  }
  // ---------- تعديل المجموعات يدوياً ----------
  let sel = null;
  const done = (msg, undo) => { sel = null; render(); LP.toast(msg, T('تراجع'), () => { undo(); render(); }, 5000); };
  const doMove = (n, gi) => { const from = g().groupOf(n); if (g().moveGirl(n, gi)) done(T('نُقل «{n}» إلى {g}', { n: g().dn(n), g: LP.session.groupName(gi) }), () => g().moveGirl(n, from)); };
  const doSwap = (a, b) => { if (g().swapGirls(a, b)) done(T('تم تبديل «{a}» و«{b}»', { a: g().dn(a), b: g().dn(b) }), () => g().swapGirls(a, b)); };
  function wireEdit() {
    $$('#tgPrev .tg-n').forEach(b => {
      b.onclick = (e) => {
        e.stopPropagation(); const n = b.dataset.n;
        if (!sel || sel === n) { sel = sel === n ? null : n; return render(); }
        if (g().groupOf(sel) === g().groupOf(n)) { sel = n; return render(); }
        doSwap(sel, n);
      };
      b.ondragstart = (e) => { e.dataTransfer.setData('text/lp-name', b.dataset.n); e.dataTransfer.effectAllowed = 'move'; };
      b.ondragover = (e) => { e.preventDefault(); };
      b.ondrop = (e) => { e.preventDefault(); e.stopPropagation(); const a = e.dataTransfer.getData('text/lp-name'); if (a && a !== b.dataset.n) { if (g().groupOf(a) === g().groupOf(b.dataset.n)) return; doSwap(a, b.dataset.n); } };
    });
    $$('#tgPrev .tg-card').forEach(c => {
      c.onclick = () => { if (sel && g().groupOf(sel) !== +c.dataset.g) doMove(sel, +c.dataset.g); };
      c.ondragover = (e) => { e.preventDefault(); c.classList.add('over'); };
      c.ondragleave = () => c.classList.remove('over');
      c.ondrop = (e) => { e.preventDefault(); c.classList.remove('over'); const a = e.dataTransfer.getData('text/lp-name'); if (a) doMove(a, +c.dataset.g); };
    });
  }
  // لون كل مجموعة (هو لون طالباتها في العجلة) بجانب اختيار العدد
  function paintDots(k) {
    let d = document.getElementById('tgDots');
    if (!d) { d = document.createElement('span'); d.id = 'tgDots'; $('#tgCount').after(d); }
    const GC = LP.session.GCOL, gn = (i) => (LP.session.groupName ? LP.session.groupName(i) : T('مجموعة {n}', { n: i + 1 }));
    d.innerHTML = Array.from({ length: k }, (_, i) => `<i style="background:${GC[i % GC.length]}" title="${esc(gn(i))}"></i>`).join('');
  }
  $('#tgCount').addEventListener('change', () => paintDots(+$('#tgCount').value));
  $('#twAuto').onchange = () => LP.setAutoHide($('#twAuto').checked);
  $('#tgMake').onclick = async () => {
    const k = +$('#tgCount').value;             // نقرأ اختيار المعلمة قبل أي تحديث للوحة
    if (!(await g().ensure(false))) { LP.toast(T('أضيفي أسماء الطالبات أولاً')); return; }
    sel = null; g().rebalance(k); g().render(); render();
    LP.toast(T('تم تكوين المجموعات ✓'));
  };
  $('#tgSession').onclick = async () => { if (await g().ensure(false)) g().sessionDialog(); };
  LP.sureBtn($('#tpReset'), () => { g().resetPoints(); render(); LP.toast(T('صُفّرت كل النقاط')); });
  $('#tpClock').onclick = () => { g().resetClock(); LP.toast(T('أُعيدت ساعة الحصة إلى الصفر')); };
  $('#tpExcel').onclick = () => { if (g().S) g().copyExcel(); };
  $('#tcResults').onclick = () => { LP.closePanels(); LP.openResults && LP.openResults(); };
  $('#tcDesign').onclick = () => { LP.closePanels(); LP.openCertSettings && LP.openCertSettings(); };
  document.addEventListener('lp-tools', render);
  document.addEventListener('lp-classes', () => setTimeout(render, 300));
  LP.renderTools = render;
})();
