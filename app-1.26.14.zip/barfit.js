// الشريط السفلي يتكيّف مع عرض الشاشة:
// - ما لا يتسع من الأدوات ينتقل إلى زر «»» ويظهر فوق بعضه في نافذة صغيرة
// - ترتيب الأدوات بالسحب (ومنها ما يُثبَّت داخل «»»)
// - فاصل بين الأدوات والتبويبات، ومقبض أعلى الشريط لتكبير الأزرار
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const bar = $('#bar'); if (!bar) return;
  const root = document.documentElement;
  const BAR_MIN = 40, BAR_MAX = 72, TABS_DEF = 140, TABS_MIN = 60;
  const winGrp = $('#moreBtn').closest('.grp');
  const toolGrps = () => [...bar.children].filter(g => g.classList.contains('grp') && g !== winGrp);
  const key = (b) => b.id || (b.dataset.tool ? 't-' + b.dataset.tool : '');
  const items = () => [...toolGrps().flatMap(g => [...g.children]), ...pinBox.children, ...autoBox.children].filter(b => b.matches('button.b') && key(b));
  const isRtl = () => getComputedStyle(bar).direction === 'rtl';

  // ---------- زر «»» ونافذته ----------
  const ovBtn = document.createElement('button');
  ovBtn.className = 'b'; ovBtn.id = 'ovfBtn'; ovBtn.style.display = 'none';
  ovBtn.dataset.tip = 'أدوات أخرى';
  ovBtn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M13 6l-6 6 6 6M19 6l-6 6 6 6"/></svg>';
  winGrp.insertBefore(ovBtn, $('#moreBtn'));
  const pop = document.createElement('div'); pop.id = 'ovfPop';
  pop.innerHTML = `<div class="ovf-box" id="ovfPin"></div><div class="ovf-box" id="ovfAuto"></div>
    <div class="ovf-foot"><button class="ovf-edit" id="ovfEdit">✎ ${T('ترتيب أدوات الشريط')}</button></div>`;
  document.body.appendChild(pop);
  const pinBox = pop.querySelector('#ovfPin'), autoBox = pop.querySelector('#ovfAuto');
  pinBox.dataset.empty = T('اسحبي أداة إلى هنا لتبقى داخل «»»');

  function placePop() {
    const r = ovBtn.getBoundingClientRect(), br = bar.getBoundingClientRect();
    pop.style.bottom = (innerHeight - br.top + 6) + 'px';
    const w = pop.offsetWidth;
    pop.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left + r.width / 2 - w / 2)) + 'px';
  }
  const openPop = (on) => { pop.classList.toggle('on', on); ovBtn.classList.toggle('popOpen', on); if (on) placePop(); };
  ovBtn.onclick = (e) => { e.stopPropagation(); if (edit) return; openPop(!pop.classList.contains('on')); };
  document.addEventListener('pointerdown', (e) => {
    if (edit || !pop.classList.contains('on')) return;
    if (!pop.contains(e.target) && !ovBtn.contains(e.target)) openPop(false);
  }, true);
  // الضغط على أداة داخل النافذة: تعمل ثم تُغلق النافذة (قوائم الأدوات تُفتح في مكانها المعتاد)
  pop.addEventListener('click', (e) => { if (!edit && e.target.closest('button.b')) setTimeout(() => openPop(false), 0); });
  pop.querySelector('#ovfEdit').onclick = () => startEdit();

  // ---------- الإعدادات المحفوظة ----------
  // lay = { groups: [[مفاتيح]…], pin: [مفاتيح], tabsW, barH }
  let lay = {}, defaults = null;
  function snapDefaults() { if (!defaults) defaults = toolGrps().map(g => [...g.children].filter(b => b.matches('button.b')).map(key).filter(Boolean)); }
  const save = () => api.setSettings({ barLay: lay });

  // يعيد كل أداة إلى مكانها حسب الترتيب المحفوظ (ثم يُحسب ما لا يتسع)
  function rebuild() {
    snapDefaults();
    const all = new Map(items().map(b => [key(b), b]));
    const gs = toolGrps(), used = new Set();
    const order = (lay.groups && lay.groups.length === gs.length) ? lay.groups : defaults;
    gs.forEach((g, i) => {
      for (const k of order[i] || []) { const b = all.get(k); if (b && !used.has(k) && !(lay.pin || []).includes(k)) { g.appendChild(b); used.add(k); } }
    });
    for (const k of lay.pin || []) { const b = all.get(k); if (b && !used.has(k)) { pinBox.appendChild(b); used.add(k); } }
    // أداة جديدة لم تكن في الترتيب المحفوظ: إلى مجموعتها الأصلية
    for (const [k, b] of all) if (!used.has(k)) {
      const gi = defaults.findIndex(a => a.includes(k));
      (gs[gi >= 0 ? gi : gs.length - 1]).appendChild(b);
    }
  }
  // ما لا يتسع: من آخر الأدوات إلى أولها (أدوات الرسم آخر ما ينتقل)
  const markEmpty = (g) => g.classList.toggle('gEmpty', !edit && !g.querySelector('button'));
  let fitting = false;
  function fit() {
    if (fitting) return; fitting = true;
    try {
      rebuild();
      toolGrps().forEach(markEmpty);
      bar.classList.toggle('editing', !!edit);
      if (!edit) {
        const order = toolGrps().flatMap(g => [...g.children].filter(b => b.matches('button.b')));
        const over = () => bar.scrollWidth > bar.clientWidth + 1;
        // أول ما يُختصر: تبويبات بلا عنوان
        ovBtn.style.display = '';       // يُحسب مكانه قبل القياس
        for (let i = order.length - 1; i >= 0 && over(); i--) { const g = order[i].parentNode; autoBox.insertBefore(order[i], autoBox.firstChild); markEmpty(g); }
      }
      const n = pinBox.children.length + autoBox.children.length;
      ovBtn.style.display = (n || edit) ? '' : 'none';
      pop.classList.toggle('hasPin', pinBox.children.length > 0);
      pop.classList.toggle('hasAuto', autoBox.children.length > 0);
      markOn();
      if (pop.classList.contains('on')) placePop();
    } finally { fitting = false; watch(); mo.takeRecords(); }
  }
  // نقطة على «»» إن كانت أداة مختارة داخله (مثل القلم)
  function markOn() { ovBtn.classList.toggle('hasOn', !!pop.querySelector('button.b.on')); }
  new MutationObserver(markOn).observe(pop, { subtree: true, attributes: true, attributeFilter: ['class'] });

  let raf = 0;
  const refit = () => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; fit(); }); };
  const ro = new ResizeObserver(refit);
  ro.observe(bar);
  ['#recPill', '#trialPill', '#gbCtx', '#bellBtn', '#allTabs'].forEach(s => { const el = $(s); if (el) ro.observe(el); });
  // أزرار تضيفها أجزاء أخرى من البرنامج لاحقاً
  const mo = new MutationObserver(() => { if (!fitting && !dragging) refit(); });
  const watch = () => { mo.disconnect(); [...toolGrps(), winGrp].forEach(g => mo.observe(g, { childList: true })); };

  // ---------- الفاصل بين الأدوات والتبويبات ----------
  const drag = bar.querySelector('.drag');
  const split = document.createElement('div'); split.id = 'barSplit'; split.title = T('اسحبي لتوسيع التبويبات أو الأدوات');
  drag.before(split);
  const setTabsW = (w) => { lay.tabsW = Math.round(Math.max(TABS_MIN, Math.min(w, bar.clientWidth * 0.7))); root.style.setProperty('--tabsMin', lay.tabsW + 'px'); };
  split.addEventListener('pointerdown', (e) => {
    e.preventDefault(); split.setPointerCapture(e.pointerId); split.classList.add('on');
    const r = drag.getBoundingClientRect(), rtl = isRtl();
    const far = rtl ? r.left : r.right;           // طرف التبويبات الثابت (جهة أزرار النافذة)
    const mv = (ev) => { setTabsW(rtl ? ev.clientX - far : far - ev.clientX); refit(); };
    const up = () => { split.classList.remove('on'); split.removeEventListener('pointermove', mv); split.removeEventListener('pointerup', up); split.removeEventListener('pointercancel', up); save(); };
    split.addEventListener('pointermove', mv); split.addEventListener('pointerup', up); split.addEventListener('pointercancel', up);
  });
  split.ondblclick = () => { delete lay.tabsW; root.style.setProperty('--tabsMin', TABS_DEF + 'px'); save(); refit(); };

  // ---------- تكبير الأزرار: سحب الحافة العليا للشريط ----------
  const grip = document.createElement('div'); grip.id = 'barGrip'; grip.title = T('اسحبي للأعلى لتكبير الأزرار');
  bar.appendChild(grip);
  const setBarH = (h) => { lay.barH = Math.round(Math.max(BAR_MIN, Math.min(BAR_MAX, h))); root.style.setProperty('--barH', lay.barH + 'px'); };
  grip.addEventListener('pointerdown', (e) => {
    e.preventDefault(); grip.setPointerCapture(e.pointerId); grip.classList.add('on');
    const y0 = e.clientY, h0 = bar.offsetHeight;
    const mv = (ev) => { setBarH(h0 + (y0 - ev.clientY)); refit(); };
    const up = () => { grip.classList.remove('on'); grip.removeEventListener('pointermove', mv); grip.removeEventListener('pointerup', up); grip.removeEventListener('pointercancel', up); save(); window.dispatchEvent(new Event('resize')); };
    grip.addEventListener('pointermove', mv); grip.addEventListener('pointerup', up); grip.addEventListener('pointercancel', up);
  });
  grip.ondblclick = () => { delete lay.barH; root.style.setProperty('--barH', BAR_MIN + 'px'); save(); refit(); window.dispatchEvent(new Event('resize')); };

  // ---------- ترتيب الأدوات بالسحب ----------
  let edit = false, dragging = null;
  const hint = document.createElement('div'); hint.id = 'barEditHint';
  hint.innerHTML = `<span>✋ ${T('اسحبي أي أداة إلى مكان آخر في الشريط، أو إلى «»» لتبقى فيه دائماً.')}</span>
    <button id="beReset">${T('الترتيب الأصلي')}</button><button class="pri" id="beDone">${T('تم')}</button>`;
  document.body.appendChild(hint);
  function startEdit() {
    LP.closePanels && LP.closePanels();
    edit = true; document.body.classList.add('barEdit');
    fit(); openPop(true);
  }
  function endEdit() {
    edit = false; document.body.classList.remove('barEdit');
    openPop(false); fit();
  }
  LP.editBar = startEdit;
  hint.querySelector('#beDone').onclick = endEdit;
  hint.querySelector('#beReset').onclick = () => { delete lay.groups; delete lay.pin; save(); fit(); openPop(true); };
  document.addEventListener('keydown', (e) => { if (edit && (e.key === 'Escape' || e.key === 'Enter')) { e.preventDefault(); e.stopPropagation(); endEdit(); } }, true);
  // في وضع الترتيب لا تعمل الأدوات عند الضغط
  const block = (e) => { if (edit && e.target.closest('#bar button.b, #ovfPop button.b')) { e.preventDefault(); e.stopPropagation(); } };
  document.addEventListener('click', block, true);

  const ph = document.createElement('div'); ph.className = 'barPh';
  function dropAt(x, y) {
    const el = document.elementFromPoint(x, y); if (!el) return;
    const box = el.closest('#ovfPin, #ovfAuto, #ovfPop') ? pinBox : el.closest('#bar .grp');
    if (!box || box === winGrp) return;
    const tgt = el.closest('button.b');
    if (tgt && tgt !== dragging && box.contains(tgt)) {
      const r = tgt.getBoundingClientRect(), mid = x > r.left + r.width / 2;
      tgt[(isRtl() ? !mid : mid) ? 'after' : 'before'](ph);
    } else if (!tgt && !box.contains(ph)) box.appendChild(ph);
  }
  document.addEventListener('pointerdown', (e) => {
    if (!edit) return;
    const b = e.target.closest('#bar .grp button.b, #ovfPop button.b');
    if (!b || winGrp.contains(b) || !key(b)) return;
    e.preventDefault(); e.stopPropagation();
    const r = b.getBoundingClientRect();
    const ghost = b.cloneNode(true); ghost.id = ''; ghost.className = 'b barGhost';
    ghost.style.cssText = `position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
    document.body.appendChild(ghost);
    dragging = b; b.classList.add('barDragging'); b.after(ph);
    const dx = e.clientX - r.left, dy = e.clientY - r.top;
    const mv = (ev) => { ghost.style.left = (ev.clientX - dx) + 'px'; ghost.style.top = (ev.clientY - dy) + 'px'; dropAt(ev.clientX, ev.clientY); };
    const up = () => {
      document.removeEventListener('pointermove', mv, true); document.removeEventListener('pointerup', up, true); document.removeEventListener('pointercancel', up, true);
      ghost.remove(); b.classList.remove('barDragging');
      if (ph.parentNode) ph.replaceWith(b);
      dragging = null;
      // حفظ الترتيب كما يظهر الآن
      lay.groups = toolGrps().map(g => [...g.children].filter(x => x.matches('button.b')).map(key).filter(Boolean));
      lay.pin = [...pinBox.children].filter(x => x.matches('button.b')).map(key).filter(Boolean);
      save(); fit(); placePop();
    };
    document.addEventListener('pointermove', mv, true); document.addEventListener('pointerup', up, true); document.addEventListener('pointercancel', up, true);
  }, true);

  // عنصر في قائمة «المزيد»
  const hb = $('#hideBar');
  if (hb) {
    const mi = document.createElement('button'); mi.className = 'mi'; mi.id = 'editBarMi';
    mi.innerHTML = `<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h10M4 17h7"/><path d="M17 14l3 3-3 3"/></svg><span>${T('ترتيب أدوات الشريط')}</span>`;
    hb.after(mi); mi.onclick = () => setTimeout(startEdit, 0);
  }

  // ---------- التحميل ----------
  function applyLay() {
    root.style.setProperty('--barH', (lay.barH || BAR_MIN) + 'px');
    root.style.setProperty('--tabsMin', (lay.tabsW || TABS_DEF) + 'px');
    fit();
  }
  async function load() { const p = await api.getSettings().catch(() => ({})); lay = (p && p.barLay) || {}; applyLay(); }
  document.addEventListener('lp-auth', () => setTimeout(load, 50));
  snapDefaults(); load();
})();
