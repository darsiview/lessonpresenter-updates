// الشريط السفلي يتكيّف مع عرض الشاشة — كل مجموعة مستقلة:
// - لكل مجموعة سهم «» في طرفها يفتح فوقها ما اختفى منها فقط
// - داخل نافذة السهم: سحب أداة إلى الشريط أو من الشريط إلى الداخل (تبديل ما يظهر)
// - الخط الفاصل بعد كل مجموعة يُسحب لتضييقها أو توسيعها (نقرتان = عرضها الكامل)
// - «ترتيب أدوات الشريط»: نقل الأدوات بين المجموعات
// - فاصل بين الأدوات والتبويبات، ومقبض أعلى الشريط لتكبير الأزرار
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const bar = $('#bar'); if (!bar) return;
  const root = document.documentElement;
  const BAR_MIN = 40, BAR_MAX = 72, TABS_DEF = 140, TABS_MIN = 60, DRAG_PX = 6;
  const winGrp = $('#moreBtn').closest('.grp');
  const toolGrps = () => [...bar.children].filter(g => g.classList.contains('grp') && g !== winGrp);
  const key = (b) => b.id || (b.dataset.tool ? 't-' + b.dataset.tool : '');
  const isTool = (b) => b && b.matches && b.matches('button.b') && !b.classList.contains('gov') && !!key(b);
  const isRtl = () => getComputedStyle(bar).direction === 'rtl';
  const drag = bar.querySelector('.drag');
  const grpTools = (g) => [...g.children].filter(isTool);

  // مخزن مخفي لأدوات كل مجموعة غير الظاهرة (تبقى في الصفحة لتعمل اختصارات لوحة المفاتيح)
  const stashRoot = document.createElement('div'); stashRoot.id = 'barStash'; stashRoot.hidden = true;
  document.body.appendChild(stashRoot);
  const G = [];   // { el, ov, sep, stash, n }
  function initGroups() {
    toolGrps().forEach((el, i) => {
      if (G[i] && G[i].el === el) return;
      const ov = document.createElement('button'); ov.className = 'b gov'; ov.dataset.tip = 'المزيد من هذه المجموعة';
      ov.innerHTML = '<svg viewBox="0 0 24 24"><path d="M13 6l-6 6 6 6M19 6l-6 6 6 6"/></svg>';
      const sep = document.createElement('div'); sep.className = 'gsep'; sep.title = T('اسحبي لتضييق المجموعة أو توسيعها — نقرتان: عرضها الكامل');
      const stash = document.createElement('div'); stashRoot.appendChild(stash);
      el.classList.add('tg');
      G[i] = { el, ov, sep, stash, n: 0 };
      ov.addEventListener('click', (e) => { e.stopPropagation(); if (edit) return; if (openG === i) closePop(); else openPop(i); });
      sep.addEventListener('pointerdown', (e) => sepDrag(e, i));
      sep.addEventListener('dblclick', () => { if (lay.cap) delete lay.cap[i]; save(); refit(); });
    });
  }

  // ---------- الإعدادات المحفوظة ----------
  // lay = { groups: [[مفاتيح]…], cap: { رقم المجموعة: عدد الظاهر }, tabsW, barH }
  let lay = {}, defaults = null;
  const save = () => api.setSettings({ barLay: lay });
  function snapDefaults() { if (!defaults) defaults = toolGrps().map(g => grpTools(g).map(key)); }
  const allTools = () => [...toolGrps().flatMap(grpTools), ...[...stashRoot.querySelectorAll('button.b')], ...[...pop.querySelectorAll('button.b')]].filter(isTool);

  // ترتيب كل مجموعة (المحفوظ + أي أداة جديدة في مجموعتها الأصلية)
  function orders() {
    const all = new Map(allTools().map(b => [key(b), b]));
    const saved = (lay.groups && lay.groups.length === G.length) ? lay.groups : defaults;
    const used = new Set(), out = G.map(() => []);
    saved.forEach((ks, i) => ks.forEach(k => { const b = all.get(k); if (b && !used.has(k) && out[i]) { out[i].push(b); used.add(k); } }));
    for (const [k, b] of all) if (!used.has(k)) { const gi = defaults.findIndex(a => a.includes(k)); out[gi >= 0 ? gi : G.length - 1].push(b); }
    return out;
  }
  // أداة مخفية بتنسيق البرنامج (مثل التسجيل في Android) لا تُحسب
  const shown = (b) => getComputedStyle(b).display !== 'none';

  // يرسم المجموعة: أول n أداة ظاهرة، ثم السهم، ثم الخط الفاصل؛ والباقي في المخزن
  function render(i, list, n) {
    const g = G[i]; g.n = n; let c = 0;
    for (const b of list) {
      if (!shown0.get(b)) { g.el.appendChild(b); continue; }   // لا تشغل مكاناً
      if (c < n) { g.el.appendChild(b); c++; } else g.stash.appendChild(b);
    }
    const hid = g.stash.children.length > 0;
    g.ov.style.display = hid && !edit ? '' : 'none';
    g.el.appendChild(g.ov); g.el.appendChild(g.sep);
    g.el.classList.toggle('gEmpty', !edit && !list.length);
    g.ov.classList.toggle('hasOn', !!g.stash.querySelector('button.b.on'));
  }
  let shown0 = new Map(), lists = [];
  let fitting = false;
  function fit() {
    if (fitting) return; fitting = true;
    try {
      const reopen = openG; if (openG != null) closePop(true);
      drag.style.minWidth = '';
      initGroups(); snapDefaults();
      lists = orders();
      // كل الأدوات في مجموعاتها أولاً لمعرفة الظاهر منها
      lists.forEach((l, i) => l.forEach(b => G[i].el.appendChild(b)));
      shown0 = new Map(lists.flat().map(b => [b, shown(b)]));
      const cnt = (i) => lists[i].filter(b => shown0.get(b)).length;
      bar.classList.toggle('editing', !!edit);
      lists.forEach((l, i) => {
        const cap = !edit && lay.cap && lay.cap[i] != null ? Math.max(1, Math.min(lay.cap[i], cnt(i))) : cnt(i);
        render(i, l, cap);
      });
      if (!edit) {
        const over = () => bar.scrollWidth > bar.clientWidth + 1;
        // يُختصر من آخر الشريط أولاً، وتبقى أداة واحدة على الأقل مع سهمها؛ أدوات الرسم آخر ما يُختصر
        for (let i = G.length - 1; i >= 0 && over(); i--) {
          while (over() && G[i].n > 1) render(i, lists[i], G[i].n - 1);
        }
        // الشاشة ضيقة جداً: تضييق التبويبات، ثم مجموعات بسهمها فقط
        if (over()) drag.style.minWidth = TABS_MIN + 'px';
        for (let i = G.length - 1; i >= 0 && over(); i--) render(i, lists[i], 0);
      }
      if (reopen != null && G[reopen] && G[reopen].stash.children.length) openPop(reopen);
    } finally { fitting = false; watch(); mo.takeRecords(); }
  }
  let raf = 0;
  const refit = () => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; if (!dragging) fit(); }); };
  const ro = new ResizeObserver(refit);
  ro.observe(bar);
  ['#recPill', '#trialPill', '#gbCtx', '#bellBtn', '#allTabs'].forEach(s => { const el = $(s); if (el) ro.observe(el); });
  // أزرار تضيفها أجزاء أخرى من البرنامج لاحقاً
  const mo = new MutationObserver(() => { if (!fitting && !dragging) refit(); });
  const watch = () => { mo.disconnect(); [...toolGrps(), winGrp].forEach(g => mo.observe(g, { childList: true })); };
  // نقطة على سهم المجموعة إن كانت الأداة المختارة داخله (مثل القلم)
  new MutationObserver(() => G.forEach(g => g.ov.classList.toggle('hasOn', !!g.stash.querySelector('button.b.on'))))
    .observe(stashRoot, { subtree: true, attributes: true, attributeFilter: ['class'] });

  // ---------- نافذة سهم المجموعة ----------
  const pop = document.createElement('div'); pop.id = 'ovfPop';
  pop.innerHTML = `<div class="ovf-box" id="ovfBox"></div><div class="ovf-hint">${T('اسحبي أداة إلى الشريط لتظهر، أو من الشريط إلى هنا')}</div>`;
  document.body.appendChild(pop);
  const box = pop.querySelector('#ovfBox');
  let openG = null;
  function placePop() {
    if (openG == null) return;
    const r = G[openG].ov.getBoundingClientRect(), gr = G[openG].el.getBoundingClientRect(), br = bar.getBoundingClientRect();
    pop.style.bottom = (innerHeight - br.top + 6) + 'px';
    const w = pop.offsetWidth, cx = (gr.left + gr.right) / 2;
    pop.style.left = Math.max(8, Math.min(innerWidth - w - 8, cx - w / 2)) + 'px';
    pop.style.setProperty('--ax', (r.left + r.width / 2 - parseFloat(pop.style.left)) + 'px');
  }
  function openPop(i) {
    closePop(true);
    LP.closePanels && LP.closePanels();
    openG = i; const g = G[i];
    while (g.stash.firstChild) box.appendChild(g.stash.firstChild);
    pop.classList.add('on'); g.ov.classList.add('popOpen'); g.el.classList.add('gOpen');
    placePop();
  }
  function closePop(quiet) {
    if (openG == null) return;
    const g = G[openG];
    while (box.firstChild) { const b = box.firstChild; if (b === ph) { b.remove(); continue; } g.stash.appendChild(b); }
    pop.classList.remove('on'); g.ov.classList.remove('popOpen'); g.el.classList.remove('gOpen');
    openG = null;
  }
  document.addEventListener('pointerdown', (e) => {
    if (openG == null || dragging) return;
    if (!pop.contains(e.target) && !G[openG].el.contains(e.target)) closePop();
  }, true);
  window.addEventListener('blur', () => closePop());
  // الضغط على أداة داخل النافذة: تعمل ثم تُغلق النافذة (قوائم الأدوات تُفتح في مكانها المعتاد)
  pop.addEventListener('click', (e) => { if (e.target.closest('button.b') && !justDragged) setTimeout(() => closePop(), 0); }, true);

  // ---------- السحب داخل المجموعة المفتوحة (تبديل الظاهر والمخفي) ----------
  const ph = document.createElement('div'); ph.className = 'barPh';
  let dragging = null, justDragged = false;
  // أين تقع الأداة لو أُفلتت هنا: داخل النافذة، أو بين أدوات المجموعة في الشريط
  function placePh(x, y, area) {
    const el = document.elementFromPoint(x, y); if (!el) return;
    let host = null;
    if (el.closest('#ovfPop')) host = box;
    else if (area === 'group' && el.closest('.grp') === G[openG].el) host = G[openG].el;
    else if (area === 'any') { const g = el.closest('#bar .grp'); if (g && g !== winGrp) host = g; else if (el.closest('#ovfPop')) host = box; }
    if (!host) return;
    const tgt = el.closest('button.b');
    if (tgt && tgt !== dragging && isTool(tgt) && host.contains(tgt)) {
      const r = tgt.getBoundingClientRect(), mid = x > r.left + r.width / 2;
      tgt[(isRtl() ? !mid : mid) ? 'after' : 'before'](ph);
    } else if (!host.contains(ph)) {
      const stop = host === box ? null : host.querySelector('.gov');
      host.insertBefore(ph, stop);
    }
  }
  function startDrag(e, b, area, onDrop) {
    const x0 = e.clientX, y0 = e.clientY, r = b.getBoundingClientRect();
    let ghost = null;
    const begin = () => {
      dragging = b;
      ghost = b.cloneNode(true); ghost.removeAttribute('id'); ghost.className = 'b barGhost';
      ghost.style.cssText = `position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
      document.body.appendChild(ghost);
      b.classList.add('barDragging'); b.after(ph);
    };
    const mv = (ev) => {
      if (!dragging) { if (Math.hypot(ev.clientX - x0, ev.clientY - y0) < DRAG_PX) return; begin(); }
      ev.preventDefault();
      ghost.style.left = (ev.clientX - (x0 - r.left)) + 'px'; ghost.style.top = (ev.clientY - (y0 - r.top)) + 'px';
      placePh(ev.clientX, ev.clientY, area);
    };
    const up = () => {
      document.removeEventListener('pointermove', mv, true); document.removeEventListener('pointerup', up, true); document.removeEventListener('pointercancel', up, true);
      if (!dragging) return;          // ضغطة عادية: تعمل الأداة
      ghost.remove(); b.classList.remove('barDragging');
      justDragged = true; setTimeout(() => { justDragged = false; }, 50);
      onDrop(ph.parentNode ? ph : null);
      ph.remove(); dragging = null;
    };
    document.addEventListener('pointermove', mv, true); document.addEventListener('pointerup', up, true); document.addEventListener('pointercancel', up, true);
  }
  // بعد السحب لا تعمل الأداة بالضغطة نفسها
  document.addEventListener('click', (e) => {
    if ((justDragged || edit) && e.target.closest('#bar .grp button.b:not(.gov), #ovfPop button.b')) { e.preventDefault(); e.stopPropagation(); }
  }, true);

  // سحب في المجموعة المفتوحة: عدد الظاهر ثابت، فما يدخل الشريط يُخرج آخر ظاهر إلى النافذة والعكس
  document.addEventListener('pointerdown', (e) => {
    if (edit || openG == null || e.button > 0) return;
    const i = openG, g = G[i];
    const b = e.target.closest('button.b'); if (!isTool(b)) return;
    if (!(box.contains(b) || g.el.contains(b))) return;
    startDrag(e, b, 'group', (at) => {
      if (!at) return;
      const fromBox = !g.el.contains(b) || box.contains(b);
      // الترتيب كما يظهر بعد الإفلات
      const seq = (host) => [...host.children].filter(x => x === ph || (isTool(x) && x !== b)).map(x => x === ph ? b : x);
      let vis = seq(g.el), hid = seq(box);
      const cnt = (l) => l.filter(x => shown0.get(x) !== false).length;
      // دخلت أداة إلى الشريط: آخر ظاهرة (غيرها) تنتقل إلى النافذة
      if (cnt(vis) > g.n) { const out = vis.filter(x => x !== b && shown0.get(x) !== false).pop(); vis = vis.filter(x => x !== out); hid = [out, ...hid]; }
      // خرجت أداة من الشريط: أول مخفية (غيرها) تظهر مكانها
      if (cnt(vis) < g.n) { const inn = hid.find(x => x !== b && shown0.get(x) !== false); if (inn) { hid = hid.filter(x => x !== inn); vis = [...vis, inn]; } }
      const order = [...vis, ...hid].map(key);
      lay.groups = lists.map((l, j) => j === i ? order : l.map(key));
      if (lay.cap && lay.cap[i] != null) lay.cap[i] = g.n;
      save(); fit(); if (openG !== i && G[i].stash.children.length) openPop(i);
    });
  }, true);

  // ---------- الخط الفاصل: تضييق المجموعة وتوسيعها ----------
  function sepDrag(e, i) {
    e.preventDefault(); e.stopPropagation(); closePop(true);
    const sep = G[i].sep; sep.setPointerCapture(e.pointerId); sep.classList.add('on');
    const x0 = e.clientX, n0 = G[i].n, total = lists[i].filter(b => shown0.get(b)).length;
    const step = (parseFloat(getComputedStyle(root).getPropertyValue('--barH')) || 40) - 12 + 3;
    const mv = (ev) => {
      const d = isRtl() ? x0 - ev.clientX : ev.clientX - x0;       // بعيداً عن المجموعة = توسيع
      const n = Math.max(1, Math.min(total, n0 + Math.round(d / step)));
      lay.cap = lay.cap || {};
      if (n >= total) delete lay.cap[i]; else lay.cap[i] = n;
      fit();
    };
    const up = () => { sep.classList.remove('on'); sep.removeEventListener('pointermove', mv); sep.removeEventListener('pointerup', up); sep.removeEventListener('pointercancel', up); save(); };
    sep.addEventListener('pointermove', mv); sep.addEventListener('pointerup', up); sep.addEventListener('pointercancel', up);
  }

  // ---------- الفاصل بين الأدوات والتبويبات ----------
  const split = document.createElement('div'); split.id = 'barSplit'; split.title = T('اسحبي لتوسيع التبويبات أو الأدوات');
  drag.before(split);
  const setTabsW = (w) => { lay.tabsW = Math.round(Math.max(TABS_MIN, Math.min(w, bar.clientWidth * 0.7))); root.style.setProperty('--tabsMin', lay.tabsW + 'px'); };
  split.addEventListener('pointerdown', (e) => {
    e.preventDefault(); split.setPointerCapture(e.pointerId); split.classList.add('on'); closePop(true);
    const r = drag.getBoundingClientRect(), rtl = isRtl();
    const far = rtl ? r.left : r.right;           // طرف التبويبات الثابت (جهة أزرار النافذة)
    const mv = (ev) => { setTabsW(rtl ? ev.clientX - far : far - ev.clientX); fit(); };
    const up = () => { split.classList.remove('on'); split.removeEventListener('pointermove', mv); split.removeEventListener('pointerup', up); split.removeEventListener('pointercancel', up); save(); };
    split.addEventListener('pointermove', mv); split.addEventListener('pointerup', up); split.addEventListener('pointercancel', up);
  });
  split.ondblclick = () => { delete lay.tabsW; root.style.setProperty('--tabsMin', TABS_DEF + 'px'); save(); refit(); };

  // ---------- تكبير الأزرار: سحب الحافة العليا للشريط ----------
  const grip = document.createElement('div'); grip.id = 'barGrip'; grip.title = T('اسحبي للأعلى لتكبير الأزرار');
  bar.appendChild(grip);
  const setBarH = (h) => { lay.barH = Math.round(Math.max(BAR_MIN, Math.min(BAR_MAX, h))); root.style.setProperty('--barH', lay.barH + 'px'); };
  grip.addEventListener('pointerdown', (e) => {
    e.preventDefault(); grip.setPointerCapture(e.pointerId); grip.classList.add('on'); closePop(true);
    const y0 = e.clientY, h0 = bar.offsetHeight;
    const mv = (ev) => { setBarH(h0 + (y0 - ev.clientY)); refit(); };
    const up = () => { grip.classList.remove('on'); grip.removeEventListener('pointermove', mv); grip.removeEventListener('pointerup', up); grip.removeEventListener('pointercancel', up); save(); window.dispatchEvent(new Event('resize')); };
    grip.addEventListener('pointermove', mv); grip.addEventListener('pointerup', up); grip.addEventListener('pointercancel', up);
  });
  grip.ondblclick = () => { delete lay.barH; root.style.setProperty('--barH', BAR_MIN + 'px'); save(); refit(); window.dispatchEvent(new Event('resize')); };

  // ---------- «ترتيب أدوات الشريط»: نقل الأدوات بين المجموعات ----------
  let edit = false;
  const hint = document.createElement('div'); hint.id = 'barEditHint';
  hint.innerHTML = `<span>✋ ${T('اسحبي أي أداة إلى مكان آخر أو إلى مجموعة أخرى في الشريط.')}</span>
    <button id="beReset">${T('الترتيب الأصلي')}</button><button class="pri" id="beDone">${T('تم')}</button>`;
  document.body.appendChild(hint);
  function startEdit() { closePop(true); LP.closePanels && LP.closePanels(); edit = true; document.body.classList.add('barEdit'); fit(); }
  function endEdit() { edit = false; document.body.classList.remove('barEdit'); fit(); }
  LP.editBar = startEdit;
  hint.querySelector('#beDone').onclick = endEdit;
  hint.querySelector('#beReset').onclick = () => { lay = { tabsW: lay.tabsW, barH: lay.barH }; save(); fit(); };
  document.addEventListener('keydown', (e) => {
    if (edit && (e.key === 'Escape' || e.key === 'Enter')) { e.preventDefault(); e.stopPropagation(); endEdit(); }
    else if (openG != null && e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closePop(); }
  }, true);
  document.addEventListener('pointerdown', (e) => {
    if (!edit || e.button > 0) return;
    const b = e.target.closest('#bar .grp button.b'); if (!isTool(b) || winGrp.contains(b)) return;
    e.preventDefault();
    startDrag(e, b, 'any', (at) => {
      if (!at) return;
      at.replaceWith(b);
      lay.groups = G.map(g => grpTools(g.el).map(key));
      save(); fit();
    });
  }, true);

  // عنصر في قائمة «المزيد»
  const hb = $('#hideBar');
  if (hb) {
    const mi = document.createElement('button'); mi.className = 'mi'; mi.id = 'editBarMi';
    mi.innerHTML = `<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h10M4 17h7"/><path d="M17 14l3 3-3 3"/></svg><span>${T('ترتيب أدوات الشريط')}</span>`;
    hb.after(mi); mi.onclick = () => setTimeout(startEdit, 0);
  }

  // ---------- التحميل ----------
  function applyLay() {
    root.style.setProperty('--barH', (lay.barH || BAR_MIN) + 'px');
    root.style.setProperty('--tabsMin', (lay.tabsW || TABS_DEF) + 'px');
    fit();
  }
  async function load() { const p = await api.getSettings().catch(() => ({})); lay = (p && p.barLay) || {}; delete lay.pin; applyLay(); }
  document.addEventListener('lp-auth', () => setTimeout(load, 50));
  initGroups(); snapDefaults(); load();
})();
