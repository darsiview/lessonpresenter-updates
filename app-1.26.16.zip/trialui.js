// التحديث والنسخة التجريبية دون ازدحام الشريط:
// - «نسخة تجريبية» في قائمة مكان العمل وأسفل الإعدادات؛ آخر 3 أيام نقطة برتقالية
// - التحديث الجاهز: نقطة خضراء على «⋯» و«الإعدادات»، وشريط في أعلى الإعدادات
// - بعد التحديث: رسالة واحدة «تم التحديث»
(() => {
  const api = window.api;
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const left = (n) => T(n === 1 ? 'تبقى يوم واحد' : n === 2 ? 'تبقى يومان' : 'تبقى {n} أيام', { n });
  const pill = document.createElement('button'); pill.id = 'trialPill'; pill.style.display = 'none';
  const bar = document.getElementById('bar'); if (bar) bar.prepend(pill);
  let lockEl = null, ready = null, last = null;
  async function refresh() {
    const st = await api.updState().catch(() => null); if (!st) return;
    last = st;
    // «نسخة تجريبية» خارج الشريط: سطر في قائمة مكان العمل وأسفل الإعدادات.
    // آخر 3 أيام: نقطة برتقالية على زر مكان العمل؛ ومن ليس لديه مدرسة يرى تنبيهاً صغيراً بدلاً منها
    const warn = st.trial && !st.locked && st.daysLeft <= 3;
    document.body.classList.toggle('trialWarn', !!warn);
    if (warn && !document.body.classList.contains('hasCtx')) {
      pill.style.display = ''; pill.className = 'warn';
      pill.textContent = '🧪 ' + (st.daysLeft > 0 ? left(st.daysLeft) : T('اليوم آخر يوم'));
      pill.title = T('تنتهي النسخة التجريبية في {d}. التحديثات تمدد المدة تلقائياً.', { d: st.expires });
    } else pill.style.display = 'none';
    if (st.locked) lock(st); else if (lockEl) { lockEl.remove(); lockEl = null; }
    if (st.ready) setReady(st.ready);
    // بعد التحديث: رسالة واحدة
    let prev = null; try { prev = localStorage.getItem('lp-ver'); localStorage.setItem('lp-ver', st.version); } catch {}
    if (prev && prev !== st.version) setTimeout(() => LP.toast('✓ ' + T('تم التحديث إلى {v}', { v: st.version }) + (st.notes ? ' — ' + st.notes : ''), null, null, 8000), 2500);
  }
  pill.onclick = () => LP.openSettings && LP.openSettings('me');
  function setReady(rd) {
    if (!rd) return; ready = rd;
    document.body.classList.add('updReady');
    paintBanner();
  }
  // شريط في أعلى الإعدادات (يظهر في كل التبويبات، ولـ«الضيف» أيضاً)
  function paintBanner() {
    const panel = document.getElementById('setPanel'), body = document.getElementById('setBody');
    if (!panel || !body) return;
    let b = document.getElementById('updBanner');
    if (!ready) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('div'); b.id = 'updBanner'; panel.insertBefore(b, body); }
    b.innerHTML = `<span>⬆ <b>${T('النسخة {v} جاهزة', { v: esc(ready.version) })}</b>${ready.notes ? ' — ' + esc(ready.notes) : ''}</span><button class="pri" id="updGo">${T('إعادة التشغيل الآن')}</button><small>${T('أو تُطبَّق تلقائياً عند فتح البرنامج في المرة القادمة')}</small>`;
    b.querySelector('#updGo').onclick = () => api.updRestart();
  }
  // رقم النسخة وزر التحقق في أسفل الإعدادات لكل التبويبات (ومنها «الضيف»)
  function paintFooter() {
    const panel = document.getElementById('setPanel'); if (!panel || !last) return;
    let f = document.getElementById('updFoot');
    if (!f) { f = document.createElement('div'); f.id = 'updFoot'; panel.appendChild(f); }
    f.innerHTML = `<span>${T('عارض الدروس — النسخة {v}', { v: esc(last.version) })}${last.trial ? ' · ' + T('تجريبية حتى {d} ({n} يوماً)', { d: esc(last.expires), n: Math.max(0, last.daysLeft) }) : ''}</span><button class="pbtn" id="updChk">🔄 ${T('التحقق من التحديث')}</button>`;
    f.querySelector('#updChk').onclick = () => checkNow(true);
  }
  new MutationObserver(() => { if (document.getElementById('setPanel').classList.contains('on')) { paintBanner(); paintFooter(); } })
    .observe(document.getElementById('setPanel'), { attributes: true, attributeFilter: ['class'] });
  function lock(st) {
    if (!lockEl) { lockEl = document.createElement('div'); lockEl.id = 'trialLock'; document.body.appendChild(lockEl); }
    lockEl.innerHTML = `<div class="tl-card"><div class="tl-ic">⏳</div>
      <h2>${T(st.message ? 'هذه النسخة متوقفة' : 'انتهت فترة التجربة لهذه النسخة')}</h2>
      <p>${st.message ? esc(st.message) : T('شكراً لتجربتكِ عارض الدروس. اتصلي بالإنترنت واضغطي «التحقق من التحديث» للحصول على النسخة الأحدث.')}</p>
      <p class="tl-v">${T('النسخة {v}', { v: esc(st.version) })}</p>
      <button class="pri" id="tlCheck">🔄 ${T('التحقق من التحديث')}</button><p class="tl-msg" id="tlMsg"></p>
      <p class="tl-note">${T('بياناتكِ محفوظة في مجلد «بيانات» ولا تُحذف.')}</p></div>`;
    lockEl.querySelector('#tlCheck').onclick = async () => {
      const m = lockEl.querySelector('#tlMsg'); m.textContent = '⏳ ' + T('جارٍ التحقق…');
      const r = await api.updCheck().catch(() => ({ err: 'net' }));
      if (r.ready) { m.textContent = T('تم تنزيل النسخة {v} — جارٍ إعادة التشغيل…', { v: r.ready.version }); setTimeout(() => api.updRestart(), 1500); }
      else if (r.state && !r.state.locked) refresh();
      else m.textContent = T(r.err === 'net' ? 'لا يوجد اتصال بالإنترنت' : r.upToDate ? 'لا توجد نسخة أحدث بعد' : 'تعذّر التحقق، حاولي لاحقاً');
    };
  }
  async function checkNow(manual) {
    if (manual) LP.toast('⏳ ' + T('جارٍ التحقق من التحديث…'));
    const r = await api.updCheck().catch(() => ({ err: 'net' }));
    if (r.ready) { setReady(r.ready); if (manual) LP.toast(T('النسخة {v} جاهزة', { v: r.ready.version }), T('إعادة التشغيل الآن'), () => api.updRestart(), 15000); }
    else if (manual) LP.toast(T(r.upToDate ? 'لديكِ أحدث نسخة ✓' : r.err === 'nocfg' ? 'التحديث التلقائي غير مُعدّ في هذه النسخة' : r.err === 'net' ? 'لا يوجد اتصال بالإنترنت' : 'تعذّر التحقق، حاولي لاحقاً'));
    await refresh(); paintFooter();
  }
  LP.checkUpdate = checkNow;
  // سطر النسخة التجريبية في قائمة مكان العمل
  LP.trialLine = () => {
    const st = last; if (!st || !st.trial || st.locked) return '';
    const w = st.daysLeft <= 3;
    const txt = w ? (st.daysLeft > 0 ? left(st.daysLeft) + ' — ' + T('يلزم التحديث') : T('اليوم آخر يوم') + ' — ' + T('يلزم التحديث')) : T('نسخة تجريبية حتى {d}', { d: st.expires });
    return `<button data-trial class="ctx-trial${w ? ' warn' : ''}">🧪 ${esc(txt)}</button>`;
  };
  api.onUpdReady((rd) => setReady(rd));
  refresh(); setInterval(refresh, 30 * 60e3);
  document.addEventListener('lp-auth', () => setTimeout(refresh, 1500));   // مع/بدون مدرسة يتغير مكان التنبيه
  setTimeout(() => api.updGood(), 20000);   // البرنامج يعمل ← تُعتمد هذه النسخة
})();
