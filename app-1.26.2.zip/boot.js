// نقطة البداية: إن وُجد تحديث موقّع ومُتحقَّق منه (أحدث من هذه النسخة) يعمل البرنامج منه، وإلا من الملفات الأصلية.
// التحديثات في «بيانات/app-updates/<النسخة>»، والملفات الأصلية لا تُمس أبداً (يعمل من الفلاش أيضاً).
const { app } = require('electron');
const path = require('path');
const fs = require('fs');
function dataRoot() {
  if (process.env.LP_DATA) return process.env.LP_DATA;
  if (app.isPackaged && !fs.existsSync(path.join(path.dirname(process.execPath), 'installed.mode'))) {
    const d = path.join(path.dirname(process.execPath), 'بيانات');
    try { fs.accessSync(d, fs.constants.W_OK); return d; } catch {}
  }
  return path.join(app.getPath('appData'), 'LessonPresenter');
}
const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
let target = null;
try {
  const base = path.join(dataRoot(), 'app-updates'), curF = path.join(base, 'current.json');
  const cur = JSON.parse(fs.readFileSync(curF, 'utf8')), mine = require('./package.json').version, dir = path.join(base, String(cur.ver));
  // ثلاث محاولات فاشلة متتالية للتحديث ← نعود للنسخة الأصلية تلقائياً
  if (cur.ver && cmp(cur.ver, mine) > 0 && (cur.tries || 0) < 3 && fs.existsSync(path.join(dir, '.ok')) && fs.existsSync(path.join(dir, 'main.js'))) {
    cur.tries = (cur.tries || 0) + 1; fs.writeFileSync(curF, JSON.stringify(cur)); target = dir;
  }
} catch {}
if (target) {
  process.env.LP_BOOT_FROM = target;
  try { require(path.join(target, 'main.js')); }
  catch (e) { try { fs.appendFileSync(path.join(dataRoot(), 'سجل-البرنامج.txt'), `\n[boot] update failed: ${e && e.stack}\n`); } catch {} require('./main.js'); }
} else require('./main.js');
