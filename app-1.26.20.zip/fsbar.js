// شريط المجموعات المتكيّف:
// - يتسع لكل المجموعات دائماً (دون شريط تمرير): يختصر تدريجياً (العدد ← أزرار +/− ← الاسم)
// - في عرض باوربوينت بملء الشاشة: يجلس في الشريط الأسود فوق الشريحة إن اتسع له، وإلا يختفي بعد ثوانٍ من توقف الفأرة
// - ⇕ في عرض باوربوينت يُظهر السطر الأول (عنوان الدرس والمؤقت والنتائج) مؤقتاً
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const bar = $('#grpBar'), chips = $('#gbChips'), row2 = bar && bar.querySelector('.gb-row2');
  if (!bar || !chips || !row2) return;
  const body = document.body;
  const full = () => body.classList.contains('fullShow');
  const LEVELS = ['gbL1', 'gbL2', 'gbL3'];

  // ---------- الاختصار التدريجي ----------
  let fitting = false;
  function fit() {
    if (fitting) return; fitting = true;
    try {
      bar.classList.remove(...LEVELS);
      undoTxt(false);
      if (getComputedStyle(bar).display === 'none' || !chips.children.length) return;
      const over = () => chips.scrollWidth > chips.clientWidth + 1 || row2.scrollWidth > row2.clientWidth + 1;
      for (const c of LEVELS) { if (!over()) break; bar.classList.add(c); if (c === 'gbL1') undoTxt(true); }
      chips.querySelectorAll('.gchip').forEach(ch => {
        const nm = ch.querySelector('.gname'), pts = ch.querySelector('.gpts');
        ch.dataset.tip = bar.classList.contains('gbL2') ? (nm ? nm.textContent : '') + ' · ' + (pts ? pts.textContent : '') + ' — ' + T('ضغطة: نقطة، و«تراجع» لإزالتها') : '';
      });
    } finally { fitting = false; place(); }
  }
  // «تراجع» يصبح السهم وحده عند الاختصار
  const undo = $('#gbUndo');
  function undoTxt(short) {
    if (!undo) return;
    if (short) { if (!undo.dataset.full) { undo.dataset.full = undo.textContent; undo.textContent = '↶'; } }
    else if (undo.dataset.full) { undo.textContent = undo.dataset.full; delete undo.dataset.full; }
  }
  // عند الاختصار: الضغط على المجموعة = نقطة (الضغطتان لتغيير الاسم لا تُحسبان)
  let clickT = null;
  chips.addEventListener('click', (e) => {
    if (!bar.classList.contains('gbL2') || e.target.closest('button')) return;
    const ch = e.target.closest('.gchip'); if (!ch) return;
    clearTimeout(clickT);
    clickT = setTimeout(() => { const b = ch.querySelector('button[data-v="1"]'); if (b) b.click(); }, 260);
  });
  chips.addEventListener('dblclick', () => clearTimeout(clickT));

  // ---------- مكان الشريط في العرض الكامل ----------
  function place() {
    if (!full()) { body.classList.remove('fsBandTop', 'fsBandBot'); return; }
    const ar = (LP.slideAr && LP.slideAr()) || 16 / 9, W = innerWidth, H = innerHeight;
    const band = (H - Math.min(H, W / ar)) / 2;
    const h = bar.offsetHeight;
    const top = band >= h + 6;
    body.classList.toggle('fsBandTop', top);
    if (top) body.style.setProperty('--gbBandTop', Math.max(0, Math.floor((band - h) / 2)) + 'px');
    const bb = $('#bar'), fsB = parseFloat(getComputedStyle(body).getPropertyValue('--fsBottom')) || 0;
    body.classList.toggle('fsBandBot', !!bb && band >= bb.offsetHeight + fsB + 2);
    if (window.__lpQS) window.__lpQS();
  }

  // ---------- الاختفاء بعد توقف الفأرة (حين يغطي الشريحة) ----------
  let idleT = null;
  const busy = () => bar.matches(':hover') || bar.classList.contains('fsRow1') || !!document.querySelector('#gDlg.on, #valPop.on, .gb-menu.on, #grpMenu.on');
  function wake() {
    body.classList.remove('gbIdle');
    clearTimeout(idleT);
    if (!full()) return;
    idleT = setTimeout(function chk() { if (busy()) { idleT = setTimeout(chk, 1500); return; } body.classList.add('gbIdle'); if (window.__lpQS) window.__lpQS(); }, 4000);
  }
  document.addEventListener('mousemove', () => { if (full()) wake(); }, true);
  document.addEventListener('pointerdown', () => { if (full()) wake(); }, true);

  // ⇕ في العرض الكامل: السطر الأول مؤقتاً (دون تغيير الإعداد)
  document.addEventListener('click', (e) => {
    if (!full() || !e.target.closest('#gbRows')) return;
    e.stopPropagation(); e.preventDefault();
    bar.classList.toggle('fsRow1'); wake(); fit();
  }, true);

  // ---------- متى يُعاد الحساب ----------
  let raf = 0;
  const refit = () => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; fit(); }); };
  new MutationObserver(refit).observe(chips, { childList: true, subtree: true, characterData: true });
  let wasFull = full(), wasOne = '';
  new MutationObserver(() => {
    const f = full();
    if (f === wasFull) return;
    wasFull = f;
    if (!f) { bar.classList.remove('fsRow1'); body.classList.remove('gbIdle', 'fsBandTop', 'fsBandBot'); clearTimeout(idleT); }
    else wake();
    refit();
  }).observe(body, { attributes: true, attributeFilter: ['class'] });
  // ظهور الشريط أو تبديل السطرين
  new MutationObserver(() => {
    const one = bar.classList.contains('one'), on = bar.classList.contains('on'), r1 = bar.classList.contains('fsRow1');
    const k = one + '|' + on + '|' + r1;
    if (k === wasOne) return; wasOne = k; refit();
  }).observe(bar, { attributes: true, attributeFilter: ['class'] });
  new ResizeObserver(refit).observe(bar);
  window.addEventListener('resize', refit);
  LP.fitGroupBar = refit;
  refit();
})();
