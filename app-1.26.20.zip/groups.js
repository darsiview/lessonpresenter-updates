// العجلة الصغيرة العائمة + شريط المجموعات والنقاط + الحصص
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const GCOL = ['#ff7a3d', '#228be6', '#2fb344', '#ae3ec9', '#f5b400', '#e64980', '#12b886', '#4c6ef5'];
  const stage = $('#stage'), mw = $('#mw'), bar = $('#grpBar');
  const cv = $('#mwCanvas'), cx = cv.getContext('2d');

  let prof = {}, G = {}, cls = null, S = null;     // ملف المعلمة، بيانات المجموعات، الفصل الحالي، الحصة الحالية
  let chosen = {};                                 // الفصول التي اختيرت لها الحصة في هذا التشغيل
  let mode = 'girl', pick = null, angle = 0, spinning = false, keepVisible = null;

  // ================= الأسماء =================
  const FAMILY_PREFIX = /^(آل|ال|بن|ابن|بنت|أبو|ابو|عبد)$/;
  function shortName(full) {
    const p = String(full).trim().split(/\s+/);
    if (p.length <= 2) return p.join(' ');
    let i = p.length - 1;
    if (i > 1 && FAMILY_PREFIX.test(p[i - 1])) i--;
    return p[0] + ' ' + p.slice(i).join(' ');
  }
  const first = (full) => String(full).trim().split(/\s+/)[0];
  // اسم العجلة: ثنائي (الاسم + العائلة)، وثلاثي عند التشابه (يُضاف اسم الأب). الاسم الكامل يبقى للشهادات وإكسل
  let disp = new Map();
  function threePart(full) {
    const p = String(full).trim().split(/\s+/);
    if (p.length <= 3) return p.join(' ');
    let i = p.length - 1; if (i > 1 && FAMILY_PREFIX.test(p[i - 1])) i--;
    return i > 1 ? p[0] + ' ' + p[1] + ' ' + p.slice(i).join(' ') : p.join(' ');
  }
  function buildDisp() {
    const names = roster(), sh = names.map(shortName), c = {};
    sh.forEach(x => { c[x] = (c[x] || 0) + 1; });
    disp = new Map(names.map((n, i) => [n, c[sh[i]] > 1 ? threePart(n) : sh[i]]));
  }
  const dn = (n) => disp.get(n) || shortName(n);

  // ================= التخزين =================
  let saveT, savePending = false;
  // سجل الأحداث بتاريخها: كل تغيّر في النقاط أو المشاركات أو الغياب يُحفظ بوقته (للتقارير الدقيقة مهما كانت الحصة)
  let snap = null;
  const snapOf = (x) => ({ id: x.id, pts: { ...(x.pts || {}) }, turns: { ...(x.turns || {}) }, abs: { ...(x.absent || {}) } });
  function logDeltas() {
    if (!S) return;
    const cd = cdata(); cd.log ||= [];
    if (!snap || snap.id !== S.id) {
      // حصة قديمة (من قبل السجل) تُتابع الآن: نسجّل ما فيها بتاريخ إنشائها حتى لا يضيع من التقارير
      // (الحصة المتابَعة تبدأ بنقاط حصتها الأصلية، وتلك محسوبة هناك، فلا نكررها)
      if (!S.from && !cd.log.some(e => e.sid === S.id)) {
        const t0 = S.created || Date.now();
        for (const [n, v] of Object.entries(S.pts || {})) if (v) cd.log.push({ t: t0, sid: S.id, n, k: 'p', v });
        for (const [n, v] of Object.entries(S.turns || {})) if (v) cd.log.push({ t: t0, sid: S.id, n, k: 't', v });
        for (const n of Object.keys(S.absent || {})) cd.log.push({ t: S.absent[n] || t0, sid: S.id, n, k: 'a', v: 1 });
      }
      snap = snapOf(S); return;
    }
    const t = Date.now();
    const diff = (a, b, k) => { for (const n of new Set([...Object.keys(a), ...Object.keys(b)])) { const d = (b[n] || 0) - (a[n] || 0); if (d) cd.log.push({ t, sid: S.id, n, k, v: d }); } };
    diff(snap.pts, S.pts || {}, 'p'); diff(snap.turns, S.turns || {}, 't');
    const A = new Set(Object.keys(snap.abs)), B = new Set(Object.keys(S.absent || {}));
    for (const n of B) if (!A.has(n)) cd.log.push({ t, sid: S.id, n, k: 'a', v: 1 });
    for (const n of A) if (!B.has(n)) cd.log.push({ t, sid: S.id, n, k: 'a', v: -1 });
    snap = snapOf(S);
  }
  LP.groupsFlush = () => flushSave();
  LP.groupsSnapReset = () => { snap = S ? snapOf(S) : null; };
  function save() {
    if (S) S.at = Date.now();            // آخر نشاط (لمعرفة «درس اليوم»)
    logDeltas();
    clearTimeout(saveT); savePending = true;
    saveT = setTimeout(flushSave, 250);
  }
  function flushSave() {
    clearTimeout(saveT);
    if (!savePending) return Promise.resolve();
    savePending = false;
    return api.setSettings({ grp: G });
  }
  async function loadProfile() {
    await flushSave();                 // لا نقرأ من الملف قبل حفظ آخر تعديل (وإلا رجعت الحالة القديمة)
    prof = await api.getSettings();
    G = prof.grp || {};
    L0 = prof.lessonNow || L0 || { title: '', goals: [], goalsDone: [] };
  }
  // درس اليوم بدون أسماء طالبات: العنوان والأهداف تعمل أيضاً
  let L0 = null;
  const LH = () => S || L0 || (L0 = { title: '', goals: [], goalsDone: [] });
  function saveLesson() { if (S) save(); else api.setSettings({ lessonNow: L0 }); }
  function curClass() {
    const list = prof.classes || [];
    if (!list.length) return null;
    return list[Math.min(prof.classIdx || 0, list.length - 1)];
  }
  const roster = () => (cls ? (cls.students || []).filter(Boolean) : []);
  const classKey = () => (cls ? (LP.classKey ? LP.classKey(cls) : cls.name) : '');
  const cdata = () => (G[classKey()] ||= { sessions: [], cur: null, ngroups: 0 });
  const sessionOf = (id) => cdata().sessions.find(s => s.id === id) || null;
  const fmtDate = (ts) => LP.fmtDay(ts);

  function defaultCount(n) { return Math.max(2, Math.min(8, Math.round(n / 5) || 2)); }
  function splitInOrder(names, k) {
    const g = Array.from({ length: k }, () => []);
    const per = Math.ceil(names.length / k);
    names.forEach((n, i) => g[Math.min(k - 1, Math.floor(i / per))].push(n));
    // نضمن أن الفرق طالبة واحدة على الأكثر
    return balanceSizes(g);
  }
  function balanceSizes(g) {
    for (let guard = 0; guard < 100; guard++) {
      let mx = 0, mn = 0;
      g.forEach((x, i) => { if (x.length > g[mx].length) mx = i; if (x.length < g[mn].length) mn = i; });
      if (g[mx].length - g[mn].length <= 1) break;
      g[mn].push(g[mx].pop());
    }
    return g;
  }
  function newSession(from, continueFrom) {
    const names = roster();
    const k = cdata().ngroups || defaultCount(names.length);
    const s = {
      id: Date.now().toString(36), created: Date.now(), from: continueFrom ? continueFrom.created : null,
      groups: from ? from.groups.map(g => g.slice()) : splitInOrder(names, k),
      gpts: continueFrom ? continueFrom.gpts.slice() : [],
      pts: continueFrom ? { ...continueFrom.pts } : {}, turns: continueFrom ? { ...continueFrom.turns } : {},
      last: {}, removed: [], round: { n: 1, picked: [] }, nums: [], nextG: 0, hist: [],
      title: continueFrom ? (continueFrom.title || '') : from ? '' : (L0 && L0.title) || '', goals: continueFrom ? (continueFrom.goals || []).slice() : from ? [] : ((L0 && L0.goals) || []).slice(), goalsDone: continueFrom ? (continueFrom.goalsDone || []).slice() : [], goalHead: continueFrom ? continueFrom.goalHead : from ? undefined : (L0 && L0.goalHead),
      clock: { acc: 0, since: null }, thanks: []
    };
    s.gpts = s.groups.map((_, i) => s.gpts[i] || 0);
    const cd = cdata();
    cd.sessions.unshift(s);
    // الحصص القديمة (بعد 30 حصة) تُختصر إلى ملخص صغير حتى تبقى في التقارير والنقاط التراكمية
    if (cd.sessions.length > 30) { cd.archive ||= []; for (const o of cd.sessions.slice(30)) cd.archive.push({ id: o.id, created: o.created, pts: o.pts || {}, turns: o.turns || {}, absent: o.absent || {}, n: (o.groups || []).flat().length }); }
    cd.sessions = cd.sessions.slice(0, 30);
    cd.cur = s.id;
    return s;
  }
  // الأسماء الجديدة تدخل أصغر مجموعة، والمحذوفة تخرج من المجموعات
  function syncRoster() {
    buildDisp();
    if (!S) return;
    const names = roster(), set = new Set(names);
    S.groups = S.groups.map(g => g.filter(n => set.has(n)));
    const inG = new Set(S.groups.flat());
    for (const n of names) if (!inG.has(n)) {
      let mn = 0; S.groups.forEach((g, i) => { if (g.length < S.groups[mn].length) mn = i; });
      S.groups[mn].push(n);
    }
    S.removed = S.removed.filter(n => set.has(n));
    S.round.picked = S.round.picked.filter(n => set.has(n));
    while (S.gpts.length < S.groups.length) S.gpts.push(0);
  }
  const active = () => { const off = new Set(S.removed); return S.groups.map(g => g.filter(n => !off.has(n))); };
  const groupOf = (name) => S.groups.findIndex(g => g.includes(name));
  const groupName = (i, l) => { let c = null; try { c = cls && cdata().gnames; } catch {} return (c && c[i]) || I18N.tl(l || I18N.lang, 'مجموعة {n}', { n: i + 1 }); };
  // لغة العجلة: مستقلة عن لغة البرنامج (زر «ع / EN» على العجلة)
  const wlang = () => prof.wheelLang || I18N.lang;
  const W = (s, v, c) => I18N.tl(wlang(), s, v, c);
  const gnW = (i) => groupName(i, wlang());

  // ================= اختيار الحصة =================
  async function ensureSession(askUser) {
    await loadProfile();
    cls = curClass();
    if (!cls || !roster().length) { S = null; renderAll(); return false; }
    const cd = cdata();
    let asked = false;
    if (!chosen[classKey()] && cd.sessions.length && askUser) {
      chosen[classKey()] = true;
      const last = sessionOf(cd.cur) || cd.sessions[0];
      // آخر درس لهذا الفصل اليوم: يُكمل تلقائياً مع تنبيه صغير؛ وإلا يُسأل المعلم
      if (last && isToday(lastAt(last))) {
        const t = last.title || T('بلا عنوان');
        setTimeout(() => LP.toast('📅 ' + T('إكمال درس اليوم: {t}', { t }), T('تغيير'), () => sessionDialog(), 7000), 300);
      } else { asked = true; sessionDialog(); }
    }
    S = sessionOf(cd.cur) || cd.sessions[0] || null;
    if (!S) { S = newSession(); chosen[classKey()] = true; save(); }
    syncRoster();
    renderAll();
    if (askUser && !asked) LP.valueCard && LP.valueCard(classKey());
    return true;
  }
  const lastAt = (s) => (s && (s.at || s.created)) || 0;
  const isToday = (t) => !!t && new Date(t).toDateString() === new Date().toDateString();

  function sessionDialog(showAll) {
    const cd = cdata();
    const card = $('#gDlgCard');
    const classes = prof.classes || [], vis = classes.map((c, i) => [c, i]).filter(([c]) => !LP.classVisible || LP.classVisible(c));
    const list = cd.sessions.slice().sort((a, b) => (b.id === cd.cur) - (a.id === cd.cur) || lastAt(b) - lastAt(a));
    const shown = showAll ? list : list.slice(0, 5);
    const item = (s) => {
      const total = Object.values(s.pts || {}).reduce((a, b) => a + b, 0);
      const now = s.id === cd.cur && S && S.id === s.id && isToday(lastAt(s));
      const tag = now ? `<em class="gs-now">${T('المفتوح الآن')}</em> · ` : s.id === cd.cur ? `<em class="gs-last">${T('آخر حصة')}</em> · ` : '';
      return `<button class="gsess" data-id="${s.id}"><span><b>${esc(s.title || T('بلا عنوان'))}</b> · ${tag}${esc(fmtDate(lastAt(s)))}</span><small>${T('{n} نقطة', { n: total })}</small></button>`;
    };
    card.innerHTML = `<h3>📅 ${T('حصة الفصل «{c}»', { c: cls ? cls.name : '' })}</h3>
      <p>${T('هل هذا درس جديد، أم إكمال لدرس سابق؟')}</p>
      ${vis.length > 1 ? `<div class="gdlg-row" style="margin:0 0 10px">${vis.map(([c, i]) => `<button class="${i === (prof.classIdx || 0) ? 'pri' : ''}" data-cls="${i}">${esc(c.name)}</button>`).join('')}</div>` : ''}
      <div class="gdlg-row" style="margin-bottom:4px"><button class="pri" id="gNewSess">＋ ${T('درس جديد')}</button></div>
      <p class="gs-hint">${T('النقاط من الصفر، والمجموعات كما هي.')}</p>
      ${list.length ? `<p style="margin:12px 0 2px;font-weight:700;color:var(--txt)">${T('إكمال درس سابق:')}</p><p class="gs-hint" style="margin-bottom:6px">${T('تُكمل النقاط والمجموعات والأهداف من حيث توقفت.')}</p>` : ''}
      ${shown.map(item).join('')}
      ${!showAll && list.length > 5 ? `<button class="gs-more" id="gSessMore">${T('عرض الأقدم ({n})', { n: list.length - 5 })}</button>` : ''}
      <div class="gdlg-row"><button id="gDlgClose">${T('إغلاق')}</button></div>`;
    $('#gDlg').classList.add('on');
    card.querySelectorAll('[data-cls]').forEach(b => b.onclick = async () => {
      await api.setSettings({ classIdx: +b.dataset.cls });
      document.dispatchEvent(new Event('lp-classes'));
      chosen = {}; await ensureSession(false); sessionDialog();
    });
    if ($('#gSessMore')) $('#gSessMore').onclick = () => sessionDialog(true);
    const after = () => { save(); closeDlg(); syncRoster(); renderAll(); LP.valueCard && LP.valueCard(classKey()); };
    $('#gNewSess').onclick = () => { S = newSession(sessionOf(cd.cur)); LP.toast(T('بدأ درس جديد')); after(); };
    card.querySelectorAll('.gsess').forEach(b => b.onclick = () => {
      const old = sessionOf(b.dataset.id);
      if (old && old.id === cd.cur) { S = old; }
      else if (old) { S = newSession(old, old); LP.toast(T('إكمال الدرس: {t}', { t: old.title || T('بلا عنوان') })); }
      after();
    });
    $('#gDlgClose').onclick = closeDlg;
  }
  const closeDlg = () => $('#gDlg').classList.remove('on');
  $('#gDlg').addEventListener('click', e => { if (e.target.id === 'gDlg') closeDlg(); });

  // ================= شريط المجموعات =================
  // التقويم الدراسي: الفصل والأسبوع وقيمة الشهر بجانب التاريخ
  const calTxt = () => { if (!LP.cal) return ''; const l = LP.cal.label(); LP.renderValBtn && LP.renderValBtn(); return l ? ' · ' + l : ''; };
  document.addEventListener('lp-cal', () => { if (bar.classList.contains('on')) renderBar(); });
  function renderBar() {
    $('#gbPin').classList.toggle('on', !!prof.gbPin);
    applyRows();
    if (!S) {
      $('#gbClassName').innerHTML = esc(cls ? cls.name : T('لا يوجد فصل'));
      $('#gbSession').textContent = fmtDate(Date.now()) + calTxt();
      $('#gbChips').innerHTML = `<span class="gb-note">${T('أضيفي أسماء الطالبات أولاً')}</span><button class="gb-make" id="gbMake">${T('إضافة الأسماء')}</button>`;
      $('#gbMake').onclick = () => LP.openTools();
      renderTitle(); renderClock();
      return;
    }
    $('#gbClassName').innerHTML = `${esc(cls ? cls.name : '')} <b>${roster().length - S.removed.length}</b>`;
    $('#gbSession').textContent = fmtDate(Date.now()) + calTxt();
    const lead = Math.max(...S.gpts);
    $('#gbChips').innerHTML = S.groups.map((g, i) => `<span class="gchip ${S.gpts[i] === lead && lead > 0 ? 'lead' : ''} ${mode === 'girl' && nextGroupIdx() === i ? 'turn' : ''}" style="--gc:${GCOL[i % GCOL.length]}" title="${esc(g.map(dn).join('، '))}">
        <span class="gdot" style="background:${GCOL[i % GCOL.length]}"></span><span class="gname" data-gren="${i}" title="${T('اضغطي مرتين لتغيير الاسم')}">${esc(groupName(i))}</span><small class="gcount">${g.filter(n => !S.removed.includes(n)).length}</small>
        <span class="gpts">${S.gpts[i]}</span><button data-gi="${i}" data-v="-1">−</button><button data-gi="${i}" data-v="1">+</button></span>`).join('');
    $$('#gbChips button').forEach(b => b.onclick = () => {
      const gi = +b.dataset.gi, v = +b.dataset.v;
      S.gpts[gi] += v; S.hist.push({ kind: 'g', gi, v }); save(); renderBar();
      fx(v > 0 ? '+1' : '−1', v > 0 ? '#2fb344' : '#e5484d', b);
    });
    renderTitle(); renderClock();
  }

  // ---------- عنوان الحصة ----------
  function renderTitle() {
    const H = LH(), t = H.title;
    const el = $('#gbTitle');
    $('#gbTitleTxt').textContent = t ? '📘 ' + t : T('اكتبي موضوع الدرس…');
    el.classList.toggle('set', !!t); el.classList.toggle('empty', !t);
    el.title = t || T('عنوان الحصة');
    const n = (H.goals || []).length;
    $('#gbGoalsN').textContent = n ? `${(H.goalsDone || []).length}/${n}` : '0';
    $('#gbGoals').style.display = '';
    $('#gbTitle').style.display = '';
  }
  function setTitle(title, goals, extra) {
    const H = LH();
    H.title = String(title || '').trim();
    if (goals) { H.goals = goals.filter(Boolean); H.goalsDone = []; }
    if (extra) Object.assign(H, extra);
    saveLesson(); renderTitle();
    document.dispatchEvent(new Event('lp-goals'));
  }
  const titlePop = $('#gbTitlePop');
  function titleSuggestions(q) {
    q = q.trim().toLowerCase();
    const seen = new Set(), out = [];
    // من دفتر الدروس (العنوان والأهداف)
    for (const l of (LP.lessonBook ? LP.lessonBook.forGrade(cls) : [])) {
      if (q && !l.title.toLowerCase().includes(q)) continue;
      if (seen.has(l.title)) continue; seen.add(l.title);
      out.push({ title: l.title, goals: l.goals || [], sub: l.subject ? `${l.subject}${l.grade ? ' · ' + l.grade : ''}` : '', book: l });
    }
    // من الحصص السابقة
    for (const c of Object.values(G)) for (const se of (c.sessions || [])) {
      if (!se.title || seen.has(se.title)) continue;
      if (q && !se.title.toLowerCase().includes(q)) continue;
      seen.add(se.title); out.push({ title: se.title, goals: se.goals || [], sub: T('حصة سابقة') });
    }
    return out.slice(0, 12);
  }
  function renderTitleSug() {
    const list = titleSuggestions($('#gbTitleIn').value);
    $('#gbTitleSug').innerHTML = list.map((x, i) => `<button class="mi" data-i="${i}"><span dir="auto">${esc(x.title)}</span><small>${x.goals.length ? '🎯 ' + x.goals.length + ' · ' : ''}${esc(x.sub)}</small></button>`).join('');
    $$('#gbTitleSug [data-i]').forEach(b => b.onclick = () => {
      const x = list[+b.dataset.i];
      setTitle(x.title, x.goals.length ? x.goals : null, x.book ? { subject: x.book.subject || '' } : null);
      titlePop.classList.remove('on');
      if (x.goals.length && LP.showGoals) LP.showGoals(true);
    });
  }
  $('#gbTitle').onclick = (e) => {
    e.stopPropagation();
    if (titlePop.classList.toggle('on')) {
      const r = $('#gbTitle').getBoundingClientRect(), sr = stage.getBoundingClientRect();
      titlePop.style.left = Math.max(8, Math.min(r.left - sr.left, sr.width - 330)) + 'px';
      $('#gbTitleIn').value = LH().title || '';
      renderTitleSug();
      setTimeout(() => { $('#gbTitleIn').focus(); $('#gbTitleIn').select(); }, 30);
    }
  };
  $('#gbTitleIn').addEventListener('input', renderTitleSug);
  $('#gbTitleIn').addEventListener('keydown', e => {
    e.stopPropagation();
    if (e.key === 'Enter') { setTitle($('#gbTitleIn').value); titlePop.classList.remove('on'); }
    if (e.key === 'Escape') titlePop.classList.remove('on');
  });
  $('#gbTitleFromTab').onclick = () => {
    const t = (LP.currentTitle && LP.currentTitle()) || '';
    if (!t || LP.isWelcome(LP.currentUrl())) { LP.toast(T('لا يوجد درس مفتوح')); return; }
    const book = LP.lessonBook && LP.lessonBook.forUrl(LP.currentUrl());
    if (book) setTitle(book.title, book.goals, { subject: book.subject || '' }); else setTitle(t);
    titlePop.classList.remove('on');
  };
  $('#gbTitleClear').onclick = () => { setTitle('', []); titlePop.classList.remove('on'); };
  document.addEventListener('pointerdown', e => { if (!e.target.closest('#gbTitlePop') && !e.target.closest('#gbTitle')) titlePop.classList.remove('on'); }, true);
  $('#gbGoals').onclick = () => { if (LP.showGoals) LP.showGoals(); };
  $('#gbSession').onclick = () => LP.toggleDateMode();
  document.addEventListener('lp-date', () => { if (bar.classList.contains('on')) renderBar(); });

  // ---------- ساعة الحصة ----------
  const clockMs = () => { if (!S || !S.clock) return 0; const c = S.clock; return c.acc + (c.since ? Date.now() - c.since : 0); };
  const durMin = () => (cls && cls.duration) || 40;
  const mmss = (ms) => { const s2 = Math.floor(Math.abs(ms) / 1000); return Math.floor(s2 / 60) + ':' + String(s2 % 60).padStart(2, '0'); };
  function renderClock() {
    const box = $('#gbClock');
    box.style.display = S ? '' : 'none';
    if (!S) return;
    S.clock ||= { acc: 0, since: null };
    const ms = clockMs(), total = durMin() * 60000, left = total - ms;
    $('#gbClockTxt').textContent = mmss(ms);
    $('#gbOf').textContent = T('من {n} دقيقة', { n: durMin() });
    const st = $('#gbStatus'), run = !!S.clock.since;
    let cls2 = 'idle', txt = T('لم تبدأ');
    if (left <= 0) { cls2 = 'late'; txt = T('انتهى الوقت +{t}', { t: mmss(-left) }); }
    else if (ms && !run) { cls2 = 'pause'; txt = T('متوقفة'); }
    else if (run && left <= 5 * 60000) { cls2 = 'warn'; txt = T('بقي {t}', { t: mmss(left) }); }
    else if (run) { cls2 = 'ok'; txt = T('بقي {t}', { t: mmss(left) }); }
    st.className = 'gb-status ' + cls2; st.textContent = txt;
    $('#gbClockBtn').textContent = run ? T('إيقاف مؤقت') : ms ? T('متابعة') : T('ابدئي الحصة');
    $('#gbClockBtn').classList.toggle('run', run);
    $('#gbProg').style.width = Math.min(100, ms / total * 100) + '%';
    $('.gb-prog').classList.toggle('over', left <= 0);
  }
  $('#gbClockBtn').onclick = () => {
    if (!S) return;
    S.clock ||= { acc: 0, since: null };
    if (S.clock.since) { S.clock.acc += Date.now() - S.clock.since; S.clock.since = null; }
    else S.clock.since = Date.now();
    save(); renderClock();
  };
  let lastOverMin = -1;
  setInterval(() => {
    if (!S || !bar.classList.contains('on')) return;
    renderClock();
    const left = durMin() * 60000 - clockMs();
    if (S.clock && S.clock.since && left <= 0 && lastOverMin !== S.id) { lastOverMin = S.id; LP.toast(T('انتهى وقت الحصة ⏰')); LP.sound && LP.sound.fanfare(); }
  }, 1000);

  // ---------- أزرار الشريط ----------
  $('#gbTimer').onclick = () => LP.openTimer && LP.openTimer($('#gbTimer'));
  $('#gbTools').onclick = () => LP.openTools();
  $('#gbResults').onclick = () => { if (!S) return noNames(); if (LP.openResults) LP.openResults(); else certDialog(); };
  $('#gbPin').onclick = () => {
    prof.gbPin = !prof.gbPin; api.setSettings({ gbPin: prof.gbPin });
    LP.toast(T(prof.gbPin ? 'الشريط مثبّت: يبقى ظاهراً دائماً' : 'الشريط غير مثبّت'));
    renderBar();
  };
  $('#gbUndo').onclick = undo;
  $('#gbHide').onclick = () => toggleBar(false);
  $('#gbHide2').onclick = () => toggleBar(false);
  $('#gbRows').onclick = toggleRows;
  $('#gbClass').onclick = async () => { if (await ensureSession(false)) sessionDialog(); else noNames(); };
  // قائمة المزيد في الشريط
  const gbMenu = $('#gbMenu');
  $('#gbMenuBtn').onclick = (e) => {
    e.stopPropagation();
    if (gbMenu.classList.toggle('on')) {
      const r = $('#gbMenuBtn').getBoundingClientRect(), sr = stage.getBoundingClientRect();
      gbMenu.style.left = Math.max(8, Math.min(r.left - sr.left - 200, sr.width - 260)) + 'px';
    }
  };
  document.addEventListener('pointerdown', e => { if (!e.target.closest('#gbMenu') && !e.target.closest('#gbMenuBtn')) gbMenu.classList.remove('on'); }, true);
  gbMenu.addEventListener('click', e => {
    const b = e.target.closest('[data-g]'); if (!b) return;
    gbMenu.classList.remove('on');
    const k = b.dataset.g;
    if (k === 'names') return LP.openNamesPanel();
    if (k === 'rows') return toggleRows();
    if (!S) return noNames();
    if (k === 'gnames') return namesDialog(0);
    ({ rebalance: rebalanceDialog, count: countDialog, session: sessionDialog, excel: copyExcel, cert: () => (LP.openResults ? LP.openResults() : certDialog()) })[k]();
  });

  function undo() {
    if (!S || !S.hist.length) { LP.toast(T('لا يوجد ما يمكن التراجع عنه')); return; }
    const h = S.hist.pop();
    if (h.kind === 'g') S.gpts[h.gi] -= h.v;
    else h.names.forEach((n, j) => { S.pts[n] = (S.pts[n] || 0) - h.v; if (h.gis[j] >= 0) S.gpts[h.gis[j]] -= h.v; });
    save(); renderAll(); LP.toast(T('تم التراجع'));
  }

  // ---------- إعادة التقسيم ----------
  // تعديل المجموعات يدوياً: نقل طالب لمجموعة أخرى، أو تبديل طالبين. نقاط المجموعات تبقى للمجموعة، ونقاط الطالب له
  function moveGirl(n, gi) {
    const from = groupOf(n); if (from < 0 || from === gi || !S.groups[gi]) return false;
    S.groups[from] = S.groups[from].filter(x => x !== n); S.groups[gi].push(n); save(); return true;
  }
  function swapGirls(a, b) {
    const ga = groupOf(a), gb = groupOf(b); if (ga < 0 || gb < 0 || ga === gb) return false;
    S.groups[ga][S.groups[ga].indexOf(a)] = b; S.groups[gb][S.groups[gb].indexOf(b)] = a; save(); return true;
  }
  function rebalance(k) {
    const off = new Set(S.removed);
    const all = S.groups.flat();
    const present = all.filter(n => !off.has(n)), absent = all.filter(n => off.has(n));
    // عشوائي متوازن: نرتب حسب النقاط مع خلط، ثم توزيع متعرّج حتى لا تجتمع الأكثر مشاركة في مجموعة واحدة
    const shuffled = present.map(n => ({ n, r: Math.random(), p: S.pts[n] || 0 })).sort((a, b) => b.p - a.p || a.r - b.r).map(x => x.n);
    const g = Array.from({ length: k }, () => []);
    shuffled.forEach((n, i) => { const row = Math.floor(i / k), col = i % k; g[row % 2 ? k - 1 - col : col].push(n); });
    for (const n of absent) { let mn = 0; g.forEach((x, i) => { if (x.length < g[mn].length) mn = i; }); g[mn].push(n); }
    S.groups = g;
    S.gpts = g.map(() => 0);                   // المجموعات الجديدة تبدأ من الصفر، ونقاط الطالبات تبقى
    S.nextG = 0; S.round = { n: S.round.n + 1, picked: [] }; S.nums = []; S.deferred = [];
    S.hist = S.hist.filter(h => h.kind !== 'g').map(h => ({ ...h, gis: h.gis.map(() => -1) }));
    cdata().ngroups = k;
    save();
  }
  function rebalanceDialog() {
    const k = S.groups.length;
    rebalance(k);
    showPreview(T('🔀 التقسيم الجديد'), T('وُزّعت الحاضرات بالتساوي وعشوائياً. نقاط كل طالبة محفوظة لها، والمجموعات تبدأ من الصفر.'), true);
    renderAll();
  }
  function showPreview(title, msg, again) {
    const card = $('#gDlgCard');
    card.innerHTML = `<h3>${title}</h3><p>${msg}</p>
      <div class="gprev">${S.groups.map((g, i) => `<div><b style="color:${GCOL[i % GCOL.length]}">${esc(groupName(i))} (${g.length})</b>${g.map(n => esc(dn(n)) + (S.removed.includes(n) ? ' 🚫' : '')).join('<br>')}</div>`).join('')}</div>
      <div class="gdlg-row">${again ? `<button id="gAgain">🔀 ${T('أعيدي التقسيم')}</button>` : ''}<button class="pri" id="gOk">${T('تم')}</button></div>`;
    $('#gDlg').classList.add('on');
    if (again) $('#gAgain').onclick = rebalanceDialog;
    $('#gOk').onclick = closeDlg;
  }
  function countDialog() {
    let k = S.groups.length;
    const card = $('#gDlgCard');
    const draw = () => {
      card.innerHTML = `<h3>👥 ${T('عدد المجموعات')}</h3><p>${T('يُعاد توزيع الطالبات بالتساوي على العدد الجديد، والمجموعات تبدأ من الصفر.')}</p>
        <div class="gcount"><button id="gcm">−</button><b>${k}</b><button id="gcp">+</button></div>
        <p style="text-align:center">${T('حوالي {n} طالبات في كل مجموعة', { n: Math.round(roster().length / k) })}</p>
        <div class="gdlg-row"><button class="pri" id="gcOk">${T('تطبيق')}</button><button id="gcNo">${T('إلغاء')}</button></div>`;
      $('#gcm').onclick = () => { k = Math.max(2, k - 1); draw(); };
      $('#gcp').onclick = () => { k = Math.min(8, Math.min(roster().length, k + 1)); draw(); };
      $('#gcOk').onclick = () => { rebalance(k); renderAll(); showPreview(T('👥 المجموعات الجديدة'), T('وُزّعت الحاضرات بالتساوي وعشوائياً. نقاط كل طالبة محفوظة لها، والمجموعات تبدأ من الصفر.'), true); };
      $('#gcNo').onclick = closeDlg;
    };
    draw(); $('#gDlg').classList.add('on');
  }

  // ---------- أسماء المجموعات (لكل فصل، تبقى مع إعادة التقسيم والحصص الجديدة) ----------
  function namesDialog(focusI) {
    const card = $('#gDlgCard'), cur = (cdata().gnames || []).slice();
    const IDEAS = ['⭐ النجوم', '🦅 الصقور', '🌸 الزهور', '🚀 المبدعون', '💡 المتميزون', '🌟 الأبطال', '🌿 الواحة', '🔥 الشعلة'];
    card.innerHTML = `<h3>🏷 ${T('أسماء المجموعات')}</h3><p>${T('اكتبي اسماً لكل مجموعة، أو اتركيه فارغاً للاسم الافتراضي.')}</p>
      <div class="gnames">${S.groups.map((_, i) => `<label><i style="background:${GCOL[i % GCOL.length]}"></i>
        <input data-gi="${i}" maxlength="24" spellcheck="false" value="${esc(cur[i] || '')}" placeholder="${esc(T('مجموعة {n}', { n: i + 1 }))}"></label>`).join('')}</div>
      <div class="gideas">${IDEAS.map(x => `<button data-idea="${esc(T(x))}">${esc(T(x))}</button>`).join('')}</div>
      <div class="gdlg-row"><button class="pri" id="gnOk">${T('حفظ')}</button><button id="gnClr">${T('الأسماء الافتراضية')}</button><button id="gnNo">${T('إلغاء')}</button></div>`;
    let last = null;
    card.querySelectorAll('input').forEach(i => i.onfocus = () => { last = i; });
    card.querySelectorAll('[data-idea]').forEach(b => b.onclick = () => {
      const t = last || [...card.querySelectorAll('input')].find(i => !i.value) || card.querySelector('input');
      t.value = b.dataset.idea; const nx = t.closest('label').nextElementSibling; (nx ? nx.querySelector('input') : t).focus();
    });
    const done = (names) => { cdata().gnames = names; save(); closeDlg(); renderAll(); };
    $('#gnOk').onclick = () => done([...card.querySelectorAll('input')].map(i => i.value.trim()));
    $('#gnClr').onclick = () => done([]);
    $('#gnNo').onclick = closeDlg;
    card.querySelectorAll('input').forEach(i => i.onkeydown = (e) => { if (e.key === 'Enter') $('#gnOk').click(); });
    $('#gDlg').classList.add('on');
    setTimeout(() => { const f = card.querySelector(`input[data-gi="${focusI || 0}"]`); f && (f.focus(), f.select()); }, 30);
  }
  $('#gbChips').addEventListener('dblclick', e => { const n = e.target.closest('[data-gren]'); if (n && S) namesDialog(+n.dataset.gren); });

  // ---------- الشريط: سطر واحد أو سطران ----------
  function applyRows() { bar.classList.toggle('one', prof.gbRows === 1); $('#gbRows').title = T(prof.gbRows === 1 ? 'إظهار السطرين (الدرس والأدوات)' : 'سطر واحد: المجموعات فقط'); }
  function toggleRows() { prof.gbRows = prof.gbRows === 1 ? 2 : 1; api.setSettings({ gbRows: prof.gbRows }); applyRows(); }

  // ---------- النتائج والشهادة ----------
  function copyExcel() {
    const rows = [[T('الاسم'), T('المجموعة'), T('النقاط'), T('المشاركات')].join('\t')];
    S.groups.forEach((g, i) => g.forEach(n => rows.push([n, groupName(i), S.pts[n] || 0, S.turns[n] || 0].join('\t'))));
    rows.push('');
    S.groups.forEach((_, i) => rows.push([groupName(i), '', S.gpts[i], ''].join('\t')));
    navigator.clipboard.writeText(rows.join('\n')).then(() => LP.toast(T('نُسخت النتائج — الصقيها في إكسل')), () => LP.toast(T('تعذّر النسخ')));
  }
  function topGirls() {
    const all = S.groups.flat();
    const best = Math.max(0, ...all.map(n => S.pts[n] || 0));
    if (best <= 0) return [];
    return all.filter(n => (S.pts[n] || 0) === best).slice(0, 3);
  }
  function certDialog() {
    const tops = topGirls();
    const card = $('#gDlgCard');
    if (!tops.length) {
      card.innerHTML = `<h3>🏅 ${T('شهادة الأكثر مشاركة')}</h3><p>${T('لا توجد نقاط بعد في هذه الحصة.')}</p><div class="gdlg-row"><button class="pri" id="gOk">${T('تم')}</button></div>`;
      $('#gDlg').classList.add('on'); $('#gOk').onclick = closeDlg; return;
    }
    let who = tops[0];
    const draw = () => {
      card.innerHTML = `<h3>🏅 ${T('شهادة الأكثر مشاركة')}</h3>
        ${tops.length > 1 ? `<div class="gdlg-row" style="margin:0 0 8px">${tops.map(n => `<button class="${n === who ? 'pri' : ''}" data-n="${esc(n)}">${esc(dn(n))}</button>`).join('')}</div>` : ''}
        <canvas id="certCanvas" width="1200" height="820"></canvas>
        <div class="gdlg-row"><button class="pri" id="gCertSave">💾 ${T('حفظ الشهادة')}</button><button id="gOk">${T('إغلاق')}</button></div>`;
      card.querySelectorAll('[data-n]').forEach(b => b.onclick = () => { who = b.dataset.n; draw(); });
      paintCert($('#certCanvas'), who);
      $('#gCertSave').onclick = async () => { if (await api.savePng($('#certCanvas').toDataURL('image/png'))) LP.toast(T('تم حفظ الشهادة')); };
      $('#gOk').onclick = closeDlg;
    };
    draw(); $('#gDlg').classList.add('on');
  }
  function paintCert(c, name) {
    const x = c.getContext('2d'), W = c.width, H = c.height, ac = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#ff7a3d';
    const rtl = I18N.dir() === 'rtl';
    x.fillStyle = '#fffaf3'; x.fillRect(0, 0, W, H);
    x.strokeStyle = ac; x.lineWidth = 18; x.strokeRect(30, 30, W - 60, H - 60);
    x.strokeStyle = '#f5b400'; x.lineWidth = 4; x.strokeRect(60, 60, W - 120, H - 120);
    for (let i = 0; i < 40; i++) { x.fillStyle = GCOL[i % GCOL.length] + '55'; x.beginPath(); x.arc(90 + Math.random() * (W - 180), 90 + Math.random() * 80, 4 + Math.random() * 6, 0, 7); x.fill(); }
    x.textAlign = 'center'; x.direction = rtl ? 'rtl' : 'ltr';
    const f = (w, s) => `${w} ${s}px "Segoe UI", Tahoma, Arial`;
    x.fillStyle = '#333'; x.font = f(900, 74); x.fillText('🏅 ' + T('شهادة تميّز'), W / 2, 220);
    x.font = f(500, 34); x.fillStyle = '#666'; x.fillText(T('تُمنح للطالبة'), W / 2, 300);
    x.font = f(900, 72); x.fillStyle = ac;
    let fs = 72; while (x.measureText(name).width > W - 220 && fs > 34) { fs -= 4; x.font = f(900, fs); }
    x.fillText(name, W / 2, 400);
    x.font = f(600, 36); x.fillStyle = '#444'; x.fillText(T('لأنها الأكثر مشاركة في الحصة'), W / 2, 480);
    const gi = groupOf(name);
    x.font = f(500, 30); x.fillStyle = '#666';
    x.fillText(`${T('الفصل')}: ${classKey()}   ·   ${gi >= 0 ? groupName(gi) : ''}   ·   ${T('{n} نقطة', { n: S.pts[name] || 0 })}`, W / 2, 560);
    x.fillText(fmtDate(S.created), W / 2, 610);
    const lead = Math.max(...S.gpts), wins = S.gpts.map((p, i) => p === lead && lead > 0 ? groupName(i) : null).filter(Boolean);
    if (wins.length) { x.font = f(700, 30); x.fillStyle = '#2b8a3e'; x.fillText('🏆 ' + T('المجموعة الفائزة: {g}', { g: wins.join('، ') }), W / 2, 690); }
  }

  // ================= العجلة الصغيرة =================
  // طريقة الاختيار: 'all' (افتراضي) لا تكرار حتى يشارك الجميع، 'groups' دور متساوٍ لكل مجموعة حتى لو تكررت طالبة
  const fairAll = () => (prof.wheelFair || 'all') === 'all';
  // المؤجَّلات بالتخطي: يعدن بعد أن تشارك بقية الجولة
  function eligible(n, a) {
    if (S.round.picked.includes(n)) return false;
    const df = S.deferred || [];
    if (!df.includes(n)) return true;
    return !a.flat().some(x => !S.round.picked.includes(x) && !df.includes(x));
  }
  function nextGroupIdx() {
    if (!S) return -1;
    const a = active(), k = S.groups.length;
    if (fairAll() && a.flat().some(n => !S.round.picked.includes(n))) {
      for (let j = 0; j < k; j++) { const gi = (S.nextG + j) % k; if (a[gi].some(n => eligible(n, a))) return gi; }
    }
    for (let j = 0; j < k; j++) { const gi = (S.nextG + j) % k; if (a[gi].length) return gi; }
    return -1;
  }
  function slices() {
    if (!S) return [];
    if (mode === 'group') {
      const gr = S.gRound || [];
      return active().map((g, gi) => g.length ? { label: gnW(gi), grp: gi, done: gr.includes(gi), color: GCOL[gi % GCOL.length] } : null).filter(Boolean);
    }
    if (mode === 'num') {
      const mx = Math.max(0, ...active().map(g => g.length));
      return Array.from({ length: mx }, (_, i) => ({ label: String(i + 1), num: i + 1, done: S.nums.includes(i + 1), color: GCOL[i % GCOL.length] }));
    }
    const picked = new Set(S.round.picked), out = [], hide = !!prof.autoHide;
    active().forEach((g, gi) => g.forEach(n => {
      const done = picked.has(n);
      if (hide && done && n !== keepVisible) return;          // «أخرجي الطالبة بعد اختيارها» حتى نهاية الجولة
      out.push({ label: dn(n), name: n, gi, done, color: GCOL[gi % GCOL.length] });
    }));
    return out;
  }
  const bwc = $('#bwCanvas'), bwx = bwc.getContext('2d');
  const bigOpen = () => $('#wheelPanel').classList.contains('on');
  function drawWheel() { drawOn(cv, cx, 10); if (bigOpen()) drawOn(bwc, bwx, 22); }
  // rr: نصف قطر زر «−» على الطرف الخارجي لكل قطاع
  const rimShown = (canvas, n, rr) => mode === 'girl' && n > 0 && n <= 34 && (Math.PI * 2 / n) * (canvas.width / 2 - 4) > rr * 2 + 6;
  function drawOn(canvas, g, rr) {
    g.setTransform(1, 0, 0, 1, 0, 0);    // حماية: لوحة الرسم تبدأ دائماً من وضعها الصحيح
    try { drawOn2(canvas, g, rr); } catch (e) { console.error('wheel draw', e); }
    finally { g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; }
  }
  function drawOn2(canvas, g, rr) {
    const CW = canvas.width, R = CW / 2 - 4, c = CW / 2;
    g.clearRect(0, 0, CW, CW);
    const sl = slices();
    if (!sl.length) { g.fillStyle = 'rgba(128,128,128,.25)'; g.beginPath(); g.arc(c, c, R, 0, 7); g.fill(); return; }
    const seg = Math.PI * 2 / sl.length, rim = rimShown(canvas, sl.length, rr);
    sl.forEach((s, i) => {
      const a0 = angle + i * seg - Math.PI / 2;
      g.beginPath(); g.moveTo(c, c); g.arc(c, c, R, a0, a0 + seg); g.closePath();
      g.globalAlpha = s.done ? 0.35 : (i % 2 ? 0.82 : 1);
      g.fillStyle = s.color; g.fill();
      g.globalAlpha = 1; g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = CW > 500 ? 3 : 2; g.stroke();
      const mid = a0 + seg / 2, flip = Math.cos(mid) < -0.001;
      g.save(); g.translate(c, c); g.rotate(flip ? mid + Math.PI : mid);
      // زر «−» على الطرف الخارجي، والاسم يبدأ بعده نحو المركز
      const outer = rim ? R - rr * 2 - 10 : R - 10;
      if (rim) {
        const rx = (R - rr - 5) * (flip ? -1 : 1);
        g.beginPath(); g.arc(rx, 0, rr, 0, 7); g.fillStyle = 'rgba(255,255,255,.92)'; g.fill();
        g.strokeStyle = '#e5484d'; g.lineWidth = Math.max(1.5, rr / 6); g.stroke();
        g.fillStyle = '#e5484d'; g.fillRect(rx - rr * 0.5, -Math.max(1.5, rr / 7), rr, Math.max(3, rr / 3.5));
      }
      // الخط يصغر حتى يظهر الاسم كاملاً، ولا يُقص إلا عند الضرورة
      let fsz = Math.max(CW > 500 ? 15 : 10, Math.min(CW > 500 ? 36 : 24, seg * R * 0.5, (CW > 500 ? 520 : 300) / Math.max(6, sl.length) + 8));
      const minF = CW > 500 ? 15 : 10, maxW = outer - R * 0.3;
      g.font = `800 ${fsz}px "Segoe UI", Tahoma, Arial`;
      while (g.measureText(s.label).width > maxW && fsz > minF) { fsz -= 1; g.font = `800 ${fsz}px "Segoe UI", Tahoma, Arial`; }
      g.fillStyle = '#1b1b1b'; g.textBaseline = 'middle';
      g.textAlign = flip ? 'left' : 'right'; g.direction = 'rtl';
      if (mode !== 'girl') {   // المجموعات والأرقام: النص في منتصف القطاع وبخط كبير
        let fz = CW > 500 ? 44 : 24; g.font = `900 ${fz}px "Segoe UI", Tahoma, Arial`;
        const lab = mode === 'num' ? W('رقم {n}', { n: s.num }) : s.label, mw2 = R * 0.62;
        while (g.measureText(lab).width > mw2 && fz > 10) { fz -= 1; g.font = `900 ${fz}px "Segoe UI", Tahoma, Arial`; }
        g.textAlign = 'center'; g.fillText(lab, (flip ? -1 : 1) * R * 0.64, 0);
        g.restore(); return;
      }
      let t = s.label;
      while (g.measureText(t).width > maxW && t.length > 2) t = t.slice(0, -1);
      if (t !== s.label) t += '…';
      g.fillText(t, flip ? -outer : outer, 0);
      g.restore();
    });
    g.beginPath(); g.arc(c, c, R, 0, 7); g.lineWidth = CW > 500 ? 8 : 5; g.strokeStyle = '#fff'; g.stroke();
  }
  // الضغط على العجلة: على الاسم = اختيارها مباشرة، وعلى «−» عند الطرف = إخراجها (غائبة)
  function tapWheel(canvas, e, rr) {
    if (spinning || !S) return;
    const r = canvas.getBoundingClientRect(), W = canvas.width, half = W / 2, R = half - 4;
    const x = (e.clientX - r.left) / r.width * W - half, y = (e.clientY - r.top) / r.height * W - half;
    const d = Math.hypot(x, y);
    if (d > R || d < R * 0.28) return;
    const sl = slices(); if (!sl.length) return;
    const seg = Math.PI * 2 / sl.length;
    let a = Math.atan2(y, x) - (angle - Math.PI / 2); a = ((a % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
    const i = Math.floor(a / seg) % sl.length, s = sl[i];
    if (rimShown(canvas, sl.length, rr) && d > R - rr * 2 - 10) {
      removeGirl(s.name); if (pick && pick.names.includes(s.name)) pick = null; renderAll(); return;
    }
    hidePop();
    const res = mode === 'num' ? pickNum(s) : mode === 'group' ? pickGroup(s) : markPicked(s.name);
    save(); spinTo(res);
  }
  function rotateTo(idx) {
    const sl = slices(), seg = Math.PI * 2 / Math.max(1, sl.length);
    const start = angle; let target = -(idx * seg + seg / 2);
    while (target - start > Math.PI) target -= Math.PI * 2;
    while (start - target > Math.PI) target += Math.PI * 2;
    popOpen();
    spinning = true; const t0 = performance.now(), dur = 450;
    (function frame(now) {
      const t = Math.min(1, (now - t0) / dur); angle = start + (target - start) * (1 - Math.pow(1 - t, 3)); drawWheel();
      if (t < 1) return requestAnimationFrame(frame);
      spinning = false; angle = angle % (Math.PI * 2);
      renderAll(); if (!bigOpen()) showBig();
      LP.sound && LP.sound.beep(660, 0.12, 0.15);
    })(t0);
  }
  cv.addEventListener('click', e => tapWheel(cv, e, 10));
  bwc.addEventListener('click', e => tapWheel(bwc, e, 22));
  function infoText() {
    const a = active().flat(), picked = S.round.picked.filter(n => a.includes(n)).length, gi = nextGroupIdx();
    if (mode === 'num') return W('رؤوس مرقمة · {d} من {n}', { d: S.nums.length, n: slices().length });
    if (mode === 'group') return W('عجلة المجموعات · {d} من {n}', { d: (S.gRound || []).length, n: slices().length });
    return W('جولة {r} · {p} من {n}', { r: S.round.n, p: picked, n: a.length }) + (gi >= 0 ? ' · ' + W('الدور: {g}', { g: gnW(gi) }) : '');
  }
  function renderInfo() {
    if (!S) { $('#mwInfo').textContent = ''; return; }
    const a = active().flat(), picked = S.round.picked.filter(n => a.includes(n)).length;
    const gi = nextGroupIdx();
    $('#mwInfo').textContent = infoText();
    $$('.wseg button').forEach(b => b.classList.toggle('on', b.dataset.m === mode));
    const off = S.removed.length;
    $('#mwOffN').textContent = off;
    $('#mwOff').hidden = off === 0;
  }
  function renderResult() {
    const r = $('#mwRes'), pts = $('#mwPts');
    if (!S) { r.innerHTML = ''; pts.classList.remove('on'); return; }
    r.innerHTML = resultHTML(W('اضغطي SPIN أو اختاري اسماً'));
    r.classList.toggle('isNum', !!(pick && pick.num));
    bindNum(r);
    pts.classList.toggle('on', !!(pick && pick.names.length && !pick.num));
    $('#mwOutPick').style.display = pick && !pick.num && !pick.group ? '' : 'none';
    // إذا طالت العجلة الصغيرة (أسماء الرقم مثلاً) نبقيها كاملة داخل الشاشة
    if (mw.classList.contains('on') && !document.body.classList.contains('mini')) requestAnimationFrame(() => placeMw(prof.mwPos));
  }
  // نصوص العجلة الثابتة بلغة العجلة
  const WST = [
    ['#mw .mw-seg [data-m=girl]', '', 'طالبة'], ['#mw .mw-seg [data-m=group]', '', 'مجموعة'], ['#mw .mw-seg [data-m=num]', '', 'رقم'],
    ['.bw-seg [data-m=girl]', '👤 ', 'طالبة'], ['.bw-seg [data-m=group]', '👥 ', 'مجموعة'], ['.bw-seg [data-m=num]', '# ', 'رقم'],
    ['#mwPts .p1', '', 'أجابت +1'], ['#bwPts .p1', '', 'أجابت +1'], ['#mwPts .p0', '', 'شاركت'], ['#bwPts .p0', '', 'شاركت'],
    ['#mwPts .pskip', '', 'تخطّي'], ['#bwPts .pskip', '', 'تخطّي'], ['#bwOutPick', 'غ ', 'غائبة'], ['#mwOutPick', '', 'غ'],
    ['#mwNames', '', 'الأسماء'], ['#bwRound', '↺ ', 'جولة جديدة'], ['#bwUndo', '↶ ', 'تراجع'],
    ['#wheelPanel .ph h2', '🎡 ', 'العجلة'], ['#wheelPanel .bw-hint', '', 'اضغطي على اسم الطالبة في العجلة لاختيارها مباشرة، وعلى «−» عند طرف قطاعها لإخراجها من العجلة.']
  ];
  let wstLang = null;
  function wheelStatic() {
    const l = wlang();
    // في الفصل المختلط: أزرار النتيجة بصيغة الطالب المختار (أجاب / أجابت)
    const pc = pick && pick.names && pick.names.length === 1 && LP.studentCtx ? LP.studentCtx(pick.names[0]) : null;
    const key = l + '|' + (pc ? pc.cg : '') + '|' + (window.LPG ? LPG.ctx.cg + LPG.ctx.tg : '');
    if (wstLang !== key) {
      wstLang = key;
      const dir0 = l === 'ar' ? 'rtl' : 'ltr';
      for (const [q, pre, k] of WST) document.querySelectorAll(q).forEach(e => { e.textContent = pre + W(k, null, pc); e.dir = dir0; });
      document.querySelectorAll('.bw-seg').forEach(e => { e.dir = dir0; });
      const lab = $('#bwAuto') && $('#bwAuto').parentNode; if (lab) lab.lastChild.nodeValue = ' ' + W('أخرجي الطالبة من العجلة بعد أن أمنحها النقاط');
      const dir = l === 'ar' ? 'rtl' : 'ltr';
      mw.dir = dir; $('#wheelPanel .pb.bw').dir = dir; $('#wheelPanel').lang = l; mw.lang = l;
    }
    // الزر يعرض اللغة التي سيتحوّل إليها
    const nx = l === 'ar' ? 'EN' : 'ع';
    $('#mwLang').textContent = nx; $('#bwLang').textContent = nx;
    $('#mwOff').innerHTML = `${esc(W('خارج العجلة'))} (<span id="mwOffN">${S ? S.removed.length : 0}</span>)`;
  }
  const toggleWl = (e) => {
    e && e.stopPropagation();
    const l = wlang(); prof.wheelLang = l === 'ar' ? (I18N.lang !== 'ar' ? I18N.lang : 'en') : 'ar';
    api.setSettings({ wheelLang: prof.wheelLang });
    renderAll();
    LP.toast(prof.wheelLang === 'ar' ? 'لغة العجلة: العربية' : prof.wheelLang === 'fr' ? 'Langue de la roue : français' : 'Wheel language: English');
  };
  LP.setWheelPref = (p) => { Object.assign(prof, p); renderAll(); };
  $('#mwLang').onclick = toggleWl; $('#bwLang').onclick = toggleWl;

  function renderAll() { if (S && (!snap || snap.id !== S.id)) logDeltas(); wheelStatic(); renderBar(); drawWheel(); renderInfo(); renderResult(); if ($('#mwPop').classList.contains('on')) renderPop(); renderBig(); }

  // ---------- الدوران ----------
  function choose() {
    if (mode === 'group') {
      const sl = slices(); if (!sl.length) return null;
      let free = sl.filter(x => !x.done);
      if (!free.length) { S.gRound = []; free = sl; }
      return pickGroup(free[Math.floor(Math.random() * free.length)]);
    }
    if (mode === 'num') {
      const sl = slices(); if (!sl.length) return null;
      let free = sl.filter(s => !s.done);
      if (!free.length) { S.nums = []; free = sl; }
      return pickNum(free[Math.floor(Math.random() * free.length)]);
    }
    const a = active(), all = a.flat();
    if (!all.length) return null;
    // جولة جديدة عندما يأتي دور الجميع
    if (all.every(n => S.round.picked.includes(n))) { S.round = { n: S.round.n + 1, picked: [] }; S.deferred = []; }
    const gi = nextGroupIdx();
    let cands = fairAll() ? a[gi].filter(n => eligible(n, a)) : a[gi].filter(n => !S.round.picked.includes(n));
    if (S.skipNext && cands.length > 1) cands = cands.filter(n => n !== S.skipNext);
    let name;
    if (cands.length) name = cands[Math.floor(Math.random() * cands.length)];
    else name = a[gi].slice().sort((x, y) => (S.turns[x] || 0) - (S.turns[y] || 0) || (S.last[x] || 0) - (S.last[y] || 0))[0];   // لا نتخطى المجموعة
    return markPicked(name, true);
  }
  function pickGroup(s) {
    S.gRound ||= []; if (!S.gRound.includes(s.grp)) S.gRound.push(s.grp);
    const names = active()[s.grp].slice();
    return { group: true, gi: s.grp, names, gis: names.map(() => s.grp), slice: slices().findIndex(x => x.grp === s.grp) };
  }
  function pickNum(s) {
    if (!S.nums.includes(s.num)) S.nums.push(s.num);
    const names = [], gis = [];
    active().forEach((g, gi) => { if (g[s.num - 1]) { names.push(g[s.num - 1]); gis.push(gi); } });
    return { num: s.num, names, gis, scored: {}, slice: slices().findIndex(x => x.num === s.num) };
  }
  // auto: من SPIN. الاختيار المباشر لا يغيّر ترتيب الدور، إلا إذا كانت الطالبة من المجموعة التي عليها الدور
  function markPicked(name, auto) {
    keepVisible = name;
    const gi = groupOf(name), turn = nextGroupIdx();
    const prev = { nextG: S.nextG, last: S.last[name], was: S.round.picked.includes(name), df: (S.deferred || []).includes(name) };
    S.skipNext = null;
    if (!S.round.picked.includes(name)) S.round.picked.push(name);
    if (S.deferred) S.deferred = S.deferred.filter(x => x !== name);
    S.turns[name] = (S.turns[name] || 0) + 1; S.last[name] = Date.now();
    if (auto || gi === turn || !fairAll()) S.nextG = (gi + 1) % S.groups.length;
    const sl = slices();
    return { names: [name], gis: [gi], prev, slice: sl.findIndex(s => s.name === name) };
  }
  // تخطّي: لا تُحسب مشاركة، وترجع إلى العجلة (والدور يبقى لمجموعتها)
  function skipPick() {
    if (!pick || !S || pick.num) return;
    if (pick.group) { S.gRound = (S.gRound || []).filter(g => g !== pick.gi); }
    else {
      const n = pick.names[0], pv = pick.prev || {};
      S.turns[n] = Math.max(0, (S.turns[n] || 0) - 1);
      if (!pv.was) S.round.picked = S.round.picked.filter(x => x !== n);
      if (pv.last) S.last[n] = pv.last; else delete S.last[n];
      if (pv.nextG !== undefined) S.nextG = pv.nextG;
      if (fairAll()) { S.deferred ||= []; if (!S.deferred.includes(n)) S.deferred.push(n); }   // تؤجَّل لنهاية الجولة
      else S.skipNext = n;
    }
    save();
    cheer('skip', bigOpen() ? $('#bwRes') : null);
    pick = null; keepVisible = null; popClose(); renderAll();
  }
  $$('#mwPts [data-skip], #bwPts [data-skip]').forEach(b => b.onclick = skipPick);
  function spin() {
    if (spinning || !S) return;
    hidePop();
    const res = choose();
    if (!res) { LP.toast(T('لا توجد طالبات في العجلة')); return; }
    save(); spinTo(res);
  }
  // دوران حقيقي كامل يقف على النتيجة (من SPIN أو عند الضغط على اسم)
  function spinTo(res) {
    const sl = slices(), seg = Math.PI * 2 / sl.length;
    const idx = Math.max(0, res.slice);
    let target = -(idx * seg + seg / 2 + (Math.random() - 0.5) * seg * 0.6);
    const start = angle % (Math.PI * 2);
    target -= Math.PI * 2 * (4 + Math.floor(Math.random() * 2));
    while (target > start - Math.PI * 2 * 3) target -= Math.PI * 2;
    popOpen();
    spinning = true; $('#mwSpin').disabled = true; $('#bwSpin').disabled = true; pick = null; renderResult();
    const dur = 2600, t0 = performance.now(), ease = t => 1 - Math.pow(1 - t, 4);
    let lastSeg = -1;
    (function frame(now) {
      const t = Math.min(1, (now - t0) / dur);
      angle = start + (target - start) * ease(t);
      try { drawWheel(); } catch (e) { console.error(e); }
      const cur = Math.floor((((-angle) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2) / seg);
      if (cur !== lastSeg) { lastSeg = cur; LP.sound && LP.sound.tickSound(); }
      if (t < 1) return requestAnimationFrame(frame);
      spinning = false; $('#mwSpin').disabled = false; $('#bwSpin').disabled = false;
      angle = angle % (Math.PI * 2);
      pick = res; renderAll(); if (!bigOpen()) showBig();
      LP.sound && LP.sound.fanfare();
    })(t0);
  }
  $('#mwSpin').onclick = spin;
  $('#mwFoldSpin').onclick = (e) => { e.stopPropagation(); spin(); };
  $('#bwSpin').onclick = spin;
  $('#mwRound').onclick = $('#bwRound').onclick = () => {
    if (!S) return;
    if (mode === 'num') S.nums = []; else if (mode === 'group') S.gRound = []; else { S.round = { n: S.round.n + 1, picked: [] }; S.deferred = []; }
    save(); pick = null; keepVisible = null; renderAll(); LP.toast(T('بدأت جولة جديدة'));
  };
  $$('.wseg button').forEach(b => b.onclick = () => { if (spinning || mode === b.dataset.m) return; mode = b.dataset.m; pick = null; angle = 0; renderAll(); });

  // العجلة المنبثقة: عند الدوران تكبر في وسط الدرس، وبعد ظهور الاسم بثانيتين تعود لمكانها
  // (في الوضع المصغّر فوق البرامج تكبر النافذة الصغيرة نفسها من زاويتها العليا)
  let popT = null, popMode = null, popPh = null, popPrev = null, popMove = 0;
  const popWanted = () => prof.wheelPop !== false || (LP.dockSize && LP.dockSize('wheel') === 'fold');
  function popOpen() {
    clearTimeout(popT);
    if (popMode || bigOpen() || !popWanted() || !mw.classList.contains('on')) return;
    if (document.body.classList.contains('mini')) { mw.style.transformOrigin = '0 0'; mw.classList.add('big'); popMode = 'mini'; return; }
    popPrev = { parent: mw.parentNode, left: mw.style.left, top: mw.style.top };
    if (mw.parentNode !== stage) { popPh = document.createElement('div'); popPh.className = 'mw-ph'; popPh.dataset.k = 'wheel'; popPh.style.height = mw.offsetHeight + 'px'; mw.parentNode.insertBefore(popPh, mw); stage.appendChild(mw); }
    mw.classList.add('pop'); popMode = 'pop';
    mw.style.left = Math.max(8, (stage.clientWidth - mw.offsetWidth) / 2) + 'px';
    mw.style.top = Math.max(8, (stage.clientHeight - mw.offsetHeight) / 2) + 'px';
    drawWheel();
  }
  function popClose() {
    clearTimeout(popT);
    if (!popMode) return;
    if (popMode === 'mini') mw.classList.remove('big');
    else {
      mw.classList.remove('pop');
      if (popPh) { popPh.replaceWith(mw); popPh = null; }
      if (popPrev) { mw.style.left = popPrev.left; mw.style.top = popPrev.top; }
    }
    popMode = null; popPrev = null; drawWheel();
    if (mw.parentNode === stage && !document.body.classList.contains('mini')) placeMw(prof.mwPos);
  }
  function popLater(ms) { clearTimeout(popT); popT = setTimeout(() => { if (Date.now() - popMove < 700) return popLater(700); popClose(); }, ms || 2000); }
  const showBig = () => { if (popMode) popLater(); };
  // إن كانت المعلمة تحرّك الفأرة فوقها (تريد الضغط على زر) ننتظر حتى تتوقف
  mw.addEventListener('pointermove', (e) => { if (popMode && (e.movementX || e.movementY)) popMove = Date.now(); });

  // ---------- النقاط ----------
  function give(v) {
    if (!pick || !pick.names.length || !S) return;
    if (pick.group) {   // عجلة المجموعات: النقطة للمجموعة كلها
      S.gpts[pick.gi] += v; S.hist.push({ kind: 'g', gi: pick.gi, v }); save();
      cheer(v, bigOpen() ? $('#bwRes') : null);
      if (LP.sound) { if (v > 0) LP.sound.fanfare(); else if (v < 0) LP.sound.beep(200, 0.35, 0.2, 0, 'sawtooth'); }
      pick = null; popClose(); renderAll(); return;
    }
    pick.names.forEach((n, j) => { S.pts[n] = (S.pts[n] || 0) + v; if (pick.gis[j] >= 0) S.gpts[pick.gis[j]] += v; });
    S.hist.push({ kind: 's', names: pick.names.slice(), gis: pick.gis.slice(), v });
    save();
    cheer(v, bigOpen() ? $('#bwRes') : null);
    if (LP.sound) { if (v > 0) LP.sound.fanfare(); else if (v < 0) LP.sound.beep(200, 0.35, 0.2, 0, 'sawtooth'); }
    pick = null; keepVisible = null; popClose(); renderAll();
  }
  // الرؤوس المرقمة: لكل طالبة نقطتها (لها ولمجموعتها)
  function giveNum(n, v, near) {
    if (!pick || !pick.num || !pick.names.includes(n) || n in pick.scored) return;
    const gi = groupOf(n);
    S.pts[n] = (S.pts[n] || 0) + v; if (gi >= 0) S.gpts[gi] += v;
    S.turns[n] = (S.turns[n] || 0) + 1; S.last[n] = Date.now();
    S.hist.push({ kind: 's', names: [n], gis: [gi], v }); pick.scored[n] = v; save();
    cheer(v, near);
    if (LP.sound) { if (v > 0) LP.sound.beep(880, 0.12, 0.15); else if (v < 0) LP.sound.beep(200, 0.3, 0.2, 0, 'sawtooth'); }
    renderAll();
  }
  // نص النتيجة لكل نوع من العجلة (للعجلة الصغيرة والكبيرة)
  function resultHTML(hint) {
    if (!pick) return `<small>${hint}</small>`;
    if (pick.group) return `<b style="color:${GCOL[pick.gi % GCOL.length]}">${esc(gnW(pick.gi))}</b><span class="members">${pick.names.map(n => esc(dn(n))).join(' · ')}</span>`;
    if (pick.num) return `<b>${W('رقم {n}', { n: pick.num })}</b><div class="nrows">${pick.names.map((n, j) => {
      const sc = pick.scored[n];
      return `<div class="nrow"><i style="background:${GCOL[pick.gis[j] % GCOL.length]}"></i><span class="nn">${esc(gnW(pick.gis[j]))}: <b>${esc(dn(n))}</b></span>${sc === undefined
        ? `<button class="n1" data-nv="1" data-n="${esc(n)}" title="${W('أجابت +1', null, LP.studentCtx && LP.studentCtx(n))}">+1</button><button class="n0" data-nv="0" data-n="${esc(n)}">${W('شاركت', null, LP.studentCtx && LP.studentCtx(n))}</button><button class="nm" data-nv="-1" data-n="${esc(n)}">−1</button>`
        : `<em class="${sc > 0 ? 'up' : sc < 0 ? 'down' : ''}">${sc > 0 ? W('أجابت +1', null, LP.studentCtx && LP.studentCtx(n)) : sc < 0 ? '−1' : W('شاركت', null, LP.studentCtx && LP.studentCtx(n))} ✓</em>`}</div>`;
    }).join('') || '—'}</div>`;
    return `<b dir="auto">${esc(dn(pick.names[0]))}</b><small>${esc(gnW(pick.gis[0]))} · ${W('{n} نقطة', { n: S.pts[pick.names[0]] || 0 })}</small>`;
  }
  const bindNum = (root) => root.querySelectorAll('[data-nv]').forEach(b => b.onclick = () => giveNum(b.dataset.n, +b.dataset.nv, b));
  // نقطة سريعة من قائمة الأسماء (لها ولمجموعتها)
  function giveTo(n, v, near) {
    const gi = groupOf(n);
    S.pts[n] = (S.pts[n] || 0) + v; if (gi >= 0) S.gpts[gi] += v;
    S.hist.push({ kind: 's', names: [n], gis: [gi], v }); save();
    fx(v > 0 ? '+1' : '−1', v > 0 ? '#2fb344' : '#e5484d', near);
    if (LP.sound) { if (v > 0) LP.sound.beep(880, 0.12, 0.15); else LP.sound.beep(200, 0.3, 0.2, 0, 'sawtooth'); }
    renderAll();
  }
  $$('#mwPts [data-v], #bwPts [data-v]').forEach(b => b.onclick = () => give(+b.dataset.v));
  // «غ» غائب: يُسجَّل الغياب بتاريخه، ويخرج من العجلة لهذه الحصة (بلا مشاركة ولا نقطة)، ثم تدور العجلة من جديد
  function markAbsent(n) {
    if (!S || !n) return;
    if (pick && pick.names[0] === n && !pick.num && !pick.group) {
      const pv = pick.prev || {};
      S.turns[n] = Math.max(0, (S.turns[n] || 0) - 1);
      if (!pv.was) S.round.picked = S.round.picked.filter(x => x !== n);
      if (pv.last) S.last[n] = pv.last; else delete S.last[n];
      if (pv.nextG !== undefined) S.nextG = pv.nextG;
    }
    S.absent ||= {}; S.absent[n] = Date.now();
    if (!S.removed.includes(n)) S.removed.push(n);
    save();
    LP.toast(I18N.t('سُجّل غياب {n} — يمكن إرجاعها من «خارج العجلة» إن حضرت', { n: dn(n) }, LP.studentCtx && LP.studentCtx(n)));
    pick = null; keepVisible = null; popClose(); renderAll();
    if (mw.classList.contains('on') || bigOpen()) setTimeout(() => { if (!spinning) spin(); }, 700);
  }
  $('#mwOutPick').onclick = $('#bwOutPick').onclick = () => { if (pick && !pick.num && !pick.group) markAbsent(pick.names[0]); };
  // عبارات تشجيعية بلغة العجلة (عشوائية، ولا تتكرر العبارة نفسها مرتين متتاليتين)
  const CHEERS = {
    ar: { p: ['رائع!', 'ممتاز!', 'إجابة صحيحة!', 'أحسنت!', 'عمل رائع!', 'إبداع!', 'تألّق!', 'إجابة بطولية!'],
          z: ['شكراً على المشاركة!', 'مشاركة جميلة!', 'محاولة جيدة!', 'شكراً!'],
          m: ['لا بأس!', 'المرة القادمة أفضل!', 'نتعلّم من الخطأ!'],
          s: ['لاحقاً!', 'سنعود بعد قليل', 'تخطّي'] },
    en: { p: ['Great job!', 'Excellent!', 'Well done!', 'Awesome!', 'Brilliant!', 'Correct!', 'Super star!', 'Fantastic!'],
          z: ['Thanks for sharing!', 'Nice try!', 'Good effort!', 'Thank you!'],
          m: ['Oops!', 'Next time!', 'Keep trying!'],
          s: ['Later!', 'We’ll come back!', 'Skipped'] },
    fr: { p: ['Bravo !', 'Excellent !', 'Très bien !', 'Super !', 'Génial !', 'Bonne réponse !'],
          z: ['Merci de participer !', 'Bel essai !', 'Merci !'],
          m: ['Oups !', 'La prochaine fois !', 'Courage !'],
          s: ['Plus tard !', 'On revient vite !', 'Passé'] }
  };
  let lastCheer = '';
  function cheer(v, near) {
    if (prof.wheelCheers === false) { fx(v === 'skip' ? W('تخطّي') : v > 0 ? '+1' : v < 0 ? '−1' : W('شاركت'), v === 'skip' ? '#868e96' : v > 0 ? '#2fb344' : v < 0 ? '#e5484d' : '#868e96', near); return; }
    const set = CHEERS[wlang()] || CHEERS.en, k = v === 'skip' ? 's' : v > 0 ? 'p' : v < 0 ? 'm' : 'z';
    let list = set[k].filter(x => x !== lastCheer); if (!list.length) list = set[k];
    const t = list[Math.floor(Math.random() * list.length)]; lastCheer = t;
    const tail = k === 'p' ? ' \u2066+1\u2069' : k === 'm' ? ' \u2066−1\u2069' : '';
    fx(t + tail, k === 'p' ? '#2fb344' : k === 'm' ? '#e5484d' : k === 'z' ? '#1c7ed6' : '#868e96', near, true);
  }
  function fx(text, color, near, big) {
    const d = document.createElement('div'); d.className = 'mw-fx' + (big ? ' cheer' : ''); d.textContent = text; d.style.color = color;
    d.dir = wlang() === 'ar' ? 'rtl' : 'ltr';
    if (near) { const r = near.getBoundingClientRect(), sr = stage.getBoundingClientRect(); d.style.left = (r.left - sr.left + r.width / 2) + 'px'; d.style.top = (r.top - sr.top + 40) + 'px'; stage.appendChild(d); }
    else if (big && mw.closest('#dock')) { d.classList.add('onStage'); stage.appendChild(d); }   // العجلة في العمود: العبارة كبيرة فوق الدرس ليراها الجميع
    else mw.appendChild(d);
    setTimeout(() => d.remove(), big ? 1600 : 1000);
  }

  // ---------- الإخراج والإرجاع ----------
  function removeGirl(n) {
    if (!S.removed.includes(n)) S.removed.push(n);
    save(); LP.toast(I18N.t('خرجت {n} من العجلة', { n: dn(n) }, LP.studentCtx && LP.studentCtx(n)));
  }
  function returnGirl(n) { S.removed = S.removed.filter(x => x !== n); if (S.absent && S.absent[n]) { delete S.absent[n]; LP.toast(I18N.t('أُلغي غياب {n} ✓', { n: dn(n) }, LP.studentCtx && LP.studentCtx(n))); } save(); }

  // ---------- القوائم الصغيرة (مخفية حتى تُضغط) ----------
  let popKind = null;
  function hidePop() { popKind = null; $('#mwPop').classList.remove('on'); }
  // قائمة الأسماء تظهر فوق كل شيء (لا تختفي خلف الأهداف أو المؤقت)، بجانب العجلة
  function placePop() {
    const pop = $('#mwPop'), mw = $('#mw');
    if (pop.parentElement !== document.body) document.body.appendChild(pop);
    const r = mw.getBoundingClientRect(), vw = innerWidth, vh = innerHeight, w = Math.min(300, vw - 24);
    const toLeft = r.left + r.width / 2 > vw / 2;
    let x = toLeft ? r.left - w - 8 : r.right + 8;
    if (x < 12 || x + w > vw - 12) x = Math.max(12, Math.min(vw - w - 12, r.left + (r.width - w) / 2));
    const top = Math.max(12, Math.min(r.top, vh - 260));
    Object.assign(pop.style, { left: x + 'px', top: top + 'px', width: w + 'px', maxHeight: (vh - top - 12) + 'px' });
  }
  function togglePop(kind) {
    if (popKind === kind) return hidePop();
    popKind = kind; renderPop(); placePop(); $('#mwPop').classList.add('on');
  }
  addEventListener('resize', () => { if (popKind) placePop(); });
  const popHead = (t) => `<div class="mwp-head"><b>${t}</b><button class="mwp-x" title="${W('إغلاق')}">✕</button></div>`;
  const wirePopHead = (pop) => { const x = pop.querySelector('.mwp-x'); if (x) x.onclick = () => hidePop(); };
  function renderPop() {
    const pop = $('#mwPop');
    if (!S) { pop.innerHTML = ''; return; }
    if (popKind === 'off') {
      if (!S.removed.length) return hidePop();
      pop.innerHTML = popHead(W('خارج العجلة')) + S.removed.map(n =>
        `<div class="mw-row"><span class="nm">${esc(dn(n))}${S.absent && S.absent[n] ? ` <em class="absb">${W('غ')}</em>` : ''}</span><button data-back="${esc(n)}" title="${W('إرجاع إلى العجلة')}">↺</button></div>`).join('');
      wirePopHead(pop);
      pop.querySelectorAll('[data-back]').forEach(b => b.onclick = () => { returnGirl(b.dataset.back); renderAll(); });
      return;
    }
    const off = new Set(S.removed), picked = new Set(S.round.picked);
    pop.innerHTML = popHead(W('الأسماء')) + S.groups.map((g, gi) => {
      const rows = g.filter(n => !off.has(n)).sort((a, b) => a.localeCompare(b, 'ar')).map(n =>
        `<div class="mw-row ${picked.has(n) ? 'done' : 'wait'}"><span class="nm" data-pick="${esc(n)}" title="${W('اختاريها مباشرة')}">${esc(dn(n))}</span>
          <span class="pt">${S.pts[n] || 0}</span><button data-thx="${esc(n)}" title="${W('شهادة شكر')}">🎖</button><button data-out="${esc(n)}" title="${W('إخراج من العجلة')}">−</button></div>`).join('');
      return `<div class="ph2"><i style="background:${GCOL[gi % GCOL.length]}"></i>${esc(gnW(gi))}</div>${rows || `<div class="mw-empty">—</div>`}`;
    }).join('');
    wirePopHead(pop);
    pop.querySelectorAll('[data-out]').forEach(b => b.onclick = () => { removeGirl(b.dataset.out); renderAll(); });
    pop.querySelectorAll('[data-thx]').forEach(b => b.onclick = () => { hidePop(); if (LP.thanks) LP.thanks(b.dataset.thx); });
    pop.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => {
      if (spinning) return; mode = 'girl'; hidePop(); const res = markPicked(b.dataset.pick); save(); spinTo(res);
    });
  }
  $('#mwNames').onclick = () => togglePop('names');
  $('#mwOff').onclick = () => togglePop('off');
  document.addEventListener('pointerdown', e => { if (popKind && !e.target.closest('#mw') && !e.target.closest('#mwPop')) hidePop(); }, true);

  // ---------- السحب وحفظ المكان ----------
  function placeMw(pos) {
    if (mw.closest('#dock') || popMode) return;
    const W = stage.clientWidth, H = stage.clientHeight, w = mw.offsetWidth || 210, h = mw.offsetHeight || 330;
    const x = Math.max(4, Math.min(W - w - 4, (pos ? pos.x : 1) * (W - w)));
    const y = Math.max(4, Math.min(H - h - 4, (pos ? pos.y : 1) * (H - h)));
    mw.style.left = x + 'px'; mw.style.top = y + 'px';
    mw.classList.toggle('popDown', y < 320);
  }
  (() => {
    // السحب الموحّد مع الالتصاق المغناطيسي (في goals.js)
    LP.floatDrag(mw, $('#mwHead'), 'mwPos', (x, y) => mw.classList.toggle('popDown', y < 320), (pos) => { prof.mwPos = pos; });
    new ResizeObserver(() => { if (mw.classList.contains('on') && !document.body.classList.contains('mini')) placeMw(prof.mwPos); }).observe(stage);
  })();

  // ================= العجلة الكبيرة (نفس العجلة ونفس الجولة والنقاط) =================
  let bwListOn = false;
  function renderBig() {
    if (!bigOpen()) return;
    if (!S) { $('#bwInfo').textContent = ''; $('#bwRes').innerHTML = ''; $('#bwList').innerHTML = ''; return; }
    const a = active().flat(), picked = S.round.picked.filter(n => a.includes(n)).length, gi = nextGroupIdx();
    $('#bwInfo').textContent = mode === 'girl' ? W('جولة {r} · {p} من {n}', { r: S.round.n, p: picked, n: a.length }) : infoText();
    $('#bwTurn').innerHTML = mode === 'girl' && gi >= 0 ? `<i style="background:${GCOL[gi % GCOL.length]}"></i>${esc(W('الدور: {g}', { g: gnW(gi) }))}` : '';
    // النتيجة
    const r = $('#bwRes');
    r.innerHTML = resultHTML(W(mode === 'girl' ? 'اضغطي SPIN، أو اضغطي على اسم في العجلة لاختيارها' : mode === 'group' ? 'اضغطي SPIN لاختيار مجموعة' : 'اضغطي SPIN لاختيار رقم'));
    bindNum(r);
    $('#bwPts').classList.toggle('on', !!(pick && pick.names.length && !pick.num));
    $('#bwOutPick').style.display = pick && !pick.num && !pick.group ? '' : 'none';
    $('#bwAuto').checked = !!prof.autoHide;
    $('#bwListBtn').textContent = W(bwListOn ? 'إخفاء قائمة الأسماء' : 'إظهار قائمة الأسماء');
    renderBigList();
  }
  function renderBigList() {
    const box = $('#bwList');
    box.classList.toggle('on', bwListOn);
    const off = new Set(S.removed);
    $('#bwOff').innerHTML = S.removed.length ? `<span>${W('خارج العجلة')}:</span>` + S.removed.map(n => `<button class="bback" data-back="${esc(n)}" title="${W('إرجاع إلى العجلة')}">↺ ${esc(dn(n))}${S.absent && S.absent[n] ? ` <em class="absb">${W('غ')}</em>` : ''}</button>`).join('') : '';
    $$('#bwOff [data-back]').forEach(b => b.onclick = () => { returnGirl(b.dataset.back); renderAll(); });
    if (!bwListOn) { box.innerHTML = ''; return; }
    const picked = new Set(S.round.picked);
    box.innerHTML = S.groups.map((g, gi) => `<div class="bgrp"><div class="bgh"><i style="background:${GCOL[gi % GCOL.length]}"></i>${esc(gnW(gi))} <span>${S.gpts[gi]}</span></div>
      ${g.filter(n => !off.has(n)).sort((x, y) => dn(x).localeCompare(dn(y), 'ar')).map(n => `<div class="bchip ${(S.turns[n] || 0) === 0 ? 'zero' : ''} ${picked.has(n) ? 'done' : ''}">
        <span class="nm" data-pick="${esc(n)}" title="${esc(n)}">${esc(dn(n))}</span><i>${S.pts[n] || 0}</i><small title="${W('المشاركات')}">🙋${S.turns[n] || 0}</small>
        <button class="pl" data-plus="${esc(n)}" title="+1">+1</button><button class="mn" data-out="${esc(n)}" title="${W('إخراج من العجلة')}">−</button></div>`).join('') || '<div class="muted">—</div>'}</div>`).join('');
    $$('#bwList [data-pick]').forEach(b => b.onclick = () => { if (spinning) return; mode = 'girl'; const res = markPicked(b.dataset.pick); save(); spinTo(res); });
    $$('#bwList [data-plus]').forEach(b => b.onclick = () => giveTo(b.dataset.plus, 1, b));
    $$('#bwList [data-out]').forEach(b => b.onclick = () => { removeGirl(b.dataset.out); if (pick && pick.names.includes(b.dataset.out)) pick = null; renderAll(); });
  }
  $('#bwListBtn').onclick = () => { bwListOn = !bwListOn; renderBig(); };
  $('#bwAuto').onchange = () => setAutoHide($('#bwAuto').checked);
  function setAutoHide(on) { prof.autoHide = on; api.setSettings({ autoHide: on }); renderAll(); }
  $('#bwUndo').onclick = () => undo();
  async function openBigWheel() {
    if (bigOpen()) { LP.closePanels(); return; }
    if (!(await ensureSession(true))) { noNames(); return; }
    LP.openPanel($('#wheelPanel'));
    renderAll();
  }
  $('#wheelBtn').onclick = openBigWheel;
  $('#bwMini').onclick = () => { LP.closePanels(); toggleWheel(true); };
  document.addEventListener('keydown', e => {
    if (!bigOpen() || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); spin(); }
    else if (pick && (e.key === '1' || e.key === '0' || e.key === '-')) { e.preventDefault(); e.stopPropagation(); give(e.key === '1' ? 1 : e.key === '0' ? 0 : -1); }
  }, true);
  new ResizeObserver(() => { if (bigOpen()) drawWheel(); }).observe($('#wheelPanel'));
  LP.openBigWheel = openBigWheel;
  LP.setAutoHide = setAutoHide;

  // ================= الإظهار والإخفاء =================
  function noNames() {
    LP.toast(T('أضيفي أسماء الطالبات أولاً من «اختيار طالب عشوائي»'), T('إضافة الأسماء'), () => LP.openNamesPanel(), 6000);
  }
  async function toggleWheel(force) {
    const on = force !== undefined ? force : !mw.classList.contains('on');
    if (!on) { popClose(); mw.classList.remove('on', 'big'); hidePop(); api.setSettings({ mwOn: false }); return; }
    if (!(await ensureSession(true))) { noNames(); return; }
    mw.classList.add('on'); if (!document.body.classList.contains('mini')) placeMw(prof.mwPos); drawWheel(); api.setSettings({ mwOn: true });
  }
  async function toggleBar(force) {
    const on = force !== undefined ? force : !bar.classList.contains('on');
    if (!on) { bar.classList.remove('on'); api.setSettings({ gbOn: false }); return; }
    await ensureSession(true);
    bar.classList.add('on'); renderBar(); api.setSettings({ gbOn: true });
  }
  $('#qWheel').onclick = () => toggleWheel();
  $('#qGroups').onclick = () => toggleBar();
  const syncBtns = () => { $('#qWheel').classList.toggle('on', mw.classList.contains('on')); $('#qGroups').classList.toggle('on', bar.classList.contains('on')); };
  new MutationObserver(syncBtns).observe(mw, { attributes: true, attributeFilter: ['class'] });
  new MutationObserver(syncBtns).observe(bar, { attributes: true, attributeFilter: ['class'] });
  $('#mwClose').onclick = () => toggleWheel(false);
  $('#mwTimer').onclick = (e) => { e.stopPropagation(); LP.openTimer && LP.openTimer($('#mwTimer')); };
  $('#miniWheelBtn').onclick = () => toggleWheel();
  $('#grpBarBtn').onclick = () => toggleBar();
  LP.toggleMiniWheel = toggleWheel;
  LP.toggleGroupBar = toggleBar;
  // مفاتيح النقاط عند ظهور الاختيار
  LP.miniWheelKey = (k) => {
    if (!(mw.classList.contains('on') || bigOpen()) || !pick) return false;
    if (k === '1') { give(1); return true; }
    if (k === '0') { give(0); return true; }
    if (k === '-' || k === '_') { give(-1); return true; }
    return false;
  };

  // تغيّر الأسماء أو الفصل
  document.addEventListener('lp-classes', async () => {
    if (!mw.classList.contains('on') && !bar.classList.contains('on')) return;
    const before = classKey();
    await loadProfile(); cls = curClass();
    if (classKey() !== before) { pick = null; delete chosen[classKey()]; }
    await ensureSession(classKey() !== before);
  });

  document.addEventListener('lp-auth', async (e) => {
    if (!e.detail || !e.detail.user) return;
    await loadProfile();
    if (prof.gbPin || prof.gbOn) toggleBar(true);
    if (prof.mwOn) toggleWheel(true);
  });
  function resetPoints() {
    if (!S) return;
    S.pts = {}; S.turns = {}; S.gpts = S.groups.map(() => 0); S.hist = []; S.round = { n: 1, picked: [] }; S.nums = []; S.nextG = 0;
    // التصفير يحذف أحداث هذه الحصة من السجل (لا يُحسب كنقاط سالبة اليوم)
    const cd = cdata(); if (cd.log) cd.log = cd.log.filter(e => e.sid !== S.id);
    snap = snapOf(S);
    pick = null; keepVisible = null; save(); renderAll();
  }
  function resetClock() { if (!S) return; S.clock = { acc: 0, since: null }; save(); renderClock(); }
  LP._groups = { get S() { return S; }, spin, give, markAbsent, rebalance, get pick() { return pick; }, removeGirl: (n) => { removeGirl(n); renderAll(); }, returnGirl: (n) => { returnGirl(n); renderAll(); },
    moveGirl: (n, gi) => { const ok = moveGirl(n, gi); if (ok) renderAll(); return ok; }, swapGirls: (a, b) => { const ok = swapGirls(a, b); if (ok) renderAll(); return ok; }, groupOf: (n) => groupOf(n),
    sessionDialog, copyExcel, resetPoints, resetClock, dn, ensure: ensureSession, render: renderAll, get autoHide() { return !!prof.autoHide; }, defaultCount, roster: () => roster() };
  LP.session = { get S() { return S; }, get cd() { return cls ? cdata() : null; }, get L() { return LH(); }, saveLesson, get cls() { return cls; }, save, setTitle, shortName: dn, fullShort: shortName, groupName, groupOf, get G() { return G; }, fmtDate, ensure: ensureSession, render: renderAll, copyExcel, paintCertBase: null, GCOL };
})();
