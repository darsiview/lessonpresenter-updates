// سحب موحّد للبطاقات العائمة (العجلة، المؤقّت، الأهداف) مع التصاق مغناطيسي
(() => {
  const $ = (s) => document.querySelector(s);
  const api = window.api;
  const stage = $('#stage');
  // ================= سحب موحّد + التصاق =================
  // el: البطاقة، handle: مقبض السحب، key: مفتاح حفظ الموضع في الإعدادات
  const SNAP = 14;
  LP.floatDrag = function (el, handle, key, onMove, onEnd) {
    let d = null;
    const others = () => [...stage.querySelectorAll('.fcard.on, #mw.on, .timerW.on')].filter(x => x !== el);
    handle.addEventListener('pointerdown', e => {
      if (e.target.closest('button,input,textarea,select,[contenteditable="true"]') || document.body.classList.contains('mini') || el.closest('#dock')) return;
      d = { x: e.clientX - el.offsetLeft, y: e.clientY - el.offsetTop }; handle.setPointerCapture(e.pointerId);
      el.classList.add('dragging');
    });
    handle.addEventListener('pointermove', e => {
      if (!d) return;
      const W = stage.clientWidth, H = stage.clientHeight, w = el.offsetWidth, h = el.offsetHeight;
      let x = e.clientX - d.x, y = e.clientY - d.y;
      // التصاق بحواف المسرح
      const xs = [[4, 0], [W - w - 4, 0]], ys = [[4, 0], [H - h - 4, 0]];
      // التصاق بالبطاقات الأخرى (جنباً إلى جنب أو فوق بعض) ومحاذاة حوافها
      for (const o of others()) {
        const L = o.offsetLeft, Tp = o.offsetTop, R = L + o.offsetWidth, B = Tp + o.offsetHeight, G = 6;
        xs.push([R + G], [L - w - G], [L], [R - w]);
        ys.push([B + G], [Tp - h - G], [Tp], [B - h]);
      }
      let bx = null, by = null;
      for (const [v] of xs) if (Math.abs(x - v) < SNAP && (bx === null || Math.abs(x - v) < Math.abs(x - bx))) bx = v;
      for (const [v] of ys) if (Math.abs(y - v) < SNAP && (by === null || Math.abs(y - v) < Math.abs(y - by))) by = v;
      if (bx !== null) x = bx; if (by !== null) y = by;
      x = Math.max(4, Math.min(W - w - 4, x)); y = Math.max(4, Math.min(H - h - 4, y));
      el.style.left = x + 'px'; el.style.top = y + 'px';
      el.classList.toggle('snapped', bx !== null || by !== null);
      if (onMove) onMove(x, y);
    });
    const up = () => {
      if (!d) return; d = null; el.classList.remove('dragging', 'snapped');
      const W = stage.clientWidth - el.offsetWidth, H = stage.clientHeight - el.offsetHeight;
      const pos = { x: W > 0 ? el.offsetLeft / W : 0, y: H > 0 ? el.offsetTop / H : 0 };
      if (key) api.setSettings({ [key]: pos });
      el._pos = pos;
      if (onEnd) onEnd(pos);
    };
    handle.addEventListener('pointerup', up); handle.addEventListener('pointercancel', up);
  };
  // ================= تغيير الحجم بالسحب من أي طرف أو زاوية =================
  // o.ratio: { get: () => k, set: (k) => {}, min, max } ← تكبير متناسب (العجلة، المؤقّت)
  // بدون ratio: عرض وارتفاع حرّان (الأهداف) مع o.minW / o.minH
  // o.posKey: مفتاح حفظ الموضع (حين يتغير بالسحب من الطرف الأيسر/الأعلى)، o.onEnd: بعد الانتهاء
  LP.floatResize = function (el, o = {}) {
    const DIRS = ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'];
    let d = null;
    for (const dir of DIRS) {
      const h = document.createElement('i'); h.className = 'rzh rz-' + dir; h.dataset.rz = dir;
      el.appendChild(h);
      h.addEventListener('pointerdown', e => {
        if (el.closest('#dock') || e.button) return;
        e.preventDefault(); e.stopPropagation(); try { h.setPointerCapture(e.pointerId); } catch {}
        d = { dir, x: e.clientX, y: e.clientY, w: el.offsetWidth, h: el.offsetHeight, l: el.offsetLeft, t: el.offsetTop, k: o.ratio ? o.ratio.get() : 1 };
        el.classList.add('resizing'); el.dataset.user = 1;
        // المتابعة على مستوى الصفحة (لا نعتمد على التقاط المؤشر وحده)
        document.addEventListener('pointermove', move, true);
        document.addEventListener('pointerup', up, true);
        document.addEventListener('pointercancel', up, true);
      });
      const move = (e) => {
        if (!d) return;
        const mini = document.body.classList.contains('mini');
        let dx = e.clientX - d.x, dy = e.clientY - d.y;
        if (d.dir.includes('w')) dx = -dx;
        if (d.dir.includes('n')) dy = -dy;
        if (!d.dir.includes('e') && !d.dir.includes('w')) dx = 0;
        if (!d.dir.includes('n') && !d.dir.includes('s')) dy = 0;
        const repos = () => {    // السحب من اليسار/الأعلى: الطرف المقابل يبقى مكانه
          if (mini) return;
          if (d.dir.includes('w')) el.style.left = Math.max(4, d.l + d.w - el.offsetWidth) + 'px';
          if (d.dir.includes('n')) el.style.top = Math.max(4, d.t + d.h - el.offsetHeight) + 'px';
        };
        if (o.ratio) {
          const sx = d.w ? (d.w + dx) / d.w : 1, sy = d.h ? (d.h + dy) / d.h : 1;
          const sc = !dx ? sy : !dy ? sx : (Math.abs(sx - 1) > Math.abs(sy - 1) ? sx : sy);
          const prev = o.ratio.get();
          o.ratio.set(Math.max(o.ratio.min || .5, Math.min(o.ratio.max || 2.5, d.k * sc)));
          repos();
          // لا تتجاوز البطاقة حدود الشاشة: نرجع لآخر حجم يتسع
          if (!mini && o.ratio.get() > prev) {
            const W = stage.clientWidth, H = stage.clientHeight;
            // إن اقتربت من الحافة تُزاح البطاقة للداخل، وإن لم تتسع الشاشة نرجع لآخر حجم
            if (el.offsetTop + el.offsetHeight > H - 4) el.style.top = Math.max(4, H - el.offsetHeight - 4) + 'px';
            if (el.offsetLeft + el.offsetWidth > W - 4) el.style.left = Math.max(4, W - el.offsetWidth - 4) + 'px';
            if (el.offsetWidth > W - 8 || el.offsetHeight > H - 8) { o.ratio.set(prev); repos(); }
          }
          return;
        } else {
          const W = stage.clientWidth, H = stage.clientHeight;
          const nw = Math.max(o.minW || 200, Math.min(mini ? 2000 : W - 8, d.w + dx)), nh = Math.max(o.minH || 100, Math.min(mini ? 2000 : H - 8, d.h + dy));
          if (dx) el.style.width = nw + 'px';
          if (dy) el.style.height = nh + 'px';
        }
        repos();
      };
      const up = () => {
        document.removeEventListener('pointermove', move, true);
        document.removeEventListener('pointerup', up, true);
        document.removeEventListener('pointercancel', up, true);
        if (!d) return; d = null; el.classList.remove('resizing');
        if (!document.body.classList.contains('mini')) {
          const W = stage.clientWidth - el.offsetWidth, H = stage.clientHeight - el.offsetHeight;
          const pos = { x: W > 0 ? el.offsetLeft / W : 0, y: H > 0 ? el.offsetTop / H : 0 };
          el._pos = pos; if (o.posKey) api.setSettings({ [o.posKey]: pos });
        }
        if (o.onEnd) o.onEnd();
      };
    }
  };
  LP.floatPlace = function (el, pos, def) {
    if (el.closest('#dock')) { el._pos = pos || def; return; }       // داخل العمود الجانبي: مكانه ثابت
    const W = stage.clientWidth, H = stage.clientHeight, w = el.offsetWidth, h = el.offsetHeight;
    const p = pos || def || { x: 0, y: 0 };
    el._pos = p;
    el.style.left = Math.max(4, Math.min(W - w - 4, p.x * (W - w))) + 'px';
    el.style.top = Math.max(4, Math.min(H - h - 4, p.y * (H - h))) + 'px';
  };


  // ================= التاريخ: ميلادي / هجري / الاثنان =================
  LP.dateMode = 'g';
  const loc = (cal) => ({ ar: 'ar-SA', en: 'en-GB', fr: 'fr-FR' }[I18N.lang] || 'ar-SA') + '-u-ca-' + cal + (I18N.lang === 'ar' ? '-nu-arab' : '');
  const f = (ts, cal, o) => { try { return new Date(ts).toLocaleDateString(loc(cal), o); } catch { return new Date(ts).toLocaleDateString(); } };
  LP.fmtDay = (ts, mode) => {
    mode = mode || LP.dateMode || 'g';
    const day = f(ts, 'gregory', { weekday: 'long' });
    const g = f(ts, 'gregory', { day: 'numeric', month: 'long', year: 'numeric' });
    const h = f(ts, 'islamic-umalqura', { day: 'numeric', month: 'long', year: 'numeric' });
    return mode === 'h' ? `${day}، ${h}` : mode === 'both' ? `${day}، ${g} · ${h}` : `${day}، ${g}`;
  };
  LP.toggleDateMode = () => {
    LP.dateMode = { g: 'h', h: 'both', both: 'g' }[LP.dateMode] || 'g';
    api.setSettings({ dateMode: LP.dateMode });
    document.dispatchEvent(new Event('lp-date'));
  };
  document.addEventListener('lp-auth', async (e) => { if (e.detail && e.detail.user) { const p = await api.getSettings(); LP.dateMode = p.dateMode || 'g'; document.dispatchEvent(new Event('lp-date')); } });
})();
