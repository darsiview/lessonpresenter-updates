// التخطيط الثابت: عمود جانبي للأدوات (الساعة، العجلة، درس اليوم) والدرس يتحجّم في المساحة الباقية.
// لا شيء فوق الدرس إلا أدوات الكتابة (القلم والأختام والليزر). الوضع العائم القديم يبقى خياراً في الإعدادات.
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const stage = $('#stage');

  // ---------- البناء: [العمود][الدرس] داخل صف واحد ----------
  const mid = document.createElement('div'); mid.id = 'mid';
  stage.parentNode.insertBefore(mid, stage);
  const dock = document.createElement('aside'); dock.id = 'dock';
  dock.innerHTML = `<div class="dk-grip" id="dkGrip" title=""></div><div class="dk-in" id="dkIn">
    <div class="dk-head"><b>🧰 <span data-t="أدوات الحصة"></span></b><span style="flex:1"></span>
      <button class="dk-x" id="dkHide" title="">✕</button></div>
    <div id="dkSlots"><div class="dk-sec" id="dkSecTimer" data-k="timer">
    <section class="dk-timer" id="dkTimer">
      <div class="dk-sh" id="dkTimerHead"><span class="dk-mv" title="">⋮⋮</span><b>⏱</b><span class="dk-fnum" id="dkFoldNum"></span>
        <button class="dk-fbtn" id="dkFoldPause">⏸</button><span style="flex:1"></span></div>
      <div class="dk-face" id="dkFace" title=""><svg viewBox="0 0 200 200" id="dkSvg"></svg><div class="dk-num" id="dkNum">00:00</div>
        <div class="dk-barw"><i id="dkBarFill"></i></div></div>
      <div class="dk-tb">
        <button id="dkPause" title="">⏸</button><button id="dkAdd" title="">+1</button>
        <button id="dkStyle" title="">🕒</button><button id="dkOpen" title="">⚙</button><button id="dkStop" title="">✕</button>
      </div>
    </section>
    <button class="dk-new" id="dkNew">⏱ <span data-t="المؤقّت"></span></button>
    </div></div></div>`;
  mid.appendChild(dock); mid.appendChild(stage);
  dock.querySelectorAll('[data-t]').forEach(e => { e.textContent = T(e.dataset.t); });
  const tips = { dkHide: 'إخفاء العمود (يبقى ما فيه يعمل)', dkPause: 'إيقاف مؤقت / متابعة', dkAdd: 'إضافة دقيقة', dkOpen: 'إعداد المؤقّت', dkStop: 'إيقاف المؤقّت', dkFace: 'اضغطي لتكبير الساعة أو تصغيرها', dkStyle: 'شكل الساعة: دائرية / رقمية / شريط', dkGrip: 'اسحبي لتصغير العمود (ضغطتان: الحجم الكامل)' };
  for (const [id, t] of Object.entries(tips)) $('#' + id).title = T(t);

  const slots = $('#dkSlots');
  const mw = $('#mw'), goals = () => $('#goalsCard');
  let prof = {}, btn = null;
  // في وضع الإطار (عرض باوربوينت) تنتقل البطاقات العائمة إلى العمود حتى لا تغطي الشريحة
  const framing = () => document.documentElement.classList.contains('pptHole') && prof.pptFrame !== false;
  const docked = () => (prof.layout !== 'float' || framing()) && !document.body.classList.contains('mini');

  // ---------- نقل الأدوات بين العمود والدرس ----------
  function place() {
    const g = goals();
    if (g) g.dataset.k = 'goals';
    const want = docked();
    document.body.classList.toggle('docked', want);
    const tsec = $('#dkSecTimer');
    for (const el of [tsec, mw, g]) {
      if (!el || el.classList.contains('pop')) continue;       // العجلة المنبثقة تعود لمكانها بنفسها
      const k = keyOf(el), free = want && isFree(k);
      if (free) { placeFree(el, k); continue; }
      if (el.classList.contains('dkFree')) unFree(el);
      if (want && el.parentNode !== slots) slots.appendChild(el);
      else if (!want && el.parentNode === slots && el !== tsec) stage.appendChild(el);
    }
    if (!want && tsec.parentNode !== slots) { unFree(tsec); slots.insertBefore(tsec, slots.firstChild); }
    addRetBtn($('#dkTimerHead'), 'timer'); addRetBtn($('#mwHead'), 'wheel', $('#mwClose')); if (g) addRetBtn($('#gcHead'), 'goals', $('#gcClose'));
    applyFsDock();
    if (want) applyOrder();
    applySizes();
    // الجهة: «تلقائي» = بداية السطر (يمين العربية، يسار الإنجليزية والفرنسية)
    const rtl = I18N.dir() === 'rtl', side = prof.dockSide || 'auto';
    const atStart = side === 'auto' || (side === 'right') === rtl;
    dock.style.order = atStart ? '0' : '2';
    dock.classList.toggle('endSide', !atStart);
    applyScale();
    vis();
  }
  function vis() {
    const st = LP.timerState ? LP.timerState() : { active: false };
    const g = goals();
    const has = (st.active && !isFree('timer')) || (mw.classList.contains('on') && !isFree('wheel')) || (g && g.classList.contains('on') && !isFree('goals'));
    // الساعة العائمة: تظهر فقط ومؤقّت يعمل
    if (isFree('timer') && docked()) $('#dkSecTimer').style.display = st.active ? '' : 'none';
    dock.classList.toggle('show', docked() && !prof.dockHidden && has);
    $('#dkTimer').style.display = st.active ? '' : 'none';
    if (!(isFree('timer') && docked())) $('#dkSecTimer').style.display = '';
    $('#dkNew').style.display = st.active ? 'none' : '';
    btn && btn.classList.toggle('on', dock.classList.contains('show'));
  }
  new MutationObserver(vis).observe(mw, { attributes: true, attributeFilter: ['class'] });
  const watchGoals = () => { const g = goals(); if (g && !g._dkw) { g._dkw = 1; new MutationObserver(vis).observe(g, { attributes: true, attributeFilter: ['class'] }); } };
  new MutationObserver(() => place()).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  new MutationObserver(() => place()).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

  // ---------- تصغير العمود بالسحب: كل ما فيه يصغر معه بنفس النسبة ----------
  const MIN = 0.5;
  const baseW = () => (prof.dockW === 'wide' ? 340 : 280);
  let scale = 1;
  function applyScale(sc) {
    scale = Math.max(MIN, Math.min(1, sc !== undefined ? sc : (+prof.dockScale || 1)));
    dock.style.setProperty('--dockW', Math.round(baseW() * scale) + 'px');
    $('#dkIn').style.zoom = scale;
    dock.classList.toggle('scaled', scale < 0.999);
  }
  (() => {
    const grip = $('#dkGrip');
    let drag = null;
    grip.addEventListener('pointerdown', (e) => {
      e.preventDefault(); grip.setPointerCapture(e.pointerId);
      const r = dock.getBoundingClientRect();
      drag = { onRight: r.left + r.width / 2 > window.innerWidth / 2, r };
      document.body.classList.add('dkResizing');
    });
    grip.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const w = drag.onRight ? drag.r.right - e.clientX : e.clientX - drag.r.left;
      applyScale(w / baseW());
    });
    const end = () => { if (!drag) return; drag = null; document.body.classList.remove('dkResizing'); prof.dockScale = +scale.toFixed(3); api.setSettings({ dockScale: prof.dockScale }); };
    grip.addEventListener('pointerup', end); grip.addEventListener('pointercancel', end);
    grip.addEventListener('dblclick', () => { applyScale(1); prof.dockScale = 1; api.setSettings({ dockScale: 1 }); });
  })();
  LP.dockScale = () => scale;

  // ---------- الساعة: دائرية / رقمية / شريط ----------
  const STYLES = ['ring', 'digital', 'bar'];
  const styleOf = () => (STYLES.includes(prof.clockStyle) ? prof.clockStyle : 'ring');
  function applyStyle() {
    const t = $('#dkTimer'), st = styleOf();
    STYLES.forEach(x => t.classList.toggle('st-' + x, x === st));
    $('#dkStyle').textContent = { ring: '🕒', digital: '🔢', bar: '▬' }[st];
  }
  $('#dkStyle').onclick = () => { prof.clockStyle = STYLES[(STYLES.indexOf(styleOf()) + 1) % 3]; api.setSettings({ clockStyle: prof.clockStyle }); applyStyle(); lastKey = ''; face(); };
  LP.applyClockStyle = (st) => { prof.clockStyle = st; applyStyle(); lastKey = ''; face(); };

  // ---------- الساعة الدائرية ----------
  const C = { ok: '#2fb344', warn: '#fd7e14', danger: '#e5484d' };
  const fmt = (s) => { s = Math.max(0, Math.ceil(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
  const pt = (a, r) => [100 + r * Math.sin(a), 100 - r * Math.cos(a)];
  let lastKey = '', lastFace = '';
  function face() {
    if (!LP.timerState) return;
    const s = LP.timerState(); vis();
    if (!s.active) { lastFace = ''; return; }
    const fk = [s.left, s.total, s.done, s.running, styleOf(), $('#dkTimer').className].join('|');
    if (fk === lastFace) return;
    lastFace = fk;
    const total = Math.max(1, s.total), frac = s.done ? 0 : Math.max(0, Math.min(1, s.left / total));
    const col = s.done ? C.danger : s.left <= 10 ? C.danger : s.left <= s.warnAt ? C.warn : C.ok;
    // أرقام الدقائق حول الساعة (حتى 12 رقماً)
    const mins = Math.max(1, Math.ceil(total / 60)), step = mins <= 12 ? 1 : Math.ceil(mins / 12);
    const key = mins + '|' + step;
    let marks = '';
    if (key !== lastKey) {
      lastKey = key;
      for (let m = 0; m < mins; m += step) {
        const a = 2 * Math.PI * m / mins, [x, y] = pt(a, 88), [x1, y1] = pt(a, 74), [x2, y2] = pt(a, 80);
        marks += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" class="dk-tick"/><text x="${x}" y="${y}" class="dk-lbl">${m === 0 ? mins : m}</text>`;
      }
      $('#dkSvg').innerHTML = `<circle cx="100" cy="100" r="98" class="dk-bg"/><g id="dkMarks">${marks}</g><path id="dkArc"/><circle cx="100" cy="100" r="38" class="dk-hub"/>`;
    }
    // الجزء المتبقي: قطاع يتناقص مع الوقت
    const arc = $('#dkArc');
    if (frac >= 0.9999) arc.setAttribute('d', 'M100,100 m0,-70 a70,70 0 1,1 0,140 a70,70 0 1,1 0,-140z');
    else if (frac <= 0) arc.setAttribute('d', '');
    else {
      const a = 2 * Math.PI * frac, [x, y] = pt(a, 70);
      arc.setAttribute('d', `M100,100 L100,30 A70,70 0 ${frac > 0.5 ? 1 : 0},1 ${x.toFixed(2)},${y.toFixed(2)} Z`);
    }
    arc.setAttribute('fill', col);
    const bf = $('#dkBarFill'); bf.style.width = (frac * 100).toFixed(2) + '%'; bf.style.background = col;
    $('#dkFace').style.setProperty('--clk', col);
    $('#dkNum').textContent = s.done ? T('انتهى!') : fmt(s.left);
    $('#dkNum').style.color = col;
    $('#dkTimer').classList.toggle('done', s.done);
    $('#dkPause').textContent = s.running ? '⏸' : '▶';
    $('#dkFoldPause').textContent = s.running ? '⏸' : '▶';
    $('#dkFoldNum').textContent = s.done ? T('انتهى!') : fmt(s.left); $('#dkFoldNum').style.color = col;
  }
  LP.onTimerDraw = face;
  $('#dkFace').onclick = () => cycleSize('timer');
  $('#dkFoldPause').onclick = () => LP.timerCtl && LP.timerCtl.pause();
  $('#dkPause').onclick = () => LP.timerCtl && LP.timerCtl.pause();
  $('#dkAdd').onclick = () => LP.timerCtl && LP.timerCtl.add();
  $('#dkStop').onclick = () => LP.timerCtl && LP.timerCtl.stop();
  $('#dkOpen').onclick = () => LP.timerCtl && LP.timerCtl.open();
  $('#dkNew').onclick = () => LP.timerCtl && LP.timerCtl.open();
  $('#dkHide').onclick = () => setHidden(true);

  // ---------- زر في الشريط الرئيسي: إظهار العمود وإخفاؤه ----------
  (() => {
    const grp = [...document.querySelectorAll('#bar .grp')].pop(); if (!grp) return;
    btn = document.createElement('button'); btn.className = 'b'; btn.id = 'dockBtn';
    btn.dataset.tip = T('العمود الجانبي للأدوات');
    btn.innerHTML = '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M15 4v16"/></svg>';
    btn.onclick = () => {
      if (prof.layout === 'float') { LP.toast(T('الأدوات عائمة: غيّري «طريقة عرض الأدوات» من الإعدادات ← المظهر')); return; }
      setHidden(!prof.dockHidden ? true : false);
      if (!prof.dockHidden && !dock.classList.contains('show')) LP.toast(T('افتحي المؤقّت أو العجلة أو درس اليوم ليظهر العمود'));
    };
    grp.insertBefore(btn, grp.firstChild);
  })();
  function setHidden(h) { prof.dockHidden = !!h; api.setSettings({ dockHidden: prof.dockHidden }); vis(); }

  // ---------- أحجام الأدوات في العمود: كبير / صغير / مطويّ ----------
  const SIZES = ['big', 'small', 'fold'];
  const SZ_TIP = { big: 'تصغير', small: 'طيّ (سطر واحد)', fold: 'تكبير' };
  const SZ_ICO = { big: '⤡', small: '▁', fold: '⤢' };
  const secEl = (k) => (k === 'timer' ? $('#dkSecTimer') : k === 'wheel' ? mw : goals());
  const sizeOf = (k) => { const d = prof.dkSize || {}; if (SIZES.includes(d[k])) return d[k]; return k === 'timer' && prof.dockTimerBig === false ? 'small' : 'big'; };
  function addSizeBtn(k, head, before) {
    if (!head || head.querySelector('.dk-szb')) return;
    const b = document.createElement('button'); b.className = 'dk-szb'; b.dataset.k = k;
    b.onclick = (e) => { e.stopPropagation(); cycleSize(k); };
    head.insertBefore(b, before || null);
  }
  function applySizes() {
    addSizeBtn('timer', $('#dkTimerHead'));
    addSizeBtn('wheel', $('#mwHead'), $('#mwClose'));
    const g = goals(); if (g) addSizeBtn('goals', $('#gcHead'), $('#gcClose'));
    for (const k of ['timer', 'wheel', 'goals']) {
      const el = k === 'timer' ? $('#dkTimer') : secEl(k); if (!el) continue;
      const z = sizeOf(k); el.dataset.size = z;
      if (k === 'timer') { el.classList.toggle('small', z === 'small'); el.classList.toggle('fold', z === 'fold'); }
      const b = (k === 'timer' ? $('#dkTimerHead') : el).querySelector('.dk-szb');
      if (b) { b.textContent = SZ_ICO[z]; b.title = T(SZ_TIP[z]); }
    }
    lastFace = '';
  }
  function cycleSize(k) {
    const z = SIZES[(SIZES.indexOf(sizeOf(k)) + 1) % 3];
    prof.dkSize = { ...(prof.dkSize || {}), [k]: z };
    api.setSettings({ dkSize: prof.dkSize });
    applySizes(); face();
    if (k === 'wheel' && LP._groups && LP._groups.render) LP._groups.render();
  }
  LP.dockSize = (k) => (docked() && mw.closest('#dock') ? sizeOf(k) : 'big');

  // ---------- ترتيب الأدوات في العمود بالسحب، وإخراجها منه إلى أي مكان فوق الدرس ----------
  const ORDER = ['timer', 'wheel', 'goals'];
  const POSKEY = { timer: 'dkTimerPos', wheel: 'mwPos', goals: 'goalsPos' };
  const orderOf = () => { const o = Array.isArray(prof.dkOrder) ? prof.dkOrder.filter(k => ORDER.includes(k)) : []; for (const k of ORDER) if (!o.includes(k)) o.push(k); return o; };
  const isFree = (k) => !!(prof.dkFree && prof.dkFree[k]);
  const keyOf = (el) => el && (el.dataset.k || (el === mw ? 'wheel' : el.id === 'goalsCard' ? 'goals' : null));
  function applyOrder() {
    for (const k of orderOf()) { const el = secEl(k); if (el && el.parentNode === slots && !el.classList.contains('pop')) slots.appendChild(el); }
  }
  // أداة خارج العمود: بطاقة عائمة فوق الدرس تُسحب بحرية، وضغطتان على رأسها (أو ↩) تعيدانها
  function setFree(k, on, at) {
    prof.dkFree = { ...(prof.dkFree || {}), [k]: !!on };
    if (!on) delete prof.dkFree[k];
    const patch = { dkFree: prof.dkFree };
    if (on && at) { prof[POSKEY[k]] = at; patch[POSKEY[k]] = at; }
    api.setSettings(patch);
    place();
  }
  function placeFree(el, k) {
    if (el.parentNode !== stage) stage.appendChild(el);
    el.classList.add('dkFree');
    requestAnimationFrame(() => LP.floatPlace(el, prof[POSKEY[k]] || { x: 0.5, y: 0.3 }));
  }
  function unFree(el) { el.classList.remove('dkFree'); el.style.left = el.style.top = ''; }
  LP.dockFree = (k) => isFree(k);
  (() => {
    let drag = null;
    const handle = (t) => t.closest('#dock .dk-mv, #dock .mw-drag, #dock .fc-drag, #dock #mwHead, #dock #gcHead, #dock .dk-sh');
    const move = (e) => {
      if (!drag) return;
      if (!drag.moved && Math.abs(e.clientY - drag.y0) + Math.abs(e.clientX - drag.x0) < 6) return;
      if (!drag.moved) { drag.moved = true; drag.item.classList.add('dk-dragging'); document.body.classList.add('dkSorting'); }
      const dr = dock.getBoundingClientRect();
      // خارج العمود بمسافة واضحة → تصبح الأداة عائمة في مكان الفأرة
      if (e.clientX < dr.left - 30 || e.clientX > dr.right + 30) {
        const k = keyOf(drag.item), item = drag.item; stop();
        const sr = stage.getBoundingClientRect(), w = item.offsetWidth || 260, h = item.offsetHeight || 200;
        const x = Math.max(0, Math.min(1, (e.clientX - sr.left - w / 2) / Math.max(1, sr.width - w)));
        const y = Math.max(0, Math.min(1, (e.clientY - sr.top - 12) / Math.max(1, sr.height - h)));
        if (k) setFree(k, true, { x, y });
        return;
      }
      const sibs = [...slots.children].filter(c => c !== drag.item && c.offsetParent !== null);
      let before = null;
      for (const c of sibs) { const r = c.getBoundingClientRect(); if (e.clientY < r.top + r.height / 2) { before = c; break; } }
      if (before !== drag.item.nextSibling) slots.insertBefore(drag.item, before);
    };
    function stop() {
      if (!drag) return;
      const moved = drag.moved; drag.item.classList.remove('dk-dragging'); document.body.classList.remove('dkSorting'); drag = null;
      window.removeEventListener('pointermove', move, true); window.removeEventListener('pointerup', up, true); window.removeEventListener('pointercancel', up, true);
      return moved;
    }
    function up() {
      if (!stop()) return;
      prof.dkOrder = [...slots.children].map(keyOf).filter(Boolean);
      api.setSettings({ dkOrder: prof.dkOrder });
    }
    dock.addEventListener('pointerdown', (e) => {
      if (document.body.classList.contains('fullShow') && e.target.closest('.dk-head')) return;
      const h = handle(e.target); if (!h || e.target.closest('button')) return;
      const item = [...slots.children].find(c => c.contains(h)); if (!item) return;
      e.preventDefault();
      drag = { item, y0: e.clientY, x0: e.clientX, moved: false };
      window.addEventListener('pointermove', move, true); window.addEventListener('pointerup', up, true); window.addEventListener('pointercancel', up, true);
    });
    // أداة عائمة: ضغطتان على رأسها، أو تركها فوق العمود، تعيدانها إليه
    const freeHead = (t) => { const it = t.closest('.dkFree'); return it && t.closest('.dk-sh, #mwHead, #gcHead') && !t.closest('button') ? it : null; };
    stage.addEventListener('dblclick', (e) => { const it = freeHead(e.target); if (it) setFree(keyOf(it), false); });
    let freeDown = null;
    stage.addEventListener('pointerdown', (e) => { freeDown = freeHead(e.target); }, true);
    window.addEventListener('pointerup', (e) => {
      const it = freeDown; freeDown = null; if (!it || !dock.classList.contains('show')) return;
      const dr = dock.getBoundingClientRect();
      if (e.clientX >= dr.left && e.clientX <= dr.right && e.clientY >= dr.top && e.clientY <= dr.bottom) setTimeout(() => setFree(keyOf(it), false), 0);
    }, true);
    // الساعة العائمة تُسحب مثل بقية البطاقات
    LP.floatDrag($('#dkSecTimer'), $('#dkTimerHead'), 'dkTimerPos', null, (pos) => { prof.dkTimerPos = pos; });
  })();
  // زر ↩ في رأس الأداة العائمة
  function addRetBtn(head, k, before) {
    if (!head || head.querySelector('.dk-ret')) return;
    const b = document.createElement('button'); b.className = 'dk-ret'; b.textContent = '↩'; b.title = T('إرجاع إلى العمود الجانبي');
    b.onclick = (e) => { e.stopPropagation(); setFree(k, false); };
    head.insertBefore(b, before || null);
  }

  // ---------- العمود نفسه في وضع العرض الكامل: لوحة تُسحب من رأسها ----------
  (() => {
    let d = null;
    const head = dock.querySelector('.dk-head');
    head.addEventListener('pointerdown', (e) => {
      if (!document.body.classList.contains('fullShow') || e.target.closest('button')) return;
      const r = dock.getBoundingClientRect();
      d = { dx: e.clientX - r.left, dy: e.clientY - r.top, end: dock.classList.contains('endSide') }; head.setPointerCapture(e.pointerId);
    });
    head.addEventListener('pointermove', (e) => {
      if (!d) return;
      const W = window.innerWidth, H = window.innerHeight, w = dock.offsetWidth, h = dock.offsetHeight;
      let x = Math.max(0, Math.min(W - w, e.clientX - d.dx)), y = Math.max(0, Math.min(H - h - 50, e.clientY - d.dy));
      const rtl = getComputedStyle(dock).direction === 'rtl';
      // المسافة من جهة العمود (البداية أو النهاية حسب الاتجاه)
      const fromStart = rtl ? W - (x + w) : x, fromEnd = rtl ? x : W - (x + w);
      dock.style.setProperty('--fsDockX', Math.round(d.end ? fromEnd : fromStart) + 'px');
      dock.style.setProperty('--fsDockY', Math.round(y) + 'px');
    });
    const up = () => { if (!d) return; d = null; prof.fsDock = { x: dock.style.getPropertyValue('--fsDockX'), y: dock.style.getPropertyValue('--fsDockY') }; api.setSettings({ fsDock: prof.fsDock }); };
    head.addEventListener('pointerup', up); head.addEventListener('pointercancel', up);
  })();
  const applyFsDock = () => { const f = prof.fsDock; if (f && f.x) { dock.style.setProperty('--fsDockX', f.x); dock.style.setProperty('--fsDockY', f.y); } };

  LP.applyLayout = async (p) => { prof = p || await api.getSettings(); applyStyle(); place(); face(); };
  applyStyle();
  // الساعة الدائرية حين تُخرج من العمود: تكبير/تصغير بالسحب من أي طرف
  (() => {
    const el = $('#dkSecTimer'); if (!el || !LP.floatResize) return;
    let k = 1;
    const setK = (v) => { k = v; el.style.setProperty('--dkk', v); };
    LP.floatResize(el, { posKey: 'dkTimerPos', ratio: { get: () => k, set: setK, min: .5, max: 3 },
      onEnd: () => { if (el._pos) prof.dkTimerPos = el._pos; api.setSettings({ dkTimerScale: +k.toFixed(2) }); } });
    document.addEventListener('lp-auth', async (e) => { if (e.detail && e.detail.user) { const p = await api.getSettings(); setK(p.dkTimerScale || 1); } });
  })();
  document.addEventListener('lp-auth', async (e) => { if (e.detail && e.detail.user) { await LP.applyLayout(); setTimeout(() => { watchGoals(); place(); }, 1800); } });
  // بطاقة الأهداف تُنشأ في goals.js — ننتظرها
  setTimeout(() => { watchGoals(); place(); }, 500);
})();
