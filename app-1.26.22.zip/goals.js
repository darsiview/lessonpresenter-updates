// بطاقة الأهداف العائمة + سحب موحّد مع التصاق مغناطيسي للبطاقات العائمة
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const stage = $('#stage');
  const DEF_HEAD = 'في نهاية الدرس سأكون قادرة على:';

  // ================= بطاقة الأهداف =================
  const card = document.createElement('div');
  card.id = 'goalsCard'; card.className = 'fcard'; card.dir = I18N.dir();
  card.innerHTML = `<div class="fc-head" id="gcHead"><span class="fc-drag">⋮⋮</span><span class="fc-ttl">📘 ${T('درس اليوم')}</span>
      <button class="fc-x" id="gcFm" title="${T('تصغير الخط')}">A−</button>
      <button class="fc-x" id="gcFp" title="${T('تكبير الخط')}">A+</button>
      <button class="fc-x" id="gcEdit" title="${T('تعديل الأهداف')}">✎</button>
      <button class="fc-x" id="gcBig" title="${T('عرض كبير')}">⛶</button>
      <button class="fc-x" id="gcClose" title="${T('إغلاق')}">✕</button></div>
    <div class="gc-body" id="gcBody"></div>`;
  stage.appendChild(card);
  const big = document.createElement('div');
  big.id = 'goalsBig'; big.dir = I18N.dir(); big.innerHTML = '<div class="gbg-card" id="gbgCard"></div>';
  document.body.appendChild(big);

  let prof = {}, editing = false;
  const S = () => LP.session && LP.session.L;
  const headOf = () => { const s = S(); return (s && s.goalHead) || prof.goalHead || T(DEF_HEAD); };
  const save = () => LP.session && LP.session.saveLesson();

  function render() {
    const s = S(), body = $('#gcBody');
    if (!s) { body.innerHTML = `<div class="gc-empty">${T('أضيفي أسماء الطالبات أولاً من «اختيار طالب عشوائي»')}</div>`; return; }
    const goals = s.goals || [], done = new Set(s.goalsDone || []);
    if (editing) {
      body.innerHTML = `<input id="gcHeadIn" class="gc-headin" dir="auto" value="${esc(headOf())}">
        <div class="gc-hrow"><button id="gcHeadDef" title="${T('جعلها العبارة الافتراضية لكل الدروس')}">⭐ ${T('افتراضية')}</button><button id="gcHeadReset" title="${T('استعادة العبارة الأصلية')}">↺</button></div>
        <textarea id="gcGoalsIn" rows="6" dir="auto" placeholder="${T('هدف في كل سطر')}">${esc(goals.join('\n'))}</textarea>
        <div class="gc-hrow"><button class="pri" id="gcSave">${T('حفظ')}</button><button id="gcCancel">${T('إلغاء')}</button></div>`;
      body.querySelectorAll('input,textarea').forEach(i => i.addEventListener('keydown', e => e.stopPropagation()));
      $('#gcHeadDef').onclick = async () => { prof.goalHead = $('#gcHeadIn').value.trim(); await api.setSettings({ goalHead: prof.goalHead }); s.goalHead = undefined; save(); LP.toast(T('تم الحفظ ✓')); };
      $('#gcHeadReset').onclick = async () => { $('#gcHeadIn').value = T(DEF_HEAD); prof.goalHead = ''; await api.setSettings({ goalHead: '' }); s.goalHead = undefined; save(); };
      $('#gcCancel').onclick = () => { editing = false; render(); };
      $('#gcSave').onclick = () => {
        const h = $('#gcHeadIn').value.trim();
        s.goalHead = h && h !== (prof.goalHead || T(DEF_HEAD)) ? h : undefined;
        const ng = $('#gcGoalsIn').value.split('\n').map(x => x.trim()).filter(Boolean);
        const keep = new Set((s.goalsDone || []).map(i => goals[i]));
        s.goals = ng; s.goalsDone = ng.map((g, i) => keep.has(g) ? i : -1).filter(i => i >= 0);
        save(); editing = false; render(); document.dispatchEvent(new Event('lp-goals-changed'));
        if (LP.session.render) LP.session.render();
      };
      setTimeout(() => $('#gcGoalsIn').focus(), 30);
      return;
    }
    if (!goals.length) {
      body.innerHTML = `<div class="gc-empty">${T('لا توجد أهداف لهذه الحصة.')}<br><button id="gcAddG">＋ ${T('كتابة الأهداف')}</button></div>`;
      $('#gcAddG').onclick = () => { editing = true; render(); };
      return;
    }
    body.innerHTML = `<div class="gc-lbl">${T('موضوع الدرس')}</div>
      <div class="gc-title" dir="auto">${s.title ? esc(s.title) : `<span class="muted">${T('اكتبي موضوع الدرس من الشريط العلوي')}</span>`}</div>
      <div class="gc-date">${esc(LP.fmtDay(Date.now()))}${LP.cal && LP.cal.label() ? ' · ' + esc(LP.cal.label()) : ''}</div>
      ${LP.cal && LP.cal.value() ? `<div class="gc-val">🌟 ${T('قيمة الشهر')}: <b>${esc(LP.cal.value())}</b></div>` : ''}
      <div class="gc-lbl">🎯 ${T('أهداف الدرس')}</div>
      <div class="gc-h" dir="auto">${esc(headOf())}</div>
      <ol class="gc-list">${goals.map((g, i) => `<li class="${done.has(i) ? 'done' : ''}" data-i="${i}"><span class="ck">${done.has(i) ? '✓' : ''}</span><span dir="auto">${esc(g)}</span></li>`).join('')}</ol>
      <div class="gc-prog"><i style="width:${Math.round(100 * done.size / goals.length)}%"></i></div>`;
    body.querySelectorAll('li').forEach(li => li.onclick = () => toggle(+li.dataset.i));
  }
  function toggle(i) {
    const s = S(); if (!s) return;
    const d = new Set(s.goalsDone || []);
    if (d.has(i)) d.delete(i); else { d.add(i); if (LP.sound && LP.sound.beep) LP.sound.beep(880, .15); }
    s.goalsDone = [...d].sort((a, b) => a - b); save();
    render(); if (big.classList.contains('on')) renderBig();
    if (LP.session.render) LP.session.render();
    if (s.goals.length && d.size === s.goals.length) LP.toast('🎉 ' + T('تحققت كل أهداف الدرس!'));
  }
  function renderBig() {
    const s = S(); if (!s) return;
    const done = new Set(s.goalsDone || []);
    $('#gbgCard').innerHTML = `<button class="gbg-x" id="gbgX">✕</button>
      ${s.title ? `<div class="gbg-lbl">${T('موضوع الدرس')}</div><div class="gbg-t" dir="auto">📘 ${esc(s.title)}</div>` : ''}<div class="gbg-d">${esc(LP.fmtDay(Date.now()))}</div>
      <div class="gbg-lbl">🎯 ${T('أهداف الدرس')}</div><div class="gbg-h" dir="auto">${esc(headOf())}</div>
      <ol>${(s.goals || []).map((g, i) => `<li class="${done.has(i) ? 'done' : ''}" data-i="${i}"><span class="ck">${done.has(i) ? '✓' : i + 1}</span><span dir="auto">${esc(g)}</span></li>`).join('')}</ol>`;
    $('#gbgX').onclick = () => big.classList.remove('on');
    $('#gbgCard').querySelectorAll('li').forEach(li => li.onclick = () => toggle(+li.dataset.i));
  }
  big.addEventListener('click', e => { if (e.target === big) big.classList.remove('on'); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && big.classList.contains('on')) { big.classList.remove('on'); e.stopPropagation(); } }, true);

  async function show(force) {
    prof = await api.getSettings();
    if (card.classList.contains('on') && !force) { hide(); return; }
    if (LP.session && !LP.session.S) await LP.session.ensure(false);
    editing = !!(S() && !(S().goals || []).length);
    card.classList.add('on'); applySize(); render();
    LP.floatPlace(card, prof.goalsPos, { x: 0.02, y: 0.04 });
    api.setSettings({ goalsOn: true });
  }
  function hide() { card.classList.remove('on'); editing = false; api.setSettings({ goalsOn: false }); }
  LP.showGoals = show;
  LP.goalsBig = () => { if (!S() || !(S().goals || []).length) return show(true); renderBig(); big.classList.add('on'); };

  // الحجم والخط: البطاقة تُكبَّر من زاويتها، ويُحفظ حجمها (وتبقى بنفس الحجم فوق البرامج)
  function applySize() {
    const z = prof.goalsSize;
    if (z && z.w) { card.style.width = z.w + 'px'; card.style.height = z.h ? z.h + 'px' : ''; }
    card.style.setProperty('--gcfs', (prof.goalsFont || 14) + 'px');
  }
  let sizeT;
  new ResizeObserver(() => {
    if (!card.classList.contains('on') || card.closest('#dock') || !card.style.width && !card.dataset.user) return;
    clearTimeout(sizeT); sizeT = setTimeout(() => { prof.goalsSize = { w: card.offsetWidth, h: card.offsetHeight }; api.setSettings({ goalsSize: prof.goalsSize }); }, 400);
  }).observe(card);
  card.addEventListener('pointerdown', e => { const r = card.getBoundingClientRect(); if (e.clientX > r.right - 18 && e.clientY > r.bottom - 18 || e.clientX < r.left + 18 && e.clientY > r.bottom - 18) card.dataset.user = 1; });
  const font = (d) => { prof.goalsFont = Math.max(11, Math.min(36, (prof.goalsFont || 14) + d)); applySize(); api.setSettings({ goalsFont: prof.goalsFont }); };
  $('#gcFm').onclick = () => font(-2);
  $('#gcFp').onclick = () => font(2);
  $('#gcClose').onclick = hide;
  $('#gcEdit').onclick = () => { editing = !editing; render(); };
  $('#gcBig').onclick = () => LP.goalsBig();
  LP.floatDrag(card, $('#gcHead'), 'goalsPos');
  LP.floatResize(card, { minW: 220, minH: 110, posKey: 'goalsPos' });
  // خارج البرنامج تظهر الأهداف للعرض لا للتعديل
  LP.goalsNoEdit = () => { if (editing) { editing = false; render(); } };
  new ResizeObserver(() => { if (card.classList.contains('on') && !document.body.classList.contains('mini')) LP.floatPlace(card, card._pos); }).observe(stage);
  document.addEventListener('lp-date', () => { if (card.classList.contains('on') && !editing) render(); });
  document.addEventListener('lp-goals', () => { if (card.classList.contains('on')) { editing = false; render(); } if (big.classList.contains('on')) renderBig(); });
  document.addEventListener('lp-auth', async (e) => {
    if (!e.detail || !e.detail.user) { card.classList.remove('on'); return; }
    prof = await api.getSettings();
    if (prof.goalsOn) setTimeout(() => show(true), 1500);
  });
})();
