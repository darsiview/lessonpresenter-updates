// إظهار البطاقات العائمة (العجلة، المؤقّت، الأهداف) فوق كل البرامج
// الفكرة: نافذة البرنامج نفسها تصغر إلى حجم البطاقات وتبقى فوق وورد وتيمز وغيرها،
// فتبقى العجلة والنقاط والمؤقّت تعمل كما هي بدون نسخة ثانية.
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const body = document.body;
  const GAP = 6;

  const KINDS = {
    wheel: { el: () => $('#mw'), head: () => $('#mwHead'), before: () => $('#mwClose'), isOn: () => $('#mw').classList.contains('on'),
      show: () => LP.toggleMiniWheel(true), hide: () => LP.toggleMiniWheel(false) },
    timer: { el: () => $('#timerW'), head: () => $('#timerW .tbtns'), before: () => $('#tClose'), isOn: () => $('#timerW').classList.contains('on'),
      show: () => { if (!$('#timerW').classList.contains('on')) LP.openTimer(); }, hide: () => {} },
    goals: { el: () => $('#goalsCard'), head: () => $('#gcHead'), before: () => $('#gcClose'), isOn: () => $('#goalsCard').classList.contains('on'),
      show: () => LP.showGoals(true), hide: () => {} },
    groups: { el: () => $('#grpBar'), head: () => $('#gbMenuBtn').parentNode, before: () => $('#gbMenuBtn'), isOn: () => $('#grpBar').classList.contains('on'),
      show: () => LP.toggleGroupBar(true), hide: () => {} }
  };
  let out = [];              // البطاقات المعروضة فوق البرامج بالترتيب
  const saved = new Map();   // مواضعها داخل البرنامج قبل الخروج
  const isMini = () => body.classList.contains('mini');

  // زر 📌 في رأس كل بطاقة
  for (const [k, d] of Object.entries(KINDS)) {
    const b = document.createElement('button');
    b.className = (k === 'wheel' ? 'mw-x' : k === 'goals' ? 'fc-x' : k === 'groups' ? 'gb-btn' : '') + ' popBtn';
    b.dataset.pop = k;
    b.textContent = '📌';
    b.title = T('إظهار فوق كل البرامج');
    b.onclick = (e) => { e.stopPropagation(); if (out.includes(k)) back(); else popOut(k); };
    d.head().insertBefore(b, d.before());
  }
  const syncBtns = () => { api.floatToolsOut && api.floatToolsOut(out.slice()); syncBtns0(); };
  const syncBtns0 = () => document.querySelectorAll('.popBtn').forEach(b => {
    const o = out.includes(b.dataset.pop);
    b.textContent = o ? '↩' : '📌'; b.title = T(o ? 'رجوع إلى العارض' : 'إظهار فوق كل البرامج');
    b.classList.toggle('on', o);
  });

  // ترتيب البطاقات فوق بعضها في النافذة الصغيرة
  function layout() {
    let y = 0;
    for (const k of out) {
      const el = KINDS[k].el();
      if (!el.classList.contains('on')) continue;
      el.style.left = '0px'; el.style.top = y + 'px';
      y += el.offsetHeight + GAP;
    }
  }
  // حجم النافذة = كل ما يظهر من البطاقات وقوائمها المفتوحة
  let last = '';
  function measure() {
    if (!isMini()) return;
    layout();
    let w = 0, h = 0;
    const els = [];
    for (const k of out) { const el = KINDS[k].el(); if (el.classList.contains('on')) els.push(el, ...el.querySelectorAll('.mw-pop.on')); }
    const tp = $('#timerPop'); if (tp.classList.contains('on')) els.push(tp);
    for (const el of els) { const r = el.getBoundingClientRect(); w = Math.max(w, r.right); h = Math.max(h, r.bottom); }
    const key = Math.ceil(w) + 'x' + Math.ceil(h);
    if (key !== last) { last = key; api.miniSize({ w, h }); }
  }
  let timer = null;

  async function popOut(k) {
    if (out.includes(k)) return;
    const d = KINDS[k];
    if (!d.isOn()) { await d.show(); if (!d.isOn()) return; }
    const el = d.el();
    saved.set(k, { left: el.style.left, top: el.style.top });
    out.push(k);
    if (!isMini()) {
      LP.closePanels && LP.closePanels();
      body.classList.add('mini');
      // كل البطاقات الأخرى المفتوحة تختفي مؤقتاً حتى لا تغطي الصفحة الصغيرة
      for (const [o, od] of Object.entries(KINDS)) if (!out.includes(o) && od.isOn()) od.el().classList.add('miniHide');
    }
    el.classList.remove('miniHide'); el.classList.add('miniOut');
    if (k === 'goals' && LP.goalsNoEdit) LP.goalsNoEdit();
    layout();
    await api.miniEnter({ w: el.offsetWidth, h: el.offsetHeight });
    last = ''; measure();
    clearInterval(timer); timer = setInterval(() => {
      // بطاقة أُغلقت من زرها ✕ → تخرج من القائمة
      out = out.filter(o => { const on = KINDS[o].isOn(); if (!on) restore(o); return on; });
      if (!out.length) { back(); return; }
      measure();
    }, 250);
    syncBtns();
  }
  function restore(k) {
    const el = KINDS[k].el(), s = saved.get(k);
    el.classList.remove('miniOut');
    if (s) { el.style.left = s.left; el.style.top = s.top; }
  }
  async function back() {
    clearInterval(timer); timer = null;
    for (const k of out) restore(k);
    out = [];
    document.querySelectorAll('.miniHide').forEach(e => e.classList.remove('miniHide'));
    body.classList.remove('mini');
    syncBtns();
    await api.miniExit();
  }
  // دائرة أداة في الزر العائم
  async function hideOne(k) {
    if (!out.includes(k)) return;
    if (out.length === 1) return back();
    out = out.filter(o => o !== k); restore(k);
    const d = KINDS[k]; d.el().classList.add('miniHide');
    last = ''; measure(); syncBtns();
  }
  api.onFloatTool && api.onFloatTool(async ({ k, inApp }) => {
    if (!KINDS[k]) return;
    if (inApp && !isMini()) {
      // داخل البرنامج: إظهار/إخفاء في مكانها المعتاد
      if (k === 'wheel') LP.toggleMiniWheel();
      else if (k === 'groups') LP.toggleGroupBar();
      else if (k === 'goals') LP.showGoals(!KINDS.goals.isOn());
      else if (k === 'timer') { if (LP.timerState && LP.timerState().active) LP.timerCtl.open(); else LP.openTimer(); }
      return;
    }
    if (out.includes(k)) return hideOne(k);
    const el = KINDS[k].el(); el.classList.remove('miniHide');
    if (k === 'timer' && !KINDS.timer.isOn() && !(LP.timerState && LP.timerState().active)) {
      // لا يوجد مؤقّت يعمل: نرجع للبرنامج لاختيار الوقت، ثم يظهر المؤقّت فوق البرامج تلقائياً
      if (isMini()) { LP.openTimer(); return; }
      api.bringFront && api.bringFront(); LP.openTimer && LP.openTimer();
      const iv = setInterval(() => { if (LP.timerState && LP.timerState().active) { clearInterval(iv); setTimeout(() => popOut('timer'), 600); } }, 300);
      setTimeout(() => clearInterval(iv), 60000);
      return;
    }
    popOut(k);
  });
  LP.popOut = popOut;
  LP.popBack = back;
  LP.isMini = isMini;
  api.onMiniExitReq(() => back());
  // Ctrl+Shift+G: داخل البرنامج = إظهار/إخفاء العجلة، وخارجه = العجلة فوق كل البرامج
  api.onMiniWheelKey(async (focused) => {
    if (focused) { LP.toggleMiniWheel(); return; }
    if (out.includes('wheel')) { if (out.length === 1) back(); else { LP.toggleMiniWheel(false); } return; }
    popOut('wheel');
  });
  // المؤقّت داخل الوضع المصغّر: قائمة المدد تظهر تحت البطاقات
  const origOpenTimer = LP.openTimer;
  LP.openTimer = (anchor) => {
    if (!isMini()) return origOpenTimer(anchor);
    const tp = $('#timerPop');
    if (tp.classList.contains('on')) { tp.classList.remove('on'); return; }
    tp.classList.add('on');
    let y = 0; for (const k of out) { const el = KINDS[k].el(); if (el.classList.contains('on')) y = Math.max(y, el.getBoundingClientRect().bottom); }
    tp.style.left = '0px'; tp.style.top = (y + GAP) + 'px'; tp.style.bottom = 'auto';
    if (!out.includes('timer')) setTimeout(() => {
      // عند بدء المؤقّت يظهر مع البطاقات الأخرى
      const iv = setInterval(() => { if (!isMini()) return clearInterval(iv); if (KINDS.timer.isOn()) { clearInterval(iv); popOut('timer'); } }, 200);
      setTimeout(() => clearInterval(iv), 60000);
    }, 0);
  };
  // تسجيل الخروج أو قفل البرنامج يعيد النافذة
  document.addEventListener('lp-auth', () => { if (isMini()) back(); });
})();
