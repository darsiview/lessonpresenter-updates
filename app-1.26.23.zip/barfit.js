// الشريط السفلي يتكيّف مع عرض الشاشة — كل مجموعة مستقلة:
// - لكل مجموعة سهم «» في طرفها يفتح فوقها ما اختفى منها فقط
// - داخل نافذة السهم: سحب أداة إلى الشريط أو من الشريط إلى الداخل (تبديل ما يظهر)
// - الخط الفاصل بعد كل مجموعة (وقبل أزرار النافذة) يُسحب بحرية: يأخذ من الفراغ والتبويبات ثم يدفع المجاورة (نقرتان = عرضها الكامل)
// - «ترتيب أدوات الشريط»: نقل الأدوات بين المجموعات
// - فاصل بين الأدوات والتبويبات، ومقبض أعلى الشريط لتكبير الأزرار
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const bar = $('#bar'); if (!bar) return;
  const root = document.documentElement;
  const BAR_MIN = 40, BAR_MAX = 72, TABS_DEF = 140, TABS_MIN = 60, DRAG_PX = 6;
  const winGrp = $('#moreBtn').closest('.grp');
  const toolGrps = () => [...bar.children].filter(g => g.classList.contains('grp') && g !== winGrp);
  const key = (b) => b.id || (b.dataset.tool ? 't-' + b.dataset.tool : '');
  const isTool = (b) => b && b.matches && b.matches('button.b') && !b.classList.contains('gov') && !!key(b);
  const isRtl = () => getComputedStyle(bar).direction === 'rtl';
  const drag = bar.querySelector('.drag');
  const grpTools = (g) => [...g.children].filter(isTool);

  // مخزن مخفي لأدوات كل مجموعة غير الظاهرة (تبقى في الصفحة لتعمل اختصارات لوحة المفاتيح)
  const stashRoot = document.createElement('div'); stashRoot.id = 'barStash'; stashRoot.hidden = true;
  document.body.appendChild(stashRoot);
  // G: مجموعات الأدوات بالترتيب، وآخرها مجموعة أزرار النافذة (win)
  const G = [];   // { el, ov, sep, stash, n, win }
  const wk = (i) => (G[i] && G[i].win) ? 'win' : String(i);
  function mkGroup(el, i, win) {
    const ov = document.createElement('button'); ov.className = 'b gov'; ov.dataset.tip = 'المزيد من هذه المجموعة';
    ov.innerHTML = '<svg viewBox="0 0 24 24"><path d="M13 6l-6 6 6 6M19 6l-6 6 6 6"/></svg>';
    const sep = document.createElement('div'); sep.className = 'gsep'; sep.title = T('اسحبي لتضييق المجموعة أو توسيعها — نقرتان: عرضها الكامل');
    const stash = document.createElement('div'); stashRoot.appendChild(stash);
    el.classList.add(win ? 'wg' : 'tg');
    const g = { el, ov, sep, stash, n: 0, win };
    ov.addEventListener('click', (e) => { e.stopPropagation(); if (edit) return; if (openG === i) closePop(); else openPop(i); });
    sep.addEventListener('pointerdown', (e) => sepDrag(e, i));
    sep.addEventListener('dblclick', () => { if (lay.w) delete lay.w[wk(i)]; save(); fit(); });
    return g;
  }
  let winOrder = null;
  function initGroups() {
    const tg = toolGrps();
    tg.forEach((el, i) => { if (!(G[i] && G[i].el === el)) G[i] = mkGroup(el, i, false); });
    const wi = tg.length;
    if (!(G[wi] && G[wi].el === winGrp)) G[wi] = mkGroup(winGrp, wi, true);
    G.length = wi + 1;
    if (!winOrder) winOrder = grpTools(winGrp).map(key);
  }

  // ---------- الإعدادات المحفوظة ----------
  // lay = { groups: [[مفاتيح]…], w: { رقم المجموعة أو win: نسبة من عرض الشريط }, tabsW, barH }
  let lay = {}, defaults = null;
  const save = () => api.setSettings({ barLay: lay });
  function snapDefaults() { if (!defaults) defaults = toolGrps().map(g => grpTools(g).map(key)); }
  const allTools = () => [...toolGrps().flatMap(grpTools), ...[...stashRoot.querySelectorAll('button.b')], ...[...pop.querySelectorAll('button.b')], ...grpTools(winGrp)].filter(isTool);

  // ترتيب كل مجموعة (المحفوظ + أي أداة جديدة في مجموعتها الأصلية)؛ وآخرها أزرار النافذة بترتيبها الثابت
  function orders() {
    const all = new Map(allTools().map(b => [key(b), b]));
    const k = G.length - 1;
    const saved = (lay.groups && lay.groups.length === k) ? lay.groups : defaults;
    const used = new Set(), out = G.map(() => []);
    const wl = out[k];
    for (const kk of winOrder) { const b = all.get(kk); if (b) { wl.push(b); used.add(kk); } }
    saved.forEach((ks, i) => ks.forEach(kk => { const b = all.get(kk); if (b && !used.has(kk) && i < k) { out[i].push(b); used.add(kk); } }));
    for (const [kk, b] of all) if (!used.has(kk)) {
      if (b.closest && b.closest('.wg')) { winOrder.push(kk); wl.push(b); continue; }
      const gi = defaults.findIndex(a => a.includes(kk)); out[gi >= 0 ? gi : k - 1].push(b);
    }
    return out;
  }
  // أداة مخفية بتنسيق البرنامج (مثل التسجيل في Android) لا تُحسب
  const shown = (b) => getComputedStyle(b).display !== 'none';
  // أزرار النافذة: ما يختفي أولاً؛ ✕ لا يختفي أبداً
  const WHIDE = ['dockBtn', 'min', 'max', 'moreBtn'];
  const real = (i) => lists[i].filter(b => shown0.get(b));
  function visibleFor(i, n) {
    const r = real(i);
    if (!G[i].win) return new Set(r.slice(0, n));
    const hideable = r.filter(b => b.id !== 'close').sort((a, b) => {
      const ia = WHIDE.indexOf(a.id), ib = WHIDE.indexOf(b.id); return (ia < 0 ? -1 : ia) - (ib < 0 ? -1 : ib);
    });
    const hide = new Set(hideable.slice(0, Math.max(0, r.length - n)));
    return new Set(r.filter(b => !hide.has(b)));
  }
  // يضع العناصر في المجموعة بالترتيب دون تحريك ما هو في مكانه (حتى لا ينقطع سحب الخط)
  function sync(el, arr) {
    arr.forEach((x, idx) => { if (el.children[idx] !== x) el.insertBefore(x, el.children[idx] || null); });
  }
  // يرسم المجموعة: n أداة ظاهرة + السهم + الخط؛ والباقي في المخزن
  function render(i, n) {
    const g = G[i]; g.n = n;
    const vis = visibleFor(i, n), list = lists[i];
    const inBar = list.filter(b => !shown0.get(b) || vis.has(b));
    for (const b of list) if (!inBar.includes(b) && b.parentNode !== g.stash) g.stash.appendChild(b);
    const hid = list.some(b => shown0.get(b) && !vis.has(b));
    g.ov.style.display = hid && !edit ? '' : 'none';
    sync(g.el, g.win ? [g.sep, g.ov, ...inBar] : [...inBar, g.ov, g.sep]);
    g.el.classList.toggle('gEmpty', !edit && !list.length);
    g.ov.classList.toggle('hasOn', !!g.stash.querySelector('button.b.on'));
  }
  // عرض المجموعة لو ظهر منها n أداة (حساب دون رسم)
  const wOf = new Map(); let metr = null;
  function natural(i, n) {
    const r = real(i), vis = visibleFor(i, n), hid = r.length > vis.size;
    const m = metr[i];
    let w = m.pad + m.sepW;
    let cnt = 1;
    for (const b of vis) { w += wOf.get(b) || 0; cnt++; }
    if (hid) { w += m.ovW; cnt++; }
    return w + m.gap * (cnt - 1);
  }
  const minN = (i) => G[i].win ? Math.min(1, real(i).length) : 0;
  function nFor(i, width) {
    const tot = real(i).length;
    for (let n = tot; n > minN(i); n--) if (natural(i, n) <= width + 0.5) return n;
    return minN(i);
  }

  let shown0 = new Map(), lists = [];
  let fitting = false, lastWant = [];
  // order: ترتيب المجموعات التي تضيق عند نقص المكان (اختياري؛ يُستخدم أثناء سحب خط)
  function fit(order) {
    if (fitting) return; fitting = true;
    try {
      const reopen = openG; if (openG != null) closePop(true);
      drag.style.minWidth = '';
      initGroups(); snapDefaults();
      lists = orders();
      // كل الأدوات في مجموعاتها أولاً لمعرفة الظاهر منها وعرض كل أداة
      G.forEach((g, i) => { g.el.style.width = ''; sync(g.el, g.win ? [g.sep, g.ov, ...lists[i]] : [...lists[i], g.ov, g.sep]); g.ov.style.display = ''; });
      shown0 = new Map(lists.flat().map(b => [b, shown(b)]));
      lists.flat().forEach(b => wOf.set(b, b.offsetWidth));
      metr = G.map(g => {
        const cs = getComputedStyle(g.el), sc = getComputedStyle(g.sep);
        return { pad: parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight) + parseFloat(cs.borderLeftWidth) + parseFloat(cs.borderRightWidth),
          sepW: g.sep.offsetWidth + 3, ovW: g.ov.offsetWidth, gap: parseFloat(cs.columnGap) || 0 };
      });
      bar.classList.toggle('editing', !!edit);
      if (edit) { G.forEach((g, i) => render(i, real(i).length)); return; }

      // المساحة المتاحة للمجموعات = عرض الشريط − بقية العناصر − أقل عرض للتبويبات
      const B = bar.clientWidth, bcs = getComputedStyle(bar);
      const kids = [...bar.children].filter(c => c.id !== 'barGrip' && getComputedStyle(c).display !== 'none' && !(c.classList.contains('gEmpty')));
      const other = kids.filter(c => !G.some(g => g.el === c) && c !== drag).reduce((s, c) => s + c.offsetWidth, 0);
      const gaps = (parseFloat(bcs.columnGap) || 0) * (kids.length - 1);
      const Tm = Math.max(TABS_MIN, lay.tabsW || TABS_DEF);
      const avail = B - parseFloat(bcs.paddingLeft) - parseFloat(bcs.paddingRight) - gaps - other - Tm;
      const W = lay.w || {};
      const want = G.map((g, i) => {
        const full = natural(i, real(i).length), mn = natural(i, minN(i));
        return Math.max(mn, W[wk(i)] != null ? W[wk(i)] * B : full);
      });
      const full = G.map((g, i) => natural(i, real(i).length));
      // ما يضيق أولاً: المجموعات التي لم تحدد المعلمة عرضها (من آخر الشريط)، ثم التي حددته، ثم أزرار النافذة
      const k = G.length - 1;
      const def = [...[...Array(k).keys()].reverse().filter(i => W[wk(i)] == null), ...[...Array(k).keys()].reverse().filter(i => W[wk(i)] != null), k];
      let excess = want.reduce((s, x) => s + x, 0) - avail;
      for (const j of (order || def)) {
        if (excess <= 0) break;
        const cut = Math.min(excess, want[j] - natural(j, minN(j)));
        if (cut > 0) { want[j] -= cut; excess -= cut; }
      }
      if (excess > 0) drag.style.minWidth = Math.max(TABS_MIN, Tm - excess) + 'px';
      G.forEach((g, i) => {
        render(i, nFor(i, want[i]));
        g.el.style.width = Math.abs(want[i] - full[i]) < 0.5 ? '' : want[i] + 'px';
      });
      lastWant = want;
      // احتياط لفروق القياس: لا يُقطع شيء من الشريط
      const over = () => bar.scrollWidth > bar.clientWidth + 1;
      for (let i = k - 1; i >= 0 && over(); i--) while (over() && G[i].n > 0) { G[i].el.style.width = ''; render(i, G[i].n - 1); }
      if (over()) drag.style.minWidth = TABS_MIN + 'px';
      mergeRuns();
      if (reopen != null && G[reopen] && G[reopen].stash.children.length) openPop(reopen);
    } finally { fitting = false; watch(); mo.takeRecords(); }
  }
  // مجموعات متتالية اختفت كل أدواتها: سهم واحد يجمعها (بدل «« «« «« متتالية)
  function mergeRuns() {
    const k = G.length - 1;
    G.forEach(g => { g.run = null; g.el.classList.remove('gMerged', 'gMergedAll'); g.sep.style.display = ''; });
    const empty = (i) => G[i].n === 0 && real(i).length > 0;
    for (let i = 0; i < k; i++) {
      if (!empty(i)) continue;
      let j = i; while (j + 1 < k && empty(j + 1)) j++;
      if (j > i) {
        G[i].run = []; for (let x = i; x <= j; x++) G[i].run.push(x);
        for (let x = i; x <= j; x++) {
          if (x !== j) G[x].sep.style.display = 'none';
          if (x !== i) { G[x].el.classList.add('gMerged'); G[x].ov.style.display = 'none'; if (x !== j) G[x].el.classList.add('gMergedAll'); }
        }
        G[i].ov.classList.toggle('hasOn', G[i].run.some(x => !!G[x].stash.querySelector('button.b.on')));
      }
      i = j;
    }
  }
  let raf = 0;
  const refit = () => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; if (!dragging) fit(); }); };
  const ro = new ResizeObserver(refit);
  ro.observe(bar);
  ['#recPill', '#trialPill', '#gbCtx', '#bellBtn', '#allTabs'].forEach(s => { const el = $(s); if (el) ro.observe(el); });
  // أزرار تضيفها أجزاء أخرى من البرنامج لاحقاً
  const mo = new MutationObserver(() => { if (!fitting && !dragging) refit(); });
  const watch = () => { mo.disconnect(); [...toolGrps(), winGrp].forEach(g => mo.observe(g, { childList: true })); };
  // نقطة على سهم المجموعة إن كانت الأداة المختارة داخله (مثل القلم)
  new MutationObserver(() => G.forEach(g => g.ov.classList.toggle('hasOn', (g.run || [G.indexOf(g)]).some(x => !!G[x].stash.querySelector('button.b.on')))))
    .observe(stashRoot, { subtree: true, attributes: true, attributeFilter: ['class'] });

  // ---------- نافذة سهم المجموعة ----------
  const pop = document.createElement('div'); pop.id = 'ovfPop';
  pop.innerHTML = `<div class="ovf-box" id="ovfBox"></div><div class="ovf-hint">${T('اسحبي أداة إلى الشريط لتظهر، أو من الشريط إلى هنا')}</div>`;
  document.body.appendChild(pop);
  const box = pop.querySelector('#ovfBox');
  let openG = null;
  const origin = new Map();
  function placePop() {
    if (openG == null) return;
    const r = G[openG].ov.getBoundingClientRect(), gr = G[openG].el.getBoundingClientRect(), br = bar.getBoundingClientRect();
    pop.style.bottom = (innerHeight - br.top + 6) + 'px';
    const w = pop.offsetWidth, cx = (gr.left + gr.right) / 2;
    pop.style.left = Math.max(8, Math.min(innerWidth - w - 8, cx - w / 2)) + 'px';
    pop.style.setProperty('--ax', (r.left + r.width / 2 - parseFloat(pop.style.left)) + 'px');
  }
  function openPop(i) {
    closePop(true);
    LP.closePanels && LP.closePanels();
    openG = i; const g = G[i];
    (g.run || [i]).forEach((x, n) => {
      const st = G[x].stash;
      if (n && st.firstChild) { const d = document.createElement('i'); d.className = 'ovf-div'; box.appendChild(d); }
      while (st.firstChild) { const b = st.firstChild; origin.set(b, x); box.appendChild(b); }
    });
    pop.classList.add('on'); g.ov.classList.add('popOpen'); g.el.classList.add('gOpen');
    placePop();
  }
  function closePop(quiet) {
    if (openG == null) return;
    const g = G[openG];
    while (box.firstChild) { const b = box.firstChild; if (b === ph || b.classList.contains('ovf-div')) { b.remove(); continue; } const x = origin.get(b); (x != null && G[x] ? G[x] : g).stash.appendChild(b); }
    origin.clear();
    pop.classList.remove('on'); g.ov.classList.remove('popOpen'); g.el.classList.remove('gOpen');
    openG = null;
  }
  document.addEventListener('pointerdown', (e) => {
    if (openG == null || dragging) return;
    if (!pop.contains(e.target) && !G[openG].el.contains(e.target)) closePop();
  }, true);
  window.addEventListener('blur', () => closePop());
  // الضغط على أداة داخل النافذة: تعمل ثم تُغلق النافذة (قوائم الأدوات تُفتح في مكانها المعتاد)
  pop.addEventListener('click', (e) => { if (e.target.closest('button.b') && !justDragged) setTimeout(() => closePop(), 0); }, true);

  // ---------- السحب داخل المجموعة المفتوحة (تبديل الظاهر والمخفي) ----------
  const ph = document.createElement('div'); ph.className = 'barPh';
  let dragging = null, justDragged = false;
  // أين تقع الأداة لو أُفلتت هنا: داخل النافذة، أو بين أدوات المجموعة في الشريط
  function placePh(x, y, area) {
    const el = document.elementFromPoint(x, y); if (!el) return;
    let host = null;
    if (el.closest('#ovfPop')) host = box;
    else if (area === 'group' && el.closest('.grp') === G[openG].el) host = G[openG].el;
    else if (area === 'any') { const g = el.closest('#bar .grp'); if (g && g !== winGrp) host = g; else if (el.closest('#ovfPop')) host = box; }
    if (!host) return;
    const tgt = el.closest('button.b');
    if (tgt && tgt !== dragging && isTool(tgt) && host.contains(tgt)) {
      const r = tgt.getBoundingClientRect(), mid = x > r.left + r.width / 2;
      tgt[(isRtl() ? !mid : mid) ? 'after' : 'before'](ph);
    } else if (!host.contains(ph)) {
      const stop = host === box ? null : host.querySelector('.gov');
      host.insertBefore(ph, stop);
    }
  }
  function startDrag(e, b, area, onDrop) {
    const x0 = e.clientX, y0 = e.clientY, r = b.getBoundingClientRect();
    let ghost = null;
    const begin = () => {
      dragging = b;
      ghost = b.cloneNode(true); ghost.removeAttribute('id'); ghost.className = 'b barGhost';
      ghost.style.cssText = `position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
      document.body.appendChild(ghost);
      b.classList.add('barDragging'); b.after(ph);
    };
    const mv = (ev) => {
      if (!dragging) { if (Math.hypot(ev.clientX - x0, ev.clientY - y0) < DRAG_PX) return; begin(); }
      ev.preventDefault();
      ghost.style.left = (ev.clientX - (x0 - r.left)) + 'px'; ghost.style.top = (ev.clientY - (y0 - r.top)) + 'px';
      placePh(ev.clientX, ev.clientY, area);
    };
    const up = () => {
      document.removeEventListener('pointermove', mv, true); document.removeEventListener('pointerup', up, true); document.removeEventListener('pointercancel', up, true);
      if (!dragging) return;          // ضغطة عادية: تعمل الأداة
      ghost.remove(); b.classList.remove('barDragging');
      justDragged = true; setTimeout(() => { justDragged = false; }, 50);
      onDrop(ph.parentNode ? ph : null);
      ph.remove(); dragging = null;
    };
    document.addEventListener('pointermove', mv, true); document.addEventListener('pointerup', up, true); document.addEventListener('pointercancel', up, true);
  }
  // بعد السحب لا تعمل الأداة بالضغطة نفسها
  document.addEventListener('click', (e) => {
    if ((justDragged || edit) && e.target.closest('#bar .grp button.b:not(.gov), #ovfPop button.b')) { e.preventDefault(); e.stopPropagation(); }
  }, true);

  // سحب في المجموعة المفتوحة: عدد الظاهر ثابت، فما يدخل الشريط يُخرج آخر ظاهر إلى النافذة والعكس
  document.addEventListener('pointerdown', (e) => {
    if (edit || openG == null || e.button > 0) return;
    const i = openG, g = G[i]; if (g.win || (g.run && g.run.length > 1)) return;
    const b = e.target.closest('button.b'); if (!isTool(b)) return;
    if (!(box.contains(b) || g.el.contains(b))) return;
    startDrag(e, b, 'group', (at) => {
      if (!at) return;
      const fromBox = !g.el.contains(b) || box.contains(b);
      // الترتيب كما يظهر بعد الإفلات
      const seq = (host) => [...host.children].filter(x => x === ph || (isTool(x) && x !== b)).map(x => x === ph ? b : x);
      let vis = seq(g.el), hid = seq(box);
      const cnt = (l) => l.filter(x => shown0.get(x) !== false).length;
      // دخلت أداة إلى الشريط: آخر ظاهرة (غيرها) تنتقل إلى النافذة
      if (cnt(vis) > g.n) { const out = vis.filter(x => x !== b && shown0.get(x) !== false).pop(); vis = vis.filter(x => x !== out); hid = [out, ...hid]; }
      // خرجت أداة من الشريط: أول مخفية (غيرها) تظهر مكانها
      if (cnt(vis) < g.n) { const inn = hid.find(x => x !== b && shown0.get(x) !== false); if (inn) { hid = hid.filter(x => x !== inn); vis = [...vis, inn]; } }
      const order = [...vis, ...hid].map(key);
      lay.groups = lists.slice(0, -1).map((l, j) => j === i ? order : l.map(key));
      save(); fit(); if (openG !== i && G[i].stash.children.length) openPop(i);
    });
  }, true);

  // ---------- الخط الفاصل: تضييق المجموعة وتوسيعها بحرية ----------
  // يأخذ أولاً من المساحة الفارغة والتبويبات، ثم يدفع المجموعات التي في اتجاه السحب
  function sepDrag(e, i) {
    if (edit || e.button > 0) return;
    e.preventDefault(); e.stopPropagation(); closePop(true);
    const g = G[i], sep = g.sep; sep.classList.add('on'); document.body.classList.add('barSizing');
    const x0 = e.clientX, w0 = g.el.getBoundingClientRect().width, B = bar.clientWidth, k = G.length - 1;
    const order = g.win ? [...[...Array(k).keys()].reverse(), k]
      : [...[...Array(k).keys()].filter(j => j > i), k, ...[...Array(k).keys()].filter(j => j < i).reverse(), i];
    const before = { ...(lay.w || {}) };
    const mv = (ev) => {
      ev.preventDefault();
      const d = g.win ? (isRtl() ? ev.clientX - x0 : x0 - ev.clientX) : (isRtl() ? x0 - ev.clientX : ev.clientX - x0);
      lay.w = { ...before, [wk(i)]: Math.max(0, w0 + d) / B };
      fit(order);
      // المجموعات التي دُفعت تبقى بعرضها الجديد
      G.forEach((x, j) => { if (j !== i && lastWant[j] < natural(j, real(j).length) - 0.5 && (before[wk(j)] == null || lastWant[j] < before[wk(j)] * B - 0.5)) lay.w[wk(j)] = lastWant[j] / B; });
      lay.w[wk(i)] = lastWant[i] / B;
    };
    const up = () => {
      document.removeEventListener('pointermove', mv, true); document.removeEventListener('pointerup', up, true); document.removeEventListener('pointercancel', up, true);
      sep.classList.remove('on'); document.body.classList.remove('barSizing');
      // عرضها الكامل تماماً = بلا تحديد
      G.forEach((x, j) => { if (lay.w[wk(j)] != null && Math.abs(lay.w[wk(j)] * B - natural(j, real(j).length)) < 1) delete lay.w[wk(j)]; });
      save(); fit();
    };
    document.addEventListener('pointermove', mv, true); document.addEventListener('pointerup', up, true); document.addEventListener('pointercancel', up, true);
  }

  // ---------- الفاصل بين الأدوات والتبويبات ----------
  const split = document.createElement('div'); split.id = 'barSplit'; split.title = T('اسحبي لتوسيع التبويبات أو الأدوات');
  drag.before(split);
  const setTabsW = (w) => { lay.tabsW = Math.round(Math.max(TABS_MIN, Math.min(w, bar.clientWidth * 0.7))); root.style.setProperty('--tabsMin', lay.tabsW + 'px'); };
  split.addEventListener('pointerdown', (e) => {
    e.preventDefault(); split.setPointerCapture(e.pointerId); split.classList.add('on'); closePop(true);
    const r = drag.getBoundingClientRect(), rtl = isRtl();
    const far = rtl ? r.left : r.right;           // طرف التبويبات الثابت (جهة أزرار النافذة)
    const mv = (ev) => { setTabsW(rtl ? ev.clientX - far : far - ev.clientX); fit(); };
    const up = () => { split.classList.remove('on'); split.removeEventListener('pointermove', mv); split.removeEventListener('pointerup', up); split.removeEventListener('pointercancel', up); save(); };
    split.addEventListener('pointermove', mv); split.addEventListener('pointerup', up); split.addEventListener('pointercancel', up);
  });
  split.ondblclick = () => { delete lay.tabsW; root.style.setProperty('--tabsMin', TABS_DEF + 'px'); save(); refit(); };

  // ---------- تكبير الأزرار: سحب الحافة العليا للشريط ----------
  const grip = document.createElement('div'); grip.id = 'barGrip'; grip.title = T('اسحبي للأعلى لتكبير الأزرار');
  bar.appendChild(grip);
  const setBarH = (h) => { lay.barH = Math.round(Math.max(BAR_MIN, Math.min(BAR_MAX, h))); root.style.setProperty('--barH', lay.barH + 'px'); };
  grip.addEventListener('pointerdown', (e) => {
    e.preventDefault(); grip.setPointerCapture(e.pointerId); grip.classList.add('on'); closePop(true);
    const y0 = e.clientY, h0 = bar.offsetHeight;
    const mv = (ev) => { setBarH(h0 + (y0 - ev.clientY)); refit(); };
    const up = () => { grip.classList.remove('on'); grip.removeEventListener('pointermove', mv); grip.removeEventListener('pointerup', up); grip.removeEventListener('pointercancel', up); save(); window.dispatchEvent(new Event('resize')); };
    grip.addEventListener('pointermove', mv); grip.addEventListener('pointerup', up); grip.addEventListener('pointercancel', up);
  });
  grip.ondblclick = () => { delete lay.barH; root.style.setProperty('--barH', BAR_MIN + 'px'); save(); refit(); window.dispatchEvent(new Event('resize')); };

  // ---------- «ترتيب أدوات الشريط»: نقل الأدوات بين المجموعات ----------
  let edit = false;
  const hint = document.createElement('div'); hint.id = 'barEditHint';
  hint.innerHTML = `<span>✋ ${T('اسحبي أي أداة إلى مكان آخر أو إلى مجموعة أخرى في الشريط.')}</span>
    <button id="beReset">${T('الترتيب الأصلي')}</button><button class="pri" id="beDone">${T('تم')}</button>`;
  document.body.appendChild(hint);
  function startEdit() { closePop(true); LP.closePanels && LP.closePanels(); edit = true; document.body.classList.add('barEdit'); fit(); }
  function endEdit() { edit = false; document.body.classList.remove('barEdit'); fit(); }
  LP.editBar = startEdit;
  hint.querySelector('#beDone').onclick = endEdit;
  hint.querySelector('#beReset').onclick = () => { lay = { tabsW: lay.tabsW, barH: lay.barH }; save(); fit(); };
  document.addEventListener('keydown', (e) => {
    if (edit && (e.key === 'Escape' || e.key === 'Enter')) { e.preventDefault(); e.stopPropagation(); endEdit(); }
    else if (openG != null && e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closePop(); }
  }, true);
  document.addEventListener('pointerdown', (e) => {
    if (!edit || e.button > 0) return;
    const b = e.target.closest('#bar .grp.tg button.b'); if (!isTool(b)) return;
    e.preventDefault();
    startDrag(e, b, 'any', (at) => {
      if (!at) return;
      at.replaceWith(b);
      lay.groups = G.filter(g => !g.win).map(g => grpTools(g.el).map(key));
      save(); fit();
    });
  }, true);

  // عنصر في قائمة «المزيد»
  const hb = $('#hideBar');
  if (hb) {
    const mi = document.createElement('button'); mi.className = 'mi'; mi.id = 'editBarMi';
    mi.innerHTML = `<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h10M4 17h7"/><path d="M17 14l3 3-3 3"/></svg><span>${T('ترتيب أدوات الشريط')}</span>`;
    hb.after(mi); mi.onclick = () => setTimeout(startEdit, 0);
  }

  // ---------- التحميل ----------
  function applyLay() {
    root.style.setProperty('--barH', (lay.barH || BAR_MIN) + 'px');
    root.style.setProperty('--tabsMin', (lay.tabsW || TABS_DEF) + 'px');
    fit();
  }
  async function load() { const p = await api.getSettings().catch(() => ({})); lay = (p && p.barLay) || {}; delete lay.pin; delete lay.cap; applyLay(); }
  document.addEventListener('lp-auth', () => setTimeout(load, 50));
  initGroups(); snapDefaults(); load();
})();
