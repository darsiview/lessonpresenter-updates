// 📅 التقويم الدراسي: فصول دراسية بتاريخين، تُقسَّم تلقائياً إلى أسابيع (مع إزالة أسابيع الإجازة وإعادة الترقيم)،
// ولكل أسبوع «قيمة الشهر» من برنامج القيم المدرسية.
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const DAY = 864e5;
  const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  let prof = {};
  // مصدر التقويم حسب مكان العمل: شخصي ← تقويمها، مدرسة ← تقويم المدرسة (أو تقويمها إن اختارت ذلك أو لم تضعه الإدارة بعد)
  function srcInfo() {
    const sid = LP.ctxHome ? LP.ctxHome() : '';
    if (!sid) return { kind: 'own', sid: '' };
    const sch = LP.schoolOf ? LP.schoolOf(sid) : null, canEdit = !!(sch && (sch.perms || []).includes('calendar'));
    const sc = (prof.schoolCal || {})[sid], has = !!(sc && (sc.terms || []).length);
    if ((prof.calUse || {})[sid] === 'own') return { kind: 'own', sid, chosenOwn: true, canEdit, has };
    if (!has && !canEdit) return { kind: 'own', sid, fallback: true };
    return { kind: 'school', sid, canEdit, has, sc };
  }
  // تقويم المدرسة + توزيع الدروس الخاص بالمعلمة (يبقى عندها فقط)
  function cal() {
    const si = srcInfo();
    if (si.kind === 'own') return (prof.cal ||= { terms: [] });
    const plans = (prof.calPlans || {})[si.sid] || {};
    return { school: si.sid, terms: ((si.sc && si.sc.terms) || []).map(t => ({ ...t, plan: plans[t.id] || {} })) };
  }
  const parse = (d) => { const [y, m, dd] = String(d || '').split('-').map(Number); return y ? new Date(y, m - 1, dd).getTime() : 0; };
  const iso = (t) => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const loc = (cal) => ({ ar: 'ar-SA', en: 'en-GB', fr: 'fr-FR' }[I18N.lang] || 'ar-SA') + '-u-ca-' + cal + (I18N.lang === 'ar' ? '-nu-arab' : '');
  const short = (t) => {
    const f = (c, o) => { try { return new Date(t).toLocaleDateString(loc(c), o); } catch { return new Date(t).toLocaleDateString(); } };
    const h = f('islamic-umalqura', { day: 'numeric', month: 'long' }), g = f('gregory', { day: 'numeric', month: 'short' });
    return LP.dateMode === 'g' ? g : LP.dateMode === 'h' ? h : `${h} (${g})`;
  };
  const hMonth = (t) => { try { return new Date(t).toLocaleDateString('en-u-ca-islamic-umalqura', { month: 'numeric', year: 'numeric' }); } catch { return ''; } };

  // ---------- الأسابيع ----------
  function weeks(term) {
    const a = parse(term.start), b = parse(term.end); if (!a || !b || b < a) return [];
    const ws = term.wStart ?? 0, len = ((term.wEnd ?? 4) - ws + 7) % 7;      // من الأحد إلى الخميس = 4 أيام بعد الأول
    let d = new Date(a); d.setDate(d.getDate() - ((d.getDay() - ws + 7) % 7));  // بداية الأسبوع الذي فيه تاريخ البداية
    const off = new Set(term.off || []), vals = term.values || {}, phr = term.phrases || {}, out = []; let i = 0, num = 0;
    while (d.getTime() <= b && i < 80) {
      const from = Math.max(d.getTime(), a), to = Math.min(d.getTime() + len * DAY, b);
      if (from > to) { d = new Date(d.getTime() + 7 * DAY + 3600e3); d.setHours(0, 0, 0, 0); i++; continue; }   // بدأ الفصل في عطلة نهاية الأسبوع
      const on = !off.has(i); if (on) num++;
      out.push({ i, from, to, on, num: on ? num : 0, value: vals[i] || '', phrase: phr[i] || '' });
      d = new Date(d.getTime() + 7 * DAY + 3600e3); d.setHours(0, 0, 0, 0); i++;
    }
    return out;
  }
  // أين نحن الآن؟ (الفصل، والأسبوع الدراسي، والقيمة)
  function at(t) {
    t = t || Date.now();
    for (const term of cal().terms) {
      const a = parse(term.start), b = parse(term.end) + DAY - 1; if (!a || t < a || t > b) continue;
      const w = weeks(term).find(x => t >= x.from && t <= x.to + DAY - 1);
      return { term, week: w && w.on ? w.num : 0, holiday: !!(w && !w.on), w, value: w ? w.value : '', phrase: w ? w.phrase : '' };
    }
    return null;
  }
  const label = (t) => { const n = at(t); if (!n) return ''; return n.term.name + (n.week ? ' · ' + T('الأسبوع {n}', { n: n.week }) : n.holiday ? ' · ' + T('إجازة') : ''); };
  const termRange = (term) => [parse(term.start), parse(term.end) + DAY - 1];
  const lastEnded = () => cal().terms.filter(x => parse(x.end) + DAY - 1 < Date.now()).sort((x, y) => parse(y.end) - parse(x.end))[0] || null;
  // توزيع المنهج: لكل فصل دراسي خريطة «الدرس ← رقم الأسبوع»
  const planOf = (term) => (term && term.plan) || {};
  // قيمة الدرس رقم أسبوع واحد (قديم) أو قائمة أسابيع
  const wksOf = (term, key) => { const v = planOf(term)[key]; return (Array.isArray(v) ? v : v ? [v] : []).map(Number).filter(Boolean).sort((a, b) => a - b); };
  const wkLabel = (arr) => { const out = []; for (let i = 0; i < arr.length; i++) { let j = i; while (j + 1 < arr.length && arr[j + 1] === arr[j] + 1) j++; out.push(j > i ? `${arr[i]}–${arr[j]}` : `${arr[i]}`); i = j; } return out.join('، '); };
  async function setPlan(termId, patch, replace) {
    prof = await api.getSettings();
    const term = cal().terms.find(x => x.id === termId); if (!term) return;
    const pl = replace ? {} : { ...(term.plan || {}) };
    for (let [k, v] of Object.entries(patch)) {
      if (Array.isArray(v)) { v = [...new Set(v.map(Number).filter(Boolean))].sort((a, b) => a - b); v = v.length > 1 ? v : v[0] || 0; }
      if (v) pl[k] = v; else delete pl[k];
    }
    term.plan = pl;
    const si = srcInfo();
    if (si.kind === 'school') { const all = { ...(prof.calPlans || {}) }; all[si.sid] = { ...(all[si.sid] || {}), [termId]: pl }; await api.setSettings({ calPlans: all }); }
    else await api.setSettings({ cal: cal() });
    document.dispatchEvent(new Event('lp-cal'));
  }
  async function reload() { prof = await api.getSettings(); }

  // ---------- مزامنة تقويم المدرسة ----------
  let lastPush = 0;
  async function fetchSchool(sid, quiet) {
    if (!sid) return;
    const r = await api.school('getData', sid, 'calendar').catch(() => null);
    if (!r || r.err || !r.v) return;
    prof = await api.getSettings();
    const old = (prof.schoolCal || {})[sid];
    if (old && (r.v.updated || 0) <= (old.updated || 0)) return;
    const schoolCal = { ...(prof.schoolCal || {}), [sid]: { terms: r.v.terms || [], updated: r.v.updated || 0, by: r.v.by || '' } };
    await api.setSettings({ schoolCal }); prof.schoolCal = schoolCal;
    if (old && !quiet && Date.now() - lastPush > 60e3 && !dlg.classList.contains('on')) LP.toast(T('حدّثت الإدارة تقويم «{s}»', { s: LP.ctxName(sid) }), null, null, 5000);
    if (dlg.classList.contains('on') && srcInfo().kind === 'school') { CD = cal(); render(); }
    document.dispatchEvent(new Event('lp-cal'));
  }
  let pushT = null;
  function pushSchool(sid, sc) {
    clearTimeout(pushT); lastPush = Date.now();
    pushT = setTimeout(async () => {
      const r = await api.school('setData', sid, 'calendar', { terms: sc.terms }).catch(() => ({ err: 'net' }));
      if (r && r.err) { LP.toast(T(r.err === 'cdenied' ? 'لا توجد صلاحية لتعديل تقويم المدرسة' : 'لم يُرفع التعديل للسحابة (تحققي من الإنترنت)'), null, null, 5000); return; }
      prof = await api.getSettings(); const schoolCal = { ...(prof.schoolCal || {}) }; schoolCal[sid] = { ...sc, updated: r.v }; await api.setSettings({ schoolCal }); prof.schoolCal = schoolCal;
    }, 900);
  }
  // ---------- قيمة الأسبوع (من التقويم، أو قيمة سريعة تُكتب من الشريط حتى نهاية الأسبوع الدراسي) ----------
  const qKey = () => srcInfo().sid || '_';
  const quick = () => { const q = (prof.valQuick || {})[qKey()]; return q && q.value && q.until >= Date.now() && (q.from || 0) <= Date.now() ? q : null; };
  // الأسبوع الدراسي الحالي (أو القادم إن كنا في عطلة نهاية الأسبوع) حسب أيام آخر تقويم، والافتراضي الأحد–الخميس
  function schoolWeek(t) {
    t = t || Date.now();
    const n = at(t), ts = cal().terms, ref = (n && n.term) || ts[ts.length - 1] || {};
    const ws = ref.wStart ?? 0, len = ((ref.wEnd ?? 4) - ws + 7) % 7;
    const d = new Date(t); d.setHours(0, 0, 0, 0);
    const off = (d.getDay() - ws + 7) % 7;
    const start = off <= len ? d.getTime() - off * DAY : d.getTime() + (7 - off) * DAY;
    const s0 = new Date(start); s0.setHours(0, 0, 0, 0);
    const e0 = new Date(s0.getTime() + len * DAY + 3600e3); e0.setHours(23, 59, 59, 0);
    return { from: s0.getTime(), to: e0.getTime() };
  }
  function now() {
    const n = at();
    if (n && n.value) return { value: n.value, phrase: n.phrase || '', src: 'cal' };
    const q = quick(); if (q) return { value: q.value, phrase: q.phrase || '', src: 'quick' };
    return { value: '', phrase: '', src: '' };
  }
  // هل يُكتب في التقويم نفسه؟ (فصل دراسي يغطي اليوم، وأسبوع دراسي، وصلاحية التعديل)
  const calEditable = () => { const n = at(), si = srcInfo(); return !!(n && n.w && n.w.on && (si.kind === 'own' || si.canEdit)); };
  async function setWeekValue(value, phrase, month) {
    prof = await api.getSettings();
    value = String(value || '').trim(); phrase = String(phrase || '').trim();
    const n = at();
    if (calEditable()) {
      const t = n.term, W = weeks(t), i = n.w.i, vs = { ...(t.values || {}) }, ps = { ...(t.phrases || {}) };
      const put = (k) => { if (value) vs[k] = value; else delete vs[k]; if (phrase) ps[k] = phrase; else delete ps[k]; };
      put(i);
      if (month) { const m = hMonth(n.w.from); for (const x of W) if (x.i > i && x.on && hMonth(x.from) === m) put(x.i); }
      t.values = vs; t.phrases = ps;
      const si = srcInfo();
      if (si.kind === 'own') await api.setSettings({ cal: prof.cal });
      else {
        const sc = { terms: cal().terms.map(x => { const { plan, ...r } = x.id === t.id ? t : x; return r; }), updated: Date.now() };
        prof.schoolCal = { ...(prof.schoolCal || {}), [si.sid]: sc };
        await api.setSettings({ schoolCal: prof.schoolCal }); pushSchool(si.sid, sc);
      }
      const all = { ...(prof.valQuick || {}) }; if (all[qKey()]) { delete all[qKey()]; await api.setSettings({ valQuick: all }); prof.valQuick = all; }
    } else {
      const w = schoolWeek(); let until = w.to;
      if (month) { const m = hMonth(w.from); let x = w; for (let k = 0; k < 6; k++) { const nx = schoolWeek(x.to + 2 * DAY); if (hMonth(nx.from) !== m) break; x = nx; until = x.to; } }
      const all = { ...(prof.valQuick || {}) };
      if (value) all[qKey()] = { value, phrase, from: Math.min(Date.now(), w.from), until }; else delete all[qKey()];
      await api.setSettings({ valQuick: all }); prof.valQuick = all;
    }
    document.dispatchEvent(new Event('lp-cal'));
    return calEditable() ? 'cal' : 'quick';
  }
  LP.cal = { weeks, at, label, termRange, short, lastEnded, planOf, wksOf, wkLabel, setPlan, reload, get terms() { return cal().terms; },
    value: (t) => { if (t) { const n = at(t); if (n && n.value) return n.value; const q = (prof.valQuick || {})[qKey()]; return q && q.value && t <= q.until && t >= (q.from || 0) ? q.value : ''; } return now().value; },
    now, setWeekValue, calEditable, schoolWeek };

  // ---------- النافذة ----------
  const dlg = document.createElement('div'); dlg.className = 'gdlg'; dlg.id = 'calDlg';
  dlg.innerHTML = '<div class="gdlg-card cal-card" id="calCard"></div>';
  $('#stage').appendChild(dlg);
  const card = dlg.querySelector('#calCard');
  const close = () => { dlg.classList.remove('on'); document.dispatchEvent(new Event('lp-cal')); };
  dlg.addEventListener('click', e => { if (e.target === dlg) close(); });
  let CD = null, ro = false;
  const save = () => {
    const si = srcInfo();
    if (si.kind === 'own') { prof.cal = CD; return api.setSettings({ cal: CD }); }
    if (!si.canEdit) return;
    const sc = { terms: CD.terms.map(({ plan, ...t }) => t), updated: Date.now() };
    prof.schoolCal = { ...(prof.schoolCal || {}), [si.sid]: sc };
    api.setSettings({ schoolCal: prof.schoolCal });
    pushSchool(si.sid, sc);
  };
  let cur = 0;
  async function open(i) {
    prof = await api.getSettings();
    const si0 = srcInfo(); if (si0.sid) await fetchSchool(si0.sid, true);
    const si = srcInfo();
    CD = cal(); ro = si.kind === 'school' && !si.canEdit;
    if (i !== undefined) cur = i;
    if (!CD.terms.length && !ro) { CD.terms.push(newTerm()); save(); }
    cur = Math.max(0, Math.min(cur, CD.terms.length - 1));
    render(); dlg.classList.add('on');
  }
  function newTerm() {
    const terms = CD.terms, prev = terms[terms.length - 1];
    const names = ['الفصل الدراسي الأول', 'الفصل الدراسي الثاني', 'الفصل الدراسي الثالث', 'الفصل الدراسي الرابع'];
    const start = prev ? iso(parse(prev.end) + 3 * DAY) : iso(Date.now());
    return { id: Date.now().toString(36), name: T(names[terms.length] || 'فصل دراسي {n}', { n: terms.length + 1 }), start, end: iso(parse(start) + 13 * 7 * DAY), wStart: prev ? prev.wStart : 0, wEnd: prev ? prev.wEnd : 4, off: [], values: {} };
  }
  // شريط المصدر أعلى النافذة
  function srcBar() {
    const si = srcInfo(), sn = esc(si.sid ? LP.ctxName(si.sid) : ''), col = si.sid ? LP.ctxColor(si.sid) : '#64748b';
    const others = (LP.schools ? LP.schools() : []);
    let h = '';
    if (si.kind === 'school') {
      h = `<span class="ctx-dot" style="background:${col}"></span>🏫 <b>${T('تقويم «{s}»', { s: sn })}</b> — ${si.canEdit ? T('يمكن تعديله، ويصل للجميع في المدرسة') : T('تضعه الإدارة')}
        <span class="cal-src-acts">${si.canEdit ? `<button class="rbtn" id="calFromOwn">⤒ ${T('نسخ من تقويمي الشخصي')}</button>` : ''}<button class="rbtn" id="calUseOwn">👤 ${T('استخدام تقويمي الخاص هنا')}</button></span>`;
    } else if (si.chosenOwn) {
      h = `👤 <b>${T('تقويمي الخاص')}</b> — ${T('في «{s}»', { s: sn })} <span class="cal-src-acts"><button class="rbtn" id="calUseSchool"><span class="ctx-dot" style="background:${col}"></span>${T('العودة لتقويم المدرسة')}</button></span>`;
    } else if (si.fallback) {
      h = `👤 <b>${T('تقويمي الخاص')}</b> — ${T('لم تضع إدارة «{s}» تقويماً بعد', { s: sn })}`;
    } else if (others.length) {
      h = `👤 <b>${T('تقويمي الخاص')}</b>`;
    }
    if (si.kind === 'own' && others.length) h += `<span class="cal-src-acts">${others.map(x => `<button class="rbtn" data-pull="${esc(x.sid)}"><span class="ctx-dot" style="background:${LP.ctxColor(x.sid)}"></span>⤓ ${T('أخذ تقويم «{s}»', { s: esc(x.name) })}</button>`).join('')}</span>`;
    return h ? `<div class="cal-src">${h}</div>` : '';
  }
  function wireSrc() {
    const si = srcInfo();
    const use = async (v) => { const calUse = { ...(prof.calUse || {}) }; if (v) calUse[si.sid] = v; else delete calUse[si.sid]; await api.setSettings({ calUse }); prof.calUse = calUse; CD = cal(); ro = srcInfo().kind === 'school' && !srcInfo().canEdit; cur = 0; if (!CD.terms.length && !ro) { CD.terms.push(newTerm()); save(); } render(); document.dispatchEvent(new Event('lp-cal')); };
    const a = $('#calUseOwn'); if (a) a.onclick = () => use('own');
    const b = $('#calUseSchool'); if (b) b.onclick = () => use('');
    const c = $('#calFromOwn'); if (c) LP.sureBtn(c, () => { const own = (prof.cal || { terms: [] }).terms; if (!own.length) { LP.toast(T('تقويمكِ الشخصي فارغ')); return; } CD.terms = own.map(({ plan, ...t }) => JSON.parse(JSON.stringify(t))); cur = 0; save(); render(); LP.toast(T('تم النسخ — وسيصل لكل المعلمات')); });
    card.querySelectorAll('[data-pull]').forEach(btn => LP.sureBtn(btn, async () => {
      const r = await api.school('getData', btn.dataset.pull, 'calendar').catch(() => null);
      const terms = r && r.v && r.v.terms; if (!terms || !terms.length) { LP.toast(T('لم تضع إدارة هذه المدرسة تقويماً بعد')); return; }
      const oldPlans = Object.fromEntries((CD.terms || []).map(t => [t.id, t.plan]));
      CD.terms = terms.map(t => ({ ...JSON.parse(JSON.stringify(t)), plan: oldPlans[t.id] || {} }));
      cur = 0; save(); render(); document.dispatchEvent(new Event('lp-cal'));
      LP.toast(T('أصبح تقويم «{s}» تقويمكِ الخاص — يمكنكِ تعديله كما تشائين', { s: LP.ctxName(btn.dataset.pull) }), null, null, 5000);
    }));
  }
  function render() {
    if (!CD.terms.length) {
      card.innerHTML = `<div class="res-head"><h3>📅 ${T('التقويم الدراسي')}</h3><span style="flex:1"></span><button class="rbtn" id="calX">✕</button></div>${srcBar()}
        <p class="muted">${T('لا يوجد تقويم بعد.')}</p><div class="gdlg-row"><button class="pri" id="calOk">${T('تم')}</button></div>`;
      $('#calX').onclick = close; $('#calOk').onclick = close; wireSrc(); return;
    }
    const terms = CD.terms, t = terms[cur], W = weeks(t), nOn = W.filter(x => x.on).length;
    const dsel = (id, v) => `<select id="${id}">${DAYS.map((d, i) => `<option value="${i}" ${i === v ? 'selected' : ''}>${T(d)}</option>`).join('')}</select>`;
    card.innerHTML = `<div class="res-head"><h3>📅 ${T('التقويم الدراسي')}</h3><span style="flex:1"></span><button class="rbtn" id="calX">✕</button></div>${srcBar()}
      <div class="tchips">${terms.map((x, i) => `<button class="tchip ${i === cur ? 'on' : ''}" data-t="${i}">${esc(x.name)}</button>`).join('')}<button class="tchip add" id="calAdd">＋ ${T('فصل دراسي')}</button></div>
      <div class="cal-grid">
        <label>${T('الاسم')}<input id="calName" dir="auto" value="${esc(t.name)}"></label>
        <label>${T('بداية الفصل')}<input type="date" id="calStart" value="${esc(t.start)}"><small>${esc(short(parse(t.start)))}</small></label>
        <label>${T('نهاية الفصل')}<input type="date" id="calEnd" value="${esc(t.end)}"><small>${esc(short(parse(t.end)))}</small></label>
        <label>${T('الأسبوع الدراسي من')}${dsel('calWs', t.wStart ?? 0)}</label>
        <label>${T('إلى')}${dsel('calWe', t.wEnd ?? 4)}</label>
      </div>
      <p class="cal-sum">${T('{n} أسبوعاً بين التاريخين — المحسوب منها {k}. أزيلي العلامة عن أسابيع الإجازة.', { n: W.length, k: nOn })}</p>
      <div class="cal-wk">${W.map(w => `<div class="cal-row ${w.on ? '' : 'off'}">
          <label class="cal-on"><input type="checkbox" data-on="${w.i}" ${w.on ? 'checked' : ''}><b>${w.on ? T('الأسبوع {n}', { n: w.num }) : T('إجازة')}</b></label>
          <span class="cal-d">${esc(short(w.from))} — ${esc(short(w.to))}</span>
          <input class="cal-v" data-v="${w.i}" dir="auto" placeholder="${T('قيمة الشهر')}" value="${esc(w.value)}" ${w.on ? '' : 'disabled'}>
          <input class="cal-v cal-p" data-p="${w.i}" dir="auto" placeholder="${T('عبارة (اختياري)')}" value="${esc(w.phrase)}" ${w.on ? '' : 'disabled'}>
          <button class="rbtn" data-next="${w.i}" title="${T('نسخ القيمة للأسبوع التالي')}">⤵</button>
          <button class="rbtn" data-month="${w.i}" title="${T('نسخ القيمة حتى نهاية الشهر')}">⇣ ${T('الشهر')}</button></div>`).join('')}</div>
      <div class="gdlg-row"><button class="pri" id="calOk">${T('تم')}</button><button class="warn" id="calDel">🗑 ${T('حذف هذا الفصل الدراسي')}</button></div>`;
    card.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => { if (e.key !== 'Escape') e.stopPropagation(); }));
    $('#calX').onclick = close; $('#calOk').onclick = close;
    card.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { cur = +b.dataset.t; render(); });
    wireSrc();
    card.classList.toggle('ro', ro);
    if (ro) {   // للقراءة فقط (تقويم المدرسة لمن ليست لها الصلاحية)
      card.querySelectorAll('.cal-grid input, .cal-grid select, .cal-wk input, .cal-wk button').forEach(e => { e.disabled = true; });
      ['#calAdd', '#calDel'].forEach(k => { const e = $(k); if (e) e.style.display = 'none'; });
      return;
    }
    $('#calAdd').onclick = () => { terms.push(newTerm()); cur = terms.length - 1; save(); render(); };
    const set = (k, v) => { t[k] = v; save(); render(); };
    $('#calName').onchange = (e) => set('name', e.target.value.trim() || t.name);
    $('#calStart').onchange = (e) => { t.off = []; t.values = {}; t.phrases = {}; set('start', e.target.value); };
    $('#calEnd').onchange = (e) => set('end', e.target.value);
    $('#calWs').onchange = (e) => { t.off = []; t.values = {}; t.phrases = {}; set('wStart', +e.target.value); };
    $('#calWe').onchange = (e) => set('wEnd', +e.target.value);
    card.querySelectorAll('[data-on]').forEach(c => c.onchange = () => {
      const i = +c.dataset.on, off = new Set(t.off || []); if (c.checked) off.delete(i); else off.add(i);
      t.off = [...off].sort((a, b) => a - b); save(); render();
    });
    card.querySelectorAll('[data-v]').forEach(inp => inp.onchange = () => { t.values = { ...(t.values || {}), [inp.dataset.v]: inp.value.trim() }; save(); });
    card.querySelectorAll('[data-p]').forEach(inp => inp.onchange = () => { t.phrases = { ...(t.phrases || {}), [inp.dataset.p]: inp.value.trim() }; save(); });
    const val = (i) => (t.values || {})[i] || (card.querySelector(`[data-v="${i}"]`) || {}).value || '';
    const phr = (i) => (t.phrases || {})[i] || (card.querySelector(`[data-p="${i}"]`) || {}).value || '';
    card.querySelectorAll('[data-next]').forEach(b => b.onclick = () => {
      const i = +b.dataset.next, v = val(i); if (!v) return;
      const nx = W.find(x => x.i > i && x.on); if (!nx) return;
      t.values = { ...(t.values || {}), [i]: v, [nx.i]: v }; const p = phr(i); if (p) t.phrases = { ...(t.phrases || {}), [i]: p, [nx.i]: p }; save(); render();
    });
    card.querySelectorAll('[data-month]').forEach(b => b.onclick = () => {
      const i = +b.dataset.month, v = val(i); if (!v) return;
      const w0 = W.find(x => x.i === i), m = hMonth(w0.from), p = phr(i); const vs = { ...(t.values || {}), [i]: v }, ps = { ...(t.phrases || {}) }; if (p) ps[i] = p;
      for (const x of W) if (x.i > i && x.on && hMonth(x.from) === m) { vs[x.i] = v; if (p) ps[x.i] = p; }
      t.values = vs; t.phrases = ps; save(); render();
    });
    LP.sureBtn($('#calDel'), () => { terms.splice(cur, 1); cur = 0; save(); if (!terms.length) close(); else render(); });
  }
  LP.openCalendar = open;

  // ---------- زر في أدوات المعلمة ----------
  const col = $('#tpYear');
  if (col) { const b = document.createElement('button'); b.className = 'tb'; b.textContent = '📅 ' + T('التقويم الدراسي وقيم الشهر'); col.prepend(b); b.onclick = () => { LP.closePanels && LP.closePanels(); open(); }; }

  // تبديل مكان العمل → تقويمه، وتحديث تقويم المدرسة كل 30 دقيقة
  document.addEventListener('lp-ctx', async () => { prof = await api.getSettings(); document.dispatchEvent(new Event('lp-cal')); const si = srcInfo(); if (si.sid) fetchSchool(si.sid, true); });
  setInterval(() => { const si = srcInfo(); if (si.sid && document.visibilityState !== 'hidden') fetchSchool(si.sid); }, 30 * 60e3);

  // ---------- التذكير بنهاية الفصل الدراسي ----------
  document.addEventListener('lp-auth', async (e) => {
    if (!e.detail || !e.detail.user) return;
    prof = await api.getSettings(); document.dispatchEvent(new Event('lp-cal'));
    setTimeout(async () => {
      const si = srcInfo(); if (si.sid) await fetchSchool(si.sid, true);
      const ended = lastEnded(), rem = prof.calRemind || {};
      if (ended && !rem[ended.id] && !(prof.yearArchive || []).some(a => a.termId === ended.id)) {
        LP.toast(T('انتهى «{t}» — هل تريدين حفظه في الأرشيف وبدء الفصل التالي؟', { t: ended.name }), T('الأرشفة'), () => LP.newYear && LP.newYear('term'), 15000);
        api.setSettings({ calRemind: { ...rem, [ended.id]: Date.now() } });
        return;
      }
      const n = at(), W = n && weeks(n.term).filter(x => x.on);
      if (n && W.length && n.week === W[W.length - 1].num && !rem['last_' + n.term.id]) {
        LP.toast(T('هذا آخر أسبوع في «{t}» 🎓', { t: n.term.name }), null, null, 7000);
        api.setSettings({ calRemind: { ...rem, ['last_' + n.term.id]: Date.now() } });
      }
    }, 4000);
  });
})();
