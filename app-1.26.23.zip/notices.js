// 🔔 التنبيهات والدروس الإدارية من المدارس
// - الإدارة (المالك أو من له صلاحية «الدروس الإدارية والتنبيهات») تنشر لكل المدرسة أو لمراحل وصفوف محددة، بتاريخ ظهور وانتهاء
// - المعلم يرى ما يخصه من كل مدارسه (مع اسم المدرسة ولونها)، ويضغط «تم الاطلاع» أو «عرض الآن / تم عرضه»
// - الإدارة تتابع: من اطّلع، ومن عرض الدرس وفي أي فصل، ومن لم يطّلع بعد
(() => {
  const api = window.api;
  const $ = (s, r = document) => r.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const call = async (op, ...a) => { const r = await api.school(op, ...a); if (!r || !r.ok) throw Object.assign(new Error(r && r.err || 'cfail'), { code: r && r.err }); return r.v; };
  const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const addDays = (n) => { const d = new Date(Date.now() + n * 864e5); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const fmtD = (s) => { if (!s) return ''; const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d).toLocaleDateString(I18N.lang === 'ar' ? 'ar-SA-u-ca-gregory' : I18N.lang, { day: 'numeric', month: 'short' }); };
  const canPub = (s) => s && (s.role === 'owner' || (s.perms || []).includes('adminLessons'));
  const isAdminOf = (s) => s && s.role !== 'teacher';

  // ---------- الزر في الشريط ----------
  const bell = document.createElement('button');
  bell.id = 'bellBtn'; bell.className = 'gb-bell'; bell.style.display = 'none';
  bell.innerHTML = '🔔<span id="bellN"></span>';
  bell.setAttribute('data-tip', 'التنبيهات والدروس الإدارية');
  const bar = document.getElementById('bar');
  const placeBell = () => { const c = document.getElementById('gbCtx'); if (c && c.parentElement) c.after(bell); else if (bar) bar.prepend(bell); };
  placeBell();
  bell.onclick = () => openPanel();

  // ---------- البيانات ----------
  // cache[sid] = { notices, scope: {stages:Set, grades:Set} | null (إدارة: ترى الكل) }
  const cache = {};
  let prof = {}, alerted = new Set(), busy = null;
  async function scopeOf(s) {
    if (isAdminOf(s)) return null;
    const [asg, st] = await Promise.all([call('getAssign', s.sid).catch(() => null), call('getData', s.sid, 'structure').catch(() => null)]);
    const S = st && st.stages ? st : { stages: [], grades: [], classes: [] };
    const stages = new Set(asg && asg.stages || []), grades = new Set(asg && asg.grades || []);
    for (const cid of asg && asg.classes || []) { const c = (S.classes || []).find(x => x.id === cid); if (c) grades.add(c.grade); }
    for (const g of S.grades || []) { if (stages.has(g.stage)) grades.add(g.id); if (grades.has(g.id)) stages.add(g.stage); }
    return { stages, grades };
  }
  const visibleTo = (n, scope) => n.all || !scope || (n.stages || []).some(x => scope.stages.has(x)) || (n.grades || []).some(x => scope.grades.has(x));
  const active = (n) => (!n.start || n.start <= today()) && (!n.end || n.end >= today());
  async function refresh() {
    if (busy) return busy;
    busy = (async () => {
      prof = await api.getSettings().catch(() => ({})) || {};
      const schools = LP.schools ? LP.schools() : [];
      bell.style.display = schools.length ? '' : 'none'; placeBell();
      for (const s of schools) {
        try {
          const c = cache[s.sid] || (cache[s.sid] = {});
          if (c.scope === undefined || Date.now() - (c.scopeAt || 0) > 30 * 60e3) { c.scope = await scopeOf(s); c.scopeAt = Date.now(); }
          c.notices = (await call('listNotices', s.sid)).sort((a, b) => (b.at || 0) - (a.at || 0));
        } catch (e) { if (e.code === 'gone' || e.code === 'cdenied') delete cache[s.sid]; }
      }
      for (const k of Object.keys(cache)) if (!schools.some(s => s.sid === k)) delete cache[k];
      paintBadge(); alertNew();
    })().finally(() => { busy = null; });
    return busy;
  }
  // ما يظهر للمستخدم الآن (من كل المدارس)
  function items(all) {
    const out = [], schools = LP.schools ? LP.schools() : [];
    for (const s of schools) {
      const c = cache[s.sid]; if (!c || !c.notices) continue;
      for (const n of c.notices) {
        const mine = visibleTo(n, c.scope);
        if (!all && !(mine && active(n))) continue;
        if (all && !mine && !canPub(s)) continue;
        out.push({ ...n, sid: s.sid, school: s });
      }
    }
    return out.sort((a, b) => (b.at || 0) - (a.at || 0));
  }
  const seenMap = () => prof.nSeen || {};
  const unread = () => items(false).filter(n => !seenMap()[n.id] && n.byUid !== (LP.auth && LP.auth.user && LP.auth.user.cloudUid));
  function paintBadge() { const k = unread().length, b = document.getElementById('bellN'); b.textContent = k ? (k > 9 ? '9+' : k) : ''; bell.classList.toggle('has', k > 0); }
  function alertNew() {
    const fresh = unread().filter(n => !alerted.has(n.id)); if (!fresh.length) return;
    fresh.forEach(n => alerted.add(n.id));
    const n = fresh[0];
    const what = n.kind === 'lesson' ? T('درس إداري جديد') : T('تنبيه جديد');
    LP.toast(`🔔 ${what} — «${n.school.name}»: ${n.title}${fresh.length > 1 ? ' ' + T('(+{n})', { n: fresh.length - 1 }) : ''}`, T('عرض'), () => openPanel(), 12000);
  }
  async function markRead(list) {
    const m = { ...seenMap() }; let ch = false;
    for (const n of list) if (!m[n.id]) { m[n.id] = Date.now(); ch = true; call('markSeen', n.sid, n.id, { name: LP.auth && LP.auth.user && LP.auth.user.name, shown: false }).catch(() => {}); }
    // حذف القديم من السجل (أكثر من 120 يوماً)
    for (const k of Object.keys(m)) if (Date.now() - m[k] > 120 * 864e5) { delete m[k]; ch = true; }
    if (ch) { prof.nSeen = m; await api.setSettings({ nSeen: m }); paintBadge(); }
  }

  // ---------- اللوحة ----------
  let dlg = null;
  const close = () => { if (dlg) { dlg.remove(); dlg = null; } };
  async function openPanel() {
    close();
    dlg = document.createElement('div'); dlg.className = 'gdlg on'; dlg.id = 'ntDlg';
    dlg.addEventListener('click', e => { if (e.target === dlg) close(); });
    dlg.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') close(); });
    dlg.innerHTML = `<div class="gdlg-card nt-card" tabindex="-1"><div class="nt-head"><h3>🔔 ${T('التنبيهات والدروس الإدارية')}</h3><span style="flex:1"></span>
      ${(LP.schools() || []).some(canPub) ? `<button class="pri nt-new">＋ ${T('نشر جديد')}</button>` : ''}<button class="nt-x">✕</button></div>
      <div class="nt-list"><p class="tnote">⏳ ${T('جارٍ التحميل…')}</p></div></div>`;
    document.body.appendChild(dlg);
    dlg.querySelector('.nt-x').onclick = close;
    const nb = dlg.querySelector('.nt-new'); if (nb) nb.onclick = () => compose();
    dlg.querySelector('.nt-card').focus();
    await refresh(); drawList();
  }
  function drawList() {
    if (!dlg) return;
    const host = dlg.querySelector('.nt-list'), list = items(true);
    const uid = LP.auth && LP.auth.user && LP.auth.user.cloudUid;
    if (!list.length) { host.innerHTML = `<p class="tnote nt-empty">${T('لا توجد تنبيهات أو دروس إدارية الآن.')}</p>`; return; }
    host.innerHTML = list.map(n => {
      const s = n.school, adm = canPub(s), act = active(n), mine = visibleTo(n, (cache[n.sid] || {}).scope);
      const state = !act ? (n.start > today() ? `<span class="nt-tag sch">🕓 ${T('مجدول من {d}', { d: fmtD(n.start) })}</span>` : `<span class="nt-tag old">${T('انتهى')}</span>`) : '';
      const mark = (prof.nShown || {})[n.id];
      const period = n.end ? T('يظهر حتى {d}', { d: fmtD(n.end) }) : '';
      const target = n.all ? T('المدرسة كاملة') : T('مراحل وصفوف محددة');
      return `<div class="nt-item ${n.kind} ${seenMap()[n.id] || n.byUid === uid ? '' : 'unread'}" data-id="${esc(n.id)}" data-sid="${esc(n.sid)}" style="--cc:${LP.ctxColor(n.sid)}">
        <div class="nt-top"><span class="nt-school">● 🏫 ${esc(s.name)}</span><span class="nt-kind">${n.kind === 'lesson' ? '🎬 ' + T('درس إداري') : '📢 ' + T('تنبيه')}</span>${state}<span style="flex:1"></span><small>${esc(n.by)} · ${new Date(n.at).toLocaleDateString(I18N.lang === 'ar' ? 'ar-SA-u-ca-gregory' : I18N.lang, { day: 'numeric', month: 'short' })}</small></div>
        <h4>${esc(n.title)}</h4>
        ${n.body ? `<p class="nt-body">${esc(n.body)}</p>` : ''}
        <div class="nt-meta">${period ? '📅 ' + period + ' · ' : ''}🎯 ${target}</div>
        <div class="nt-acts">
          ${mine && n.kind === 'lesson' && n.url ? `<button class="pri" data-play>▶ ${T('عرض الآن')}</button>` : ''}
          ${mine && act ? (mark ? `<span class="nt-done">✓ ${n.kind === 'lesson' ? T('عُرض في {c}', { c: esc(mark.cls || '') }) : T('تم الاطلاع')}</span>` : `<button class="pbtn" data-done>✓ ${n.kind === 'lesson' ? T('تم عرضه') : T('تم الاطلاع')}</button>`) : ''}
          ${adm ? `<span style="flex:1"></span><button class="pbtn" data-track>👁 ${T('المتابعة')}</button><button class="pbtn" data-edit>✎</button><button class="pbtn" data-del>🗑</button>` : ''}
        </div><div class="nt-track"></div></div>`;
    }).join('');
    host.querySelectorAll('.nt-item').forEach(el => {
      const n = list.find(x => x.id === el.dataset.id && x.sid === el.dataset.sid);
      const done = async (shown) => {
        const cls = (document.getElementById('classSel') && document.getElementById('classSel').selectedOptions[0] || {}).text || '';
        try { await call('markSeen', n.sid, n.id, { name: LP.auth && LP.auth.user && LP.auth.user.name, cls, shown }); } catch { LP.toast(T('تعذّر الحفظ، حاول لاحقاً')); return; }
        const m = { ...(prof.nShown || {}) }; m[n.id] = { at: Date.now(), cls }; prof.nShown = m; await api.setSettings({ nShown: m });
        drawList();
      };
      const p = el.querySelector('[data-play]'); if (p) p.onclick = () => { LP.openUrl(n.url); done(true); close(); };
      const d = el.querySelector('[data-done]'); if (d) d.onclick = () => done(n.kind === 'lesson');
      const ed = el.querySelector('[data-edit]'); if (ed) ed.onclick = () => compose(n);
      const dl = el.querySelector('[data-del]'); if (dl) LP.sureBtn ? LP.sureBtn(dl, async () => { try { await call('delNotice', n.sid, n.id); await refresh(); drawList(); LP.toast(T('تم الحذف')); } catch { LP.toast(T('تعذّر الحذف')); } }) : null;
      const tr = el.querySelector('[data-track]'); if (tr) tr.onclick = () => track(n, el.querySelector('.nt-track'));
    });
    markRead(list.filter(n => visibleTo(n, (cache[n.sid] || {}).scope) && active(n)));
  }
  // من اطّلع ومن عرض (للإدارة)
  async function track(n, box) {
    if (box.innerHTML) { box.innerHTML = ''; return; }
    box.innerHTML = '⏳';
    try {
      const [seen, mem] = await Promise.all([call('listSeen', n.sid, n.id), call('members', n.sid)]);
      const by = new Map(seen.map(x => [x.id, x]));
      const rows = seen.sort((a, b) => b.at - a.at).map(x => `<li>${x.shown ? '🎬 ' + T('عرضه') + (x.cls ? ' — ' + esc(x.cls) : '') : '✓ ' + T('اطّلع')} · <b>${esc(x.name)}</b> <small>${new Date(x.at).toLocaleString(I18N.lang === 'ar' ? 'ar-SA-u-ca-gregory' : I18N.lang, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}</small></li>`).join('');
      const not = mem.filter(m => !by.has(m.id) && m.id !== n.byUid).map(m => esc(m.name || m.email || '')).filter(Boolean);
      box.innerHTML = `<div class="nt-tr"><b>${T('اطّلع {a} · عرضه {b}', { a: seen.length, b: seen.filter(x => x.shown).length })}</b><ul>${rows || `<li class="tnote">${T('لا أحد بعد')}</li>`}</ul>
        ${not.length ? `<p class="tnote">${T('لم يطّلع بعد:')} ${not.join('، ')}</p>` : ''}</div>`;
    } catch { box.innerHTML = `<p class="tnote">${T('تعذّر تحميل المتابعة')}</p>`; }
  }

  // ---------- النشر والتعديل ----------
  async function compose(edit) {
    const pubs = (LP.schools() || []).filter(canPub); if (!pubs.length) return;
    let sid = edit ? edit.sid : (pubs.find(s => s.sid === (LP.ctxHome && LP.ctxHome())) || pubs[0]).sid;
    const n = edit ? { ...edit } : { kind: 'msg', title: '', body: '', url: '', all: true, stages: [], grades: [], start: today(), end: addDays(7) };
    const box = document.createElement('div'); box.className = 'gdlg on'; box.id = 'ntEdit';
    const shut = () => box.remove();
    box.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') shut(); });
    document.body.appendChild(box);
    let S = { stages: [], grades: [] };
    const loadS = async () => { S = await call('getData', sid, 'structure').catch(() => null) || {}; S.stages = S.stages || []; S.grades = S.grades || []; };
    await loadS();
    const draw = () => {
      box.innerHTML = `<div class="gdlg-card nt-card nt-form" tabindex="-1"><div class="nt-head"><h3>${edit ? '✎ ' + T('تعديل') : '＋ ' + T('نشر تنبيه أو درس إداري')}</h3><span style="flex:1"></span><button class="nt-x">✕</button></div>
        ${pubs.length > 1 ? `<label class="nt-f"><span>${T('المدرسة')}</span><select id="ntS" ${edit ? 'disabled' : ''}>${pubs.map(s => `<option value="${esc(s.sid)}" ${s.sid === sid ? 'selected' : ''}>🏫 ${esc(s.name)}</option>`).join('')}</select></label>` : `<p class="nt-one">🏫 <b>${esc(pubs[0].name)}</b></p>`}
        <div class="nt-f"><span>${T('النوع')}</span><div class="seg" id="ntK"><button data-v="msg" class="${n.kind === 'msg' ? 'on' : ''}">📢 ${T('تنبيه')}</button><button data-v="lesson" class="${n.kind === 'lesson' ? 'on' : ''}">🎬 ${T('درس إداري')}</button></div></div>
        <label class="nt-f"><span>${T('العنوان')}</span><input id="ntT" maxlength="120" value="${esc(n.title)}" placeholder="${T(n.kind === 'lesson' ? 'مثال: الإذاعة الصباحية — يوم المعلم' : 'مثال: اجتماع المعلمين بعد الحصة السادسة')}"></label>
        <label class="nt-f"><span>${T('التفاصيل')}</span><textarea id="ntB" rows="3" maxlength="2000">${esc(n.body)}</textarea></label>
        ${n.kind === 'lesson' ? `<label class="nt-f"><span>${T('رابط الدرس')}</span><input id="ntU" dir="ltr" value="${esc(n.url)}" placeholder="https://… (YouTube، OneDrive، Google Drive…)"></label>` : ''}
        <div class="nt-f"><span>${T('لمن؟')}</span><div class="seg" id="ntA"><button data-v="1" class="${n.all ? 'on' : ''}">${T('المدرسة كاملة')}</button><button data-v="0" class="${n.all ? '' : 'on'}">${T('مراحل أو صفوف محددة')}</button></div></div>
        ${n.all ? '' : S.stages.length ? `<div class="nt-tg">${S.stages.map(st => `<div class="nt-st"><label><input type="checkbox" data-st="${esc(st.id)}" ${n.stages.includes(st.id) ? 'checked' : ''}> <b>${esc(st.name)}</b></label>
            <div class="nt-gr">${S.grades.filter(g => g.stage === st.id).map(g => `<label><input type="checkbox" data-gr="${esc(g.id)}" ${n.grades.includes(g.id) || n.stages.includes(st.id) ? 'checked' : ''} ${n.stages.includes(st.id) ? 'disabled' : ''}> ${esc(g.name)}</label>`).join('')}</div></div>`).join('')}</div>`
          : `<p class="tnote">${T('لم يُبنَ هيكل المدرسة بعد (المراحل والصفوف). يمكن النشر للمدرسة كاملة، أو بناء الهيكل من نافذة المدرسة.')}</p>`}
        <div class="nt-f nt-dates"><span>${T('يظهر')}</span><label>${T('من')} <input type="date" id="ntFrom" value="${esc(n.start)}"></label><label>${T('إلى')} <input type="date" id="ntTo" value="${esc(n.end)}"></label></div>
        <p class="nt-err" id="ntErr"></p>
        <div class="gdlg-row"><button class="pri" id="ntGo">${edit ? T('حفظ') : '📤 ' + T('نشر')}</button><button class="sec" id="ntNo">${T('إلغاء')}</button></div></div>`;
      const q = (s) => box.querySelector(s);
      const keep = () => { n.title = q('#ntT').value; n.body = q('#ntB').value; if (q('#ntU')) n.url = q('#ntU').value; n.start = q('#ntFrom').value; n.end = q('#ntTo').value;
        if (!n.all) { n.stages = [...box.querySelectorAll('[data-st]:checked')].map(x => x.dataset.st); n.grades = [...box.querySelectorAll('[data-gr]:checked:not(:disabled)')].map(x => x.dataset.gr); } };
      q('.nt-x').onclick = shut; q('#ntNo').onclick = shut;
      const ss = q('#ntS'); if (ss) ss.onchange = async () => { keep(); sid = ss.value; n.stages = []; n.grades = []; await loadS(); draw(); };
      box.querySelectorAll('#ntK button').forEach(b => b.onclick = () => { keep(); n.kind = b.dataset.v; draw(); });
      box.querySelectorAll('#ntA button').forEach(b => b.onclick = () => { keep(); n.all = b.dataset.v === '1'; draw(); });
      box.querySelectorAll('[data-st]').forEach(c => c.onchange = () => { keep(); draw(); });
      q('#ntGo').onclick = async () => {
        keep();
        const err = (m) => { q('#ntErr').textContent = '⚠ ' + m; };
        if (!n.title.trim()) return err(T('العنوان مطلوب'));
        if (n.kind === 'lesson' && !/^https?:\/\/\S+/.test((LP.pickUrl ? LP.pickUrl(n.url) : n.url.trim()))) return err(T('رابط الدرس مطلوب (يبدأ بـ https://)'));
        if (!n.all && !n.stages.length && !n.grades.length) return err(T('اختر مرحلة أو صفاً على الأقل'));
        if (n.end && n.start && n.end < n.start) return err(T('تاريخ الانتهاء قبل تاريخ البدء'));
        q('#ntGo').disabled = true;
        try {
          const id = await call('saveNotice', sid, { ...n, url: (LP.pickUrl ? LP.pickUrl(n.url) : n.url.trim()), title: n.title.trim(), by: LP.auth && LP.auth.user && LP.auth.user.name });
          prof.nSeen = { ...seenMap(), [id]: Date.now() }; alerted.add(id); api.setSettings({ nSeen: prof.nSeen });   // ما ينشره المستخدم لا يُعدّ جديداً عليه
          shut(); LP.toast('✓ ' + T(edit ? 'تم الحفظ' : 'تم النشر')); await refresh(); drawList();
        } catch (e) { q('#ntGo').disabled = false; err(T(e.code === 'cdenied' ? 'لا توجد صلاحية النشر في هذه المدرسة' : 'تعذّر النشر — تحقق من الاتصال')); }
      };
      q('.nt-card').focus();
    };
    draw();
  }

  LP.openNotices = openPanel;
  LP.refreshNotices = refresh;
  // عند الدخول، وعند تغيير مكان العمل أو المدارس، وكل 10 دقائق
  let started = false;
  const kick = () => setTimeout(() => refresh().catch(() => {}), 2500);
  document.addEventListener('lp-auth', (e) => { if (!e.detail || !e.detail.user || !e.detail.user.cloud) { bell.style.display = 'none'; return; } if (!started) { started = true; kick(); setInterval(() => refresh().catch(() => {}), 10 * 60e3); } });
  document.addEventListener('lp-ctx', kick);
  if (LP.auth && LP.auth.user && LP.auth.user.cloud) { started = true; kick(); setInterval(() => refresh().catch(() => {}), 10 * 60e3); }
})();
