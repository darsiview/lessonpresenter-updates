// الدخول بالباركود (مثل واتساب) + سجل «أجهزتي» والإخراج عن بُعد
// الجهاز يعرض رمزاً فيه: معرّف جلسة عشوائي + مفتاح تشفير لا يغادر الشاشة إلا داخل الرمز.
// جوال المعلمة (بعد موافقتها) يكتب في qr/{sid} بيانات الدخول مشفّرة بهذا المفتاح، والجهاز يقرؤها ويفكّها ثم يحذفها.
const crypto = require('crypto');
const os = require('os');
const cloud = require('./cloud');
const store = require('./store');

let CFG = {}; try { CFG = require('./cloud-config.json'); } catch {}
const FS = process.env.LP_FB_FS || 'https://firestore.googleapis.com/v1';
const docs = () => `${FS}/projects/${CFG.projectId}/databases/(default)/documents`;
const phoneUrl = () => process.env.LP_PHONE_URL || CFG.phoneUrl || '';
const ready = () => !!(cloud.configured() && phoneUrl());
const b64u = (b) => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
const deviceName = () => { try { return os.hostname() || 'PC'; } catch { return 'PC'; } };

async function authed(method, url, body) {
  const res = await fetch(url, { method, signal: AbortSignal.timeout(15000), headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + await cloud.idToken() }, body: body ? JSON.stringify(body) : undefined });
  if (res.status === 404) return null;
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new cloud.CloudErr('cfail', JSON.stringify(j.error || res.status));
  return j;
}

// ---------- جلسة الرمز ----------
let cur = null;
function start(onPayload, onExpire) {
  stop();
  const sid = b64u(crypto.randomBytes(16)), key = crypto.randomBytes(32), exp = Date.now() + 120 * 1000;
  const url = `${phoneUrl()}#s=${sid}&k=${b64u(key)}&n=${encodeURIComponent(deviceName())}&t=${exp}`;
  const me = cur = { sid, key, exp, timer: null };
  const tick = async () => {
    if (cur !== me) return;
    if (Date.now() > exp) { cur = null; onExpire && onExpire(); return; }
    try {
      const res = await fetch(`${docs()}/qr/${sid}?key=${encodeURIComponent(CFG.apiKey)}`, { signal: AbortSignal.timeout(8000) });
      if (cur !== me) return;
      if (res.ok) {
        const j = await res.json(); const f = j.fields || {};
        const d = crypto.createDecipheriv('aes-256-gcm', key, unb64u(f.iv.stringValue));
        const raw = unb64u(f.p.stringValue);
        d.setAuthTag(raw.subarray(raw.length - 16));
        const data = JSON.parse(Buffer.concat([d.update(raw.subarray(0, raw.length - 16)), d.final()]).toString('utf8'));
        cur = null;
        return onPayload(data, sid);
      }
    } catch {}
    if (cur === me) me.timer = setTimeout(tick, 2000);
  };
  me.timer = setTimeout(tick, 1500);
  return { url, exp, name: deviceName() };
}
function stop() { if (cur) { clearTimeout(cur.timer); cur = null; } }
const removeQr = (sid) => authed('DELETE', `${docs()}/qr/${sid}`).catch(() => {});

// ---------- مفتاح الجوال (lk): يفتح بيانات الجهاز المشفّرة عند الدخول بالباركود ----------
// مشتق من مفتاح الخزنة (VK) الذي لا يُفتح إلا بكلمة مرور المعلمة، فلا يُحفظ في السحابة أبداً
// (كان سابقاً نصاً في ملف المعلمة بالسحابة؛ صفحة الجوال تنقل القديم مرة واحدة ثم تحذفه)
const lkFrom = (vk) => vk ? b64u(crypto.createHmac('sha256', Buffer.from(String(vk), 'base64')).update('lp-lk-v2').digest()) : null;

// ---------- أجهزتي ----------
async function registerDevice(personal) {
  const S = cloud.session(); if (!S) return;
  const f = { name: { stringValue: deviceName() }, lastSeen: { timestampValue: new Date().toISOString() }, app: { stringValue: 'desktop' }, personal: { booleanValue: !!personal } };
  const mask = Object.keys(f).map(k => 'updateMask.fieldPaths=' + k).join('&');
  await authed('PATCH', `${docs()}/users/${S.uid}/devices/${store.device.id()}?${mask}`, { fields: f }).catch(() => {});
}
// هل طلبت المعلمة من جوالها إخراج هذا الجهاز؟ ('out' أو 'wipe')
async function checkRevoke() {
  const S = cloud.session(); if (!S) return null;
  try {
    const d = await authed('GET', `${docs()}/users/${S.uid}/devices/${store.device.id()}`);
    return (d && d.fields && d.fields.revoke && d.fields.revoke.stringValue) || null;
  } catch { return null; }
}
const removeDevice = () => { const S = cloud.session(); return S ? authed('DELETE', `${docs()}/users/${S.uid}/devices/${store.device.id()}`).catch(() => {}) : null; };

module.exports = { ready, start, stop, removeQr, lkFrom, registerDevice, checkRevoke, removeDevice, deviceName };
