// الإعدادات: حسابي، المظهر (لون الشريط والشفافية)، اللغة، والمديرة
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const panel = $('#setPanel'), body = $('#setBody');
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let st = null, prof = {}, tab = 'me';

  // ================= المظهر =================
  const PRESETS = [
    { id: 'cream', name: 'كريمي وتركوازي', bar: '#fff8ec', accent: '#2bb3a3' },
    { id: 'grey', name: 'رمادي وكحلي', bar: '#f4f5f7', accent: '#1f3a5f' },
    { id: 'blue', name: 'أزرق فاتح', bar: '#eef4fb', accent: '#2f6db5' },
    { id: 'mint', name: 'نعناعي وأخضر', bar: '#eaf6f2', accent: '#1f7a6d' },
    { id: 'ivory', name: 'عاجي وبرتقالي', bar: '#fbf3e6', accent: '#b45309' },
    { id: 'g3', name: 'بنفسجي وعنابي', bar: '#ebd8ea', accent: '#a54f5d' },
    { id: 'dark', name: 'الداكن (القديم)', bar: '#24262d', accent: '#ff7a3d' },
    { id: 'pink', name: 'وردي', bar: '#f6d5e1', accent: '#c2255c' },
    { id: 'navy', name: 'كحلي داكن', bar: '#1c2a48', accent: '#4dabf7' }
  ];
  const ACCENTS = ['#2bb3a3', '#1f3a5f', '#2f6db5', '#1f7a6d', '#b45309', '#a54f5d', '#7b3f8f', '#ff7a3d', '#e5484d', '#e64980', '#ae3ec9', '#4c6ef5', '#228be6', '#12b886', '#2fb344', '#f5b400'];
  const DEFAULT = { bar: '#fff8ec', accent: '#2bb3a3', alpha: 1, darkBars: false };       // الأساسي: كريمي دافئ + تركوازي (مثل موقع الدرس المعتمد)
  const PREV_DEFAULT = { bar: '#ebd8ea', accent: '#a54f5d' };
  const OLD_DEFAULT = { bar: '#24262d', accent: '#ff7a3d' };

  const rgb = (h) => { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(x => x + x).join(''); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const lum = ([r, g, b]) => { const f = c => { c /= 255; return c <= .03928 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4); }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b); };
  const mix = (a, b, k) => a.map((x, i) => Math.round(x + (b[i] - x) * k));
  const css = (c, a) => a === undefined ? `rgb(${c.join(',')})` : `rgba(${c.join(',')},${a})`;

  function applyTheme(th) {
    th = { ...DEFAULT, ...(th || {}) };
    const bar = rgb(th.bar), dark = lum(bar) < 0.35, ac = rgb(th.accent);
    const toward = dark ? [255, 255, 255] : [0, 0, 0];
    const r = document.documentElement.style;
    r.setProperty('--bar', css(bar, th.alpha));
    // في المظهر الفاتح: البطاقات والقوائم أفتح من الخلفية، والنص بلون غامق مشتق من اللون الأساسي
    const paper = dark ? bar : mix(bar, [255, 255, 255], .82);
    r.setProperty('--bar-solid', css(paper));
    r.setProperty('--bar2', css(dark ? mix(bar, toward, .09) : mix(bar, [255, 255, 255], .45)));
    r.setProperty('--hover', css(dark ? mix(bar, toward, .15) : mix(bar, ac, .14)));
    r.setProperty('--line', css(dark ? mix(bar, toward, .16) : mix(bar, ac, .2)));
    r.setProperty('--panel', css(dark ? mix(bar, [0, 0, 0], .15) : bar, .98));
    r.setProperty('--field', css(dark ? mix(bar, [0, 0, 0], .35) : mix(bar, [255, 255, 255], .9)));
    r.setProperty('--field2', css(dark ? mix(bar, [0, 0, 0], .55) : mix(bar, [0, 0, 0], .05)));
    const ink = mix(ac, [20, 8, 30], .62);
    r.setProperty('--txt', dark ? '#e9eaee' : css(ink));
    r.setProperty('--muted', dark ? '#9a9eab' : css(mix(ink, bar, .42)));
    r.setProperty('--title', dark ? th.accent : css(mix(ac, [80, 20, 110], .35)));
    // ألوان البطاقات (مثل بطاقات أدوات المعلمة)
    const tints = dark ? [mix(bar, [0, 0, 0], .2), mix(bar, [0, 0, 0], .2), mix(bar, [0, 0, 0], .2), mix(bar, [0, 0, 0], .2)]
      : [[211, 247, 245], [251, 228, 240], [246, 225, 227], mix(bar, [255, 255, 255], .35)];
    tints.forEach((c, i) => r.setProperty('--tint' + (i + 1), css(c)));
    document.documentElement.classList.toggle('lightUI', !dark);
    document.documentElement.classList.toggle('darkBars', !!th.darkBars && !dark);
    r.setProperty('--accent', th.accent);
    r.setProperty('--accent-soft', css(ac, .18));
    $('#app').classList.toggle('overlay', th.alpha < 0.999);
    // خلفية خفيفة خلف الشريط الزجاجي
    r.setProperty('--glass-bg', `linear-gradient(90deg, ${css(mix(bar, ac, .35))}, ${css(mix(bar, toward, .25))})`);
  }
  window.LPapplyTheme = applyTheme;
  applyTheme(DEFAULT);

  // ================= اللوحة =================
  const prevClose = LP.closePanels;
  LP.closePanels = () => { const a = panel.classList.contains('on'); panel.classList.remove('on'); const b = prevClose(); return a || b; };
  $('[data-sclose]').onclick = () => panel.classList.remove('on');
  document.querySelectorAll('#setTabs button').forEach(b => b.onclick = () => { tab = b.dataset.v; render(); });
  $('#settingsBtn').onclick = () => { LP.closePanels(); panel.classList.add('on'); render(); };
  LP.openSettings = (t) => { LP.closePanels(); if (t) tab = t; panel.classList.add('on'); render(); };

  const msg = (el, text, ok) => { el.textContent = text; el.className = 'smsg ' + (ok ? 'ok' : 'err'); setTimeout(() => { if (el.textContent === text) el.textContent = ''; }, 5000); };
  const ERR = { name: 'الاسم مطلوب.', email: 'البريد الإلكتروني غير صحيح.', pin: 'الرمز السري يجب أن يكون من 4 إلى 12 رقماً.', exists: 'هذا البريد مسجّل لمستخدم آخر.', match: 'الرمزان غير متطابقين.' };
  const errText = (r) => r && r.err === 'cloudreset' ? T('حساب سحابي: لا يمكن تغيير كلمة مروره من هنا. يسترجعها صاحبه من «نسيت كلمة المرور» عبر بريده.') : r && r.err === 'cloudpw' ? T('هذه كلمة مرور حسابكِ السحابي: لتغييرها اختاري «نسيت كلمة المرور» من شاشة الدخول.') : r && r.wait ? T('محاولات كثيرة خاطئة. المحاولة ممكنة بعد {s} ثانية.', { s: r.wait }) : T(ERR[r && r.err] || 'الرمز السري غير صحيح.');

  function render() {
    const guest = st.user && st.user.guest, admin = st.user && st.user.admin;
    document.querySelectorAll('#setTabs button').forEach(b => {
      b.classList.toggle('on', b.dataset.v === tab);
      b.style.display = (b.dataset.v === 'admin' && !admin) || (b.dataset.v === 'me' && guest) ? 'none' : '';
    });
    if (guest && tab === 'me') tab = 'look';
    if (!admin && tab === 'admin') tab = 'me';
    document.querySelectorAll('#setTabs button').forEach(b => b.classList.toggle('on', b.dataset.v === tab));
    ({ me: renderMe, look: renderLook, lang: renderLang, ppt: renderPpt, admin: renderAdmin })[tab]();
  }

  // ---------- حسابي ----------
  async function renderMe() {
    const u = st.user;
    const where = await api.dataWhere();
    body.innerHTML = `
      <div class="sgroup scloud" id="sCloud" style="display:none"></div>
      <div class="sgroup"><h3>${T('بياناتي')}</h3>
        <div class="srow"><label class="l">${T('الاسم')}</label><input class="sinput" id="sName" value="${esc(u.name)}"></div>
        <div class="srow"><label class="l">${T('البريد الإلكتروني')}</label><input class="sinput ltr" id="sEmail" value="${esc(u.email || '')}" ${u.cloud ? `readonly title="${T('بريد الحساب السحابي')}"` : ''}></div>
        <div class="srow"><label class="l">${T('يخاطبني البرنامج بصيغة')}</label>
          <select id="sTG" data-noconv><option value="f" ${prof.teacherG === 'f' ? 'selected' : ''}>👩‍🏫 ${esc(I18N.t('معلمة', null, { tg: 'f', cg: 'g' }))}</option><option value="m" ${prof.teacherG !== 'f' ? 'selected' : ''}>👨‍🏫 ${T('معلم')}</option></select></div>
        <div class="srow"><button class="pbtn accent" id="sSaveMe">${T('حفظ')}</button><span class="smsg" id="mMe"></span></div>
      </div>
      <div class="sgroup" ${u.cloudPw ? 'style="display:none"' : ''}><h3>${T('تغيير الرمز السري')}</h3>
        <div class="srow"><label class="l">${T('الرمز الحالي')}</label><input class="sinput pin" type="password" inputmode="numeric" id="sOld"></div>
        <div class="srow"><label class="l">${T('الرمز الجديد')}</label><input class="sinput pin" type="password" inputmode="numeric" id="sNew"></div>
        <div class="srow"><label class="l">${T('أعيدي كتابة الرمز الجديد')}</label><input class="sinput pin" type="password" inputmode="numeric" id="sNew2"></div>
        <div class="srow"><button class="pbtn accent" id="sPin">${T('تغيير الرمز')}</button><span class="smsg" id="mPin"></span></div>
      </div>
      <div class="sgroup"><h3>${T('تسجيل الدخول في مايكروسوفت وGoogle')}</h3>
        <label class="tog2"><input type="checkbox" id="sPersonal" ${st.personal ? 'checked' : ''}><span class="sl"></span>
          <span>${T('هذا جهازي الشخصي: ابقي مسجّلة الدخول في حساباتي عند إغلاق البرنامج')}</span></label>
        <p class="ghint" style="color:var(--muted);margin:8px 0 12px">${T('على أي جهاز آخر، يخرج البرنامج من حساباتكِ عند إغلاقه، ويعيدها تلقائياً عند دخولكِ إذا كانت «خزنة الحسابات» مفعّلة. هذا الخيار يخص هذا الجهاز فقط ولا ينتقل مع الفلاش.')}</p>
        <div class="srow"><button class="pbtn" id="sSignout">🚪 ${T('تسجيل الخروج من حساباتي الآن')}</button><span class="smsg" id="mOut"></span></div>
      </div>
      <div class="sgroup ac-entry"><h3>🏫 ${T('أماكن العمل والمدارس')}</h3>
        <div class="srow"><span class="muted" style="flex:1">${T('الوضع الشخصي، والمدارس، والانضمام، والإدارة، ونقل الملكية')}</span><button class="pbtn accent" id="sAcc">${T('حسابي ومدارسي…')}</button></div></div>
      <div class="sgroup" id="sData"></div>
      <p class="muted" style="font-size:12.5px">${T('مكان حفظ البيانات:')} <span dir="ltr">${esc(where)}</span></p>
`;
    renderData(); $('#sAcc').onclick = () => LP.openAccount();
    $('#sTG').onchange = async (e) => { prof.teacherG = e.target.value; await api.setSettings({ teacherG: prof.teacherG }); if (LP.applyGender) await LP.applyGender(); if (LP.refreshWelcome) LP.refreshWelcome(); renderMe(); };
    $('#sSaveMe').onclick = async () => {
      const r = await api.updateMe(u.cloud ? { name: $('#sName').value } : { name: $('#sName').value, email: $('#sEmail').value });
      if (r.ok) { msg($('#mMe'), T('تم الحفظ ✓'), true); st = await api.authState(); LP.auth = st; $('#meName').textContent = st.user.name; }
      else msg($('#mMe'), errText(r));
    };
    $('#sPin').onclick = async () => {
      if ($('#sNew').value !== $('#sNew2').value) return msg($('#mPin'), T(ERR.match));
      const r = await api.changePin($('#sOld').value, $('#sNew').value);
      if (r.ok) { msg($('#mPin'), T('تم تغيير الرمز ✓'), true); ['#sOld', '#sNew', '#sNew2'].forEach(s => $(s).value = ''); }
      else msg($('#mPin'), errText(r));
    };
    $('#sPersonal').onchange = async (e) => { st.personal = await api.setPersonal(e.target.checked); };
    renderCloud();
    $('#sSignout').onclick = async () => {
      await api.signOutAccounts();
      msg($('#mOut'), T('تم الخروج من حساباتك على هذا الجهاز ✓'), true);
    };
  }


  // ---------- الحساب السحابي (داخل «حسابي») ----------
  async function renderCloud(form) {
    const box = $('#sCloud'); if (!box) return;
    const cs = await api.cloudState(); const u = st.user;
    if (!cs.configured || !u || u.guest) { box.style.display = 'none'; return; }
    box.style.display = '';
    const E = (r) => window.LPcloudErr ? window.LPcloudErr(r) : T('تعذّر الاتصال');
    const pw = (id, ph) => `<input class="sinput ltr" type="password" id="${id}" maxlength="64" placeholder="${T(ph)}">`;
    let h = `<h3>☁ ${T('الحساب السحابي')}</h3>`;
    if (!cs.linked) {
      h += `<p><span class="stat no">○ ${T('غير مربوط')}</span> — ${T('بياناتكِ على هذا الجهاز فقط. اربطي حسابكِ لتجدي بياناتكِ على كل أجهزتكِ.')}</p>`;
      if (!form) h += `<div class="srow"><button class="pbtn accent" id="cNew">＋ ${T('إنشاء حساب سحابي')}</button><button class="pbtn" id="cHave">${T('لديّ حساب سحابي')}</button>${cs.googleReady ? `<button class="pbtn" id="cG">G ${T('ربط بحساب Google')}</button>` : ''}</div>`;
      else h += `<div class="srow"><label class="l">${T('البريد الإلكتروني')}</label><input class="sinput ltr" id="cEm" value="${esc(u.email || '')}"></div>
        <div class="srow"><label class="l">${T('كلمة المرور')}</label>${pw('cPw', form === 'new' ? '6 أحرف أو أكثر' : '')}</div>
        ${form === 'new' ? `<div class="srow"><label class="l">${T('إعادة كتابة كلمة المرور')}</label>${pw('cPw2', '')}</div>` : ''}
        <p class="muted" style="font-size:12.5px">${T('بعد الربط تصبح كلمة المرور هذه هي رمز دخولكِ على هذا الجهاز أيضاً، وتبقى كل دروسكِ وبياناتكِ كما هي.')}</p>
        <div class="srow"><button class="pbtn accent" id="cGo">${T(form === 'new' ? 'إنشاء وربط' : 'ربط')}</button><button class="pbtn" id="cBack">${T('إلغاء')}</button><span class="smsg" id="cMsg"></span></div>`;
    } else if (cs.connected) {
      const sy = cs.sync || {};
      const tm = sy.lastSync ? new Date(sy.lastSync).toLocaleTimeString(I18N.lang === 'ar' ? 'ar-SA' : I18N.lang, { hour: 'numeric', minute: '2-digit' }) : '—';
      h += `<p><span class="stat ok">● ${T('متصل')}</span> <span dir="ltr">${esc(cs.email)}</span>${cs.realtime ? ` <span class="muted" style="font-size:12.5px">· ⚡ ${T('التحديث فوري')}</span>` : ''}</p>
        <p class="muted">↻ ${sy.syncing ? T('جارٍ المزامنة…') : T('آخر مزامنة: {t}', { t: tm })}${sy.pending ? ' · ' + T('{n} تعديلات بانتظار الرفع', { n: sy.pending }) : ''}
          <button class="pbtn" id="cSync" style="margin-inline-start:8px">${T('مزامنة الآن')}</button></p>`;
      if (!cs.verified && !cs.google) h += `<p class="muted">${T('لم يُؤكَّد البريد بعد: افتحي رسالة التأكيد في بريدكِ.')}</p>
        <div class="srow"><button class="pbtn" id="cVer">${T('إعادة إرسال رسالة التأكيد')}</button><button class="pbtn" id="cRef">↻ ${T('تحقّق')}</button><span class="smsg" id="cMsg"></span></div>`;
    } else {
      const why = cs.err === 'net' || !cs.err ? T('لا يوجد اتصال بالإنترنت الآن. يتصل تلقائياً عند عودته، وكل شيء محفوظ على الجهاز.')
        : cs.err === 'cwrong' ? T('تغيّرت كلمة المرور من جهاز آخر. اكتبي كلمة المرور الجديدة.') : E({ err: cs.err });
      h += `<p><span class="stat off">● ${T('غير متصل')}</span> <span dir="ltr">${esc(cs.email || '')}</span></p><p class="muted">${why}</p>`;
      if (cs.sync && cs.sync.pending) h += `<p class="muted">${T('{n} تعديلات بانتظار الرفع', { n: cs.sync.pending })}</p>`;
      if (cs.google) h += `<div class="srow"><button class="pbtn accent" id="cCon">G ${T('اتصال بحساب Google')}</button><span class="smsg" id="cMsg"></span></div>`;
      else if (!cs.havePw || cs.err === 'cwrong') h += `<div class="srow">${pw('cPw', 'كلمة المرور')}<button class="pbtn accent" id="cCon">${T('اتصال')}</button><span class="smsg" id="cMsg"></span></div>`;
    }
    if (cs.linked) {
      if (window.LP_WEB) h += `<p class="muted" style="font-size:12.5px">🔒 ${T('لا تبقى بياناتكِ على هذه الشاشة بعد الخروج أو إغلاق المتصفح، ونسختها محفوظة في السحابة.')}</p>
        <div class="srow"><label class="l">${T('الخروج التلقائي بعد عدم الاستخدام')}</label>
          <select id="sWebIdle">${[5, 10, 15, 20, 30, 45, 60, 0].map(m => `<option value="${m}" ${m === (prof.webIdleMin ?? 10) ? 'selected' : ''}>${m ? T('{n} دقيقة', { n: m }) : T('لا يخرج تلقائياً')}</option>`).join('')}</select></div>`;
      else h += `<p class="muted" style="font-size:12.5px">🔒 ${T('بياناتكِ على هذا الجهاز محفوظة مشفّرة، ولا تُفتح إلا بكلمة مروركِ.')}</p>`;
      if (!window.LP_WEB) h += `<div id="sVault"></div>`;
      if (!st.personal && !window.LP_WEB) h += `<div class="srow"><label class="l">${T('عند الخروج من هذا الجهاز')}</label><select id="cOut">
        <option value="">${T('اسأليني كل مرة')}</option><option value="keep">${T('احتفظي ببياناتي مشفّرة')}</option><option value="wipe">${T('امسحي بياناتي')}</option></select></div>`;
    }
    box.innerHTML = h;
    renderVault();
    const sel = $('#cOut'); if (sel) { sel.value = st.logoutChoice || ''; sel.onchange = async () => { await api.logoutChoice(sel.value); st.logoutChoice = sel.value || null; }; }
    box.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => e.stopPropagation()));
    const on = (id, fn) => { const b = $('#' + id); if (b) b.onclick = fn; };
    const run = async (b, p) => { b.disabled = true; const t = b.textContent; b.textContent = T('جارٍ الاتصال…'); const r = await p; b.disabled = false; b.textContent = t; return r; };
    on('cNew', () => renderCloud('new')); on('cHave', () => renderCloud('have')); on('cBack', () => renderCloud());
    on('cG', async () => { const r = await run($('#cG'), api.cloudLink({ mode: 'google' })); if (r.ok) done(); else LP.toast(E(r)); });
    on('cGo', async () => {
      const em = $('#cEm').value.trim(), p = $('#cPw').value;
      if (form === 'new' && p !== $('#cPw2').value) return msg($('#cMsg'), T('كلمتا المرور غير متطابقتين.'));
      const r = await run($('#cGo'), api.cloudLink({ mode: form, email: em, password: p }));
      if (r.ok) done(); else msg($('#cMsg'), E(r));
    });
    on('cVer', async () => { const r = await api.cloudVerify(); msg($('#cMsg'), r.ok ? T('أُرسلت الرسالة ✓') : E(r), r.ok); });
    on('cRef', async () => { await api.cloudRefresh(); renderCloud(); });
    { const wi = document.getElementById('sWebIdle'); if (wi) wi.onchange = () => { prof.webIdleMin = +wi.value; api.setSettings({ webIdleMin: +wi.value }); }; }
    on('cSync', async () => { const b = $('#cSync'); b.disabled = true; await api.cloudSync(); renderCloud(); });
    on('cCon', async () => { const r = await run($('#cCon'), api.cloudConnect($('#cPw') ? $('#cPw').value : '')); if (r.ok) renderCloud(); else msg($('#cMsg'), E(r)); });
    async function done() { st = await api.authState(); LP.auth = st; LP.toast('☁ ' + T('تم ربط الحساب بالسحابة ✓')); renderMe(); }
  }
  let rcT; api.onCloudState(() => { clearTimeout(rcT); rcT = setTimeout(() => { if (panel.classList.contains('on') && tab === 'me' && !($('#sCloud') && $('#sCloud').querySelector('input:focus,select:focus'))) renderCloud(); }, 300); });
  // تذكير لطيف بعد الدخول: حساب غير مربوط والجهاز متصل بالإنترنت
  document.addEventListener('lp-auth', (e) => {
    const d = e.detail; if (!d || !d.user || d.user.guest || !d.cloud || !d.cloud.configured || d.cloud.linked) return;
    let seen = false; try { seen = sessionStorage.getItem('lpCloudAsk') === d.user.id; } catch {}
    if (seen || !navigator.onLine) return;
    try { sessionStorage.setItem('lpCloudAsk', d.user.id); } catch {}
    setTimeout(() => LP.toast(T('ربط الحساب بالسحابة يحفظ البيانات على كل الأجهزة'), T('ربط'), () => LP.openSettings('me'), 9000), 2500);
  });



  // ---------- نسخة من بياناتي: تصدير واستيراد (لأي حساب) ----------
  const PART_NAMES = [['classes', 'الفصول وأسماء الطلاب'], ['library', 'مكتبتي (الدروس وعناوينها وأهدافها)'], ['points', 'النقاط والنتائج والمجموعات'], ['settings', 'الإعدادات والألوان والشهادات']];
  function renderData(stage, info) {
    const box = $('#sData'); if (!box) return;
    const checks = (pfx, only) => PART_NAMES.filter(([k]) => !only || only[k]).map(([k, n]) => `<label class="tog2" style="margin:4px 0"><input type="checkbox" data-${pfx}="${k}" checked><span class="sl"></span><span>${T(n)}</span></label>`).join('');
    if (stage === 'pw') {
      box.innerHTML = `<h3>📥 ${T('استيراد بيانات')}</h3><p>${T('هذا الملف محمي بكلمة مرور.')}</p>
        <div class="srow"><input class="sinput ltr" type="password" id="dPw" placeholder="${T('كلمة مرور الملف')}"><button class="pbtn accent" id="dOpen">${T('فتح')}</button><button class="pbtn" id="dBack">${T('إلغاء')}</button><span class="smsg" id="dMsg"></span></div>`;
      $('#dPw').addEventListener('keydown', e => e.stopPropagation());
      $('#dBack').onclick = () => renderData();
      $('#dOpen').onclick = async () => { const r = await api.dataImportUnlock($('#dPw').value); if (r.ok) renderData('sum', r); else msg($('#dMsg'), T('كلمة المرور غير صحيحة.')); };
      return;
    }
    if (stage === 'sum') {
      const s = info.summary, has = { classes: s.classes > 0, library: s.lessons > 0, points: s.points, settings: s.settings };
      box.innerHTML = `<h3>📥 ${T('استيراد بيانات')}</h3>
        <p>${T('في الملف:')} <b>${T('{c} فصول، {s} طالباً، {l} درساً', { c: s.classes, s: s.students, l: s.lessons })}</b>${info.from ? ' — ' + T('من حساب: {n}', { n: esc(info.from) }) : ''}</p>
        ${checks('ip', has)}
        <div class="srow" style="margin-top:8px"><label class="l">${T('طريقة الاستيراد')}</label>
          <select id="dMode"><option value="merge">${T('دمج: إضافة الجديد دون حذف شيء')}</option><option value="replace">${T('استبدال: يحل الملف محل بياناتي الحالية')}</option></select></div>
        <div class="srow"><button class="pbtn accent" id="dApply">${T('استيراد')}</button><button class="pbtn" id="dBack">${T('إلغاء')}</button><span class="smsg" id="dMsg"></span></div>`;
      $('#dBack').onclick = () => renderData();
      $('#dApply').onclick = async () => {
        const parts = [...box.querySelectorAll('[data-ip]')].filter(x => x.checked).map(x => x.dataset.ip);
        if (!parts.length) return;
        const r = await api.dataImportApply({ mode: $('#dMode').value, parts });
        if (!r.ok) return msg($('#dMsg'), T('تعذّر الاستيراد.'));
        LP.toast('✓ ' + T('تم الاستيراد'), null, null, 2500);
        setTimeout(() => api.authReload(), 900);
      };
      return;
    }
    box.innerHTML = `<h3>💾 ${T('نسخة من بياناتي')}</h3>
      <p class="muted" style="font-size:12.5px;margin:-4px 0 8px">${T('ملف تحفظينه على فلاشة أو أي مكان، ويُستورد في أي حساب على أي جهاز. ملفات العروض وPDF نفسها لا تدخل فيه، بل عناوينها وأماكنها.')}</p>
      ${checks('ex')}
      <div class="srow" style="margin-top:6px"><label class="l">${T('كلمة مرور للملف (اختياري، مُستحسن لأن فيه أسماء الطلاب)')}</label><input class="sinput ltr" type="password" id="dXpw" maxlength="64"></div>
      <div class="srow"><button class="pbtn accent" id="dExp">📤 ${T('تصدير بياناتي')}</button><button class="pbtn" id="dImp">📥 ${T('استيراد من ملف')}</button><span class="smsg" id="dMsg"></span></div>`;
    $('#dXpw').addEventListener('keydown', e => e.stopPropagation());
    $('#dExp').onclick = async () => {
      const parts = [...box.querySelectorAll('[data-ex]')].filter(x => x.checked).map(x => x.dataset.ex);
      if (!parts.length) return;
      const r = await api.dataExport({ parts, password: $('#dXpw').value || undefined });
      if (r.ok) msg($('#dMsg'), T('تم الحفظ ✓'), true); else if (!r.canceled) msg($('#dMsg'), T('تعذّر الحفظ.'));
    };
    $('#dImp').onclick = async () => {
      const r = await api.dataImportRead();
      if (r.canceled) return;
      if (!r.ok) return msg($('#dMsg'), T('هذا ليس ملف بيانات عارض الدروس.'));
      renderData(r.needPw ? 'pw' : 'sum', r);
    };
  }

  // ---------- خزنة الحسابات (مايكروسوفت وقوقل) ----------
  async function renderVault() {
    const box = $('#sVault'); if (!box) return;
    const v = await api.vaultState();
    const SN = { microsoft: 'Microsoft', google: 'Google' };
    box.innerHTML = `<h3 style="margin-top:14px">🔐 ${T('خزنة الحسابات')}</h3>
      <label class="tog2"><input type="checkbox" id="vOn" ${v.enabled ? 'checked' : ''}><span class="sl"></span>
        <span>${T('انقلي دخولاتي إلى مايكروسوفت وقوقل معي إلى كل الأجهزة')}</span></label>
      <p class="muted" style="font-size:12.5px;margin:6px 0">${T('مشفّرة من طرف إلى طرف: لا يقرؤها أحد غيركِ. تُحفظ تلقائياً، وتُعاد عند دخولكِ على أي جهاز.')}</p>
      ${!v.ready ? `<p class="muted" style="font-size:12.5px">${T('تُفتح الخزنة عند دخولكِ بكلمة المرور أو بالجوال.')}</p>` : ''}
      ${v.items.length ? `<div class="vlist">${v.items.map(i => `<div class="srow"><span>🔑 ${esc(SN[i.site] || i.site)} — <span dir="ltr">${esc(i.user)}</span></span><button class="pbtn" data-vs="${esc(i.site)}" data-vu="${esc(i.user)}">✕ ${T('حذف')}</button></div>`).join('')}</div>`
        : `<p class="muted" style="font-size:12.5px">${T('لا توجد كلمات مرور محفوظة. عند دخولكِ إلى مايكروسوفت أو قوقل داخل البرنامج يسألكِ هل تحفظينها.')}</p>`}
      ${v.ready ? `<div class="srow"><button class="pbtn" id="vNow">↻ ${T('حفظ دخولاتي الآن')}</button><button class="pbtn" id="vWipe">🗑 ${T('مسح الخزنة من السحابة')}</button><span class="smsg" id="vMsg"></span></div>` : ''}`;
    $('#vOn').onchange = async (e) => { await api.setSettings({ vaultOn: e.target.checked }); };
    box.querySelectorAll('[data-vs]').forEach(b => b.onclick = async () => { await api.vaultForget(b.dataset.vs, b.dataset.vu); renderVault(); });
    if ($('#vNow')) $('#vNow').onclick = async () => { await api.vaultSaveNow(); msg($('#vMsg'), T('تم الحفظ ✓'), true); };
    if ($('#vWipe')) LP.sureBtn ? LP.sureBtn($('#vWipe'), async () => { await api.vaultWipe(); renderVault(); }) : null;
  }
  api.onVaultOffer((o) => {
    const SN = { microsoft: 'Microsoft', google: 'Google' };
    LP.toast(T('حفظ دخول {s} ({u}) في خزنتكِ؟', { s: SN[o.site] || o.site, u: o.user }), T('حفظ'), async () => { if (await api.vaultAccept(o.id)) LP.toast('🔐 ' + T('حُفظ في الخزنة ✓')); }, 15000);
  });

  // ---------- المظهر ----------
  function renderLook() {
    const th = { ...DEFAULT, ...(prof.theme || {}) };
    const pct = Math.round((1 - th.alpha) * 100);
    const lay = prof.layout || 'dock', side = prof.dockSide || 'auto', dw = prof.dockW || 'normal';
    body.innerHTML = `
      <div class="sgroup"><h3>${T('طريقة عرض الأدوات')}</h3>
        <label class="impT"><input type="radio" name="sLay" value="dock" ${lay !== 'float' ? 'checked' : ''}><span>${T('ثابتة في عمود جانبي — الدرس يتحجّم في المساحة الباقية (موصى به)')}</span></label>
        <label class="impT"><input type="radio" name="sLay" value="float" ${lay === 'float' ? 'checked' : ''}><span>${T('عائمة فوق الدرس، تُسحب إلى أي مكان')}</span></label>
        <div class="srow" ${lay === 'float' ? 'style="display:none"' : ''}><label class="l">${T('جهة العمود')}</label>
          <select id="sSide"><option value="auto" ${side === 'auto' ? 'selected' : ''}>${T('تلقائي حسب اللغة (يمين في العربية)')}</option><option value="right" ${side === 'right' ? 'selected' : ''}>${T('يمين')}</option><option value="left" ${side === 'left' ? 'selected' : ''}>${T('يسار')}</option></select>
          <label class="l">${T('العرض')}</label>
          <select id="sDockW"><option value="normal" ${dw !== 'wide' ? 'selected' : ''}>${T('عادي')}</option><option value="wide" ${dw === 'wide' ? 'selected' : ''}>${T('عريض')}</option></select></div>
        <p class="ghint" style="color:var(--muted);margin:4px 0 0" ${lay === 'float' ? 'hidden' : ''}>${T('لتصغير العمود: اسحبي حافته نحو الجهة الأخرى، فتصغر الساعة والعجلة معه. ضغطتان على الحافة تعيدانه للحجم الكامل.')}</p>
      </div>
      <div class="sgroup"><h3>${T('الساعة والعجلة والشريط')}</h3>
        <div class="srow"><label class="l">${T('شكل الساعة')}</label>
          <select id="sClock">${[['ring', 'دائرية'], ['digital', 'رقمية'], ['bar', 'شريط']].map(([v, l]) => `<option value="${v}" ${(prof.clockStyle || 'ring') === v ? 'selected' : ''}>${T(l)}</option>`).join('')}</select>
          <label class="l">${T('لغة العجلة')}</label>
          <select id="sWl">${[['', 'نفس لغة البرنامج'], ['ar', 'العربية'], ['en', 'English'], ['fr', 'Français']].map(([v, l]) => `<option value="${v}" ${(prof.wheelLang || '') === v ? 'selected' : ''}>${v ? l : T(l)}</option>`).join('')}</select></div>
 <label class="chk"><input type="checkbox" id="sZoomCtl" ${prof.zoomCtl !== false ? 'checked' : ''}> ${T('زر «＋ 100% −» لتكبير الدرس نفسه (صفحات الويب)')}</label>
        <div class="srow"><label class="l">${T('اختيار الطالبة في العجلة')}</label>
          <select id="sFair"><option value="all" ${(prof.wheelFair || 'all') === 'all' ? 'selected' : ''}>${T('لا تكرار حتى يشارك الجميع')}</option><option value="groups" ${prof.wheelFair === 'groups' ? 'selected' : ''}>${T('أولوية المجموعات: دور متساوٍ لكل مجموعة حتى لو تكررت طالبة')}</option></select></div>
        <label class="chk"><input type="checkbox" id="sWPop" ${prof.wheelPop !== false ? 'checked' : ''}> ${T('العجلة تكبر في وسط الشاشة أثناء الدوران، وتعود بعد ظهور الاسم بثانيتين')}</label>
        <label class="chk"><input type="checkbox" id="sCheers" ${prof.wheelCheers !== false ? 'checked' : ''}> ${T('عبارات تشجيعية في العجلة عند منح النقاط (بلغة العجلة)')}</label>
        <div class="srow"><label class="l">${T('شريط المجموعات')}</label>
          <select id="sRows"><option value="2" ${prof.gbRows !== 1 ? 'selected' : ''}>${T('سطران: الدرس والأدوات + المجموعات')}</option><option value="1" ${prof.gbRows === 1 ? 'selected' : ''}>${T('سطر واحد: المجموعات فقط')}</option></select></div>
      </div>
      <div class="sgroup"><h3>${T('اللون الأساسي ٢ (فاتح: الخلفيات والشريط)')}</h3>
        <div class="swatches" style="margin-bottom:22px">
          ${PRESETS.map(p => `<div class="swatch ${p.bar === th.bar ? 'on' : ''}" data-bar="${p.bar}" data-acc="${p.accent || ''}" style="background:${p.bar}">${p.accent ? `<i style="background:${p.accent}"></i>` : ''}<small>${T(p.name)}</small></div>`).join('')}
          <label class="colorPick" title="${T('لون من اختيارك')}"><input type="color" id="sBarPick" value="${th.bar}"></label>
        </div>
      </div>
      <div class="sgroup"><h3>${T('اللون الأساسي ١ (الأزرار والعناوين)')}</h3>
        <p class="ghint" style="color:var(--muted);margin:-4px 0 10px">${T('يظهر على الأزرار والأداة المختارة والتبويب المفتوح والعناوين.')}</p>
        <div class="swatches">${ACCENTS.map(a => `<div class="acc ${a === th.accent ? 'on' : ''}" data-acc="${a}" style="background:${a}"></div>`).join('')}
          <label class="colorPick" style="width:30px;height:30px;border-radius:50%"><input type="color" id="sAccPick" value="${th.accent}"></label></div>
      </div>
      <div class="sgroup"><label class="chk"><input type="checkbox" id="sDarkBars" ${th.darkBars ? 'checked' : ''}> ${T('الشريطان العلوي والسفلي داكنان، والبطاقات واللوحات فاتحة')}</label></div>
      <div class="sgroup"><h3>${T('شفافية الشريط')}</h3>
        <div class="srow"><input type="range" id="sAlpha" min="0" max="70" value="${pct}"><span id="sAlphaV">${pct}%</span></div>
        <p class="ghint" style="color:var(--muted);margin:0">${T('الشفافية تعطي الشريط مظهراً زجاجياً فقط، والدرس لا يمتد تحته أبداً. 0% = لون كامل.')}</p>
        <div class="preview"><div class="pv" style="background:${th.bar};opacity:${th.alpha}"></div>
          <span class="pi" style="background:${th.accent};color:#fff">✎</span></div>
      </div>
      <button class="pbtn" id="sReset">${T('رجوع إلى الألوان الأصلية')}</button>`;
    const save = (patch) => {
      const nt = { ...th, ...patch };
      Object.assign(th, nt);
      prof.theme = nt; applyTheme(nt);
      api.setSettings({ theme: nt });
      renderLook();
    };
    body.querySelectorAll('.swatch').forEach(s => s.onclick = () => save(s.dataset.acc ? { bar: s.dataset.bar, accent: s.dataset.acc } : { bar: s.dataset.bar }));
    body.querySelectorAll('.acc').forEach(s => s.onclick = () => save({ accent: s.dataset.acc }));
    $('#sBarPick').onchange = (e) => save({ bar: e.target.value });
    $('#sAccPick').onchange = (e) => save({ accent: e.target.value });
    $('#sAlpha').oninput = (e) => {
      const a = 1 - e.target.value / 100;
      $('#sAlphaV').textContent = e.target.value + '%';
      body.querySelector('.pv').style.opacity = a;
      applyTheme({ ...th, alpha: a });
    };
    $('#sAlpha').onchange = (e) => save({ alpha: 1 - e.target.value / 100 });
    $('#sReset').onclick = () => save({ ...DEFAULT });
    $('#sDarkBars').onchange = (e) => save({ darkBars: e.target.checked });
    const lp = async (patch) => { Object.assign(prof, patch); await api.setSettings(patch); if (LP.applyLayout) LP.applyLayout(await api.getSettings()); renderLook(); };
    body.querySelectorAll('input[name=sLay]').forEach(r => r.onchange = () => lp({ layout: r.value }));
    $('#sSide').onchange = (e) => lp({ dockSide: e.target.value });
    $('#sDockW').onchange = (e) => lp({ dockW: e.target.value });
    const gp = async (patch) => { Object.assign(prof, patch); await api.setSettings(patch); LP.setWheelPref && LP.setWheelPref(patch); };
    $('#sClock').onchange = (e) => { gp({ clockStyle: e.target.value }); LP.applyClockStyle && LP.applyClockStyle(e.target.value); };
    $('#sWl').onchange = (e) => gp({ wheelLang: e.target.value || null });
    $('#sZoomCtl').onchange = (e) => { gp({ zoomCtl: e.target.checked }); LP.setZoomCtl && LP.setZoomCtl(e.target.checked); };
    $('#sWPop').onchange = (e) => gp({ wheelPop: e.target.checked });
    $('#sFair').onchange = (e) => gp({ wheelFair: e.target.value });
    $('#sCheers').onchange = (e) => gp({ wheelCheers: e.target.checked });
    $('#sRows').onchange = (e) => gp({ gbRows: +e.target.value });
  }

  // ---------- العروض (باوربوينت) ----------
  let pptEmbedOn = true;
  api.pptEmbed().then(v => { pptEmbedOn = v !== false; });
  function renderPpt() {
    const mode = prof.pptMedia || 'protect', folders = prof.pptFolders || [];
    const opt = (v, t, d) => `<label class="pmode ${mode === v ? 'on' : ''}"><input type="radio" name="pptMedia" value="${v}" ${mode === v ? 'checked' : ''}><span><b>${T(t)}</b><small>${T(d)}</small></span></label>`;
    body.innerHTML = `
      <div class="sgroup"><h3>${T('طريقة عرض باوربوينت')}</h3>
        <label class="pmode ${pptEmbedOn ? 'on' : ''}"><input type="radio" name="pptWay" value="1" ${pptEmbedOn ? 'checked' : ''}><span><b>${T('باوربوينت الحقيقي داخل البرنامج (الأفضل)')}</b><small>${T('تعمل الحركات والفيديو والأسئلة التفاعلية، وأدوات البرنامج فوقه.')}</small></span></label>
        <label class="pmode ${!pptEmbedOn ? 'on' : ''}"><input type="radio" name="pptWay" value="0" ${!pptEmbedOn ? 'checked' : ''}><span><b>${T('الشرائح كصور')}</b><small>${T('أخف على الجهاز، بدون حركات أو فيديو. استخدميه إذا ظهرت مشكلة في الطريقة الأولى.')}</small></span></label>
        <p class="smsg ok" id="pWayMsg"></p>
        <div ${pptEmbedOn ? '' : 'hidden'} style="margin-top:8px">
          <label class="pmode ${(prof.pptMode || 'full') === 'full' ? 'on' : ''}"><input type="radio" name="pptMode" value="full" ${(prof.pptMode || 'full') === 'full' ? 'checked' : ''}><span><b>${T('بملء الشاشة (الأسرع)')}</b><small>${T('باوربوينت يعرض بملء الشاشة بسرعته الطبيعية، وأشرطة البرنامج والساعة والعجلة عائمة فوقه. القلم يستخدم قلم باوربوينت نفسه.')}</small></span></label>
          <label class="pmode ${prof.pptMode === 'inside' ? 'on' : ''}"><input type="radio" name="pptMode" value="inside" ${prof.pptMode === 'inside' ? 'checked' : ''}><span><b>${T('داخل منطقة الدرس')}</b><small>${T('العرض بين أشرطة البرنامج كما كان. قد يكون أبطأ على بعض الأجهزة.')}</small></span></label>
          <label class="chk" ${(prof.pptMode || 'full') === 'full' ? '' : 'hidden'}><input type="checkbox" id="pAuto" ${prof.fsAuto ? 'checked' : ''}> ${T('إخفاء الأشرطة والعمود تلقائياً، وإظهارها عند تحريك الفأرة')}</label>
          <label class="chk" ${prof.pptMode === 'inside' ? '' : 'hidden'}><input type="checkbox" id="pFrame" ${prof.pptFrame !== false ? 'checked' : ''}> <span><b>${T('وضع الإطار (أسرع)')}</b> — ${T('لا يغطي البرنامج الشريحة أثناء العرض؛ يعود الغطاء تلقائياً عند اختيار القلم أو الأدوات.')}</span></label>
        </div>
      </div>
      <div class="sgroup"><h3>${T('رسالة «Security Alert» في العروض')}</h3>
        <p class="ghint" style="color:var(--muted);margin:-4px 0 10px">${T('تظهر عندما يكون في العرض فيديو أو صوت مرتبط بملف خارجي. البرنامج يجيب عليها بنفسه حسب اختياركِ.')}</p>
        ${opt('protect', 'محمي دائماً (الأكثر أماناً)', 'يضغط البرنامج OK مع بقاء الحماية. الفيديو المرتبط بملف خارجي لا يعمل.')}
        ${opt('folders', 'تشغيل تلقائي لعروض مجلداتي فقط', 'العروض داخل المجلدات التي تختارينها تعمل وسائطها، والباقي محمي.')}
        ${mode === 'folders' ? `<div class="pfolders">${folders.map((f, i) => `<div><span dir="ltr">${esc(f)}</span><button data-rm="${i}" title="${T('حذف')}">✕</button></div>`).join('') || `<small class="muted">${T('لم تختاري مجلداً بعد.')}</small>`}
          <button class="pbtn" id="pAddFolder">＋ ${T('إضافة مجلد')}</button></div>` : ''}
        ${opt('all', 'تشغيل تلقائي لكل العروض', 'يختار البرنامج «Enable external content» لكل عرض. استخدميه فقط إن كانت كل عروضكِ من مصادر تثقين بها.')}
        <p class="smsg" id="pMsg"></p>
      </div>`;
    body.querySelectorAll('input[name=pptWay]').forEach(r => r.onchange = async () => {
      pptEmbedOn = r.value === '1'; await api.pptSetEmbed(pptEmbedOn); renderPpt();
      $('#pWayMsg').textContent = T('يُطبَّق بعد إغلاق البرنامج وفتحه من جديد.');
    });
    body.querySelectorAll('input[name=pptMode]').forEach(r => r.onchange = async () => { prof.pptMode = r.value; await api.setSettings({ pptMode: r.value }); LP_full && LP_full.set(r.value); renderPpt(); });
    const pa = $('#pAuto'); if (pa) pa.onchange = async () => { prof.fsAuto = pa.checked; await api.setSettings({ fsAuto: pa.checked }); LP_full && LP_full.set(null, pa.checked); };
    const pf = $('#pFrame'); if (pf) pf.onchange = async () => { prof.pptFrame = pf.checked; await api.setSettings({ pptFrame: pf.checked }); LP_frame && LP_frame.set(pf.checked); if (LP.applyLayout) LP.applyLayout(await api.getSettings()); };
    body.querySelectorAll('input[name=pptMedia]').forEach(r => r.onchange = async () => {
      const v = r.value;
      if (v === 'all' && !confirmAll()) { renderPpt(); return; }
      prof.pptMedia = v; await api.setSettings({ pptMedia: v }); renderPpt();
    });
    body.querySelectorAll('[data-rm]').forEach(b => b.onclick = async () => { folders.splice(+b.dataset.rm, 1); prof.pptFolders = folders; await api.setSettings({ pptFolders: folders }); renderPpt(); });
    const add = $('#pAddFolder');
    if (add) add.onclick = async () => { const d = await api.pickFolder(); if (d && !folders.includes(d)) { folders.push(d); prof.pptFolders = folders; await api.setSettings({ pptFolders: folders }); renderPpt(); } };
  }
  function confirmAll() {
    return window.confirm(T('تشغيل الوسائط المرتبطة لكل العروض يسمح لأي عرض بتحميل ملفات من خارجه. إذا فتحتِ عرضاً من مصدر غير موثوق قد يحمّل ملفاً ضاراً. هل تريدين التفعيل؟'));
  }

  // ---------- اللغة ----------
  function renderLang() {
    const L = [['ar', 'العربية'], ['en', 'English'], ['fr', 'Français']];
    body.innerHTML = `<div class="sgroup"><h3>${T('لغة البرنامج')}</h3>
      <div class="langs">${L.map(([k, n]) => `<button class="langbtn ${I18N.lang === k ? 'on' : ''}" data-l="${k}">${n}</button>`).join('')}</div>
      <p class="ghint" style="color:var(--muted);margin:12px 0 0">${T('اللغة محفوظة لكل معلمة في حسابها.')}</p></div>`;
    body.querySelectorAll('.langbtn').forEach(b => b.onclick = () => { if (b.dataset.l !== I18N.lang) api.setLang(b.dataset.l); });
  }

  // ---------- المديرة ----------
  async function renderAdmin() {
    const users = await api.adminUsers();
    const idle = st.idleMin || 10;
    body.innerHTML = `
      <div class="sgroup"><h3>${T('المستخدمون')}</h3><div class="ulist" id="uList"></div></div>
      <div class="sgroup"><h3>${T('القفل بعد عدم الاستخدام')}</h3>
        <div class="srow"><label class="l">${T('قفل حسابات مايكروسوفت وGoogle بعد')}</label>
          <select id="sIdle">${[5, 10, 15, 30, 60].map(m => `<option value="${m}" ${m === idle ? 'selected' : ''}>${T('{n} دقيقة', { n: m })}</option>`).join('')}</select></div>
        <div class="srow"><label class="l">${T('الخروج التلقائي من الأجهزة المشتركة بعد')}</label>
          <select id="sAutoOut">${[0, 15, 30, 60, 120].map(m => `<option value="${m}" ${m === (st.autoOutMin ?? 30) ? 'selected' : ''}>${m ? T('{n} دقيقة', { n: m }) : T('لا يخرج تلقائياً')}</option>`).join('')}</select></div>
        <p class="ghint" style="color:var(--muted);margin:4px 0 0">${T('لا يشمل «جهازي الشخصي». تبقى بيانات المستخدم مشفّرة على الجهاز بعد الخروج.')}</p>
      </div>

      <div class="sgroup"><h3>${T('النسخ الاحتياطي')}</h3>
        <p class="ghint" style="color:var(--muted);margin:-4px 0 10px">${T('يحفظ نسخة من المستخدمين والدروس والفصول ومكتبة القسم في مكان يُختار.')}</p>
        <div class="srow"><button class="pbtn" id="sBackup">💾 ${T('نسخة احتياطية')}</button><button class="pbtn" id="sRestore">↺ ${T('استعادة نسخة')}</button><span class="smsg" id="mBk"></span></div>
      </div>`;
    const list = $('#uList');
    for (const u of users) {
      const row = document.createElement('div'); row.className = 'urow';
      row.innerHTML = `${LPavatar(u.name)}<div class="ui"><b>${esc(u.name)} ${u.me ? `<span class="muted" style="font-weight:400">(${T('أنت')})</span>` : ''}</b><small>${esc(u.email)}${u.cloud ? ` · ☁ ${T('حساب سحابي')}` : ''}</small></div>
        ${u.admin ? `<span class="badge">👑 ${T('مدير الجهاز')}</span>` : ''}
        <span class="acts" style="display:flex;gap:6px;flex-wrap:wrap"></span><span class="smsg"></span>`;
      const acts = row.querySelector('.acts'), m = row.querySelector('.smsg');
      const b = (text, fn) => { const x = document.createElement('button'); x.className = 'pbtn'; x.textContent = text; x.onclick = () => fn(x); acts.appendChild(x); return x; };
      if (u.cloud && !u.me) b('🔑 ' + T('إعادة تعيين الرمز'), () => msg(m, T('حساب سحابي: لا يمكن تغيير كلمة مروره من هنا. يسترجعها صاحبه من «نسيت كلمة المرور» عبر بريده.')));
      else if (!u.cloud) b('🔑 ' + T('إعادة تعيين الرمز'), () => {
        acts.innerHTML = `<input class="sinput pin" type="password" inputmode="numeric" placeholder="${T('رمز جديد')}"><button class="pbtn accent">${T('حفظ')}</button><button class="pbtn">${T('إلغاء')}</button>`;
        const [inp, ok, cancel] = acts.children; inp.focus();
        inp.addEventListener('keydown', e => e.stopPropagation());
        cancel.onclick = renderAdmin;
        ok.onclick = async () => {
          const r = await api.adminResetPin(u.id, inp.value);
          if (r.ok) { msg(m, u.me ? T('تم ✓') : T('تم ✓ — وخرج المستخدم من حساباته في مايكروسوفت وGoogle لحماية خصوصيته.'), true); setTimeout(renderAdmin, 3500); }
          else msg(m, errText(r));
        };
      });
      if (!u.me) {
        b(u.admin ? T('إلغاء صلاحية المدير') : '👑 ' + T('جعله مديراً'), async () => { await api.adminSetAdmin(u.id, !u.admin); renderAdmin(); });
        b('🗑 ' + T('حذف'), async (x) => {
          if (!x.dataset.sure) { x.dataset.sure = 1; x.textContent = T(u.cloud ? 'متأكدة؟ تُحذف بياناتها من هذا الجهاز فقط، ويبقى حسابها السحابي' : 'متأكدة؟ ستُحذف دروسها وإعداداتها'); x.style.background = 'var(--danger)'; return; }
          await api.adminDelete(u.id); renderAdmin();
        });
      }
      list.appendChild(row);
    }
    $('#sIdle').onchange = async (e) => { st.idleMin = await api.adminIdle(+e.target.value); };
    $('#sAutoOut').onchange = async (e) => { st.autoOutMin = await api.adminAutoOut(+e.target.value); };
    $('#sBackup').onclick = async () => { const r = await api.adminBackup(); if (r) msg($('#mBk'), T('تم الحفظ في:') + ' ' + r, true); else if (r === false) msg($('#mBk'), T('تعذّر الحفظ في هذا المكان.')); };
    $('#sRestore').onclick = async () => { const r = await api.adminRestore(); if (r === false) msg($('#mBk'), T('هذا المجلد ليس نسخة احتياطية صالحة.')); };
    body.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => e.stopPropagation()));
  }

  // ================= البدء =================
  document.addEventListener('lp-auth', async (e) => {
    st = e.detail;
    prof = st.user ? await api.getSettings() : {};
    // من كان على الألوان الداكنة الافتراضية القديمة ينتقل مرة واحدة إلى المظهر الفاتح الجديد
    if (!prof.themeV3) {
      const t = prof.theme;
      if (!t || (t.bar === OLD_DEFAULT.bar && t.accent === OLD_DEFAULT.accent && !prof.themeV2) || (t.bar === PREV_DEFAULT.bar && t.accent === PREV_DEFAULT.accent)) prof.theme = { ...DEFAULT };
      prof.themeV3 = true; api.setSettings({ theme: prof.theme, themeV3: true });
    }
    applyTheme(prof.theme);
  });
})();
