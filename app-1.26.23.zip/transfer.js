// نقل ملكية المدرسة بمصافحة: من «الإعدادات ← حسابي ← مدارسي»، وتوافق المالكة الجديدة بنفسها بعد التحقق من حسابها
(() => {
  const api = window.api;
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const call = async (op, ...a) => { const r = await api.school(op, ...a); if (r && r.err) throw new Error(r.err); return r ? r.v : null; };
  const fail = (e) => LP.toast(T(e && e.message === 'net' ? 'لا يوجد اتصال بالإنترنت' : e && e.message === 'expired' ? 'انتهت مدة طلب النقل أو أُلغي' : e && e.message === 'cdenied' ? 'لا توجد صلاحية لهذا العمل (أو قواعد السحابة لم تُحدَّث بعد).' : 'تعذّر الاتصال بالسحابة، حاولي لاحقاً'), null, null, 5000);
  const days = (at) => Math.max(0, Math.ceil((at + 7 * 864e5 - Date.now()) / 864e5));
  const box = (html) => { const d = document.createElement('div'); d.className = 'gdlg on tr-dlg'; d.innerHTML = `<div class="gdlg-card" style="max-width:480px">${html}</div>`; document.body.appendChild(d); d.addEventListener('keydown', e => e.stopPropagation()); return d; };

  // ---------- قائمة أماكن العمل (تُعرض في شاشة «حسابي ومدارسي») ----------
  const roleLbl = (r) => r === 'owner' ? '👑 ' + T('المالكة') : r === 'teacher' ? T('معلمة') : '🛡 ' + T('دور إداري');
  LP.renderMySchools = async (host, after) => {
    if (!host) return;
    const list = LP.schools ? LP.schools() : [], cur = LP.ctxHome ? LP.ctxHome() : '';
    const rows = [{ sid: '', name: T('شخصي'), role: '' }, ...list];
    host.innerHTML = rows.map(s => `<div class="ms-row ${s.sid === cur ? 'cur' : ''}" data-sid="${esc(s.sid)}"><span class="ctx-dot" style="background:${LP.ctxColor(s.sid)}"></span>
      <span class="ms-nm">${s.sid ? '🏫' : '👤'} <b>${esc(s.name)}</b>${s.sid ? `<small>${roleLbl(s.role)}</small>` : `<small>${T('فصولي ودروسي الخاصة')}</small>`}</span>
      <span class="ms-act">${s.sid ? `<button class="pbtn" data-man>${T(s.role === 'teacher' ? 'تفاصيل' : 'إدارة')}</button>` : ''}
      ${s.sid === cur ? `<span class="ms-cur">✓ ${T('الحالي')}</span>` : `<button class="pbtn accent" data-open>${T('فتح')}</button>`}</span>
      ${s.role === 'owner' ? `<div class="ms-tr"></div>` : ''}</div>`).join('');
    host.querySelectorAll('.ms-row').forEach(async row => {
      const sid = row.dataset.sid;
      const op = row.querySelector('[data-open]'); if (op) op.onclick = async () => { await LP.setCtx(sid); LP.toast('✓ ' + T('مكان العمل الآن: {s}', { s: LP.ctxName(sid) })); LP.renderMySchools(host, after); };
      const mn = row.querySelector('[data-man]'); if (mn) mn.onclick = () => { if (after) after(); LP.openSchool(sid); };
      const tr = row.querySelector('.ms-tr'); if (!tr) return;
      let info = null; try { info = await call('info', sid); } catch { return; }
      if (info.pendingOwner && days(info.pendingAt) > 0) {
        tr.innerHTML = `<span class="ms-pend">⏳ ${T('بانتظار موافقة {w} ({d} أيام)', { w: esc(info.pendingName), d: days(info.pendingAt) })}</span><button class="pbtn" data-cancel>${T('إلغاء الطلب')}</button>`;
        tr.querySelector('[data-cancel]').onclick = async () => { try { await call('cancelTransfer', sid); LP.toast(T('أُلغي طلب نقل الملكية')); LP.renderMySchools(host, after); } catch (e) { fail(e); } };
      } else {
        tr.innerHTML = `<button class="ms-link" data-tr>${T('نقل الملكية…')}</button>`;
        tr.querySelector('[data-tr]').onclick = () => startTransfer(info, () => LP.renderMySchools(host, after));
      }
    });
  };

  // ---------- شاشة «حسابي ومدارسي» الموحّدة ----------
  LP.openAccount = async () => {
    document.querySelectorAll('#acDlg, .ctx-menu, #ctxPick').forEach(x => x.remove());
    if (LP.closePanels) LP.closePanels();
    const st = await api.authState().catch(() => ({})), u = st.user || {};
    const cs = await api.cloudState().catch(() => ({}));
    const d = document.createElement('div'); d.className = 'gdlg on'; d.id = 'acDlg';
    const close = () => d.remove();
    d.addEventListener('click', e => { if (e.target === d) close(); });
    d.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') close(); });
    const list = LP.schools ? LP.schools() : [];
    const own = list.filter(s => s.role === 'owner'), adm = list.filter(s => s.role !== 'owner' && s.role !== 'teacher');
    const cloud = u.guest ? '' : cs.connected ? `<span class="ac-ok">☁ ${T('متصل بالسحابة')}</span>` : cs.linked ? `<span class="ac-warn">☁ ${T('غير متصل الآن')}</span>` : `<span class="ac-warn">☁ ${T('غير مرتبط بالسحابة')}</span>`;
    d.innerHTML = `<div class="gdlg-card ac-card" tabindex="-1">
      <div class="sc-head"><h3>👤 ${T('حسابي ومدارسي')}</h3><span style="flex:1"></span><button class="sc-x" data-x>✕</button></div>
      <div class="ac-me"><div class="ac-av">${esc((u.name || '؟').trim().charAt(0))}</div>
        <div class="ac-id"><b>${esc(u.guest ? T('ضيف') : u.name || '')}</b><span dir="ltr">${esc(u.email || '')}</span>${cloud}</div>
        ${u.guest ? '' : `<button class="pbtn" data-edit>✎ ${T('بياناتي')}</button>`}</div>
      ${own.map(s => `<div class="ac-badge" style="--cc:${LP.ctxColor(s.sid)}">⭐ ${T('حساب إدارة: {s}', { s: esc(s.name) })}</div>`).join('')}
      ${adm.map(s => `<div class="ac-badge" style="--cc:${LP.ctxColor(s.sid)}">🛡 ${T('صلاحيات إدارية في: {s}', { s: esc(s.name) })}</div>`).join('')}
      <h4 class="ac-h">${T('أماكن العمل')}</h4>
      <div class="ms-list" id="acList"></div>
      <div class="ac-foot">${u.guest ? `<p class="tnote">${T('الدخول بحساب يتيح حفظ الفصول والانضمام للمدارس.')}</p>`
        : cs.connected ? `<button class="pri" data-join>＋ ${T('الانضمام لمدرسة أو إنشاء مدرسة')}</button>`
        : `<p class="tnote">☁️ ${T('الانضمام للمدارس يحتاج ربط الحساب بالسحابة.')}</p><button class="pbtn" data-edit>${T('ربط الحساب بالسحابة')}</button>`}
        ${!u.guest && cs.linked ? `<button class="ac-lost" data-lost>📱 ${T('ضاع الجوال؟')}</button>` : ''}</div></div>`;
    document.body.appendChild(d);
    d.querySelectorAll('[data-x]').forEach(b => b.onclick = close);
    d.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { close(); LP.openSettings('me'); });
    const j = d.querySelector('[data-join]'); if (j) j.onclick = () => { close(); LP.openSchoolJoin(); };
    const lo = d.querySelector('[data-lost]'); if (lo) lo.onclick = () => { close(); lostPhone(u.email); };
    if (!u.guest) LP.renderMySchools(d.querySelector('#acList'), close); else d.querySelector('#acList').innerHTML = '';
    d.querySelector('.ac-card').focus();
  };

  // ---------- ضاع الجوال: تغيير كلمة المرور يُخرج الجوال القديم من الحساب ----------
  function lostPhone(email) {
    const d = box(`<h3>📱 ${T('ضاع الجوال')}</h3>
      <p>${T('الحساب والبيانات بأمان: الجوال طريق مختصر للدخول فقط، والدخول متاح دائماً بالبريد وكلمة المرور.')}</p>
      <div class="tr-warn">1. ${T('تغيير كلمة المرور: يصل رابط إلى البريد المسجّل، وبعد التغيير يخرج الجوال القديم من الحساب تلقائياً.')}<br>
        2. ${T('الدخول إلى البرنامج بكلمة المرور الجديدة مرة واحدة على هذا الجهاز، فتعمل كلمات المرور المحفوظة والدخول بالجوال الجديد.')}<br>
        3. ${T('على الجوال الجديد: مسح أي باركود دخول، ثم الدخول بالبريد وكلمة المرور الجديدة مرة واحدة.')}</div>
      <p class="tnote" dir="ltr" style="text-align:center">${esc(email || '')}</p>
      <div class="gdlg-row"><button class="warn" id="lpGo">${T('إرسال رابط تغيير كلمة المرور')}</button><button id="lpNo">${T('إغلاق')}</button></div>`);
    d.querySelector('#lpNo').onclick = () => d.remove();
    d.querySelector('#lpGo').onclick = async (e) => {
      e.target.disabled = true;
      const r = await api.cloudForgot(email).catch(() => ({ ok: false }));
      if (r && r.ok) { LP.toast(T('أُرسل الرابط إلى البريد ✉️')); d.remove(); }
      else { e.target.disabled = false; LP.toast(T('تعذّر الإرسال. يلزم التأكد من الاتصال بالإنترنت.')); }
    };
  }

  // ---------- طلب النقل (المالكة) ----------
  async function startTransfer(info, done) {
    let ms = []; try { ms = (await call('members', info.sid)).filter(m => m.role !== 'owner'); } catch (e) { return fail(e); }
    if (!ms.length) { LP.toast(T('لا توجد عضوات في المدرسة بعد')); return; }
    const d = box(`<h3>⚠️ ${T('نقل ملكية «{s}»', { s: esc(info.name) })}</h3>
      <p>${T('اختاري العضوة التي ستصبح مالكة المدرسة:')}</p>
      <select id="trWho">${ms.map(m => `<option value="${esc(m.id)}">${esc(m.name || m.email)}${m.email ? ' — ' + esc(m.email) : ''}</option>`).join('')}</select>
      <div class="tr-warn">• ${T('لا يتغير شيء الآن: يُرسل طلب، ويجب أن توافق هي بنفسها وتؤكد بكلمة مرور حسابها.')}<br>
        • ${T('بعد موافقتها تصبح هي المالكة بكل الصلاحيات، وتصبحين أنتِ «معلمة».')}<br>
        • ${T('لا يمكن التراجع بعد الموافقة إلا إذا أعادت لكِ الملكية.')}<br>
        • ${T('يُلغى الطلب تلقائياً بعد 7 أيام إن لم توافق.')}</div>
      <label>${T('للتأكيد اكتبي اسم المدرسة:')} <b>${esc(info.name)}</b></label>
      <input id="trName" autocomplete="off">
      <div class="gdlg-row"><button class="warn" id="trGo" disabled>${T('إرسال طلب النقل')}</button><button id="trNo">${T('إلغاء')}</button></div>`);
    const nm = d.querySelector('#trName'), go = d.querySelector('#trGo');
    nm.oninput = () => { go.disabled = nm.value.trim() !== String(info.name).trim(); };
    d.querySelector('#trNo').onclick = () => d.remove();
    go.onclick = async () => {
      const uid = d.querySelector('#trWho').value, m = ms.find(x => x.id === uid);
      go.disabled = true;
      try { await call('requestTransfer', info.sid, uid, m.name || m.email); d.remove(); LP.toast(T('أُرسل الطلب إلى {w} — تنتقل الملكية بعد موافقتها', { w: m.name || m.email }), null, null, 6000); done && done(); }
      catch (e) { fail(e); go.disabled = false; }
    };
    setTimeout(() => nm.focus(), 50);
  }

  // ---------- موافقة المالكة الجديدة ----------
  async function checkIncoming() {
    const list = LP.schools ? LP.schools().map(s => s.sid) : [];
    if (!list.length || document.querySelector('.tr-dlg')) return;
    let inc = []; try { inc = await call('pendingForMe', list); } catch { return; }
    for (const p of inc) await askAccept(p);
  }
  function askAccept(p) {
    return new Promise(async (resolve) => {
      const who = await api.schoolWho().catch(() => null) || {};
      const d = box(`<h3>👑 ${T('طلب تسلّم ملكية مدرسة')}</h3>
        <p>${T('تطلب منكِ «{b}» تسلّم ملكية «{s}».', { b: esc(p.by), s: esc(p.name) })}</p>
        <div class="tr-warn">• ${T('ستصبحين المالكة بكل الصلاحيات (الأعضاء، الأدوار، الرمز، حذف المدرسة).')}<br>• ${T('وتصبح المالكة الحالية «معلمة».')}<br>• ${T('ينتهي الطلب بعد {d} أيام.', { d: days(p.at) })}</div>
        ${who.google ? `<p class="tnote">${T('للتأكيد سيُفتح المتصفح لتسجيل الدخول بحساب Google نفسه.')}</p>` : `<label>${T('للتأكيد اكتبي كلمة مرور حسابكِ السحابي:')}</label><input type="password" id="trPw" autocomplete="current-password">`}
        <div class="gdlg-row"><button class="pri" id="trOk">${T('موافقة وتسلّم الملكية')}</button><button id="trNo2">${T('رفض')}</button><button id="trLater">${T('لاحقاً')}</button></div>`);
      const end = () => { d.remove(); resolve(); };
      d.querySelector('#trLater').onclick = end;
      d.querySelector('#trNo2').onclick = async () => { try { await call('declineTransfer', p.sid); LP.toast(T('تم رفض الطلب')); } catch (e) { fail(e); } end(); };
      d.querySelector('#trOk').onclick = async () => {
        const pw = who.google ? '' : d.querySelector('#trPw').value;
        if (!who.google && !pw) { d.querySelector('#trPw').focus(); return; }
        const b = d.querySelector('#trOk'); b.disabled = true;
        const r = await api.schoolReauth(pw);
        if (!r || !r.ok) { b.disabled = false; LP.toast(T(r && r.err === 'badpw' ? 'كلمة المرور غير صحيحة' : r && r.err === 'mismatch' ? 'هذا ليس نفس الحساب' : 'تعذّر التحقق من الحساب'), null, null, 5000); return; }
        try {
          await call('acceptTransfer', p.sid);
          const info = await call('info', p.sid); await LP.schoolSaved(info);
          LP.toast(T('أصبحتِ مالكة «{s}» 👑', { s: p.name }), null, null, 6000);
        } catch (e) { fail(e); }
        end();
      };
    });
  }
  LP.checkTransfers = checkIncoming;
  { const b = document.getElementById('meAcc'); if (b) b.onclick = () => { document.getElementById('morePop').classList.remove('on'); LP.openAccount(); }; }
  document.addEventListener('lp-auth', (e) => { if (e.detail && e.detail.user) setTimeout(checkIncoming, 6000); });
  document.addEventListener('lp-ctx', () => setTimeout(checkIncoming, 3000));
})();
