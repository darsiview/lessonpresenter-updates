// 🌟 قيمة الأسبوع: زر في شريط المجموعات (عرض/كتابة سريعة)، وبطاقة كبيرة للطلاب أول درس للفصل في اليوم.
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const btn = $('#gbVal'); if (!btn) return;
  const ls = { get: (k) => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} } };
  let prof = {};
  const cur = () => (LP.cal && LP.cal.now ? LP.cal.now() : { value: '', phrase: '' });

  function render() {
    const v = cur();
    btn.classList.toggle('empty', !v.value);
    btn.innerHTML = v.value ? `🌟 <b>${esc(v.value)}</b>` : `🌟 ${T('قيمة الأسبوع')}`;
    btn.title = v.value ? (v.phrase || T('قيمة الأسبوع')) : T('كتابة قيمة هذا الأسبوع');
  }
  document.addEventListener('lp-cal', render);
  document.addEventListener('lp-auth', async () => { prof = await api.getSettings(); render(); });
  LP.renderValBtn = render;

  // ---------- النافذة الصغيرة ----------
  const pop = document.createElement('div'); pop.className = 'vpop'; pop.id = 'valPop';
  document.body.appendChild(pop);
  const closePop = () => pop.classList.remove('on');
  document.addEventListener('pointerdown', e => { if (pop.classList.contains('on') && !pop.contains(e.target) && e.target !== btn && !btn.contains(e.target)) closePop(); }, true);
  function place() {
    const r = btn.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight;
    let left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), innerWidth - w - 8);
    let top = r.bottom + 6; if (top + h > innerHeight - 8) top = Math.max(8, r.top - h - 6);
    pop.style.left = left + 'px'; pop.style.top = top + 'px';
  }
  function menu() {
    const v = cur();
    pop.innerHTML = `<div class="vp-head">🌟 ${T('قيمة هذا الأسبوع')}: <b>${esc(v.value)}</b></div>
      ${v.phrase ? `<div class="vp-phrase">${esc(v.phrase)}</div>` : ''}
      <button class="vp-item" id="vpShow">📣 ${T('إظهارها للطلاب')}</button>
      <button class="vp-item" id="vpEdit">✏️ ${T('تعديل')}</button>`;
    pop.classList.add('on'); place();
    $('#vpShow').onclick = () => { closePop(); show(true); };
    $('#vpEdit').onclick = edit;
  }
  async function edit() {
    prof = await api.getSettings();
    const v = cur(), inCal = LP.cal.calEditable();
    const w = LP.cal.schoolWeek();
    const note = inCal ? T('تُحفظ في التقويم الدراسي لهذا الأسبوع.') : T('تبقى حتى نهاية الأسبوع الدراسي ({d}).', { d: LP.cal.short(w.to) });
    pop.innerHTML = `<div class="vp-head">🌟 ${T('قيمة هذا الأسبوع')}</div>
      <input id="vpVal" dir="auto" maxlength="40" placeholder="${T('مثال: الأمانة')}" value="${esc(v.value)}">
      <textarea id="vpPhr" dir="auto" rows="2" maxlength="160" placeholder="${T('عبارة قصيرة (اختياري)')}">${esc(v.phrase)}</textarea>
      <div class="vp-scope"><label><input type="radio" name="vpSc" value="w" checked> ${T('هذا الأسبوع')}</label><label><input type="radio" name="vpSc" value="m"> ${T('حتى نهاية الشهر')}</label></div>
      <label class="vp-chk"><input type="checkbox" id="vpCard" ${prof.valCard !== false ? 'checked' : ''}> ${T('إظهار البطاقة للطلاب في أول درس كل يوم')}</label>
      <p class="vp-note">${esc(note)}</p>
      <div class="vp-row"><button class="pri" id="vpSave">${T('حفظ')}</button>${v.value ? `<button id="vpDel">${T('حذف')}</button>` : ''}<button id="vpCancel">${T('إلغاء')}</button></div>`;
    pop.classList.add('on'); place();
    pop.querySelectorAll('input,textarea').forEach(i => i.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') closePop(); if (e.key === 'Enter' && i.tagName === 'INPUT' && i.type !== 'checkbox') $('#vpSave').click(); }));
    setTimeout(() => $('#vpVal').focus(), 30);
    const saveCard = async () => { const on = $('#vpCard').checked; if ((prof.valCard !== false) !== on) { await api.setSettings({ valCard: on }); prof.valCard = on; } };
    $('#vpSave').onclick = async () => {
      const val = $('#vpVal').value.trim(), phr = $('#vpPhr').value.trim(), month = pop.querySelector('[name=vpSc]:checked').value === 'm';
      await saveCard();
      const where = await LP.cal.setWeekValue(val, phr, month);
      closePop(); render();
      if (val) LP.toast(where === 'cal' ? T('حُفظت القيمة في التقويم') : T('حُفظت القيمة حتى نهاية الأسبوع الدراسي'), T('إظهارها للطلاب'), () => show(true), 6000);
    };
    if ($('#vpDel')) $('#vpDel').onclick = async () => { await saveCard(); await LP.cal.setWeekValue('', '', false); closePop(); render(); };
    $('#vpCancel').onclick = async () => { await saveCard(); closePop(); };
  }
  btn.onclick = (e) => {
    e.stopPropagation();
    if (pop.classList.contains('on')) { closePop(); return; }
    if (cur().value) menu(); else edit();
  };

  // ---------- بطاقة الطلاب ----------
  let cardEl = null, cardT = null;
  function hide() {
    if (!cardEl) return;
    const el = cardEl; cardEl = null; clearTimeout(cardT);
    const r = btn.getBoundingClientRect(), box = el.querySelector('.vc-box').getBoundingClientRect();
    if (r.width && btn.offsetParent) {
      const dx = (r.left + r.width / 2) - (box.left + box.width / 2), dy = (r.top + r.height / 2) - (box.top + box.height / 2);
      el.querySelector('.vc-box').style.transform = `translate(${dx}px,${dy}px) scale(.08)`;
    }
    el.classList.add('out');
    setTimeout(() => el.remove(), 650);
  }
  function show(force) {
    const v = cur(); if (!v.value) return false;
    if (cardEl) hide();
    const el = document.createElement('div'); el.className = 'vcard';
    el.innerHTML = `<div class="vc-box"><div class="vc-lbl">🌟 ${T('قيمة هذا الأسبوع')}</div><div class="vc-val">${esc(v.value)}</div>${v.phrase ? `<div class="vc-phr">${esc(v.phrase)}</div>` : ''}</div>`;
    document.body.appendChild(el); cardEl = el;
    requestAnimationFrame(() => el.classList.add('in'));
    el.onclick = hide;
    cardT = setTimeout(hide, force ? 12000 : 8000);
    return true;
  }
  document.addEventListener('keydown', e => { if (cardEl && e.key === 'Escape') hide(); }, true);
  // أول درس للفصل في اليوم (مرة واحدة لكل فصل في اليوم)
  LP.valueCard = async (ck) => {
    if (!ck) return;
    prof = await api.getSettings();
    if (prof.valCard === false) return;
    const v = cur(); if (!v.value) return;
    const k = 'lpValCard:' + ck + ':' + new Date().toDateString();
    if (ls.get(k) === v.value) return;
    setTimeout(() => { if (document.querySelector('#gDlg.on')) return; if (show()) ls.set(k, v.value); }, 900);
  };
  LP.showValueCard = () => show(true);
  render();
})();
