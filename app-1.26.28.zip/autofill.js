// يُحقن في صفحات الدخول (لا يُحمَّل في نافذة البرنامج): شريط الحسابات المحفوظة، والدخول التلقائي بعد عدّ تنازلي،
// وقائمة عند الضغط على الخانة، والتقاط الدخول الجديد للحفظ. كلمات المرور لا تُرسل للصفحة إلا عند اختيار حساب.
// يُستدعى كـ: (FILL_SRC)(P)  — P = { site, accts:[{user,label}], auto, locked, autoOK, nosuggest, dir, T:{...} }
(function (P) {
  if (window.__lpFill) { window.__lpFill.update(P); return; }
  const st = window.__lpFill = { P, u: '', p: '', timer: null, left: 0, hidden: false };
  const T = (k, v) => String((st.P.T && st.P.T[k]) || k).replace(/\{(\w+)\}/g, (_, n) => (v && v[n] != null ? v[n] : ''));
  const SS = (k, v) => { try { if (v === undefined) return JSON.parse(sessionStorage.getItem('__lp_' + k) || 'null'); if (v === null) sessionStorage.removeItem('__lp_' + k); else sessionStorage.setItem('__lp_' + k, JSON.stringify(v)); } catch { return null; } };
  const MS = () => st.P.site === 'microsoft' || st.P.site === 'google';
  const setv = (el, v) => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const vis = (el) => el && el.offsetParent !== null && !el.disabled && !el.readOnly;
  const USER_MS = 'input[type=email],input[name=loginfmt],input#identifierId,input[name=identifier],input[autocomplete=username]';
  const USER_ANY = USER_MS + ',input[name*=user i],input[name*=email i],input[name*=login i],input[id*=user i],input[id*=email i],input[id*=login i]';
  const userField = () => [...document.querySelectorAll(MS() ? USER_MS : USER_ANY)].find(el => vis(el) && el.type !== 'password' && el.type !== 'hidden');
  const passField = () => [...document.querySelectorAll('input[type=password]')].find(vis);
  const isManual = () => (SS('manual') || 0) > Date.now() - 300e3;
  const flow = () => { const f = SS('flow'); return f && f.t > Date.now() - 90e3 ? f : null; };
  const navBack = (() => { try { const n = performance.getEntriesByType('navigation')[0]; return !!(n && n.type === 'back_forward'); } catch { return false; } })();
  if (navBack) SS('sent', null);                  // الرجوع لصفحة الدخول ليس فشلاً
  const nameOf = (a) => a.label ? `${a.label} (${a.user})` : a.user;
  const esc = (t) => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // ---------- التقاط الدخول (لعرض الحفظ/التحديث بعده) ----------
  let rt; const report = () => { clearTimeout(rt); rt = setTimeout(() => { if (st.u && st.p) console.log('__LPCRED__' + JSON.stringify({ site: st.P.site, u: st.u, p: st.p })); }, 500); };

  // ---------- الواجهة (داخل Shadow DOM حتى لا تتأثر بتنسيق الموقع) ----------
  let host = null, root = null, menu = null;
  const CSS = `:host{all:initial}
    .bar,.menu{font:13px/1.4 system-ui,"Segoe UI",Tahoma,sans-serif;color:#1f2937;background:#fff;border:1px solid #d1d5db;border-radius:12px;box-shadow:0 8px 28px rgba(0,0,0,.18)}
    .bar{position:fixed;top:10px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:6px;padding:6px 8px;flex-wrap:wrap;max-width:min(92vw,680px)}
    .bar.off{display:none}
    .t{font-weight:600;padding:0 4px}
    button{font:inherit;border:1px solid #d1d5db;background:#f9fafb;color:#111;border-radius:8px;padding:4px 10px;cursor:pointer}
    button:hover{background:#eef2ff}
    button.pri{background:#0d9488;border-color:#0d9488;color:#fff}
    button.x{border:0;background:none;color:#6b7280;padding:4px 6px}
    .msg{color:#b45309;font-size:12px;padding:0 4px}
    .menu{position:fixed;padding:4px;min-width:220px;display:flex;flex-direction:column}
    .menu button{border:0;background:none;text-align:start;padding:7px 10px;border-radius:8px}
    .menu button:hover{background:#f0fdfa}
    .menu small{color:#6b7280}`;
  function ensure() {
    if (host && host.isConnected) return;
    host = document.createElement('lp-acct'); host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647';
    root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>${CSS}</style><div class="bar" dir="${st.P.dir || 'rtl'}"></div>`;
    (document.body || document.documentElement).appendChild(host);
  }
  const barEl = () => root && root.querySelector('.bar');
  function hideBar() { const b = barEl(); if (b) b.classList.add('off'); }
  const showBar = () => { ensure(); barEl().classList.remove('off'); };
  function flash(m) { showBar(); const b = barEl(); let s = b.querySelector('.msg'); if (!s) { s = document.createElement('span'); s.className = 'msg'; b.appendChild(s); } s.textContent = m; setTimeout(() => { if (s.isConnected) s.textContent = ''; }, 6000); }

  function render() {
    const P = st.P;
    if (st.hidden || P.nosuggest || !P.accts.length || isManual() || (!userField() && !(passField() && flow()))) { hideBar(); return; }
    showBar();
    const first = P.accts[0];
    const head = st.timer
      ? `<span class="t">🔑 ${esc(T('الدخول إلى «{n}» خلال {s}…', { n: first.label || first.user, s: st.left }))}</span>`
      : `<span class="t">🔑</span>`;
    const accs = P.accts.map((a, i) => `<button data-i="${i}" class="${st.timer && i === 0 ? 'pri' : ''}">${esc(nameOf(a))}</button>`).join('');
    barEl().innerHTML = `${head}${accs}<button data-other>${esc(T('حساب آخر'))}</button>${st.timer ? `<button data-cancel>${esc(T('إلغاء'))}</button>` : ''}<button class="x" data-x title="${esc(T('إخفاء'))}">✕</button>`;
    barEl().querySelectorAll('[data-i]').forEach(b => b.onclick = (e) => { e.stopPropagation(); stop(); pick(P.accts[+b.dataset.i].user, true); });
    barEl().querySelector('[data-other]').onclick = (e) => { e.stopPropagation(); other(); };
    const c = barEl().querySelector('[data-cancel]'); if (c) c.onclick = (e) => { e.stopPropagation(); stop(); fillOnly(first.user); };
    barEl().querySelector('[data-x]').onclick = (e) => { e.stopPropagation(); stop(); st.hidden = true; hideBar(); };
  }
  function stop() { if (st.timer) { clearInterval(st.timer); st.timer = null; render(); } }
  function other() {
    stop(); SS('manual', Date.now()); SS('flow', null);
    const u = userField(), p = passField();
    if (u) setv(u, ''); if (p) { setv(p, ''); p.__lpAuto = null; }
    hideBar(); closeMenu(); (u || p) && (u || p).focus();
  }
  function fillOnly(user) { pick(user, false); }

  // ---------- طلب كلمة المرور من البرنامج عند الاختيار فقط ----------
  function pick(user, submit) {
    if (st.P.locked) return;
    SS('manual', null);
    console.log('__LPPICK__' + JSON.stringify({ site: st.P.site, user, submit: !!submit }));
  }
  st.put = (user, pass, submit) => {
    const u = userField(), p = passField();
    if (u && u.value.toLowerCase() !== String(user).toLowerCase()) setv(u, user);
    if (p && pass) { setv(p, pass); p.__lpAuto = pass; watchReveal(p); }
    SS('flow', { user, auto: !!submit, t: Date.now() });
    if (!submit && p) { try { p.focus(); p.setSelectionRange && p.setSelectionRange(p.value.length, p.value.length); } catch {} }   // المؤشر ينتقل إلى خانة كلمة المرور
    if (submit) setTimeout(() => go(p || u, !!(p && pass)), 350);
  };
  function go(el, withPass) {
    if (!el) return;
    if (withPass) SS('sent', { t: Date.now() });
    const f = el.form;
    const btn = document.querySelector('#idSIButton9') || document.querySelector('#identifierNext button, #passwordNext button') ||
      (f && f.querySelector('button[type=submit],input[type=submit],button:not([type])'));
    if (btn && vis(btn)) { btn.click(); return; }
    if (f && f.requestSubmit) { try { f.requestSubmit(); return; } catch {} }
    el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
  }

  // ---------- حماية: زر «إظهار كلمة المرور» الخاص بالموقع لا يكشف كلمة مرور الخزنة ----------
  function watchReveal(p) {
    if (p.__lpWatch) return; p.__lpWatch = 1;
    p.addEventListener('input', (e) => { if (e.isTrusted) p.__lpAuto = null; });
    new MutationObserver(() => {
      if (p.type !== 'password' && p.__lpAuto && p.value === p.__lpAuto) {
        setv(p, ''); p.type = 'password'; p.__lpAuto = null;
        flash(T('كلمة المرور المحفوظة لا تُعرض هنا'));
      }
    }).observe(p, { attributes: true, attributeFilter: ['type'] });
  }

  // ---------- القائمة عند الضغط على خانة البريد أو كلمة المرور ----------
  function closeMenu() { if (menu) { menu.remove(); menu = null; } }
  function openMenu(el) {
    const P = st.P; if (P.locked || P.nosuggest || !P.accts.length) return;
    let list = P.accts;
    // خانة كلمة المرور: الحسابات المطابقة للبريد المكتوب فقط (وإن كان البريد فارغاً: كل الحسابات)
    if (el.type === 'password') { const f = flow(), u = userField(); const who = ((u && u.value) || (MS() && f && f.user) || '').trim(); if (who) list = list.filter(a => a.user.toLowerCase() === who.toLowerCase()); }
    if (!list.length) return;
    ensure();
    closeMenu();
    menu = document.createElement('div'); menu.className = 'menu'; menu.dir = P.dir || 'rtl';
    const r = el.getBoundingClientRect();
    menu.style.top = Math.round(r.bottom + 4) + 'px'; menu.style.left = Math.round(r.left) + 'px'; menu.style.minWidth = Math.max(220, Math.round(r.width)) + 'px';
    menu.innerHTML = list.map(a => `<button data-u="${esc(a.user)}">🔑 ${esc(a.label || a.user)}${a.label ? ` <small>${esc(a.user)}</small>` : ''}</button>`).join('');
    // القائمة خارج الشريط: نضعها في الجذر نفسه بموضع ثابت
    root.appendChild(menu);
    menu.querySelectorAll('[data-u]').forEach(b => b.onmousedown = (e) => { e.preventDefault(); e.stopPropagation(); stop(); SS('manual', null); pick(b.dataset.u, false); closeMenu(); });
  }
  document.addEventListener('mousedown', (e) => { if (menu && !e.composedPath().includes(host)) closeMenu(); }, true);

  // ---------- فحص الصفحة ----------
  let started = false;
  st.scan = () => {
    const P = st.P;
    const u = userField(), p = passField();
    if (u && !u.__lpw) {
      u.__lpw = 1;
      u.addEventListener('input', () => { st.u = u.value.trim(); report(); });
      u.addEventListener('click', (e) => { if (e.isTrusted) openMenu(u); });
      // كتابة بريد محفوظ تعبّئ كلمة مروره
      let tt; u.addEventListener('input', (e) => { if (!e.isTrusted) return; stop(); clearTimeout(tt); tt = setTimeout(() => {
        const v = u.value.trim().toLowerCase(), a = P.accts.find(x => x.user.toLowerCase() === v);
        if (a && !isManual()) { if (passField()) pick(a.user, false); else SS('flow', { user: a.user, auto: false, t: Date.now() }); }
      }, 600); });
    }
    if (u && u.value) st.u = u.value.trim();
    if (!st.u) { const dn = document.querySelector('#displayName,[data-email],#profileIdentifier,[data-profile-identifier]'); if (dn) st.u = (dn.getAttribute('data-email') || dn.textContent || '').trim(); }
    if (p && !p.__lpw) {
      p.__lpw = 1;
      p.addEventListener('input', () => { st.p = p.value; report(); });
      p.addEventListener('click', (e) => { if (e.isTrusted) openMenu(p); });
      // فشل الدخول بكلمة مرور محفوظة: الصفحة رجعت بخانة فارغة بعد الإرسال
      const s = SS('sent');
      if (s && s.t > Date.now() - 25e3) { SS('sent', null); SS('flow', null); console.log('__LPFAIL__' + JSON.stringify({ site: P.site, user: st.u })); return render(); }
    }
    // فشل على الصفحة نفسها: الموقع مسح كلمة المرور المعبّأة بعد الإرسال وظهر الخطأ
    if (p && p.__lpAuto && !p.value) { const s2 = SS('sent'); if (s2 && Date.now() - s2.t > 2500 && Date.now() - s2.t < 25e3) { SS('sent', null); SS('flow', null); p.__lpAuto = null; console.log('__LPFAIL__' + JSON.stringify({ site: P.site, user: st.u })); } }
    // الصفحة الثانية (كلمة المرور) في Microsoft/Google: نكمل بالحساب المختار
    const f = flow();
    if (p && !p.value && !u && f && !isManual() && !p.__lpReq && !P.locked) { p.__lpReq = 1; pick(f.user, f.auto); }
    // العدّ التنازلي: مرة عند فتح الصفحة (لا مع الرجوع/التقدم، ولا والقفل ظاهر)
    if (!started && u && !u.value && P.accts.length && P.auto > 0 && P.autoOK && !P.locked && !P.nosuggest && !isManual() && !navBack) {
      started = true; st.left = P.auto;
      st.timer = setInterval(() => {
        if (st.P.locked) return stop();
        st.left--; if (st.left <= 0) { clearInterval(st.timer); st.timer = null; console.log('__LPAUTO__' + JSON.stringify({ site: st.P.site })); pick(st.P.accts[0].user, true); }
        render();
      }, 1000);
    }
    render();
  };
  // أي ضغطة أو كتابة في الصفحة (خارج الشريط) توقف العدّ
  const userAct = (e) => { if (st.timer && e.isTrusted && !(host && e.composedPath().includes(host))) stop(); };
  document.addEventListener('keydown', userAct, true);
  document.addEventListener('mousedown', userAct, true);
  st.lock = (b) => { st.P.locked = !!b; if (b) { stop(); closeMenu(); hideBar(); } else st.scan(); };
  st.update = (P2) => { st.P = { ...st.P, ...P2 }; st.scan(); };
  let mt; new MutationObserver(() => { clearTimeout(mt); mt = setTimeout(st.scan, 120); }).observe(document.documentElement, { childList: true, subtree: true });
  st.scan();
})
