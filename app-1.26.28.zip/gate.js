// شاشة الدخول: إعداد المديرة، اختيار المعلمة والرمز السري، إضافة معلمة، الضيفة، والاسترجاع بالبريد
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const gate = $('#gate'), box = $('#gBox');
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const palette = ['#e5484d', '#fd7e14', '#f5b400', '#2fb344', '#12b886', '#228be6', '#4c6ef5', '#ae3ec9', '#e64980'];
  const colorFor = (t) => { let h = 0; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return palette[h % palette.length]; };
  const letter = (t) => (String(t).trim().match(/[\p{L}\p{N}]/u) || ['?'])[0].toUpperCase();
  window.LPavatar = (name) => `<span class="gav" style="background:${colorFor(name)}">${esc(letter(name))}</span>`;
  let st = null;

  const ERR = {
    name: 'الاسم مطلوب.',
    email: 'البريد الإلكتروني غير صحيح.',
    pin: 'الرمز السري يجب أن يكون من 4 إلى 12 رقماً.',
    exists: 'هذا البريد مسجّل لمستخدم آخر.',
    match: 'الرمزان غير متطابقين.',
    wrong: 'الرمز السري غير صحيح.',
    send: 'تعذّر إرسال الرسالة. يلزم التأكد من الاتصال بالإنترنت.',
    cwrong: 'البريد أو كلمة المرور غير صحيحة.',
    cexists: 'هذا البريد لديه حساب سحابي من قبل. الدخول يكون من «الدخول بحساب سحابي».',
    cweak: 'كلمة المرور يجب أن تكون 6 أحرف أو أكثر.',
    cmany: 'محاولات كثيرة. يُرجى الانتظار قليلاً ثم المحاولة مرة أخرى.',
    cdisabled: 'هذا الحساب موقوف.',
    coff: 'الحساب السحابي غير مفعّل في هذه النسخة.',
    net: 'لا يوجد اتصال بالإنترنت. إن سبق الدخول على هذا الجهاز فيمكن اختيار الاسم من القائمة، أو الدخول كضيف.',
    cfail: 'تعذّر الاتصال بالخدمة السحابية. يُرجى المحاولة مرة أخرى.',
    ctaken: 'هذا الحساب السحابي مربوط بحساب آخر على هذا الجهاز.',
    ccancel: 'لم يكتمل الدخول بحساب Google.',
    cexpired: 'انتهت الجلسة. يلزم تسجيل الدخول مرة أخرى.'
  };
  window.LPcloudErr = (r) => errMsg(r);
  const errMsg = (r) => r && r.wait ? T('محاولات كثيرة خاطئة. المحاولة ممكنة بعد {s} ثانية.', { s: r.wait }) : T(ERR[r && r.err] || ERR.wrong);

  function show(html, focusSel) {
    box.innerHTML = html;
    box.style.animation = 'none'; void box.offsetWidth; box.style.animation = '';
    const f = box.querySelector(focusSel || 'input');
    if (f) setTimeout(() => f.focus(), 30);
  }
  const field = (id, label, type = 'text', extra = '') =>
    `<div class="gfield"><label for="${id}">${T(label)}</label><input id="${id}" type="${type}" ${extra} autocomplete="off" spellcheck="false"></div>`;
  const pinField = (id, label) => field(id, label, 'password', 'inputmode="numeric" class="pin" maxlength="12"');
  const pwField = (id, label) => field(id, label, 'password', 'class="pin" maxlength="64"');
  const busy = (b, on, txt) => { if (!b) return; if (on) { b.dataset.t = b.textContent; b.textContent = T(txt || 'جارٍ الاتصال…'); } else if (b.dataset.t) b.textContent = b.dataset.t; b.disabled = on; };
  const cloudOn = () => !!(st && st.cloud && st.cloud.configured);
  const qrBtn = (cls) => st && st.cloud && st.cloud.qrReady ? `<button class="gbtn ${cls || 'sec'}" id="gQr">📱 ${T('الدخول بالجوال')}</button>` : '';
  const bindQr = (back) => { const b = $('#gQr'); if (b) b.onclick = () => qrView(back); };
  const googleBtn = () => st && st.cloud && st.cloud.googleReady ? `<button class="gbtn sec ggl" id="gGoogle"><b>G</b> ${T('الدخول بحساب Google')}</button>` : '';
  const onEnter = (fn) => box.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') fn(); }));
  const val = (id) => (box.querySelector('#' + id) || {}).value || '';
  const setErr = (m) => { const e = box.querySelector('.gerr'); if (e) e.textContent = m || ''; };

  // ---------- أول تشغيل ----------
  function setupView() {
    if (!cloudOn()) return localSetupView();
    show(`<h1>👋 ${T('مرحباً بك في عارض الدروس')}</h1>
      <p class="sub">${window.LP_WEB ? T('الدخول بالحساب السحابي يحفظ الفصول والبيانات، والدخول كضيف للاستخدام السريع دون حفظ.') : T('الدخول بالحساب السحابي يحفظ البيانات على كل الأجهزة، ويمكن أيضاً استخدام البرنامج على هذا الجهاز فقط.')}</p>
      <div class="gcol">
        <button class="gbtn" id="gCloudIn">☁ ${T('الدخول بحساب سحابي')}</button>
        ${qrBtn()}
        <button class="gbtn sec" id="gCloudNew">＋ ${T('إنشاء حساب سحابي جديد')}</button>
        ${googleBtn()}
        ${window.LP_WEB ? '' : `<button class="gbtn sec" id="gLocal">💻 ${T('حساب على هذا الجهاز فقط (دون إنترنت)')}</button>`}
        <button class="gbtn link" id="gGuest">${T('دخول كضيف')}</button>
      </div>`, 'button');
    $('#gCloudIn').onclick = () => cloudLoginView(setupView);
    $('#gCloudNew').onclick = () => cloudSignupView(setupView);
    if ($('#gLocal')) $('#gLocal').onclick = localSetupView;
    $('#gGuest').onclick = async () => { await api.authGuest(); api.authReload(); };
    bindGoogle(setupView); bindQr(setupView);
  }
  // ---------- أول تشغيل دون إنترنت: إنشاء حساب المديرة على الجهاز ----------
  function localSetupView() {
    show(`<h1>👋 ${T('مرحباً بك في عارض الدروس')}</h1>
      <p class="sub">${T('هذا أول تشغيل للبرنامج على هذا الجهاز. أول حساب هو «مدير الجهاز»: يستطيع إضافة مستخدمين وإعادة تعيين رموزهم عند النسيان.')}</p>
      ${field('gName', 'الاسم')}${field('gEmail', 'البريد الإلكتروني', 'email')}
      ${pinField('gPin', 'الرمز السري (4 أرقام أو أكثر)')}${pinField('gPin2', 'إعادة كتابة الرمز السري')}
      <div class="gwarn">⚠️ ${T('الحساب على هذا الجهاز فقط لا يُسترجع إذا نُسي رمزه، وتبقى بياناته على هذا الجهاز وحده. الأفضل ربطه بحساب سحابي لاحقاً من «الإعدادات ← حسابي».')}</div>
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('إنشاء حساب مدير الجهاز')}</button>${cloudOn() ? `<button class="gbtn sec" id="gBack">${T('رجوع')}</button>` : `<button class="gbtn sec" id="gGuest">${T('دخول كضيف')}</button>`}</div>`);
    const go = async () => {
      if (val('gPin') !== val('gPin2')) return setErr(T(ERR.match));
      const r = await api.authSetup({ name: val('gName'), email: val('gEmail'), pin: val('gPin') });
      if (!r.ok) return setErr(errMsg(r));
      api.authReload();
    };
    $('#gGo').onclick = go; onEnter(go);
    if ($('#gBack')) $('#gBack').onclick = setupView;
    if ($('#gGuest')) $('#gGuest').onclick = async () => { await api.authGuest(); api.authReload(); };
  }

  // ---------- الحساب السحابي ----------
  // نتيجة أي دخول سحابي: نجاح، أو طلب ربط حساب قديم بنفس البريد، أو طلب رمز للجهاز (Google)
  function cloudResult(r, retry, back) {
    if (r.ok) { api.authReload(); return true; }
    if (r.need === 'link') { linkOldView(r.user, retry, back); return true; }
    if (r.need === 'pin') { devicePinView(retry, back); return true; }
    if (r.need === 'devpin') { devUnlockView(r.user, retry, back); return true; }
    return false;
  }
  function cloudLoginView(back, email) {
    show(`<h1>☁ ${T('الدخول بحساب سحابي')}</h1>
      <p class="sub">${T('نفس الحساب يعمل على كل الأجهزة. بعد أول دخول يعمل على هذا الجهاز حتى دون إنترنت.')}</p>
      ${field('gEmail', 'البريد الإلكتروني', 'email')}${pwField('gPw', 'كلمة المرور')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('دخول')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>
      ${googleBtn() || qrBtn() ? `<div class="gor"><span>${T('أو')}</span></div><div class="grow">${qrBtn()}${googleBtn()}</div>` : ''}
      <div class="grow" style="margin-top:12px;justify-content:space-between"><button class="gbtn link" id="gForgot">${T('نسيت كلمة المرور؟')}</button><button class="gbtn link" id="gNewC">${T('ليس لديّ حساب — إنشاء حساب')}</button></div>`);
    if (email) $('#gEmail').value = email;
    const go = async (linkPin) => {
      const b = $('#gGo'); const em = val('gEmail').trim(), pw = val('gPw');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return setErr(T(ERR.email));
      busy(b, true); setErr('');
      const r = await api.cloudSignin({ email: em, password: pw, linkPin });
      busy(b, false);
      if (!cloudResult(r, (pin) => api.cloudSignin({ email: em, password: pw, linkPin: pin }), () => cloudLoginView(back, em))) setErr(errMsg(r));
    };
    $('#gGo').onclick = () => go(); onEnter(() => go());
    $('#gBack').onclick = back || chooseView;
    $('#gForgot').onclick = () => cloudForgotView(() => cloudLoginView(back, val('gEmail')), val('gEmail'));
    $('#gNewC').onclick = () => cloudSignupView(() => cloudLoginView(back));
    bindGoogle(() => cloudLoginView(back)); bindQr(() => cloudLoginView(back));
  }
  function cloudSignupView(back) {
    show(`<h1>＋ ${T('إنشاء حساب سحابي')}</h1>
      <p class="sub">${T('تصل رسالة لتأكيد البريد. كلمة المرور نفسها تعمل على كل الأجهزة.')}</p>
      ${field('gName', 'الاسم')}${field('gEmail', 'البريد الإلكتروني', 'email')}
      ${pwField('gPw', 'كلمة المرور (6 أحرف أو أكثر)')}${pwField('gPw2', 'إعادة كتابة كلمة المرور')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('إنشاء الحساب')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      const name = val('gName').trim(), em = val('gEmail').trim(), pw = val('gPw');
      if (!name) return setErr(T(ERR.name));
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return setErr(T(ERR.email));
      if (pw.length < 6) return setErr(T(ERR.cweak));
      if (pw !== val('gPw2')) return setErr(T('كلمتا المرور غير متطابقتين.'));
      const b = $('#gGo'); busy(b, true); setErr('');
      const r = await api.cloudSignup({ name, email: em, password: pw });
      busy(b, false);
      if (!cloudResult(r, (pin) => api.cloudSignin({ email: em, password: pw, linkPin: pin }), () => cloudLoginView(back, em))) setErr(errMsg(r));
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  function cloudForgotView(back, email) {
    show(`<h1>${T('نسيت كلمة المرور')}</h1>
      <p class="sub">${T('يُرسَل إلى البريد رابط لاختيار كلمة مرور جديدة.')}</p>
      ${field('gEmail', 'البريد الإلكتروني', 'email')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('إرسال الرابط')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    if (email) $('#gEmail').value = email;
    const go = async () => {
      const em = val('gEmail').trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return setErr(T(ERR.email));
      const b = $('#gGo'); busy(b, true, 'جارٍ الإرسال…');
      const r = await api.cloudForgot(em);
      busy(b, false);
      if (!r.ok) return setErr(errMsg(r));
      show(`<h1>📧 ${T('تحقق من البريد')}</h1>
        <p class="sub">${T('إذا كان البريد مسجّلاً، يصل إليه رابط لاختيار كلمة مرور جديدة. إن لم يظهر، فقد يكون في مجلد الرسائل غير المرغوب فيها (Spam).')}</p>
        <p class="sub">${T('بعد تغييرها، يكون الدخول بكلمة المرور الجديدة من «الدخول بحساب سحابي».')}</p>
        <button class="gbtn" id="gBack">${T('رجوع')}</button>`, 'button');
      $('#gBack').onclick = back || chooseView;
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  // يوجد على هذا الجهاز حساب قديم بنفس البريد: نربطه بعد التأكد من رمزه، فتبقى كل دروسه وبياناته
  function linkOldView(u, retry, back) {
    show(`<h1>🔗 ${T('ربط الحساب القديم')}</h1>
      <div class="gme">${LPavatar(u.name)}<b>${esc(u.name)}</b></div>
      <p class="sub">${T('على هذا الجهاز حساب قديم بنفس البريد. رمزه السري القديم يربطه بالحساب السحابي، فتبقى كل الدروس والبيانات.')}</p>
      ${pinField('gPin', 'الرمز السري القديم')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('ربط الحساب')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      const b = $('#gGo'); busy(b, true);
      const r = await retry(val('gPin'));
      if (r.ok && r.wait) return;                  // الدخول بالجوال: ننتظر اكتمال تنزيل البيانات
      busy(b, false);
      if (r.ok) return api.authReload();
      setErr(errMsg(r)); $('#gPin').value = '';
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  // الدخول بـ Google لأول مرة على هذا الجهاز: رمز سري للجهاز (للدخول دون إنترنت ولفك القفل)
  function devicePinView(retry, back) {
    show(`<h1>🔒 ${T('رمز سري لهذا الجهاز')}</h1>
      <p class="sub">${T('رمز سري للدخول على هذا الجهاز دون إنترنت، ولفتح القفل بعد عدم الاستخدام.')}</p>
      ${pinField('gPin', 'الرمز السري (4 أرقام أو أكثر)')}${pinField('gPin2', 'إعادة كتابة الرمز السري')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('حفظ ومتابعة')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      if (val('gPin') !== val('gPin2')) return setErr(T(ERR.match));
      if (!/^\d{4,12}$/.test(val('gPin'))) return setErr(T(ERR.pin));
      const r = await api.cloudGoogle({ again: true, pin: val('gPin') });
      if (!cloudResult(r, (pin) => api.cloudGoogle({ again: true, linkPin: pin }), back)) setErr(errMsg(r));
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  // Google على جهاز سبق الدخول فيه: رمز الجهاز يفتح بياناتها المشفّرة
  function devUnlockView(u, retry, back) {
    show(`<h1>🔒 ${T('رمز هذا الجهاز')}</h1>
      <div class="gme">${LPavatar(u.name)}<b>${esc(u.name)}</b></div>
      <p class="sub">${T('الرمز السري المختار لهذا الجهاز يفتح البيانات المحفوظة عليه.')}</p>
      ${pinField('gPin', 'الرمز السري')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('متابعة')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => { const r = await retry(val('gPin')); if (r.ok) return api.authReload(); setErr(errMsg(r)); $('#gPin').value = ''; };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = back || chooseView;
  }
  function bindGoogle(back) {
    const b = $('#gGoogle'); if (!b) return;
    b.onclick = async () => {
      busy(b, true, 'إكمال الدخول في المتصفح…'); setErr('');
      const r = await api.cloudGoogle({});
      busy(b, false);
      if (!cloudResult(r, (pin) => api.cloudGoogle({ again: true, linkPin: pin }), back)) setErr(errMsg(r));
    };
  }

  // ---------- اختيار المعلمة ----------
  function chooseView() {
    const users = st.users.map(u => `<button class="guser" data-id="${u.id}">${LPavatar(u.name)}<span class="gn">${esc(u.name)}</span>${u.cloud ? `<span class="gb cl" title="${T('حساب سحابي')}">☁</span>` : ''}${u.admin ? `<span class="gb">👑 ${T('مدير الجهاز')}</span>` : ''}</button>`).join('');
    show(`<h1>${T('من يستخدم البرنامج؟')}</h1><p class="sub">${T('اختيار الاسم، ثم كتابة الرمز السري.')}</p>
      <div class="gusers">${users}</div>
      ${cloudOn() ? `<div class="grow"><button class="gbtn" id="gCloudIn">☁ ${T('الدخول بحساب سحابي')}</button>${qrBtn()}${googleBtn()}</div>` : ''}
      <div class="grow"><button class="gbtn sec" id="gNew">＋ ${T(cloudOn() ? 'مستخدم جديد على هذا الجهاز فقط' : 'إضافة مستخدم جديد')}</button><button class="gbtn sec" id="gGuest">${T('دخول كضيف')}</button></div>`, 'button');
    if ($('#gCloudIn')) $('#gCloudIn').onclick = () => cloudLoginView(chooseView);
    bindGoogle(chooseView); bindQr(chooseView);
    box.querySelectorAll('.guser').forEach(b => b.onclick = () => pinView(st.users.find(u => u.id === b.dataset.id)));
    $('#gNew').onclick = createView;
    $('#gGuest').onclick = async () => { await api.authGuest(); api.authReload(); };
  }

  function pinView(u) {
    show(`<div class="gme">${LPavatar(u.name)}<div><h1 style="margin:0">${esc(u.name)}</h1>${u.cloud ? `<div class="ghint">☁ ${T('حساب سحابي')}</div>` : ''}</div></div>
      ${u.cloudPw || u.qrOnly ? pwField('gPin', 'كلمة المرور') : pinField('gPin', 'الرمز السري')}
      ${u.qrOnly ? `<div class="ghint" style="margin:-6px 0 10px">${T('سبق الدخول إلى هذا الجهاز بالجوال: كلمة المرور تحتاج إنترنت هنا أول مرة، أو يمكن الدخول بالجوال مرة أخرى.')}</div>${qrBtn()}` : ''}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('دخول')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>
      <div style="margin-top:12px"><button class="gbtn link" id="gForgot">${T(u.cloudPw ? 'نسيت كلمة المرور؟' : 'نسيت الرمز السري؟')}</button></div>`);
    const go = async () => {
      const b = $('#gGo'); busy(b, true, u.qrOnly ? 'جارٍ الاتصال…' : 'جارٍ الدخول…');
      const r = await api.authLogin(u.id, val('gPin'));
      busy(b, false);
      if (!r.ok) { setErr(errMsg(r)); box.querySelector('#gPin').value = ''; return; }
      api.authReload();
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = chooseView;
    $('#gForgot').onclick = () => u.cloudPw || u.qrOnly ? cloudForgotView(() => pinView(u)) : lostPinView(u);
    bindQr(() => pinView(u));
  }

  function createView() {
    show(`<h1>${T('إضافة مستخدم جديد')}</h1><p class="sub">${T('لكل مستخدم حسابه ودروسه وإعداداته الخاصة.')}</p>
      ${field('gName', 'الاسم')}${field('gEmail', 'البريد الإلكتروني', 'email')}
      ${pinField('gPin', 'الرمز السري (4 أرقام أو أكثر)')}${pinField('gPin2', 'إعادة كتابة الرمز السري')}
      <div class="gwarn">⚠️ ${T('الحساب على هذا الجهاز فقط لا يُسترجع إذا نُسي رمزه، وتبقى بياناته على هذا الجهاز وحده. الأفضل ربطه بحساب سحابي لاحقاً من «الإعدادات ← حسابي».')}</div>
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn" id="gGo">${T('إنشاء الحساب')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    const go = async () => {
      if (val('gPin') !== val('gPin2')) return setErr(T(ERR.match));
      const r = await api.authCreate({ name: val('gName'), email: val('gEmail'), pin: val('gPin') });
      if (!r.ok) return setErr(errMsg(r));
      api.authReload();
    };
    $('#gGo').onclick = go; onEnter(go);
    $('#gBack').onclick = chooseView;
  }


  // ---------- الدخول بالجوال (باركود) ----------
  let qrBack = null, qrTimer = null;
  async function qrView(back) {
    qrBack = back || chooseView;
    show(`<h1>📱 ${T('الدخول بالجوال')}</h1>
      <div class="qrwrap"><canvas id="gQrC"></canvas><div class="qrexp" id="gQrE"></div></div>
      <ol class="qrsteps">
        <li>${T('فتح كاميرا الجوال وتوجيهها إلى الرمز، ثم فتح الرابط.')}</li>
        <li>${T('تسجيل الدخول بالحساب السحابي (أول مرة فقط على الجوال).')}</li>
        <li>${T('الضغط على «نعم، أدخلني».')}</li>
      </ol>
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`, 'button');
    $('#gBack').onclick = () => { stopQr(); qrBack(); };
    const r = await api.qrStart();
    if (!r.ok) { setErr(T(ERR.coff)); return; }
    try { LPQR.draw($('#gQrC'), r.url, 280); } catch { setErr(T(ERR.cfail)); return; }
    clearInterval(qrTimer);
    const tick = () => { const s = Math.max(0, Math.round((r.exp - Date.now()) / 1000)); const e = $('#gQrE'); if (e) e.textContent = T('يتجدد الرمز بعد {s} ثانية', { s }); };
    tick(); qrTimer = setInterval(tick, 1000);
  }
  function stopQr() { clearInterval(qrTimer); api.qrStop(); }
  api.onQrExpired(() => { if ($('#gQrC')) qrView(qrBack); });
  api.onQrDone((r) => {
    clearInterval(qrTimer);
    if (r.ok) return api.authReload();
    if (r.need === 'link') return linkOldView(r.user, (pin) => api.qrLink(pin), () => qrView(qrBack));
    if ($('#gQrC')) { setErr(errMsg(r)); setTimeout(() => { if ($('#gQrC')) qrView(qrBack); }, 2500); }
    else if (box.querySelector('.gerr')) setErr(errMsg(r));
  });

  // ---------- نسيان رمز حساب محلي ----------
  // يعيد تعيينه مدير الجهاز إن وُجد؛ وإلا فالبدء من جديد (يُحذف الحساب وبياناته على هذا الجهاز)
  function lostPinView(u) {
    const other = st.users.some(x => x.admin && x.id !== u.id);
    if (other) {
      show(`<h1>${T('نسيان الرمز السري')}</h1>
        <p class="sub">${T('الحساب على هذا الجهاز فقط لا يُسترجع بالبريد. يستطيع مدير هذا الجهاز إعادة تعيين الرمز من: الإعدادات ← إدارة هذا الجهاز.')}</p>
        <div class="grow"><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
      $('#gBack').onclick = () => pinView(u);
      return;
    }
    show(`<h1>${T('نسيان الرمز السري')}</h1>
      <p class="sub">${T('هذا حساب على هذا الجهاز فقط، فلا يمكن استرجاع رمزه. الحل الوحيد: البدء من جديد، أي حذف الحساب وكل بياناته على هذا الجهاز، ثم إنشاء حساب جديد.')}</p>
      <div class="gwarn">⚠️ ${T('تُحذف نهائياً: الفصول والأسماء والدروس والإعدادات المحفوظة في هذا الحساب على هذا الجهاز.')}</div>
      ${field('gEmail', 'للتأكيد: بريد هذا الحساب', 'email')}
      <div class="gerr"></div>
      <div class="grow"><button class="gbtn danger" id="gGo">${T('البدء من جديد')}</button><button class="gbtn sec" id="gBack">${T('رجوع')}</button></div>`);
    $('#gBack').onclick = () => pinView(u);
    let sure = false;
    $('#gGo').onclick = async () => {
      if (!sure) { sure = true; $('#gGo').textContent = T('نعم، احذف الحساب وابدأ من جديد'); setErr(T('تأكيد أخير: لا يمكن التراجع بعد الحذف.')); return; }
      const r = await api.authStartOver({ id: u.id, email: val('gEmail') });
      if (!r.ok) { sure = false; $('#gGo').textContent = T('البدء من جديد'); return setErr(T(r.err === 'nomatch' ? 'البريد لا يطابق بريد هذا الحساب.' : r.err === 'hasadmin' ? 'يوجد مدير لهذا الجهاز يستطيع إعادة تعيين الرمز.' : 'تعذّر الحذف.')); }
      api.authReload();
    };
  }

  // ---------- اللغة والإغلاق ----------
  document.querySelectorAll('#gLang button').forEach(b => b.onclick = () => api.setLang(b.dataset.l));
  $('#gClose').onclick = () => api.close();

  // ---------- البدء ----------
  document.addEventListener('lp-auth', async (e) => {
    st = e.detail;
    document.querySelectorAll('#gLang button').forEach(b => b.classList.toggle('on', b.dataset.l === st.lang));
    // اسم المستخدمة في قائمة «المزيد»
    if (st.user) {
      $('#meName').textContent = st.user.name;
      $('#meAv').textContent = letter(st.user.name);
      $('#meAv').style.background = colorFor(st.user.name);
      gate.classList.remove('on');
      return;
    }
    gate.classList.add('on');
    if (st.setup) setupView(); else chooseView();
  });

  // ---------- تبديل المستخدمة وقفل الحسابات ----------
  // الخروج: على جهاز مشترك تختار صاحبة الحساب السحابي إبقاء بياناتها مشفّرة أو مسحها
  async function logout() {
    const s2 = await api.authState(), u = s2.user;
    if (!u || u.guest || !u.cloud || s2.personal || s2.logoutChoice) {
      const r = await api.authLogout();
      if (r && !r.ok && r.pending) outDialog(s2, r.pending);
      return;
    }
    outDialog(s2);
  }
  LP.logout = logout;
  function outDialog(s2, pending) {
    let d = $('#lpOut');
    if (!d) { d = document.createElement('div'); d.id = 'lpOut'; d.dir = I18N.dir(); document.body.appendChild(d); }
    d.innerHTML = `<div class="oBox">
      <h2>🚪 ${T('الخروج من هذا الجهاز')}</h2>
      <p class="sub">${T('هذا ليس جهازاً شخصياً. ماذا يُفعل بالبيانات المحفوظة عليه؟ نسختها في السحابة تبقى في الحالتين.')}</p>
      ${pending ? `<div class="oWarn">⚠ ${T('{n} من التعديلات لم تُرفع للسحابة بعد (لا يوجد اتصال). مسحها الآن يُضيّعها.', { n: pending })}</div>` : ''}
      <button class="oOpt" data-w="0"><b>🔒 ${T('الاحتفاظ بالبيانات مشفّرة هنا')}</b><span>${T('لا يستطيع أحد فتحها غير صاحب الحساب. الدخول القادم على هذا الجهاز أسرع ويعمل دون إنترنت.')}</span></button>
      <button class="oOpt del" data-w="1"><b>🗑 ${T(pending ? 'المسح على أي حال' : 'مسح البيانات من هذا الجهاز')}</b><span>${T('مناسب لجهاز يُستخدم مرة واحدة. تُنزَّل البيانات من السحابة عند الدخول القادم.')}</span></button>
      <label class="oRem"><input type="checkbox" id="oRem"> ${T('تذكّر هذا الاختيار لهذا الجهاز')}</label>
      <div class="grow" style="justify-content:flex-end"><button class="gbtn sec" id="oCancel">${T('إلغاء')}</button></div></div>`;
    d.classList.add('on');
    $('#oCancel').onclick = () => d.classList.remove('on');
    d.querySelectorAll('.oOpt').forEach(b => b.onclick = async () => {
      d.querySelectorAll('button').forEach(x => x.disabled = true);
      const wipe = b.dataset.w === '1';
      const r = await api.authLogout({ wipe, remember: $('#oRem').checked, force: !!pending });
      if (r && !r.ok && r.pending) outDialog(s2, r.pending);
    });
  }
  $('#switchUser').onclick = logout;
  $('#lockSwitch').onclick = logout;
  // تعديلات وصلت من جهاز آخر أثناء العمل
  api.onCloudRemote(() => LP.toast(T('وصلت تحديثات من جهاز آخر'), T('تحديث'), () => api.authReload(), 12000));
  const LOCK_ERR = {
    offline: 'لم يُتحقق من كلمة المرور: هذا الجهاز دُخل إليه بالباركود، فأول فتح يدوي يحتاج اتصالاً بالإنترنت. ويمكن «تبديل المستخدم» ثم الدخول بالباركود.',
    qpoff: 'خمس محاولات خاطئة: أُوقف رمز القفل السريع. يلزم إدخال كلمة المرور الكاملة.',
    cmany: 'محاولات كثيرة. يُرجى الانتظار قليلاً ثم المحاولة مرة أخرى.'
  };
  let ulBusy = false;
  const unlock = async () => {
    if (ulBusy) return; ulBusy = true; $('#lockGo').disabled = true;
    const v = $('#lockPin').value;
    if (!v) { ulBusy = false; $('#lockGo').disabled = false; return; }
    $('#lockErr').textContent = v.length >= 6 ? T('جارٍ التحقق…') : '';
    let r; try { r = await LP_unlock(v); } finally { ulBusy = false; $('#lockGo').disabled = false; }
    if (!r.ok) { $('#lockErr').textContent = r.err && LOCK_ERR[r.err] ? T(LOCK_ERR[r.err]) : r.wait ? errMsg(r) : T('كلمة المرور أو الرمز غير صحيح.'); $('#lockPin').value = ''; $('#lockPin').focus(); }
    else { $('#lockErr').textContent = ''; $('#lockWarn').textContent = ''; if (r.full) offerQuickPin(); }
  };
  $('#lockGo').onclick = unlock;
  // تنبيه: لوحة مفاتيح عربية أو Caps Lock (النقاط لا تُظهر الخطأ)
  $('#lockPin').addEventListener('keydown', e => {
    e.stopPropagation();
    if (e.key === 'Enter') return unlock();
    const caps = e.getModifierState && e.getModifierState('CapsLock');
    const ar = e.key && e.key.length === 1 && /[\u0600-\u06FF]/.test(e.key);
    $('#lockWarn').textContent = ar ? T('⌨️ لوحة المفاتيح عربية الآن (Alt+Shift للتبديل)') : caps ? T('⇪ زر Caps Lock مفعّل') : '';
  });
  // رمز القفل السريع: يُقترح بعد فتح القفل بكلمة المرور الكاملة
  const qpAsked = () => { try { return localStorage.getItem('lp-qpAsk') === 'no'; } catch { return false; } };
  async function offerQuickPin() {
    if (qpAsked() || !api.quickPinState) return;
    const q = await api.quickPinState(); if (q.has) return;
    LP.toast(T('تعيين «رمز قفل سريع» لهذا الجهاز؟ أسهل من كلمة المرور أمام الطلاب.'), T('تعيين'), () => LP.quickPinDialog(), 9000);
  }
  LP.quickPinDialog = (onDone) => {
    const d = document.createElement('div'); d.className = 'qpDlg';
    d.innerHTML = `<div class="lockCard"><div class="lockIc">🔢</div><h3>${T('رمز القفل السريع')}</h3>
      <p class="muted" style="font-size:13px">${T('من 4 إلى 6 أرقام، لفتح القفل على هذا الجهاز فقط. لا يُستخدم للدخول من جهاز آخر، وبعد 5 محاولات خاطئة يتوقف ويلزم إدخال كلمة المرور.')}</p>
      <input type="password" id="qp1" inputmode="numeric" maxlength="6" placeholder="${T('الرمز')}">
      <input type="password" id="qp2" inputmode="numeric" maxlength="6" placeholder="${T('إعادة كتابة الرمز')}">
      <div class="lockErr" id="qpErr"></div>
      <button class="pbtn accent" id="qpSave">${T('حفظ')}</button>
      <button class="pbtn" id="qpLater">${T('لاحقاً')}</button>
      <button class="pbtn" id="qpNever" style="font-size:12px;opacity:.75">${T('لا تسألني مرة أخرى')}</button></div>`;
    document.body.appendChild(d);
    const close = () => d.remove();
    d.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') d.querySelector('#qpSave').click(); if (e.key === 'Escape') close(); }));
    setTimeout(() => d.querySelector('#qp1').focus(), 30);
    d.querySelector('#qpLater').onclick = close;
    d.querySelector('#qpNever').onclick = () => { try { localStorage.setItem('lp-qpAsk', 'no'); } catch {} close(); };
    d.querySelector('#qpSave').onclick = async () => {
      const a1 = d.querySelector('#qp1').value, a2 = d.querySelector('#qp2').value;
      if (!/^\d{4,6}$/.test(a1)) { d.querySelector('#qpErr').textContent = T('الرمز من 4 إلى 6 أرقام.'); return; }
      if (a1 !== a2) { d.querySelector('#qpErr').textContent = T('الرمزان غير متطابقين.'); return; }
      const r = await api.quickPin(a1);
      if (r && r.ok) { close(); LP.toast(T('حُفظ رمز القفل السريع ✓')); onDone && onDone(); }
      else d.querySelector('#qpErr').textContent = T('تعذّر الحفظ');
    };
  };
})();
