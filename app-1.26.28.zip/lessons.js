// مكتبة الدروس بالمواد + دفتر الدروس (العنوان والأهداف) + الاستيراد من إكسل
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const palette = ['#e5484d', '#fd7e14', '#f5b400', '#2fb344', '#12b886', '#228be6', '#4c6ef5', '#ae3ec9', '#e64980'];
  const colorFor = (t) => { let h = 0; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return palette[h % palette.length]; };
  const firstLetter = (t) => (String(t).trim().replace(/^ال(?=\S{2})/, '').match(/[\p{L}\p{N}]/u) || ['؟'])[0].toUpperCase();
  const libBody = $('#libBody'), libSearch = $('#libSearch'), libAdd = $('#libAdd'), subjBar = $('#subjBar');

  let prof = {}, subjects = [], sharedItems = [], libTab = 'mine', subj = 'all', libView = 'grid', planTermId = null;
  const isGuest = () => !!(LP.auth && LP.auth.user && LP.auth.user.guest);
  const isAdmin = () => !!(LP.auth && LP.auth.user && LP.auth.user.admin);
  const mine = () => prof.library || [];
  const saveMine = () => api.setSettings({ library: mine() });
  const subjOf = (id) => subjects.find(x => x.id === id) || null;
  const fmtDate = (ts) => { const loc = { ar: 'ar-SA-u-ca-gregory', en: 'en-GB', fr: 'fr-FR' }[I18N.lang] || 'ar'; try { return new Date(ts).toLocaleDateString(loc, { day: 'numeric', month: 'short', year: 'numeric' }); } catch { return ''; } };

  async function loadAll() {
    prof = await api.getSettings();
    if (!isGuest()) { subjects = await api.subjectsList(); sharedItems = await api.sharedList(); }
    else subjects = [];
    if (subj === 'all' && prof.mySubject && subjects.some(x => x.id === prof.mySubject) && !loadAll.done) subj = prof.mySubject;
    loadAll.done = true;
  }

  // ================= دفتر الدروس (لعنوان الحصة والأهداف) =================
  const allLessons = () => [...mine(), ...sharedItems.filter(i => !i.deleted)];
  LP.lessonBook = {
    forGrade(cls) {
      const g = LP.classGrade ? LP.classGrade(cls) : 0;
      return allLessons().filter(l => !g || !l.grade || +l.grade === g).map(l => ({ title: l.name, goals: l.goals || [], subject: (subjOf(l.subject) || {}).name || '', grade: l.grade ? LP.gradeLabel(l.grade) : '' }));
    },
    forUrl(url) {
      const l = allLessons().find(x => x.url && x.url === url);
      return l ? { title: l.name, goals: l.goals || [], subject: (subjOf(l.subject) || {}).name || '' } : null;
    },
    refresh: loadAll
  };

  // ================= شريط المواد =================
  function counts(list) {
    const c = { all: list.length, none: 0 };
    for (const l of list) { if (l.subject && subjOf(l.subject)) c[l.subject] = (c[l.subject] || 0) + 1; else c.none++; }
    return c;
  }
  function currentList() {
    if (libTab === 'mine') return mine();
    if (libTab === 'shared') return sharedItems.filter(i => !i.deleted);
    return sharedItems.filter(i => i.deleted);
  }
  function renderSubjBar() {
    if (libTab === 'trash' || isGuest()) { subjBar.innerHTML = ''; subjBar.style.display = 'none'; return; }
    subjBar.style.display = '';
    const c = counts(currentList());
    const chip = (id, icon, name, color, n, extra = '') => `<button class="schip ${subj === id ? 'on' : ''}" data-s="${id}" style="--sc:${color}"${extra}><span class="si">${icon}</span><span>${esc(name)}</span><small>${n || 0}</small></button>`;
    subjBar.innerHTML = chip('all', '📚', T('كل المواد'), 'var(--accent)', c.all)
      + subjects.map(x => chip(x.id, x.icon, x.name, x.color, c[x.id], prof.mySubject === x.id ? ` title="${T('مادتي')} ⭐"` : '')).join('')
      + (c.none ? chip('none', '🗂', T('غير مصنّفة'), '#868e96', c.none) : '')
      + `<button class="schip add" id="subjAdd">＋ ${T('مادة')}</button>`;
    subjBar.querySelectorAll('[data-s]').forEach(b => {
      b.onclick = () => { subj = b.dataset.s; renderLib(); };
      b.oncontextmenu = (e) => { e.preventDefault(); const x = subjOf(b.dataset.s); if (x) subjectDialog(x); };
    });
    $('#subjAdd').onclick = () => subjectDialog(null);
  }

  // ================= البطاقات =================
  function card(l, opts) {
    const el = document.createElement('div'); el.className = 'card' + (opts.deleted ? ' deleted' : '') + (!l.url ? ' nofile' : ''); el.title = l.url || l.name;
    const kind = /^pdf:/.test(l.url) ? '📄' : /^ppt:/.test(l.url) ? '📊' : !l.url ? '📝' : '';
    const sb = subjOf(l.subject);
    const meta = opts.deleted
      ? T('حذفته: {name}', { name: esc(l.deleted.byName) }) + ' · ' + esc(fmtDate(l.deleted.at))
      : [subj === 'all' && sb ? `${sb.icon} ${esc(sb.name)}` : '', l.grade ? esc(LP.gradeLabel(l.grade)) : '', l.unit ? esc(l.unit) : '', (l.goals || []).length ? '🎯 ' + l.goals.length : '', opts.shared ? T('أضافته: {name}', { name: esc(l.byName || '') }) : ''].filter(Boolean).join(' · ') || esc(fmtDate(l.added));
    el.innerHTML = `<div class="th" style="${l.thumb ? `background-image:url('${l.thumb}')` : `background:${sb ? sb.color : colorFor(l.name)}`}">${l.thumb ? '' : `<span class="big">${esc(firstLetter(l.name))}</span>`}${kind ? `<span class="kind">${kind}</span>` : ''}</div>
      <div class="bd"><div class="nm" dir="auto">${esc(l.name)}</div><div class="dt">${meta}</div></div>
      <div class="acts"></div>`;
    const acts = el.querySelector('.acts');
    const btn = (icon, tip, fn, cls) => { const b = document.createElement('button'); if (cls) b.className = cls; b.textContent = icon; b.title = T(tip); b.onclick = e => { e.stopPropagation(); fn(b); }; acts.appendChild(b); return b; };
    if (opts.deleted) {
      btn('↺', 'استرجاع', async () => { await api.sharedRestore(l.id); LP.toast(T('تم استرجاع الدرس')); refresh(); });
      if (isAdmin()) btn('🗑', 'حذف نهائي', async (b) => { if (!b.dataset.sure) return sure(b); await api.sharedPurge(l.id); refresh(); }, 'del');
      return el;
    }
    if (l.url) btn('⧉', 'فتح في تبويب جديد', () => { LP.closePanels(); open(l, true); });
    if (LP.cal && LP.cal.terms.length && !isGuest()) {
      const tm = planTerm(), wk = tm ? LP.cal.wksOf(tm, keyOf(l)) : [];
      btn(wk.length ? '📅 ' + LP.cal.wkLabel(wk) : '📅', 'توزيع على أسبوع أو أكثر', () => weekChooser(l), wk.length ? 'wk' : '');
      el.draggable = true;
      el.addEventListener('dragstart', e => {
        e.dataTransfer.setData('text/lp-lesson', keyOf(l));
        const sec = el.closest('.wsec'); e.dataTransfer.setData('text/lp-from', sec ? sec.dataset.week || '0' : '0');
        e.dataTransfer.effectAllowed = 'copyMove'; el.classList.add('dragging');
      });
      el.addEventListener('dragend', () => el.classList.remove('dragging'));
    }
    if (opts.canEdit) {
      btn('✎', 'تعديل', () => editDialog(l, opts.shared));
      btn('🗑', 'حذف', async (b) => {
        if (!b.dataset.sure) return sure(b);
        if (opts.shared) { await api.sharedDelete(l.id); LP.toast(T('نُقل الدرس إلى المحذوفات')); refresh(); }
        else { prof.library = mine().filter(x => x !== l); saveMine(); renderLib(); LP.toast(T('تم حذف الدرس من المكتبة')); }
      }, 'del');
    }
    if (!opts.shared && !isGuest()) btn('⇪', 'مشاركة مع القسم', async () => {
      const r = await api.sharedAdd({ name: l.name, url: l.url, thumb: l.thumb, subject: l.subject, grade: l.grade, unit: l.unit, goals: l.goals });
      LP.toast(T(r.ok ? 'أُضيف الدرس إلى مكتبة القسم' : 'هذا الدرس موجود في مكتبة القسم'));
      sharedItems = await api.sharedList();
    });
    el.addEventListener('click', e => { if (e.target.closest('.acts')) return; LP.closePanels(); open(l, false); });
    return el;
  }
  function sure(b) {
    b.dataset.sure = 1; b.textContent = T('متأكدة؟'); b.style.width = 'auto'; b.style.padding = '0 8px'; b.style.background = 'var(--danger)';
    setTimeout(() => { if (b.isConnected) renderLib(); }, 3000);
  }
  // فتح الدرس: يفتح الملف أو الرابط، ويضع عنوانه وأهدافه في الشريط العلوي تلقائياً
  // ---------- إعادة ربط الملف إن تغيّر مكانه (حرف فلاشة مختلف أو مجلد نُقل) ----------
  const localPath = (u) => {
    if (/^(pdf|ppt):/.test(u)) return u.slice(4);
    if (/^file:/i.test(u)) { try { let p = decodeURI(u.replace(/^file:\/+/i, '')); if (/^[A-Za-z]:/.test(p)) p = p.replace(/\//g, '\\'); else p = '/' + p; return p; } catch { return null; } }
    return null;
  };
  const withPath = (u, np) => /^(pdf|ppt):/.test(u) ? u.slice(0, 4) + np : 'file:///' + np.replace(/\\/g, '/').replace(/^\/+/, '');
  const dirOf = (p) => p.replace(/[\\/][^\\/]*$/, '');
  const baseOf = (p) => p.split(/[\\/]/).pop();
  // ننقل كل الدروس التي في نفس المجلد القديم إلى المكان الجديد دفعة واحدة
  async function moveAll(oldP, newP) {
    let od = dirOf(oldP), nd = dirOf(newP);
    // تغيّر حرف الفلاشة فقط (E: ← F:): نصحّح كل الدروس التي كانت على نفس الفلاشة
    if (/^[A-Za-z]:/.test(oldP) && /^[A-Za-z]:/.test(newP) && oldP.slice(2).toLowerCase() === newP.slice(2).toLowerCase()) { od = oldP.slice(0, 2); nd = newP.slice(0, 2); }
    const low = od.toLowerCase();
    let n = 0;
    const fix = (u) => { const p = localPath(u); if (!p) return null; if (p === oldP) return withPath(u, newP); if (p.toLowerCase().startsWith(low + '\\') || p.toLowerCase().startsWith(low + '/')) return withPath(u, nd + p.slice(od.length)); return null; };
    for (const l of mine()) { const nu = l.url && fix(l.url); if (nu) { l.url = nu; n++; } }
    if (n) saveMine();
    for (const l of sharedItems) { const nu = l.url && l.canEdit && fix(l.url); if (nu) { l.url = nu; n++; api.sharedUpdate(l.id, { url: nu }); } }
    return n;
  }
  async function relink(l) {
    const p = localPath(l.url || ''); if (!p) return true;
    const r = await api.fileLocate(p);
    if (r.path === p) return true;
    if (r.path) { const n = await moveAll(p, r.path); l.url = withPath(l.url, r.path); if (n > 1) LP.toast(T('تغيّر حرف الفلاشة — حُدّث مكان {n} درس تلقائياً', { n })); return true; }
    return new Promise((res) => {
      if (!$('#libPanel').classList.contains('on')) LP.openPanel($('#libPanel'));     // النافذة الصغيرة داخل لوحة المكتبة
      openDlg(`<h3>📂 ${T('لم يُعثر على ملف الدرس')}</h3>
        <p>${T('ربما نُقل الملف، أو الفلاشة غير موصولة.')}</p>
        <div class="muted" style="font-size:12px;direction:ltr;text-align:start;word-break:break-all">${esc(p)}</div>
        <p class="muted" style="font-size:12.5px">${T('إذا اخترتِ مكانه الجديد، يُحدَّث مكان كل الدروس الموجودة في نفس المجلد معاً.')}</p>
        <div class="gdlg-row"><button class="pri" id="rlPick">${T('أين هذا الملف؟')}</button><button id="rlNo">${T('إلغاء')}</button></div>`);
      $('#rlNo').onclick = () => { closeDlg(); res(false); };
      dlg.addEventListener('click', function once(e) { if (e.target === dlg) { dlg.removeEventListener('click', once); res(false); } });
      $('#rlPick').onclick = async () => {
        const np = await api.filePickFor(baseOf(p)); if (!np) return;
        const n = await moveAll(p, np); l.url = withPath(l.url, np); closeDlg(); LP.closePanels();
        LP.toast(T('حُدّث مكان {n} درس ✓', { n: Math.max(1, n) })); res(true);
      };
    });
  }
  async function open(l, newTab) {
    if (l.url && !(await relink(l))) return;
    if (l.url) {
      if (newTab && !/^(pdf|ppt):/.test(l.url)) LP.newTab(l.url); else LP.openUrl(l.url);
    }
    applyToSession(l, !l.url);
  }
  async function applyToSession(l, showGoals) {
    if (!LP.session) return;
    if (!LP.session.S) await LP.session.ensure(false);
    LP.session.setTitle(l.name, (l.goals || []).length ? l.goals : null, { subject: (subjOf(l.subject) || {}).name || '' });
    if (LP.toggleGroupBar && !$('#grpBar').classList.contains('on')) LP.toggleGroupBar(true);
    if ((l.goals || []).length && (showGoals || !l.url) && LP.showGoals) LP.showGoals(true);
  }

  // ================= العرض =================
  function renderLib() {
    $$('#libTabs button').forEach(b => b.classList.toggle('on', b.dataset.v === libTab));
    $('#libTabs [data-v="shared"]').style.display = isGuest() ? 'none' : '';
    $('#libTabs [data-v="trash"]').style.display = isGuest() ? 'none' : '';
    const cur = LP.currentUrl();
    libAdd.disabled = !cur || LP.isWelcome(cur);
    libAdd.style.display = libTab === 'trash' ? 'none' : '';
    $('#libMore').style.display = libTab === 'trash' ? 'none' : '';
    renderSubjBar();
    const q = libSearch.value.trim().toLowerCase();
    const match = l => !q || l.name.toLowerCase().includes(q) || String(l.url || '').toLowerCase().includes(q) || String(l.byName || '').toLowerCase().includes(q)
      || (l.goals || []).some(g => g.toLowerCase().includes(q)) || String(l.unit || '').toLowerCase().includes(q) || ((subjOf(l.subject) || {}).name || '').toLowerCase().includes(q);
    let list = currentList();
    const opts = (l) => libTab === 'mine' ? { canEdit: true } : libTab === 'shared' ? { shared: true, canEdit: l.canEdit } : { shared: true, deleted: true };
    libBody.innerHTML = '';
    if (libTab === 'trash' && isAdmin() && list.length) {
      const bar = document.createElement('div'); bar.className = 'trashbar';
      bar.innerHTML = `<span class="muted">${T('تُحذف الدروس نهائياً بعد 30 يوماً.')}</span>`;
      const b = document.createElement('button'); b.className = 'pbtn'; b.textContent = T('إفراغ المحذوفات');
      b.onclick = async () => { if (!b.dataset.sure) { b.dataset.sure = 1; b.textContent = T('متأكدة؟'); b.style.background = 'var(--danger)'; return; } await api.sharedPurge(); refresh(); };
      bar.appendChild(b); libBody.appendChild(bar);
    }
    // البحث يعمل في كل المواد
    if (!q && libTab !== 'trash') {
      if (subj === 'none') list = list.filter(l => !l.subject || !subjOf(l.subject));
      else if (subj !== 'all') list = list.filter(l => l.subject === subj);
    }
    const items = list.filter(match);
    if (!items.length) {
      const msg = q ? 'لا توجد دروس بهذا الاسم.'
        : libTab === 'mine' ? 'المكتبة فارغة.<br>افتحي درساً ثم اضغطي «＋ حفظ الدرس الحالي» ليظهر هنا دائماً.'
        : libTab === 'shared' ? 'مكتبة القسم فارغة.<br>أي معلمة تستطيع مشاركة دروسها هنا لتستفيد منها الزميلات.'
        : 'لا توجد دروس محذوفة.<br>الدروس المحذوفة من مكتبة القسم تبقى هنا 30 يوماً.';
      libBody.insertAdjacentHTML('beforeend', `<div class="empty">${T(msg)}</div>`);
      if (libTab !== 'trash' && !q && subj !== 'all' && subj !== 'none') {
        const sb = subjOf(subj);
        if (sb) libBody.insertAdjacentHTML('beforeend', `<div class="empty" style="padding-top:0"><button class="pbtn" id="subjEditHere">✎ ${T('تعديل المادة')}</button></div>`);
        const se = $('#subjEditHere'); if (se) se.onclick = () => subjectDialog(sb);
      }
      return;
    }
    if (libTab === 'trash' || q) { const g = document.createElement('div'); g.className = 'lib'; items.forEach(l => g.appendChild(card(l, opts(l)))); libBody.appendChild(g); return; }
    if (libView === 'weeks') { renderWeeks(items, opts); return; }
    thisWeekStrip(items, opts);
    // تجميع: المادة (في «كل المواد») ← الصف ← الوحدة
    const groupBy = (arr, keyFn) => { const m = new Map(); for (const x of arr) { const k = keyFn(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); } return m; };
    const renderGrades = (arr, host) => {
      const byGrade = groupBy(arr, l => +l.grade || 0);
      const keys = [...byGrade.keys()].sort((a, b) => (a || 99) - (b || 99));
      for (const gk of keys) {
        if (keys.length > 1 || gk) host.insertAdjacentHTML('beforeend', `<div class="lsec">${gk ? esc(LP.gradeLabel(gk)) : T('بدون صف')}</div>`);
        const byUnit = groupBy(byGrade.get(gk), l => l.unit || '');
        for (const [uk, us] of byUnit) {
          if (uk) host.insertAdjacentHTML('beforeend', `<div class="lsub">${esc(uk)}</div>`);
          const g = document.createElement('div'); g.className = 'lib'; us.forEach(l => g.appendChild(card(l, opts(l)))); host.appendChild(g);
        }
      }
    };
    if (subj === 'all') {
      const bySubj = groupBy(items, l => (l.subject && subjOf(l.subject)) ? l.subject : '');
      const order = [...subjects.map(x => x.id).filter(id => bySubj.has(id)), ...(bySubj.has('') ? [''] : [])];
      for (const sk of order) {
        const sb = subjOf(sk);
        libBody.insertAdjacentHTML('beforeend', `<div class="lsubj" style="--sc:${sb ? sb.color : '#868e96'}">${sb ? sb.icon + ' ' + esc(sb.name) : '🗂 ' + T('غير مصنّفة')}</div>`);
        renderGrades(bySubj.get(sk), libBody);
      }
    } else renderGrades(items, libBody);
  }
  async function refresh() { await loadAll(); renderLib(); }

  // ================= توزيع المنهج على أسابيع الفصل الدراسي =================
  const keyOf = (l) => String(l.id);
  function planTerm() {
    if (!LP.cal || !LP.cal.terms.length) return null;
    const ts = LP.cal.terms;
    return ts.find(x => x.id === planTermId) || (LP.cal.at() || {}).term || ts.find(x => Date.now() < LP.cal.termRange(x)[0]) || ts[ts.length - 1];
  }
  const libDays = (w) => `${LP.cal.short(w.from)} — ${LP.cal.short(w.to)}`;
  // «دروس هذا الأسبوع» أعلى المكتبة
  function thisWeekStrip(items, opts) {
    if (!LP.cal) return;
    const n = LP.cal.at(); if (!n || !n.week) return;
    const list = items.filter(l => LP.cal.wksOf(n.term, keyOf(l)).includes(n.week));
    if (!list.length) return;
    libBody.insertAdjacentHTML('beforeend', `<div class="lsubj wknow">📅 ${T('دروس هذا الأسبوع')} — ${T('الأسبوع {n}', { n: n.week })}${n.value ? ` · 🌟 ${esc(n.value)}` : ''}</div>`);
    const g = document.createElement('div'); g.className = 'lib'; list.forEach(l => g.appendChild(card(l, opts(l)))); libBody.appendChild(g);
  }
  function renderWeeks(items, opts) {
    const tm = planTerm();
    if (!tm) {
      libBody.insertAdjacentHTML('beforeend', `<div class="empty">${T('ضعي التقويم الدراسي أولاً (تاريخ الفصل وأسابيعه)، ثم وزّعي الدروس على الأسابيع.')}<br><button class="pbtn accent" id="wkCal">📅 ${T('التقويم الدراسي')}</button></div>`);
      $('#wkCal').onclick = () => { LP.closePanels(); LP.openCalendar(); };
      return;
    }
    const W = LP.cal.weeks(tm).filter(w => w.on), pl = LP.cal.planOf(tm), now = LP.cal.at();
    const curW = now && now.term.id === tm.id ? now.week : 0;
    const head = document.createElement('div'); head.className = 'wkhead';
    head.innerHTML = `<select id="wkTerm">${LP.cal.terms.map(x => `<option value="${x.id}" ${x.id === tm.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
      <button class="pbtn" id="wkAuto" title="${T('توزيع الدروس الظاهرة بالترتيب على أسابيع الفصل')}">⚡ ${T('توزيع تلقائي')}</button>
      ${LP.cal.terms.length > 1 ? `<button class="pbtn" id="wkCopy">⧉ ${T('نسخ التوزيع من فصل آخر')}</button>` : ''}
      <span class="muted">${T('اسحبي الدرس إلى أسبوعه، أو اضغطي 📅 على البطاقة. مع Ctrl يُضاف الأسبوع ويبقى الدرس في أسبوعه الأول.')}</span>`;
    libBody.appendChild(head);
    $('#wkTerm').onchange = (e) => { planTermId = e.target.value; renderLib(); };
    const drop = (host, num) => {
      host.addEventListener('dragover', e => { if ([...e.dataTransfer.types].includes('text/lp-lesson')) { e.preventDefault(); e.dataTransfer.dropEffect = e.ctrlKey && num ? 'copy' : 'move'; host.classList.add('over'); host.classList.toggle('copy', !!(e.ctrlKey && num)); } });
      host.addEventListener('dragleave', () => host.classList.remove('over', 'copy'));
      host.addEventListener('drop', async e => {
        e.preventDefault(); host.classList.remove('over', 'copy');
        const k = e.dataTransfer.getData('text/lp-lesson'); if (!k) return;
        const from = +e.dataTransfer.getData('text/lp-from') || 0, cur = LP.cal.wksOf(tm, k);
        let v;
        if (!num) v = from ? cur.filter(x => x !== from) : [];          // إلى «غير موزّعة»: يُزال من أسبوع المصدر
        else if (e.ctrlKey) v = [...cur, num];                            // Ctrl: إضافة أسبوع
        else v = [...cur.filter(x => x !== from), num];                  // نقل من أسبوع المصدر
        if (!num && !from) return;
        await LP.cal.setPlan(tm.id, { [k]: v }); renderLib();
      });
    };
    const section = (num, title, list, cls) => {
      const sec = document.createElement('div'); sec.className = 'wsec ' + (cls || ''); if (num) sec.dataset.week = num;
      sec.innerHTML = `<div class="wsh">${title}<small>${list.length || ''}</small></div>`;
      const g = document.createElement('div'); g.className = 'lib wdrop'; list.forEach(l => g.appendChild(card(l, opts(l))));
      if (!list.length) g.innerHTML = `<div class="wempty">${T('أفلتي الدروس هنا')}</div>`;
      sec.appendChild(g); drop(sec, num); libBody.appendChild(sec);
    };
    const has = (l, n) => LP.cal.wksOf(tm, keyOf(l)).includes(n);
    const un = items.filter(l => !W.some(w => has(l, w.num)));
    section(0, '🗂 ' + T('غير موزّعة'), un, 'wun');
    for (const w of W) section(w.num, `<b>${T('الأسبوع {n}', { n: w.num })}</b> <span>${esc(libDays(w))}</span>${w.value ? ` <span class="wval">🌟 ${esc(w.value)}</span>` : ''}${w.num === curW ? ` <em>${T('الآن')}</em>` : ''}`, items.filter(l => has(l, w.num)), w.num === curW ? 'now' : '');
    const nowSec = libBody.querySelector('.wsec.now'); if (nowSec) setTimeout(() => nowSec.scrollIntoView({ block: 'nearest' }), 50);
    LP.sureBtn($('#wkAuto'), async () => {
      const arr = items.slice().sort((a, b) => (+a.grade || 0) - (+b.grade || 0) || String(a.unit || '').localeCompare(String(b.unit || ''), 'ar') || (a.added || 0) - (b.added || 0));
      if (!arr.length || !W.length) return;
      // بالتساوي: إن كانت الدروس أقل من الأسابيع تتباعد، وإن كانت أكثر يأخذ كل أسبوع أكثر من درس
      const patch = {};
      arr.forEach((l, i) => { patch[keyOf(l)] = W[Math.min(W.length - 1, Math.floor(i * W.length / arr.length))].num; });
      await LP.cal.setPlan(tm.id, patch); renderLib(); LP.toast(T('وُزّع {n} درساً على {w} أسبوعاً', { n: arr.length, w: W.length }));
    });
    const cp = $('#wkCopy'); if (cp) cp.onclick = () => {
      openDlg(`<h3>⧉ ${T('نسخ التوزيع من فصل آخر')}</h3><p class="muted">${T('تُنسخ أرقام الأسابيع كما هي (الأسبوع 3 ← الأسبوع 3) للدروس غير الموزّعة في هذا الفصل.')}</p>
        <div class="gdlg-row">${LP.cal.terms.filter(x => x.id !== tm.id).map(x => `<button data-src="${x.id}">${esc(x.name)}</button>`).join('')}</div><div class="gdlg-row"><button id="cpNo">${T('إلغاء')}</button></div>`);
      $('#cpNo').onclick = closeDlg;
      dcard.querySelectorAll('[data-src]').forEach(b => b.onclick = async () => {
        const src = LP.cal.planOf(LP.cal.terms.find(x => x.id === b.dataset.src)), cur = LP.cal.planOf(tm), patch = {};
        for (const [k, v] of Object.entries(src)) { if (cur[k]) continue; const ok = (Array.isArray(v) ? v : [v]).filter(n => W.some(w => w.num === +n)); if (ok.length) patch[k] = ok; }
        await LP.cal.setPlan(tm.id, patch); closeDlg(); renderLib(); LP.toast(T('نُسخ توزيع {n} درساً', { n: Object.keys(patch).length }));
      });
    };
  }
  function weekChooser(l) {
    const tm = planTerm(); if (!tm) return;
    const W = LP.cal.weeks(tm).filter(w => w.on), sel = new Set(LP.cal.wksOf(tm, keyOf(l)));
    openDlg(`<h3>📅 ${esc(l.name)}</h3><p class="muted">${esc(tm.name)} — ${T('اختاري أسبوعاً أو أكثر (للدرس الممتد أو المكرر).')}</p>
      <div class="wkpick">${W.map(w => `<button class="${sel.has(w.num) ? 'pri' : ''}" data-w="${w.num}" title="${esc(libDays(w))}">${T('الأسبوع {n}', { n: w.num })}${w.value ? `<small>🌟 ${esc(w.value)}</small>` : ''}</button>`).join('')}</div>
      <div class="gdlg-row"><button class="pri" id="wkOk">${T('حفظ')}</button><button id="wkNone">${T('إلغاء التوزيع')}</button><button id="wkNo">${T('إغلاق')}</button></div>`);
    $('#wkNo').onclick = closeDlg;
    dcard.querySelectorAll('[data-w]').forEach(b => b.onclick = () => { const n = +b.dataset.w; sel.has(n) ? sel.delete(n) : sel.add(n); b.classList.toggle('pri', sel.has(n)); });
    const set = async (v) => { await LP.cal.setPlan(tm.id, { [keyOf(l)]: v }); closeDlg(); renderLib(); };
    $('#wkOk').onclick = () => set([...sel]);
    $('#wkNone').onclick = () => set(0);
  }
  // زر عرض المكتبة حسب الأسابيع
  (() => {
    const b = document.createElement('button'); b.className = 'pbtn'; b.id = 'libWeeks'; b.textContent = '📅 ' + T('الأسابيع');
    b.title = T('عرض الدروس حسب أسابيع الفصل الدراسي (توزيع المنهج)');
    $('#libMore').before(b);
    b.onclick = () => { libView = libView === 'weeks' ? 'grid' : 'weeks'; b.classList.toggle('accent', libView === 'weeks'); api.setSettings({ libView }); renderLib(); };
    document.addEventListener('lp-auth', async (e) => { if (e.detail && e.detail.user) { const p = await api.getSettings(); libView = p.libView === 'weeks' ? 'weeks' : 'grid'; b.classList.toggle('accent', libView === 'weeks'); } });
  })();

  // ================= نافذة صغيرة عامة =================
  const dlg = document.createElement('div'); dlg.className = 'gdlg ldlg'; dlg.innerHTML = '<div class="gdlg-card"></div>';
  document.getElementById('libPanel').appendChild(dlg);
  const dcard = dlg.querySelector('.gdlg-card');
  const openDlg = (html) => { dcard.innerHTML = html; dlg.classList.add('on'); dcard.querySelectorAll('input,textarea,select').forEach(i => i.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') closeDlg(); })); };
  const closeDlg = () => dlg.classList.remove('on');
  dlg.addEventListener('click', e => { if (e.target === dlg) closeDlg(); });
  const subjOptions = (sel) => `<option value="">${T('غير مصنّفة')}</option>` + subjects.map(x => `<option value="${x.id}" ${x.id === sel ? 'selected' : ''}>${x.icon} ${esc(x.name)}</option>`).join('');

  // ---------- تعديل / حفظ درس ----------
  async function editDialog(l, shared, isNew, onSave) {
    const d = l || {};
    openDlg(`<h3>${T(isNew ? 'حفظ الدرس في المكتبة' : 'تعديل الدرس')}</h3>
      <div class="lform">
        <label>${T('عنوان الحصة')}<input id="lfName" value="${esc(d.name || '')}" dir="auto"></label>
        <div class="lrow"><label>${T('المادة')}<select id="lfSubj">${subjOptions(d.subject)}</select></label>
          <label>${T('الصف')}<select id="lfGrade">${LP.gradeOptions(d.grade || 0)}</select></label></div>
        <label>${T('الوحدة (اختياري)')}<input id="lfUnit" value="${esc(d.unit || '')}" dir="auto"></label>
        <label>${T('الأهداف (هدف في كل سطر)')}<textarea id="lfGoals" rows="5" dir="auto" placeholder="${T('التعرف على …')}">${esc((d.goals || []).join('\n'))}</textarea></label>
        <div class="lf-file"><b>📎 ${T('العرض المرتبط')}</b><div id="lfUrl"></div>
          <div class="gdlg-row" style="margin:6px 0 0">${window.LP_WEB ? '' : `<button id="lfPick">📂 ${T('ملف من الجهاز')}</button>`}<button id="lfUnlink">${T('إزالة الربط')}</button></div></div>
      </div>
      <div class="gdlg-row"><button class="pri" id="lfSave">${T('حفظ')}</button><button id="lfCancel">${T('إلغاء')}</button></div>`);
    $('#lfCancel').onclick = closeDlg;
    setTimeout(() => $('#lfName').focus(), 30);
    // ربط الدرس بعرض (أو تغييره أو إزالته) — يُحفظ مع «حفظ»
    let url = d.url || '';
    const showUrl = () => {
      $('#lfUrl').innerHTML = url
        ? `<div class="muted" style="font-size:12px;direction:ltr;text-align:start;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(url)}">${/^ppt:/.test(url) ? '📊 ' : /^pdf:/.test(url) ? '📄 ' : '🔗 '}${esc(url.replace(/^(pdf|ppt):/, '').replace(/^file:\/\/\//, ''))}</div>`
        : `<div class="muted" style="font-size:12px">📝 ${T('درس بدون ملف: عند اختياره يظهر عنوانه وأهدافه في الشريط العلوي.')}</div>`;
      $('#lfUnlink').style.display = url ? '' : 'none';
    };
    showUrl();
    if ($('#lfPick')) $('#lfPick').onclick = async () => {
      const r = await api.openFile(); if (!r || !r.path) return;
      const p = r.path;
      url = /\.pdf$/i.test(p) ? 'pdf:' + p : /\.(pptx?|ppsx?)$/i.test(p) ? 'ppt:' + p : 'file:///' + p.replace(/\\/g, '/').replace(/^\/+/, '');
      if (!$('#lfName').value.trim()) $('#lfName').value = p.split(/[\\/]/).pop().replace(/\.[^.]+$/, '');
      showUrl();
    };
    $('#lfUnlink').onclick = () => { url = ''; showUrl(); };
    $('#lfSave').onclick = async () => {
      const patch = { name: $('#lfName').value.trim(), subject: $('#lfSubj').value, grade: +$('#lfGrade').value || 0, unit: $('#lfUnit').value.trim(),
        goals: $('#lfGoals').value.split('\n').map(x => x.trim()).filter(Boolean) };
      if (url !== (d.url || '')) patch.url = url;
      if (!patch.name) { $('#lfName').focus(); return; }
      api.setSettings({ lastSubject: patch.subject, lastGrade: patch.grade }); prof.lastSubject = patch.subject; prof.lastGrade = patch.grade;
      if (onSave) { await onSave(patch); closeDlg(); return; }
      if (shared) await api.sharedUpdate(l.id, patch);
      else { Object.assign(l, patch); saveMine(); }
      closeDlg(); refresh();
    };
  }

  // ---------- المواد ----------
  const ICONS = ['💻', '📖', '🔢', '🔬', '🔤', '🕌', '🌍', '🎨', '🎵', '⚽', '🧪', '📐', '🗣', '✍️', '🧠', '🌱', '🏠', '🇸🇦', '📚', '⭐'];
  const COLORS = ['#228be6', '#2fb344', '#fd7e14', '#12b886', '#ae3ec9', '#0ca678', '#e64980', '#f5b400', '#e5484d', '#4c6ef5', '#868e96'];
  function subjectDialog(x) {
    const d = x || { name: '', icon: '📚', color: '#228be6' };
    let icon = d.icon, color = d.color;
    openDlg(`<h3>${x ? T('تعديل المادة') : T('مادة جديدة')}</h3>
      <div class="lform">
        <label>${T('اسم المادة')}<input id="sfName" value="${esc(d.name)}" ${x && !x.canEdit ? 'disabled' : ''}></label>
        <div class="mlbl" style="padding:0">${T('الأيقونة')}</div>
        <div class="iconGrid">${ICONS.map(i => `<button data-i="${i}" class="${i === icon ? 'on' : ''}">${i}</button>`).join('')}</div>
        <div class="mlbl" style="padding:0">${T('اللون')}</div>
        <div class="colorRow">${COLORS.map(c => `<button data-c="${c}" class="${c === color ? 'on' : ''}" style="background:${c}"></button>`).join('')}</div>
        ${x ? `<label class="tog2"><input type="checkbox" id="sfMine" ${prof.mySubject === x.id ? 'checked' : ''}><span class="sl"></span><span>⭐ ${T('مادتي: تفتح أولاً في المكتبة')}</span></label>` : ''}
      </div>
      <div class="gdlg-row">${!x || x.canEdit ? `<button class="pri" id="sfSave">${T('حفظ')}</button>` : ''}${x && x.canEdit ? `<button id="sfDel">🗑 ${T('حذف المادة')}</button>` : ''}<button id="sfCancel">${T('إغلاق')}</button></div>
      ${x && x.canEdit ? `<p style="margin-top:8px">${T('عند حذف المادة لا تُحذف دروسها، بل تنتقل إلى «غير مصنّفة».')}</p>` : ''}`);
    dcard.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { icon = b.dataset.i; dcard.querySelectorAll('[data-i]').forEach(y => y.classList.toggle('on', y === b)); });
    dcard.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { color = b.dataset.c; dcard.querySelectorAll('[data-c]').forEach(y => y.classList.toggle('on', y === b)); });
    $('#sfCancel').onclick = async () => {
      if (x && $('#sfMine')) { const on = $('#sfMine').checked; if (on !== (prof.mySubject === x.id)) { prof.mySubject = on ? x.id : ''; await api.setSettings({ mySubject: prof.mySubject }); } }
      closeDlg(); renderLib();
    };
    if ($('#sfSave')) $('#sfSave').onclick = async () => {
      const name = $('#sfName').value.trim(); if (!name) return $('#sfName').focus();
      if (x) await api.subjectsUpdate(x.id, { name, icon, color });
      else { const r = await api.subjectsAdd({ name, icon, color }); if (!r.ok) { LP.toast(T(r.err === 'exists' ? 'هذه المادة موجودة' : 'تعذّر الحفظ')); return; } subj = r.id; }
      if (x && $('#sfMine')) { prof.mySubject = $('#sfMine').checked ? x.id : (prof.mySubject === x.id ? '' : prof.mySubject); await api.setSettings({ mySubject: prof.mySubject }); }
      closeDlg(); refresh();
    };
    if ($('#sfDel')) $('#sfDel').onclick = async (e) => {
      const b = e.target;
      if (!b.dataset.sure) { b.dataset.sure = 1; b.textContent = T('متأكدة؟'); b.style.background = 'var(--danger)'; b.style.color = '#fff'; return; }
      await api.subjectsDelete(x.id);
      prof.library = mine().map(l => l.subject === x.id ? { ...l, subject: '' } : l); saveMine();
      subj = 'all'; closeDlg(); refresh();
    };
    setTimeout(() => $('#sfName').focus(), 30);
  }

  // ================= الأزرار =================
  async function thumbOfView() {
    try {
      const img = await LP.view.capturePage();
      if (!img || img.isEmpty()) return null;
      const im = new Image();
      await new Promise((res, rej) => { im.onload = res; im.onerror = rej; im.src = img.toDataURL(); });
      const c = document.createElement('canvas'); c.width = 480; c.height = Math.round(480 * im.height / im.width);
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      return c.toDataURL('image/jpeg', 0.78);
    } catch { return null; }
  }
  libAdd.onclick = async () => {
    const url = LP.currentUrl();
    if (!url || LP.isWelcome(url)) return;
    if (libTab === 'mine' && mine().some(l => l.url === url)) { LP.toast(T('هذا الدرس موجود في المكتبة')); return; }
    $('#libPanel').style.visibility = 'hidden';
    await new Promise(r => setTimeout(r, 120));
    const thumb = await thumbOfView();
    $('#libPanel').style.visibility = '';
    const S = LP.session && LP.session.S;
    const cls = LP.session && LP.session.cls;
    const draft = { name: (S && S.title) || (LP.currentTitle() || '').trim() || T('درس بدون اسم'), url, thumb,
      subject: subj !== 'all' && subj !== 'none' ? subj : (prof.lastSubject || prof.mySubject || ''),
      grade: (cls && LP.classGrade(cls)) || prof.lastGrade || 0, goals: S && S.goals ? S.goals.slice() : [] };
    editDialog(draft, libTab === 'shared', true, async (patch) => {
      const item = { ...draft, ...patch };
      if (libTab === 'shared') {
        const r = await api.sharedAdd(item);
        LP.toast(T(r.ok ? 'أُضيف الدرس إلى مكتبة القسم' : 'هذا الدرس موجود في مكتبة القسم'));
      } else {
        prof.library = [{ id: Date.now(), added: Date.now(), ...item }, ...mine()]; saveMine();
        LP.toast(T('تم حفظ الدرس في المكتبة'));
      }
      refresh();
    });
  };
  const libMenu = $('#libMenu');
  $('#libMore').onclick = (e) => {
    e.stopPropagation();
    if (libMenu.classList.toggle('on')) {
      const r = $('#libMore').getBoundingClientRect(), pr = $('#libPanel').getBoundingClientRect();
      libMenu.style.top = (r.bottom - pr.top + 6) + 'px'; libMenu.style.bottom = 'auto';
      libMenu.style.left = Math.max(8, Math.min(r.left - pr.left - 150, pr.width - 330)) + 'px';
    }
  };
  document.addEventListener('pointerdown', e => { if (!e.target.closest('#libMenu') && !e.target.closest('#libMore')) libMenu.classList.remove('on'); }, true);
  libMenu.addEventListener('click', e => {
    const b = e.target.closest('[data-l]'); if (!b) return;
    libMenu.classList.remove('on');
    ({ blank: newBlank, import: importFile, paste: pasteDialog, template: downloadTemplate })[b.dataset.l]();
  });
  function newBlank() {
    const cls = LP.session && LP.session.cls;
    const draft = { name: '', url: '', subject: subj !== 'all' && subj !== 'none' ? subj : (prof.lastSubject || prof.mySubject || ''), grade: (cls && LP.classGrade(cls)) || prof.lastGrade || 0, goals: [] };
    editDialog(draft, libTab === 'shared', true, async (patch) => {
      const item = { ...draft, ...patch };
      if (libTab === 'shared') await api.sharedAdd(item);
      else { prof.library = [{ id: Date.now(), added: Date.now(), ...item }, ...mine()]; saveMine(); }
      LP.toast(T('تم حفظ الدرس في المكتبة')); refresh();
    });
  }

  // ---------- الاستيراد من إكسل ----------
  const HEAD = {
    subject: /^(المادة|مادة|subject|matière|matiere)$/i, grade: /^(الصف|صف|grade|class|classe|niveau)$/i, unit: /^(الوحدة|وحدة|unit|unité|unite)$/i,
    title: /(عنوان|الدرس|الحصة|title|lesson|leçon|lecon|titre)/i, goals: /(هدف|الأهداف|أهداف|objective|goal|objectif)/i
  };
  function parseRows(rows) {
    rows = rows.map(r => r.map(c => String(c ?? '').trim())).filter(r => r.some(Boolean));
    if (!rows.length) return [];
    let map = null, start = 0;
    const h = rows[0];
    if (h.some(c => HEAD.title.test(c) || HEAD.subject.test(c))) {
      map = { goals: [] };
      h.forEach((c, i) => {
        if (HEAD.subject.test(c) && map.subject === undefined) map.subject = i;
        else if (HEAD.grade.test(c) && map.grade === undefined) map.grade = i;
        else if (HEAD.unit.test(c) && map.unit === undefined) map.unit = i;
        else if (HEAD.goals.test(c)) map.goals.push(i);
        else if (HEAD.title.test(c) && map.title === undefined) map.title = i;
      });
      start = 1;
    }
    if (!map || map.title === undefined) map = { subject: 0, grade: 1, unit: 2, title: 3, goals: rows[0].map((_, i) => i).filter(i => i > 3) };
    const maxCol = Math.max(...rows.map(r => r.length));
    if (!map.goals.length) for (let i = map.title + 1; i < maxCol; i++) map.goals.push(i);
    const out = [];
    for (const r of rows.slice(start)) {
      const title = r[map.title] || '';
      if (!title) continue;
      const goals = map.goals.flatMap(i => String(r[i] || '').split(/\r?\n/)).map(g => g.replace(/^[\s\-•*\d.)]+/, '').trim()).filter(Boolean);
      out.push({ name: title, subjectName: map.subject !== undefined ? r[map.subject] || '' : '', grade: map.grade !== undefined ? LP.parseGrade(r[map.grade]) : 0, unit: map.unit !== undefined ? r[map.unit] || '' : '', goals });
    }
    return out;
  }
  async function importParsed(list) {
    if (!list.length) { LP.toast(T('لم أجد دروساً في الملف. تأكدي من وجود عمود «عنوان الحصة».'), null, null, 5000); return; }
    const target = isGuest() ? 'mine' : libTab === 'shared' ? 'shared' : 'mine';
    const newSubs = [...new Set(list.map(l => l.subjectName).filter(n => n && !subjects.some(x => x.name === n)))];
    openDlg(`<h3>⬆ ${T('استيراد دفتر الدروس')}</h3>
      <p>${T('وُجد {n} درساً.', { n: list.length })}${newSubs.length ? ' ' + T('ستُضاف مواد جديدة: {s}', { s: esc(newSubs.join('، ')) }) : ''}</p>
      <div class="impPrev">${list.slice(0, 6).map(l => `<div><b dir="auto">${esc(l.name)}</b><small>${[l.subjectName, l.grade ? LP.gradeLabel(l.grade) : '', l.unit, l.goals.length ? '🎯 ' + l.goals.length : ''].filter(Boolean).map(esc).join(' · ')}</small></div>`).join('')}${list.length > 6 ? `<div class="muted">… +${list.length - 6}</div>` : ''}</div>
      ${isGuest() ? '' : `<div class="gdlg-row" style="margin-top:6px"><label class="impT"><input type="radio" name="impT" value="mine" ${target === 'mine' ? 'checked' : ''}><span>${T('إلى دروسي')}</span></label>
        <label class="impT"><input type="radio" name="impT" value="shared" ${target === 'shared' ? 'checked' : ''}><span>${T('إلى مكتبة القسم')}</span></label></div>`}
      <div class="gdlg-row"><button class="pri" id="impGo">${T('استيراد')}</button><button id="impNo">${T('إلغاء')}</button></div>`);
    $('#impNo').onclick = closeDlg;
    $('#impGo').onclick = async () => {
      const where = (dcard.querySelector('input[name=impT]:checked') || { value: 'mine' }).value;
      for (const n of newSubs) await api.subjectsAdd({ name: n, icon: '📚', color: COLORS[Math.floor(Math.random() * COLORS.length)] });
      subjects = isGuest() ? [] : await api.subjectsList();
      const items = list.map(l => ({ name: l.name, url: '', subject: (subjects.find(x => x.name === l.subjectName) || {}).id || '', grade: l.grade, unit: l.unit, goals: l.goals }));
      if (where === 'shared') await api.sharedAddMany(items);
      else { const now = Date.now(); prof.library = [...items.map((it, i) => ({ id: now + i, added: now + i, ...it })), ...mine()]; saveMine(); }
      libTab = where; subj = 'all';
      closeDlg(); LP.toast(T('تم استيراد {n} درساً ✓', { n: items.length })); refresh();
    };
  }
  async function importFile() {
    const r = await api.xlsxOpen();
    if (!r) return;
    if (r.err) { LP.toast(T('تعذّر قراءة الملف'), null, null, 4000); return; }
    importParsed(parseRows(r.rows || []));
  }
  function pasteDialog() {
    openDlg(`<h3>📋 ${T('لصق من إكسل')}</h3>
      <p>${T('انسخي الخلايا من إكسل (مع صف العناوين) ثم الصقيها هنا.')}</p>
      <textarea id="pasteBox" rows="9" style="width:100%;direction:auto" placeholder="${T('المادة')}\t${T('الصف')}\t${T('الوحدة')}\t${T('عنوان الحصة')}\t${T('الهدف 1')}\t${T('الهدف 2')}"></textarea>
      <div class="gdlg-row"><button class="pri" id="pasteGo">${T('متابعة')}</button><button id="pasteNo">${T('إلغاء')}</button></div>`);
    $('#pasteNo').onclick = closeDlg;
    setTimeout(() => $('#pasteBox').focus(), 30);
    $('#pasteGo').onclick = () => {
      const txt = $('#pasteBox').value;
      // خلايا إكسل المنسوخة: أعمدة بفاصل Tab، والخلايا متعددة الأسطر بين علامات تنصيص
      const rows = []; let row = [], cell = '', q = false;
      for (let i = 0; i < txt.length; i++) {
        const ch = txt[i];
        if (q) { if (ch === '"' && txt[i + 1] === '"') { cell += '"'; i++; } else if (ch === '"') q = false; else cell += ch; continue; }
        if (ch === '"' && cell === '') { q = true; continue; }
        if (ch === '\t') { row.push(cell); cell = ''; continue; }
        if (ch === '\n' || ch === '\r') { if (ch === '\r' && txt[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; continue; }
        cell += ch;
      }
      if (cell || row.length) { row.push(cell); rows.push(row); }
      closeDlg(); importParsed(parseRows(rows));
    };
  }
  async function downloadTemplate() {
    const head = [T('المادة'), T('الصف'), T('الوحدة'), T('عنوان الحصة'), T('الهدف 1'), T('الهدف 2'), T('الهدف 3')];
    const ex = I18N.lang === 'ar'
      ? [['الحاسب', 'الخامس', 'الوحدة الأولى', 'أجهزة الالتقاط — الحصة 1', 'التعرف على أجهزة الالتقاط', 'التمييز بين أنواعها', ''], ['لغتي', 'الثالث', '', 'النص الأول', 'قراءة النص قراءة سليمة', 'استخراج الفكرة الرئيسة', '']]
      : [['Computer', '5', 'Unit 1', 'Capture devices — Lesson 1', 'Identify capture devices', 'Tell their types apart', '']];
    const ok = await api.xlsxTemplate([head, ...ex]);
    if (ok) LP.toast(T('تم حفظ النموذج'));
  }

  // ================= البدء =================
  $$('#libTabs button').forEach(b => b.onclick = async () => { libTab = b.dataset.v; if (libTab !== 'mine') sharedItems = await api.sharedList(); renderLib(); });
  libSearch.addEventListener('input', renderLib);
  libSearch.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') LP.closePanels(); });
  $('#libBtn').onclick = async () => {
    if ($('#libPanel').classList.contains('on')) return LP.closePanels();
    LP.openPanel($('#libPanel')); libSearch.value = ''; await refresh();
  };
  const prevClose = LP.closePanels;
  LP.closePanels = () => { const a = dlg.classList.contains('on') || libMenu.classList.contains('on'); closeDlg(); libMenu.classList.remove('on'); const b = prevClose(); return a || b; };
  document.addEventListener('lp-auth', async (e) => { if (e.detail && e.detail.user) await loadAll(); });
  LP._lessons = { parseRows, refresh };
})();
