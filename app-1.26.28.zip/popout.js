// إظهار البطاقات العائمة (العجلة، المؤقّت، الأهداف) فوق كل البرامج
// الفكرة: نافذة البرنامج نفسها تصغر إلى حجم البطاقات وتبقى فوق وورد وتيمز وغيرها،
// فتبقى العجلة والنقاط والمؤقّت تعمل كما هي بدون نسخة ثانية.
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const body = document.body;
  const GAP = 6;

  const KINDS = {
    wheel: { el: () => $('#mw'), head: () => $('#mwHead'), before: () => $('#mwClose'), isOn: () => $('#mw').classList.contains('on'),
      show: () => LP.toggleMiniWheel(true), hide: () => LP.toggleMiniWheel(false) },
    timer: { el: () => $('#timerW'), head: () => $('#timerW .tbtns'), before: () => $('#tClose'), isOn: () => $('#timerW').classList.contains('on'),
      show: () => { if (!$('#timerW').classList.contains('on')) LP.openTimer(); }, hide: () => {} },
    goals: { el: () => $('#goalsCard'), head: () => $('#gcHead'), before: () => $('#gcClose'), isOn: () => $('#goalsCard').classList.contains('on'),
      show: () => LP.showGoals(true), hide: () => {} },
    groups: { el: () => $('#grpBar'), head: () => $('#gbMenuBtn').parentNode, before: () => $('#gbMenuBtn'), isOn: () => $('#grpBar').classList.contains('on'),
      show: () => LP.toggleGroupBar(true), hide: () => {} }
  };
  let out = [];              // البطاقات المعروضة فوق البرامج بالترتيب
  const saved = new Map();   // مواضعها داخل البرنامج قبل الخروج
  const isMini = () => body.classList.contains('mini');
  // «أدوات مستقلة»: النافذة الشفافة تغطي الشاشة وكل أداة تُسحب وحدها لأي مكان (حين تتوفر الشفافية)
  let ovOK = false;
  try { api.uiTransp && api.uiTransp().then(v => { ovOK = !!v; }); } catch {}
  const isOv = () => body.classList.contains('ovf');
  let prof = {};
  const kindOf = (el) => Object.keys(KINDS).find(k => KINDS[k].el() === el);
  const stage = $('#stage');
  // حفظ مكان الأداة خارج البرنامج (نسبة من الشاشة) — منفصل عن مكانها داخل البرنامج
  LP.ovSave = (el) => {
    const k = kindOf(el); if (!k) return;
    const W = stage.clientWidth - el.offsetWidth, H = stage.clientHeight - el.offsetHeight;
    prof.ovPos = { ...(prof.ovPos || {}), [k]: { x: W > 0 ? el.offsetLeft / W : 0, y: H > 0 ? el.offsetTop / H : 0 } };
    api.setSettings({ ovPos: prof.ovPos });
  };

  // زر 📌 في رأس كل بطاقة
  for (const [k, d] of Object.entries(KINDS)) {
    const b = document.createElement('button');
    b.className = (k === 'wheel' ? 'mw-x' : k === 'goals' ? 'fc-x' : k === 'groups' ? 'gb-btn' : '') + ' popBtn';
    b.dataset.pop = k;
    b.textContent = '📌';
    b.title = T('إظهار فوق كل البرامج');
    // ↩ على أداة خارج البرنامج يرجعها وحدها (وتبقى الأدوات الأخرى في أماكنها)
    b.onclick = (e) => { e.stopPropagation(); if (out.includes(k)) hideOne(k); else popOut(k); };
    d.head().insertBefore(b, d.before());
  }
  const syncBtns = () => { api.floatToolsOut && api.floatToolsOut(out.slice()); syncBtns0(); };
  const syncBtns0 = () => document.querySelectorAll('.popBtn').forEach(b => {
    const o = out.includes(b.dataset.pop);
    b.textContent = o ? '↩' : '📌'; b.title = T(o ? 'رجوع إلى العارض' : 'إظهار فوق كل البرامج');
    b.classList.toggle('on', o);
  });

  // مكان أداة خارج البرنامج: آخر مكان تركها فيه المعلم، وإلا بجانب طرف الشاشة تحت ما سبقها
  function placeOv(k, el) {
    const W = stage.clientWidth, H = stage.clientHeight, w = el.offsetWidth, h = el.offsetHeight;
    const p = prof.ovPos && prof.ovPos[k];
    let x, y;
    if (p) { x = p.x * (W - w); y = p.y * (H - h); }
    else {
      x = W - w - 16; y = 16;
      for (const o of out) { if (o === k) break; const e = KINDS[o].el(); if (e.classList.contains('on') && e._ovPlaced) y = Math.max(y, e.offsetTop + e.offsetHeight + 10); }
      if (y + h > H - 8) { y = 16; x = W - w - 16 - 300; }
    }
    el.style.left = Math.max(4, Math.min(W - w - 4, x)) + 'px'; el.style.top = Math.max(4, Math.min(H - h - 4, y)) + 'px';
    el._ovPlaced = true;
  }
  // ترتيب تلقائي: عمود بجانب الطرف الأيمن إن اتسع الارتفاع، وإلا صف في الأعلى
  function arrange() {
    if (!isOv()) return;
    const W = stage.clientWidth, H = stage.clientHeight, G = 6;   // متلاصقة: تتحرك معاً
    const els = out.map(k => [k, KINDS[k].el()]).filter(([, e]) => e.classList.contains('on'));
    const total = els.reduce((a, [, e]) => a + e.offsetHeight + G, 0);
    let x = W - 16, y = 16;
    if (total <= H - 24) for (const [, e] of els) { e.style.left = (W - e.offsetWidth - 16) + 'px'; e.style.top = y + 'px'; y += e.offsetHeight + G; }
    else for (const [, e] of els) { x -= e.offsetWidth; e.style.left = Math.max(4, x) + 'px'; e.style.top = '16px'; x -= G; }
    for (const [, e] of els) LP.ovSave(e);
    measure();
  }
  // ترتيب البطاقات فوق بعضها في النافذة الصغيرة
  function layout() {
    if (isOv()) { for (const k of out) { const el = KINDS[k].el(); if (el.classList.contains('on') && !el._ovPlaced) placeOv(k, el); } return; }
    let y = 0;
    for (const k of out) {
      const el = KINDS[k].el();
      if (!el.classList.contains('on')) continue;
      el.style.left = '0px'; el.style.top = y + 'px';
      y += el.offsetHeight + GAP;
    }
  }
  // حجم النافذة = كل ما يظهر من البطاقات وقوائمها المفتوحة
  let last = '';
  function measure() {
    if (!isMini()) return;
    layout();
    if (isOv()) {
      // شكل النافذة = الأدوات وقوائمها المفتوحة فقط، والباقي يمر الضغط من خلاله
      const R = [];
      const add = (el) => { const r = el.getBoundingClientRect(); if (r.width > 2 && r.height > 2 && getComputedStyle(el).visibility !== 'hidden') R.push({ x: r.left - 2, y: r.top - 2, width: r.width + 4, height: r.height + 4 }); };
      for (const k of out) { const el = KINDS[k].el(); if (el.classList.contains('on')) { add(el); el.querySelectorAll('.mw-pop.on, .mw-fx').forEach(add); } }
      const tp = $('#timerPop'); if (tp.classList.contains('on')) add(tp.querySelector('.tov-card') || tp);
      const t = $('#toast'); if (t && t.classList.contains('show')) add(t);
      const key = JSON.stringify(R.map(r => [r.x | 0, r.y | 0, r.width | 0, r.height | 0]));
      if (key !== last) { last = key; api.miniShape(R); }
      return;
    }
    let w = 0, h = 0;
    const els = [];
    for (const k of out) { const el = KINDS[k].el(); if (el.classList.contains('on')) els.push(el, ...el.querySelectorAll('.mw-pop.on')); }
    const tp = $('#timerPop'); if (tp.classList.contains('on')) els.push(tp);
    for (const el of els) { const r = el.getBoundingClientRect(); w = Math.max(w, r.right); h = Math.max(h, r.bottom); }
    const key = Math.ceil(w) + 'x' + Math.ceil(h);
    if (key !== last) { last = key; api.miniSize({ w, h }); }
  }
  let timer = null;
  window.__lpMiniMeasure = () => { last = ''; measure(); };

  async function popOut(k) {
    if (out.includes(k)) return;
    const d = KINDS[k];
    if (!d.isOn()) { await d.show(); if (!d.isOn()) return; }
    const el = d.el();
    saved.set(k, { left: el.style.left, top: el.style.top });
    out.push(k);
    const enterOv = !isMini() && ovOK;
    if (!isMini()) {
      LP.closePanels && LP.closePanels();
      prof = await api.getSettings();
      body.classList.add('mini');
      if (enterOv) body.classList.add('ovf');
      // كل البطاقات الأخرى المفتوحة تختفي مؤقتاً حتى لا تغطي الصفحة الصغيرة
      for (const [o, od] of Object.entries(KINDS)) if (!out.includes(o) && od.isOn()) od.el().classList.add('miniHide');
    }
    el.classList.remove('miniHide'); el.classList.add('miniOut');
    if (k === 'goals' && LP.goalsNoEdit) LP.goalsNoEdit();
    el._ovPlaced = false;
    if (isOv()) {
      if (enterOv) { const r = await api.miniEnter({ w: el.offsetWidth, h: el.offsetHeight, ov: true }); if (!r || !r.ov) { body.classList.remove('ovf'); } else await new Promise(res => setTimeout(res, 120)); }
      layout();
    } else {
      layout();
      await api.miniEnter({ w: el.offsetWidth, h: el.offsetHeight });
    }
    last = ''; measure();
    clearInterval(timer); timer = setInterval(() => {
      // بطاقة أُغلقت من زرها ✕ → تخرج من القائمة
      out = out.filter(o => { const on = KINDS[o].isOn(); if (!on) restore(o); return on; });
      if (!out.length) { back(); return; }
      measure();
    }, 250);
    syncBtns();
  }
  function restore(k) {
    const el = KINDS[k].el(), s = saved.get(k);
    el.classList.remove('miniOut'); el._ovPlaced = false;
    if (s) { el.style.left = s.left; el.style.top = s.top; }
  }
  async function back() {
    clearInterval(timer); timer = null;
    for (const k of out) restore(k);
    out = [];
    document.querySelectorAll('.miniHide').forEach(e => e.classList.remove('miniHide'));
    body.classList.remove('mini', 'ovf');
    syncBtns();
    await api.miniExit();
    if (window.__lpShapeReset) window.__lpShapeReset();
    if (window.__lpQS) window.__lpQS();
  }
  // دائرة أداة في الزر العائم
  async function hideOne(k) {
    if (!out.includes(k)) return;
    if (out.length === 1) return back();
    out = out.filter(o => o !== k); restore(k);
    const d = KINDS[k]; d.el().classList.add('miniHide');
    last = ''; measure(); syncBtns();
  }
  api.onFloatTool && api.onFloatTool(async ({ k, inApp }) => {
    if (!KINDS[k]) return;
    if (inApp && !isMini()) {
      // داخل البرنامج: إظهار/إخفاء في مكانها المعتاد
      if (k === 'wheel') LP.toggleMiniWheel();
      else if (k === 'groups') LP.toggleGroupBar();
      else if (k === 'goals') LP.showGoals(!KINDS.goals.isOn());
      else if (k === 'timer') { if (LP.timerState && LP.timerState().active) LP.timerCtl.open(); else LP.openTimer(); }
      return;
    }
    if (out.includes(k)) return hideOne(k);
    const el = KINDS[k].el(); el.classList.remove('miniHide');
    if (k === 'timer' && !KINDS.timer.isOn() && !(LP.timerState && LP.timerState().active)) {
      // لا يوجد مؤقّت يعمل: نرجع للبرنامج لاختيار الوقت، ثم يظهر المؤقّت فوق البرامج تلقائياً
      if (isMini()) { LP.openTimer(); return; }
      api.bringFront && api.bringFront(); LP.openTimer && LP.openTimer();
      const iv = setInterval(() => { if (LP.timerState && LP.timerState().active) { clearInterval(iv); setTimeout(() => popOut('timer'), 600); } }, 300);
      setTimeout(() => clearInterval(iv), 60000);
      return;
    }
    popOut(k);
  });
  // 📌 تثبيت الكل: كل الأدوات المفتوحة (وإن لم يكن شيء مفتوحاً: العجلة والأهداف، والمؤقّت إن كان يعمل)
  async function popAll() {
    let ks = Object.keys(KINDS).filter(k => k !== 'groups' && KINDS[k].isOn());
    if (!ks.length) ks = ['wheel', 'goals'];
    if (LP.timerState && LP.timerState().active && !ks.includes('timer')) ks.push('timer');
    for (const k of ks) if (!out.includes(k)) await popOut(k);
  }
  async function hideAll() {
    if (!isMini()) return;
    await back();
    api.minimize && api.minimize();
  }
  api.onFloatAll && api.onFloatAll((act) => {
    if (act === 'out') popAll();
    else if (act === 'arrange') arrange();
    else if (act === 'hide') hideAll();
    else if (act === 'back') back();
  });
  // شريط المجموعات كأداة مستقلة: يُسحب من فراغه
  LP.floatDrag && LP.floatDrag($('#grpBar'), $('#grpBar .gb-row2'), null);
  LP.popAll = popAll;
  LP.popArrange = arrange;
  LP.popOut = popOut;
  LP.popBack = back;
  LP.isMini = isMini;
  api.onMiniExitReq(() => back());
  // Ctrl+Shift+G: داخل البرنامج = إظهار/إخفاء العجلة، وخارجه = العجلة فوق كل البرامج
  api.onMiniWheelKey(async (focused) => {
    if (focused) { LP.toggleMiniWheel(); return; }
    if (out.includes('wheel')) { if (out.length === 1) back(); else { LP.toggleMiniWheel(false); } return; }
    popOut('wheel');
  });
  // المؤقّت داخل الوضع المصغّر: قائمة المدد تظهر تحت البطاقات
  const origOpenTimer = LP.openTimer;
  LP.openTimer = (anchor) => {
    if (!isMini()) return origOpenTimer(anchor);
    const tp = $('#timerPop');
    if (tp.classList.contains('on')) { tp.classList.remove('on'); return; }
    tp.classList.add('on');
    if (isOv()) {
      const a = out.map(k => KINDS[k].el()).filter(e => e.classList.contains('on')).pop();
      const r = a ? a.getBoundingClientRect() : { left: stage.clientWidth - 350, bottom: 16 };
      tp.style.left = Math.max(4, Math.min(stage.clientWidth - 340, r.left)) + 'px';
      tp.style.top = Math.max(4, Math.min(stage.clientHeight - 340, r.bottom + GAP)) + 'px'; tp.style.bottom = 'auto';
    } else {
      let y = 0; for (const k of out) { const el = KINDS[k].el(); if (el.classList.contains('on')) y = Math.max(y, el.getBoundingClientRect().bottom); }
      tp.style.left = '0px'; tp.style.top = (y + GAP) + 'px'; tp.style.bottom = 'auto';
    }
    if (!out.includes('timer')) setTimeout(() => {
      // عند بدء المؤقّت يظهر مع البطاقات الأخرى
      const iv = setInterval(() => { if (!isMini()) return clearInterval(iv); if (KINDS.timer.isOn()) { clearInterval(iv); popOut('timer'); } }, 200);
      setTimeout(() => clearInterval(iv), 60000);
    }, 0);
  };
  // تسجيل الخروج أو قفل البرنامج يعيد النافذة
  document.addEventListener('lp-auth', () => { if (isMini()) back(); });
})();
