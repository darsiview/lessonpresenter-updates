let LP_unlock = null, LP_frame = null, LP_full = null;
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const app = $('#app'), stage = $('#stage');
  let view = null;
  const cv = $('#draw'), ctx = cv.getContext('2d');
  const lv = $('#laser'), lctx = lv.getContext('2d');
  const board = $('#board'), urlBox = $('#url'), toastEl = $('#toast');

  let tool = 'mouse', color = '#e5484d', width = 4;
  let eraserR = 14, stampCh = '✓', stampSize = 30, branchKind = 'tree', branchN = 3;
  try { branchKind = localStorage.getItem('lpBranchKind') || 'tree'; branchN = +localStorage.getItem('lpBranchN') || 3; } catch {}
  try { stampSize = +localStorage.getItem('lpStampSize') || 30; } catch {}
  let shapes = [], undoStack = [], redoStack = [];
  let current = null, dpr = 1, homeUrl = null;
  // السبورة والتقسيم: طبقتان للرسم (الدرس / السبورة)، ولكل طبقة تحويل (تكبير + إزاحة) ومنطقة
  let boardMode = 0, boardColor = 1, splitOn = false, layer = 'lesson';
  const ID = { s: 1, x: 0, y: 0 };
  let LT = ID, BT = ID, LR = null, BR = null;
  const boardPages = [{ shapes: [], undo: [], redo: [] }]; let boardPage = 0;
  const curT = () => layer === 'board' ? BT : LT;

  // ---------- رسائل قصيرة ----------
  let toastT;
  function toast(msg, action, fn, ms) {
    toastEl.textContent = msg;
    if (action) {
      const b = document.createElement('button'); b.className = 'toastBtn'; b.textContent = action;
      b.onclick = () => { toastEl.classList.remove('show'); fn && fn(); };
      toastEl.appendChild(b);
    }
    toastEl.style.pointerEvents = action ? 'auto' : 'none';
    toastEl.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('show'), ms || (action ? 7000 : 1600));
  }

  // ---------- مقاس اللوحة ----------
  function resize() {
    dpr = window.devicePixelRatio || 1;
    const r = stage.getBoundingClientRect();
    for (const c of [cv, lv]) { c.width = Math.round(r.width * dpr); c.height = Math.round(r.height * dpr); }
    if (splitOn && window.__lpSplitLayout) window.__lpSplitLayout();
    redraw();
  }
  new ResizeObserver(resize).observe(stage);

  // ---------- اختيار الأداة ----------
  function setTool(t) {
    commitText();
    tool = t;
    if (!selOn()) sel = null;
    cv.style.cursor = ''; hoverSel = false;
    $$('[data-tool]').forEach(b => b.classList.toggle('on', b.dataset.tool === t));
    stage.className = (t === 'mouse' ? '' : 'drawing ') + 't-' + t;
    if (t !== 'laser') laserPts.length = 0;
    if (!['eraser', 'stamp', 'spot'].includes(t)) laserPos = null;
    document.dispatchEvent(new CustomEvent('lp-tool', { detail: t }));
    $('#spotCtl').classList.toggle('on', t === 'spot');
    if (t === 'spot') toast(I18N.t('الكشّاف: غيّر الحجم بالعجلة أو بإصبعين أو بالزرين − و +'));
  }
  $$('[data-tool]').forEach(b => b.addEventListener('click', () => setTool(b.dataset.tool === tool && tool !== 'mouse' ? 'mouse' : b.dataset.tool)));

  function setColor(c) {
    color = c;
    $$('.sw').forEach(s => s.classList.toggle('on', s.dataset.c === c));
    $('#customColor').value = c;
    document.dispatchEvent(new CustomEvent('lp-pen', { detail: { color, width } }));
  }
  $$('.sw').forEach(s => s.addEventListener('click', () => { setColor(s.dataset.c); if (tool === 'mouse' || tool === 'eraser') setTool('pen'); }));
  $('#customColor').addEventListener('input', e => { setColor(e.target.value); if (tool === 'mouse' || tool === 'eraser') setTool('pen'); });

  $$('.wd').forEach(b => b.addEventListener('click', () => {
    width = +b.dataset.w; $$('.wd').forEach(x => x.classList.toggle('on', x === b));
    document.dispatchEvent(new CustomEvent('lp-pen', { detail: { color, width } }));
  }));

  // ---------- السجل (تراجع/إعادة) ----------
  const snap = () => JSON.stringify(shapes);
  function pushUndo() { undoStack.push(snap()); if (undoStack.length > 200) undoStack.shift(); redoStack = []; }
  function undo() { commitText(); sel = null; if (!undoStack.length) return; redoStack.push(snap()); shapes = JSON.parse(undoStack.pop()); redraw(); }
  function redo() { sel = null; if (!redoStack.length) return; undoStack.push(snap()); shapes = JSON.parse(redoStack.pop()); redraw(); }
  function clearAll() { commitText(); if (!shapes.length) return; pushUndo(); shapes = []; redraw(); toast(I18N.t(layer === 'board' && boardMode === 0 ? 'تم مسح رسم السبورة' : 'تم مسح الرسم')); }
  $('#undo').onclick = undo; $('#redo').onclick = redo; $('#clear').onclick = () => { clearAll(); if (LP_full && LP_full.on && active && active.ppt) window.api.pptErase(active.ppt.id); };

  // ---------- الرسم ----------
  function hexA(hex, a) {
    const h = hex.replace('#', ''); const n = parseInt(h.length === 3 ? h.split('').map(x => x + x).join('') : h, 16);
    return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`;
  }
  const STAMP_COLORS = { '✓': '#2fb344', '✗': '#e5484d', '⭐': '#f5b400', '؟': '#228be6', '!': '#fd7e14', '👍': '#f5b400' };
  function drawStamp(c, s, alpha) {
    const z = s.size, col = STAMP_COLORS[s.ch] || s.color || '#e5484d';
    c.save(); c.translate(s.x, s.y); if (s.rot) c.rotate(s.rot); c.globalAlpha = alpha || 1;
    c.lineCap = 'round'; c.lineJoin = 'round';
    c.shadowColor = 'rgba(0,0,0,.25)'; c.shadowBlur = 4; c.shadowOffsetY = 2;
    if (s.ch === '✓') {
      c.strokeStyle = col; c.lineWidth = z * 0.18;
      c.beginPath(); c.moveTo(-z * 0.42, z * 0.02); c.lineTo(-z * 0.12, z * 0.32); c.lineTo(z * 0.45, -z * 0.36); c.stroke();
    } else if (s.ch === '✗') {
      c.strokeStyle = col; c.lineWidth = z * 0.18;
      c.beginPath(); c.moveTo(-z * 0.34, -z * 0.34); c.lineTo(z * 0.34, z * 0.34); c.moveTo(z * 0.34, -z * 0.34); c.lineTo(-z * 0.34, z * 0.34); c.stroke();
    } else if (s.ch === '⭐') {
      c.fillStyle = col; c.strokeStyle = '#c98a00'; c.lineWidth = Math.max(1.5, z * 0.04);
      c.beginPath();
      for (let i = 0; i < 10; i++) { const r = i % 2 ? z * 0.22 : z * 0.5, a = -Math.PI / 2 + i * Math.PI / 5; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); }
      c.closePath(); c.fill(); c.shadowColor = 'transparent'; c.stroke();
    } else if (s.ch === '؟' || s.ch === '!') {
      c.fillStyle = col; c.beginPath(); c.arc(0, 0, z * 0.46, 0, Math.PI * 2); c.fill();
      c.shadowColor = 'transparent'; c.fillStyle = '#fff'; c.font = `900 ${Math.round(z * 0.62)}px "Segoe UI", Tahoma, Arial`;
      c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(s.ch, 0, z * 0.04);
    } else {
      c.font = `${Math.round(z * 0.85)}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`;
      c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(s.ch, 0, z * 0.04);
    }
    c.restore();
  }
  // ---------- السهم المتفرع: شجري / مروحي / حاصرة ----------
  // يُرسم في إطار محلي: مركزه (cx,cy)، والاتجاه نحو +y بطول h، والفروع منتشرة على عرض w، ثم يُدار بزاوية rot
  function arrowLine(c, x1, y1, x2, y2, lw, head) {
    const ang = Math.atan2(y2 - y1, x2 - x1);
    c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2 - Math.cos(ang) * head * 0.6, y2 - Math.sin(ang) * head * 0.6); c.stroke();
    c.beginPath(); c.moveTo(x2, y2);
    c.lineTo(x2 - head * Math.cos(ang - 0.42), y2 - head * Math.sin(ang - 0.42));
    c.lineTo(x2 - head * Math.cos(ang + 0.42), y2 - head * Math.sin(ang + 0.42));
    c.closePath(); c.fill();
  }
  function drawBranch(c, s) {
    const lw = Math.max(2, s.width), head = 9 + lw * 2.2, w = s.w, h = s.h, n = Math.max(2, Math.min(5, s.n || 3));
    c.lineCap = 'round'; c.lineJoin = 'round';
    c.translate(s.cx, s.cy); if (s.rot) c.rotate(s.rot);
    c.strokeStyle = c.fillStyle = s.color; c.lineWidth = lw;
    const xs = Array.from({ length: n }, (_, i) => -w / 2 + i * w / (n - 1));
    if (s.kind === 'fan') {
      for (const x of xs) arrowLine(c, 0, -h / 2, x, h / 2, lw, head);
      c.beginPath(); c.arc(0, -h / 2, lw * 1.4, 0, Math.PI * 2); c.fill();
    } else if (s.kind === 'brace') {
      const yb = -h / 2 + h * 0.42, r = Math.max(2, Math.min(w * 0.12, (h / 2 - yb) * 0.9, h * 0.25));
      c.beginPath(); c.moveTo(0, -h / 2); c.lineTo(0, yb - r); c.stroke();
      c.beginPath();
      c.moveTo(-w / 2, h / 2); c.quadraticCurveTo(-w / 2, yb, -w / 2 + r, yb); c.lineTo(-r, yb); c.quadraticCurveTo(0, yb, 0, yb - r);
      c.quadraticCurveTo(0, yb, r, yb); c.lineTo(w / 2 - r, yb); c.quadraticCurveTo(w / 2, yb, w / 2, h / 2);
      c.stroke();
    } else {
      const ym = -h / 2 + h * 0.38;
      c.beginPath(); c.moveTo(0, -h / 2); c.lineTo(0, ym); c.moveTo(-w / 2, ym); c.lineTo(w / 2, ym); c.stroke();
      for (const x of xs) arrowLine(c, x, ym, x, h / 2, lw, head);
    }
  }
  // إطار الشكل قبل التدوير: المركز والعرض والارتفاع
  function textBox(s) {
    ctx.save(); ctx.font = `700 ${s.size}px "Segoe UI", Tahoma, Arial`;
    const lines = String(s.text).split('\n'); const w = Math.max(...lines.map(l => ctx.measureText(l).width)); ctx.restore();
    const h = lines.length * s.size * 1.3, x0 = (s.dir || 'rtl') === 'rtl' ? s.x - w : s.x;
    return { cx: x0 + w / 2, cy: s.y + h / 2, w, h };
  }
  function box(s) {
    if (s.type === 'rect' || s.type === 'ellipse') return { cx: (s.x1 + s.x2) / 2, cy: (s.y1 + s.y2) / 2, w: Math.abs(s.x2 - s.x1), h: Math.abs(s.y2 - s.y1) };
    if (s.type === 'stamp') return { cx: s.x, cy: s.y, w: s.size, h: s.size };
    if (s.type === 'text') return textBox(s);
    if (s.type === 'branch') return { cx: s.cx, cy: s.cy, w: s.w, h: s.h };
    let pts = s.type === 'arrow' ? [[s.x1, s.y1], [s.x2, s.y2]] : (s.points || []);
    if (!pts.length) return { cx: 0, cy: 0, w: 0, h: 0 };
    const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]), pad = s.type === 'hl' ? (s.width * 5 + 6) / 2 : (s.width || 4) / 2;
    const x0 = Math.min(...xs) - pad, x1 = Math.max(...xs) + pad, y0 = Math.min(...ys) - pad, y1 = Math.max(...ys) + pad;
    return { cx: (x0 + x1) / 2, cy: (y0 + y1) / 2, w: x1 - x0, h: y1 - y0 };
  }
  const ROTATABLE = new Set(['rect', 'ellipse', 'stamp', 'text', 'branch']);
  const rotP = (x, y, cx, cy, a) => { const c = Math.cos(a), s = Math.sin(a), dx = x - cx, dy = y - cy; return [cx + dx * c - dy * s, cy + dx * s + dy * c]; };
  function drawShape(c, s) {
    c.save();
    c.lineCap = 'round'; c.lineJoin = 'round';
    if (s.type === 'stamp') { c.restore(); return drawStamp(c, s); }
    if (s.type === 'branch') { drawBranch(c, s); c.restore(); return; }
    if (s.rot && (s.type === 'rect' || s.type === 'ellipse' || s.type === 'text')) { const b = box(s); c.translate(b.cx, b.cy); c.rotate(s.rot); c.translate(-b.cx, -b.cy); }
    if (s.type === 'erase') {
      c.globalCompositeOperation = 'destination-out';
      c.strokeStyle = '#000'; c.fillStyle = '#000'; c.lineWidth = s.width;
      const p = s.points;
      c.beginPath();
      if (p.length === 1) { c.arc(p[0][0], p[0][1], s.width / 2, 0, Math.PI * 2); c.fill(); }
      else { c.moveTo(p[0][0], p[0][1]); for (let i = 1; i < p.length; i++) c.lineTo(p[i][0], p[i][1]); c.stroke(); }
      c.restore(); return;
    }
    if (s.type === 'pen' || s.type === 'hl') {
      c.strokeStyle = s.type === 'hl' ? hexA(s.color, 0.38) : s.color;
      c.lineWidth = s.type === 'hl' ? s.width * 5 + 6 : s.width;
      const p = s.points;
      c.beginPath();
      if (p.length === 1) { c.moveTo(p[0][0], p[0][1]); c.lineTo(p[0][0] + 0.1, p[0][1] + 0.1); }
      else {
        c.moveTo(p[0][0], p[0][1]);
        for (let i = 1; i < p.length - 1; i++) {
          const mx = (p[i][0] + p[i + 1][0]) / 2, my = (p[i][1] + p[i + 1][1]) / 2;
          c.quadraticCurveTo(p[i][0], p[i][1], mx, my);
        }
        c.lineTo(p[p.length - 1][0], p[p.length - 1][1]);
      }
      c.stroke();
    } else if (s.type === 'rect' || s.type === 'ellipse') {
      const x = Math.min(s.x1, s.x2), y = Math.min(s.y1, s.y2), w = Math.abs(s.x2 - s.x1), h = Math.abs(s.y2 - s.y1);
      c.beginPath();
      if (s.type === 'rect') c.roundRect ? c.roundRect(x, y, w, h, 6) : c.rect(x, y, w, h);
      else c.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
      c.fillStyle = hexA(s.color, 0.14); c.fill();
      c.strokeStyle = s.color; c.lineWidth = Math.max(2, s.width); c.stroke();
    } else if (s.type === 'arrow') {
      const lw = Math.max(2, s.width), ang = Math.atan2(s.y2 - s.y1, s.x2 - s.x1), head = 10 + lw * 2.5;
      c.strokeStyle = c.fillStyle = s.color; c.lineWidth = lw;
      c.beginPath(); c.moveTo(s.x1, s.y1);
      c.lineTo(s.x2 - Math.cos(ang) * head * 0.6, s.y2 - Math.sin(ang) * head * 0.6); c.stroke();
      c.beginPath(); c.moveTo(s.x2, s.y2);
      c.lineTo(s.x2 - head * Math.cos(ang - 0.42), s.y2 - head * Math.sin(ang - 0.42));
      c.lineTo(s.x2 - head * Math.cos(ang + 0.42), s.y2 - head * Math.sin(ang + 0.42));
      c.closePath(); c.fill();
    } else if (s.type === 'text') {
      c.fillStyle = s.color; c.font = `700 ${s.size}px "Segoe UI", Tahoma, Arial`;
      const rtl = (s.dir || 'rtl') === 'rtl';
      c.textBaseline = 'top'; c.direction = rtl ? 'rtl' : 'ltr'; c.textAlign = rtl ? 'right' : 'left';
      s.text.split('\n').forEach((ln, i) => c.fillText(ln, s.x, s.y + i * s.size * 1.3));
    }
    c.restore();
  }
  function redraw() {
    if (window.__lpQS) window.__lpQS();
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const lessonShapes = layer === 'lesson' ? shapes : (active ? pageData(active).shapes : []);
    const boardShapes = layer === 'board' ? shapes : boardPages[boardPage].shapes;
    const drawLayer = (list, T, R, cur) => {
      ctx.save();
      if (R) { ctx.beginPath(); ctx.rect(R.x, R.y, R.w, R.h); ctx.clip(); }
      ctx.translate(T.x, T.y); ctx.scale(T.s, T.s);
      for (const s of list) drawShape(ctx, s);
      if (cur) drawShape(ctx, cur);
      ctx.restore();
    };
    // السبورة الكاملة: رسمها فقط (رسم الدرس محفوظ تحتها ولا يظهر عليها)
    if (boardMode > 0) drawLayer(boardShapes, BT, null, layer === 'board' ? current : null);
    else {
      drawLayer(lessonShapes, LT, splitOn ? LR : null, layer === 'lesson' ? current : null);
      if (splitOn) {
        drawLayer(boardShapes, BT, BR, layer === 'board' ? current : null);
        // خارج حدود السبورة (عند التصغير): تظليل خفيف يوضح أين تنتهي
        const W = stage.clientWidth, H = stage.clientHeight, C = { x: BT.x, y: BT.y, w: W * BT.s, h: H * BT.s };
        if (BR && (C.w < BR.w - 1 || C.h < BR.h - 1)) {
          ctx.save(); ctx.beginPath(); ctx.rect(BR.x, BR.y, BR.w, BR.h); ctx.rect(C.x, C.y, C.w, C.h); ctx.clip('evenodd');
          ctx.fillStyle = boardColor === 2 ? 'rgba(0,0,0,.28)' : 'rgba(0,0,0,.07)'; ctx.fillRect(BR.x, BR.y, BR.w, BR.h); ctx.restore();
        }
      }
    }
  }

  // ---------- الممحاة ----------
  function distSeg(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1, l = dx * dx + dy * dy;
    let t = l ? ((px - x1) * dx + (py - y1) * dy) / l : 0; t = Math.max(0, Math.min(1, t));
    return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
  }
  function hit(s, x, y) {
    const tol = 10 + (s.width || 4);
    if (s.type === 'pen' || s.type === 'hl') {
      const p = s.points, t = s.type === 'hl' ? tol + s.width * 2.5 : tol;
      if (p.length === 1) return Math.hypot(x - p[0][0], y - p[0][1]) < t;
      for (let i = 1; i < p.length; i++) if (distSeg(x, y, p[i - 1][0], p[i - 1][1], p[i][0], p[i][1]) < t) return true;
      return false;
    }
    if (s.type === 'arrow') return distSeg(x, y, s.x1, s.y1, s.x2, s.y2) < tol;
    if (s.type === 'rect' || s.type === 'ellipse') {
      const x1 = Math.min(s.x1, s.x2), x2 = Math.max(s.x1, s.x2), y1 = Math.min(s.y1, s.y2), y2 = Math.max(s.y1, s.y2);
      return x >= x1 - tol && x <= x2 + tol && y >= y1 - tol && y <= y2 + tol;
    }
    if (s.type === 'text') {
      ctx.save(); ctx.font = `700 ${s.size}px "Segoe UI", Tahoma, Arial`;
      const lines = s.text.split('\n'); const w = Math.max(...lines.map(l => ctx.measureText(l).width)); ctx.restore();
      const x0 = (s.dir || 'rtl') === 'rtl' ? s.x - w : s.x;
      return x >= x0 - 6 && x <= x0 + w + 6 && y >= s.y - 6 && y <= s.y + lines.length * s.size * 1.3 + 6;
    }
    return false;
  }
  let erasedThisDrag = false;
  function eraseAt(x, y) {
    const keep = shapes.filter(s => !hit(s, x, y));
    if (keep.length !== shapes.length) {
      if (!erasedThisDrag) { pushUndo(); erasedThisDrag = true; }
      shapes = keep; redraw();
    }
  }


  // ---------- التحديد: تحريك الشكل وتدويره وتكبيره بعد وضعه ----------
  // آخر شكل يوضع يبقى محدداً ما دامت أداته مختارة، وأداة «✥ تحديد وتحريك» تحدد أي شكل قديم.
  let sel = null, selLayer = 'lesson', sdrag = null, hoverSel = false, nudgeT = 0;
  const SHAPE_TOOLS = new Set(['rect', 'ellipse', 'arrow', 'branch', 'stamp', 'text']);
  const selOn = () => tool === 'select' || SHAPE_TOOLS.has(tool);
  const selT = () => selLayer === 'board' ? BT : LT;
  function selValid() {
    if (sel && (!selOn() || selLayer !== layer || !shapes.includes(sel))) sel = null;
    return !!sel;
  }
  function select(s) { sel = s; selLayer = layer; }
  function hitSel(s, x, y) {
    if (s.type === 'erase') return false;
    if (ROTATABLE.has(s.type)) {
      const b = box(s);
      if (s.rot) [x, y] = rotP(x, y, b.cx, b.cy, -s.rot);
      const tol = 6 / curT().s;
      if (s.type === 'rect' || s.type === 'ellipse') return hit({ ...s, rot: 0 }, x, y);
      return Math.abs(x - b.cx) <= b.w / 2 + tol && Math.abs(y - b.cy) <= b.h / 2 + tol;
    }
    return hit(s, x, y);
  }
  // المقابض بإحداثيات الشاشة
  function handles(s) {
    const T = selT(), sc = (x, y) => [T.x + x * T.s, T.y + y * T.s];
    if (s.type === 'arrow') return [{ k: 'p1', p: sc(s.x1, s.y1) }, { k: 'p2', p: sc(s.x2, s.y2) }];
    const b = box(s), rot = ROTATABLE.has(s.type) ? (s.rot || 0) : 0, pad = 6 / T.s;
    const hw = b.w / 2 + pad, hh = b.h / 2 + pad;
    const P = (dx, dy) => sc(...rotP(b.cx + dx, b.cy + dy, b.cx, b.cy, rot));
    const out = { corners: [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]].map(([dx, dy]) => P(dx, dy)) };
    if (!ROTATABLE.has(s.type)) return [{ k: 'frame', pts: out.corners }];
    const list = [{ k: 'frame', pts: out.corners }];
    out.corners.forEach((p, i) => list.push({ k: 'rs', i, p }));
    const top = P(0, -hh), up = rotP(0, -1, 0, 0, rot);
    list.push({ k: 'rot', p: [top[0] + up[0] * 26, top[1] + up[1] * 26], base: top });
    return list;
  }
  function handleAt(sx, sy) {
    if (!selValid()) return null;
    for (const h of handles(sel)) if (h.p && Math.hypot(sx - h.p[0], sy - h.p[1]) <= 10) return h;
    return null;
  }
  function drawSel(c) {
    if (!selValid()) return;
    const hs = handles(sel);
    c.save(); c.lineWidth = 1.5;
    for (const h of hs) {
      if (h.k === 'frame') {
        c.setLineDash([5, 4]); c.strokeStyle = 'rgba(34,139,230,.95)';
        c.beginPath(); h.pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.closePath(); c.stroke(); c.setLineDash([]);
      } else if (h.k === 'rot') {
        c.strokeStyle = 'rgba(34,139,230,.95)'; c.beginPath(); c.moveTo(h.base[0], h.base[1]); c.lineTo(h.p[0], h.p[1]); c.stroke();
        c.fillStyle = '#fff'; c.beginPath(); c.arc(h.p[0], h.p[1], 7, 0, Math.PI * 2); c.fill(); c.stroke();
        c.fillStyle = '#228be6'; c.font = '700 10px "Segoe UI", Arial'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('⟳', h.p[0], h.p[1] + 0.5);
      } else {
        c.fillStyle = '#fff'; c.strokeStyle = '#228be6';
        if (h.k === 'rs') { c.beginPath(); c.rect(h.p[0] - 5, h.p[1] - 5, 10, 10); c.fill(); c.stroke(); }
        else { c.beginPath(); c.arc(h.p[0], h.p[1], 6, 0, Math.PI * 2); c.fill(); c.stroke(); }
      }
    }
    c.restore();
  }
  function moveBy(s, o, dx, dy) {
    for (const k of ['x1', 'x2', 'x', 'cx']) if (k in o) s[k] = o[k] + dx;
    for (const k of ['y1', 'y2', 'y', 'cy']) if (k in o) s[k] = o[k] + dy;
    if (o.points) s.points = o.points.map(p => [p[0] + dx, p[1] + dy]);
  }
  function startSelDrag(e, kind, h, x, y) {
    sdrag = { kind, h, o: JSON.parse(JSON.stringify(sel)), x, y, b: box(sel), pushed: false };
    cv.setPointerCapture(e.pointerId);
  }
  function selDragMove(e, sx, sy) {
    const [x, y] = toL(sx, sy), d = sdrag, s = sel, o = d.o;
    if (!d.pushed) {
      if (Math.hypot(x - d.x, y - d.y) * curT().s < 2) return;
      const i = shapes.indexOf(s); shapes[i] = o; pushUndo(); shapes[i] = s; d.pushed = true;   // التراجع يعيد الشكل كما كان
    }
    if (d.kind === 'move') moveBy(s, o, x - d.x, y - d.y);
    else if (d.kind === 'p1' || d.kind === 'p2') {
      const fx = d.kind === 'p1' ? o.x2 : o.x1, fy = d.kind === 'p1' ? o.y2 : o.y1;
      let px = x, py = y;
      if (e.shiftKey) { const a = Math.round(Math.atan2(py - fy, px - fx) / (Math.PI / 12)) * (Math.PI / 12), r = Math.hypot(px - fx, py - fy); px = fx + Math.cos(a) * r; py = fy + Math.sin(a) * r; }
      if (d.kind === 'p1') { s.x1 = px; s.y1 = py; } else { s.x2 = px; s.y2 = py; }
    } else if (d.kind === 'rot') {
      const b = d.b, a0 = Math.atan2(d.y - b.cy, d.x - b.cx), a1 = Math.atan2(y - b.cy, x - b.cx);
      let r = (o.rot || 0) + a1 - a0;
      if (e.shiftKey) r = Math.round(r / (Math.PI / 12)) * (Math.PI / 12);
      r = Math.atan2(Math.sin(r), Math.cos(r)); if (Math.abs(r) < 0.04) r = 0;     // يلتصق بالوضع الأفقي
      s.rot = r;
    } else if (d.kind === 'rs') {
      const b = d.b, rot = o.rot || 0;
      if (s.type === 'stamp' || s.type === 'text') {
        const k = Math.max(0.15, Math.hypot(x - b.cx, y - b.cy) / Math.max(1, Math.hypot(d.x - b.cx, d.y - b.cy)));
        s.size = Math.max(8, o.size * k);
        if (s.type === 'text') { s.x = b.cx + (o.x - b.cx) * k; s.y = b.cy + (o.y - b.cy) * k; }
      } else {
        const sg = [[-1, -1], [1, -1], [1, 1], [-1, 1]][d.h.i];
        const F = rotP(b.cx - sg[0] * b.w / 2, b.cy - sg[1] * b.h / 2, b.cx, b.cy, rot);
        let [vx, vy] = rotP(x, y, F[0], F[1], -rot); vx -= F[0]; vy -= F[1];
        let w = Math.abs(vx), h = Math.abs(vy);
        if (e.shiftKey && b.w && b.h) { const k = Math.max(w / b.w, h / b.h); w = b.w * k; h = b.h * k; vx = Math.sign(vx || sg[0]) * w; vy = Math.sign(vy || sg[1]) * h; }
        const mn = 8 / curT().s; w = Math.max(mn, w); h = Math.max(mn, h);
        const c = rotP(F[0] + Math.sign(vx || sg[0]) * w / 2, F[1] + Math.sign(vy || sg[1]) * h / 2, F[0], F[1], rot);
        if (s.type === 'branch') { s.cx = c[0]; s.cy = c[1]; s.w = w; s.h = h; }
        else { s.x1 = c[0] - w / 2; s.x2 = c[0] + w / 2; s.y1 = c[1] - h / 2; s.y2 = c[1] + h / 2; }
      }
    }
    redraw();
  }
  function cursorAt(sx, sy) {
    const h = handleAt(sx, sy);
    if (h) return h.k === 'rot' ? 'grab' : h.k === 'rs' ? 'nwse-resize' : 'crosshair';
    if (!selValid() && tool !== 'select') return '';
    const [x, y] = toL(sx, sy);
    if (sel && hitSel(sel, x, y)) return 'move';
    if (tool === 'select' && layerAt(sx, sy) === layer && shapes.some(s => hitSel(s, x, y))) return 'move';
    return '';
  }
  function nudge(dx, dy) {
    if (!selValid()) return false;
    const now = Date.now(); if (now - nudgeT > 700) pushUndo(); nudgeT = now;
    const k = 1 / selT().s, o = JSON.parse(JSON.stringify(sel));
    moveBy(sel, o, dx * k, dy * k); redraw(); return true;
  }
  function deleteSel() {
    if (!selValid()) return false;
    pushUndo(); shapes = shapes.filter(s => s !== sel); sel = null; redraw(); return true;
  }
  // السهم المتفرع من السحب: الاتجاه الغالب يحدد وجهة الفروع، والبعد الآخر يحدد انتشارها
  function branchFrom(ax, ay, bx, by, base) {
    const dx = bx - ax, dy = by - ay, vert = Math.abs(dy) >= Math.abs(dx);
    const len = Math.max(Math.abs(vert ? dy : dx), 1), sp = Math.abs(vert ? dx : dy);
    const rot = vert ? (dy >= 0 ? 0 : Math.PI) : (dx >= 0 ? -Math.PI / 2 : Math.PI / 2);
    return { ...base, type: 'branch', cx: (ax + bx) / 2, cy: (ay + by) / 2, h: len, w: sp < len * 0.35 ? len * 0.9 : sp, rot };
  }

  // ---------- النص ----------
  let textEl = null;
  function startText(x, y) {
    commitText();
    const size = 14 + width * 4;
    const el = document.createElement('textarea');
    el.className = 'textEntry'; el.rows = 1;
    if (I18N.dir() === 'rtl') el.style.right = (stage.clientWidth - x) + 'px'; else el.style.left = x + 'px';
    el.style.top = y + 'px'; el.dir = I18N.dir();
    el.style.color = color; el.style.fontSize = size + 'px';
    const T = curT();
    el.dataset.x = (x - T.x) / T.s; el.dataset.y = (y - T.y) / T.s; el.dataset.size = size / T.s; el.dataset.color = color;
    el.addEventListener('input', () => { el.style.height = 'auto'; el.style.height = el.scrollHeight + 'px'; el.style.width = 'auto'; });
    el.addEventListener('keydown', e => {
      e.stopPropagation();
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); commitText(); }
      if (e.key === 'Escape') { el.value = ''; commitText(); }
    });
    stage.appendChild(el); textEl = el;
    setTimeout(() => el.focus(), 0);
  }
  function commitText() {
    if (!textEl) return;
    const el = textEl; textEl = null;
    const t = el.value.trim();
    if (t) {
      pushUndo();
      shapes.push({ type: 'text', text: t, x: +el.dataset.x, y: +el.dataset.y + 4 / curT().s, size: +el.dataset.size, color: el.dataset.color, dir: I18N.dir() });
      if (tool === 'text') select(shapes[shapes.length - 1]);
      redraw();
    }
    el.remove();
  }

  // ---------- الليزر ----------
  const laserPts = []; let laserPos = null;
  let spotR = 160; const spotCur = { x: 0, y: 0, r: 160 };
  function laserLoop() {
    const now = performance.now(), life = 650;
    while (laserPts.length && now - laserPts[0].t > life) laserPts.shift();
    lctx.setTransform(1, 0, 0, 1, 0, 0); lctx.clearRect(0, 0, lv.width, lv.height);
    lctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (tool === 'spot') {
      const W = lv.width / dpr, H = lv.height / dpr;
      const cx = laserPos ? laserPos.x : W / 2, cy = laserPos ? laserPos.y : H / 2;
      spotCur.x += (cx - spotCur.x) * 0.35; spotCur.y += (cy - spotCur.y) * 0.35; spotCur.r += (spotR - spotCur.r) * 0.25;
      lctx.fillStyle = 'rgba(0,0,0,0.78)'; lctx.fillRect(0, 0, W, H);
      lctx.globalCompositeOperation = 'destination-out';
      const g = lctx.createRadialGradient(spotCur.x, spotCur.y, spotCur.r * 0.86, spotCur.x, spotCur.y, spotCur.r);
      g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      lctx.fillStyle = g; lctx.beginPath(); lctx.arc(spotCur.x, spotCur.y, spotCur.r, 0, Math.PI * 2); lctx.fill();
      lctx.globalCompositeOperation = 'source-over';
    }
    if (tool === 'eraser' && laserPos) {
      lctx.beginPath(); lctx.arc(laserPos.x, laserPos.y, eraserR, 0, Math.PI * 2);
      lctx.fillStyle = 'rgba(255,255,255,.35)'; lctx.fill();
      lctx.lineWidth = 2; lctx.strokeStyle = 'rgba(0,0,0,.55)'; lctx.setLineDash([4, 3]); lctx.stroke(); lctx.setLineDash([]);
    }
    if (tool === 'stamp' && laserPos && !hoverSel) drawStamp(lctx, { ch: stampCh, x: laserPos.x, y: laserPos.y, size: stampSize, rot: 0 }, 0.55);
    if (selOn() && !current) drawSel(lctx);
    if (tool === 'laser') {
      lctx.lineCap = 'round'; lctx.lineJoin = 'round';
      for (let i = 1; i < laserPts.length; i++) {
        const a = laserPts[i - 1], b = laserPts[i];
        if (b.gap) continue;
        const k = 1 - (now - b.t) / life;
        lctx.strokeStyle = `rgba(255,40,40,${0.85 * k})`;
        lctx.shadowColor = 'rgba(255,0,0,0.9)'; lctx.shadowBlur = 14;
        lctx.lineWidth = 3 + 5 * k;
        lctx.beginPath(); lctx.moveTo(a.x, a.y); lctx.lineTo(b.x, b.y); lctx.stroke();
      }
      if (laserPos) {
        lctx.shadowColor = 'rgba(255,0,0,1)'; lctx.shadowBlur = 22;
        lctx.fillStyle = 'rgba(255,40,40,0.95)';
        lctx.beginPath(); lctx.arc(laserPos.x, laserPos.y, 7, 0, Math.PI * 2); lctx.fill();
        lctx.shadowBlur = 0; lctx.fillStyle = '#fff';
        lctx.beginPath(); lctx.arc(laserPos.x, laserPos.y, 2.5, 0, Math.PI * 2); lctx.fill();
      }
    }
    requestAnimationFrame(laserLoop);
  }
  requestAnimationFrame(laserLoop);

  // ---------- أحداث المؤشر ----------
  const pos = e => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  const inR = (R, x, y) => R && x >= R.x && x < R.x + R.w && y >= R.y && y < R.y + R.h;
  const layerAt = (x, y) => boardMode > 0 ? 'board' : splitOn && inR(BR, x, y) ? 'board' : 'lesson';
  function useLayer(l) {
    if (l === layer) return;
    commitText(); current = null;
    const st = (n) => n === 'board' ? boardPages[boardPage] : active ? pageData(active) : null;
    const a = st(layer); if (a) { a.shapes = shapes; a.undo = undoStack; a.redo = redoStack; }
    layer = l;
    const b = st(layer) || { shapes: [], undo: [], redo: [] }; shapes = b.shapes; undoStack = b.undo; redoStack = b.redo;
  }
  const toL = (x, y) => { const T = curT(); return [(x - T.x) / T.s, (y - T.y) / T.s]; };
  let drawingNow = false, laserDown = false;

  cv.addEventListener('pointerdown', e => {
    if (e.button === 2) { setTool('mouse'); return; }
    const [sx, sy] = pos(e);
    cv.setPointerCapture(e.pointerId);
    // المقابض والشكل المحدد قبل أي رسم جديد
    if (selOn() && e.button === 0) {
      const h = handleAt(sx, sy);
      if (h && h.k !== 'frame') { commitText(); startSelDrag(e, h.k, h, ...toL(sx, sy)); return; }
      if (selValid() && layerAt(sx, sy) === selLayer && hitSel(sel, ...toL(sx, sy))) { commitText(); startSelDrag(e, 'move', null, ...toL(sx, sy)); return; }
    }
    if (tool !== 'laser' && tool !== 'spot') useLayer(layerAt(sx, sy));
    if (tool === 'select') {
      commitText();
      const [x, y] = toL(sx, sy);
      let found = null; for (let i = shapes.length - 1; i >= 0; i--) if (hitSel(shapes[i], x, y)) { found = shapes[i]; break; }
      sel = null;
      if (found) { select(found); startSelDrag(e, 'move', null, x, y); }
      redraw(); return;
    }
    sel = null;
    if (tool === 'text') { startText(sx, sy); return; }
    commitText();
    drawingNow = true;
    const [x, y] = toL(sx, sy), k = 1 / curT().s;
    if (tool === 'pen' || tool === 'hl') current = { type: tool, color, width: width * k, points: [[x, y]] };
    else if (tool === 'eraser') current = { type: 'erase', width: eraserR * 2 * k, points: [[x, y]] };
    else if (tool === 'stamp') { pushUndo(); shapes.push({ type: 'stamp', ch: stampCh, x, y, size: stampSize * k }); select(shapes[shapes.length - 1]); drawingNow = false; redraw(); return; }
    else if (tool === 'rect' || tool === 'ellipse' || tool === 'arrow') current = { type: tool, color, width: width * k, x1: x, y1: y, x2: x, y2: y };
    else if (tool === 'branch') current = { type: 'branch', kind: branchKind, n: branchN, color, width: width * k, ax: x, ay: y, cx: x, cy: y, w: 0, h: 0, rot: 0 };
    else if (tool === 'laser') { laserDown = true; laserPts.push({ x: sx, y: sy, t: performance.now(), gap: true }); }
    redraw();
  });
  cv.addEventListener('pointermove', e => {
    const [x, y] = pos(e);
    if (sdrag) { selDragMove(e, x, y); return; }
    if (selOn() && !drawingNow) { const cu = cursorAt(x, y); cv.style.cursor = cu; hoverSel = !!cu; } else if (cv.style.cursor) { cv.style.cursor = ''; hoverSel = false; }
    if (tool === 'spot') { laserPos = { x, y }; return; }
    if (tool === 'eraser' || tool === 'stamp') laserPos = { x, y };
    if (tool === 'laser') {
      laserPos = { x, y };
      laserPts.push({ x, y, t: performance.now(), gap: false });
      return;
    }
    if (!drawingNow) return;
    if (current && current.points) {
      let evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [];
      if (!evs.length) evs = [e];
      for (const ev of evs) { const p = pos(ev); current.points.push(toL(p[0], p[1])); }
    } else if (current) {
      const [lx, ly] = toL(x, y);
      if (current.type === 'branch') { Object.assign(current, branchFrom(current.ax, current.ay, lx, ly, current)); redraw(); return; }
      current.x2 = lx; current.y2 = ly;
      if (e.shiftKey && current.type !== 'arrow') {   // Shift = مربع/دائرة متساوية
        const d = Math.max(Math.abs(lx - current.x1), Math.abs(ly - current.y1));
        current.x2 = current.x1 + Math.sign(lx - current.x1 || 1) * d;
        current.y2 = current.y1 + Math.sign(ly - current.y1 || 1) * d;
      }
    }
    redraw();
  });
  const endDraw = () => {
    laserDown = false;
    if (sdrag) { sdrag = null; redraw(); return; }
    if (!drawingNow) return;
    drawingNow = false;
    if (current) {
      const tiny = current.points ? false : current.type === 'branch' ? current.h * curT().s < 12 : Math.hypot(current.x2 - current.x1, current.y2 - current.y1) * curT().s < 4;
      if (current.type === 'branch') { delete current.ax; delete current.ay; }
      if (!tiny) { pushUndo(); shapes.push(current); if (SHAPE_TOOLS.has(current.type)) select(current); }
      current = null; redraw();
    }
  };
  cv.addEventListener('pointerup', endDraw);
  cv.addEventListener('pointercancel', endDraw);
  cv.addEventListener('pointerleave', () => { if (tool !== 'spot') laserPos = null; });
  cv.addEventListener('contextmenu', e => e.preventDefault());
  // حجم الكشّاف: العجلة، إصبعان على لوحة اللمس، القرص بإصبعين على شاشة اللمس، الأزرار، أو + و −
  const setSpotR = (r) => { spotR = Math.max(40, Math.min(900, r)); const v = $('#spotSize'); if (v) v.textContent = Math.round(spotR / 1.6) + '%'; };
  cv.addEventListener('wheel', e => {
    if (tool !== 'spot') return;
    e.preventDefault();
    const d = e.deltaY * (e.deltaMode === 1 ? 40 : e.deltaMode === 2 ? 400 : 1);
    setSpotR(spotR * Math.pow(1.0018, -Math.max(-300, Math.min(300, d))));
  }, { passive: false });
  const touches = new Map(); let pinch = null;
  cv.addEventListener('pointerdown', e => {
    if (tool !== 'spot' || e.pointerType === 'mouse') return;
    touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (touches.size === 2) { const [a, b] = [...touches.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, r: spotR }; }
  });
  cv.addEventListener('pointermove', e => {
    if (!touches.has(e.pointerId)) return;
    touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch && touches.size === 2) { const [a, b] = [...touches.values()]; setSpotR(pinch.r * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d); }
  });
  const touchEnd = e => { touches.delete(e.pointerId); if (touches.size < 2) pinch = null; };
  cv.addEventListener('pointerup', touchEnd); cv.addEventListener('pointercancel', touchEnd);
  $('#spotMinus').onclick = () => setSpotR(spotR / 1.2);
  $('#spotPlus').onclick = () => setSpotR(spotR * 1.2);
  $('#spotClose').onclick = () => setTool('mouse');
  // عند الانتقال لبرنامج آخر يتوقف الكشّاف (حتى لا تبقى الشاشة مظلمة خلفه)
  window.addEventListener('blur', () => setTimeout(() => { if (tool === 'spot' && !document.hasFocus()) setTool('mouse'); }, 150));

  // ---------- السبورة (كاملة أو نصف ونصف) ----------
  // ثلاث حالات: الدرس كاملاً، السبورة كاملة، أو التقسيم (الدرس في جهة والسبورة في الأخرى).
  // للسبورة صفحاتها ورسمها المستقل عن رسم الدرس، وفي التقسيم يصغر الدرس ورسمه معاً بنفس النسبة.
  const SP = { dir: 'h', swap: false, ratio: 0.55, z: 0 };     // z = 0 → «ملاءمة»
  const spScroll = { x: 0, y: 0 };
  const mk = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html) e.innerHTML = html; return e; };
  const mats = [0, 1, 2, 3].map(() => mk('div', 'spMat'));
  const spDiv = mk('div'); spDiv.id = 'spDiv';
  const spBar = mk('div', 'spCtl', `<button data-a="swap" title="${I18N.t('تبديل الجهتين')}">⇄</button><button data-a="dir"></button><button data-a="color"></button><button data-a="full" title="${I18N.t('تكبير السبورة')}">⛶</button><button data-a="close" title="${I18N.t('إغلاق التقسيم (عودة إلى الدرس)')}">✕</button>`); spBar.id = 'spBar';
  const bdPg = mk('div', 'spCtl', `<button data-a="prev" title="${I18N.t('الصفحة السابقة')}">‹</button><span class="n"></span><button data-a="next" title="${I18N.t('الصفحة التالية')}">›</button><button data-a="add" title="${I18N.t('صفحة جديدة في السبورة')}">＋</button><button data-a="split" title="${I18N.t('نصف درس ونصف سبورة')}">◧</button>`); bdPg.id = 'bdPg'; rtlNav(bdPg);
  const spZoom = mk('div', 'spCtl', `<button data-z="-1" title="${I18N.t('تصغير الدرس')}">−</button><span class="n"></span><button data-z="1" title="${I18N.t('تكبير الدرس')}">＋</button><button data-z="0" title="${I18N.t('ملاءمة: الدرس كاملاً في جهته')}">⤢</button>`); spZoom.id = 'spZoom';
  const sbV = mk('div', 'spSB v', '<i></i>'), sbH = mk('div', 'spSB h', '<i></i>');
  // تكبير السبورة وتمريرها (مستقلان عن الدرس): في التقسيم «ملاءمة» = السبورة كاملة داخل نصفها، وفي السبورة الكاملة 100% حتى 300%
  const bdZoom = mk('div', 'spCtl', `<button data-z="-1" title="${I18N.t('تصغير السبورة')}">−</button><span class="n"></span><button data-z="1" title="${I18N.t('تكبير السبورة')}">＋</button><button data-z="0" title="${I18N.t('ملاءمة: السبورة كاملة')}">⤢</button>`); bdZoom.id = 'bdZoom';
  const bsV = mk('div', 'spSB v bsb', '<i></i>'), bsH = mk('div', 'spSB h bsb', '<i></i>');
  const BZ = { split: 0, full: 1 }, bScroll = { x: 0, y: 0 }; let bMax = { x: 0, y: 0 }, bZoomVal = 1, bArea = null;
  for (const e of [...mats, spDiv, sbV, sbH, bsV, bsH, spBar, bdPg, spZoom, bdZoom]) stage.insertBefore(e, cv);

  const setBox = (el, R) => { const st = el.style; if (!R) { st.inset = st.left = st.top = st.width = st.height = st.right = st.bottom = ''; return; } st.inset = 'auto'; st.left = R.x + 'px'; st.top = R.y + 'px'; st.width = Math.max(0, R.w) + 'px'; st.height = Math.max(0, R.h) + 'px'; };
  const inter = (a, b) => { const x = Math.max(a.x, b.x), y = Math.max(a.y, b.y), x2 = Math.min(a.x + a.w, b.x + b.w), y2 = Math.min(a.y + a.h, b.y + b.h); return { x, y, w: Math.max(0, x2 - x), h: Math.max(0, y2 - y) }; };
  const clearTab = (t) => { setBox(t.wv, null); const im = t.wv.querySelector && t.wv.querySelector('img'); if (im) setBox(im, null); t.spRect = null; };
  let spZoomVal = 1, spMax = { x: 0, y: 0 }, pptT = null;
  function sbar(el, on, R, frac, pos) {
    el.classList.toggle('on', on); if (!on) return; setBox(el, R);
    const th = el.querySelector('i'), vert = el.classList.contains('v'), len = vert ? R.h : R.w, tl = Math.max(30, len * frac), at = (len - tl) * pos;
    Object.assign(th.style, vert ? { top: at + 'px', height: tl + 'px', left: '0', width: '100%' } : { left: at + 'px', width: tl + 'px', top: '0', height: '100%' });
  }
  // السبورة داخل منطقتها R: حجمها الكامل بحجم مساحة العرض، تُصغَّر أو تُكبَّر وتُمرَّر
  function layoutBoard(R, full) {
    const W = stage.clientWidth, H = stage.clientHeight, rtl = I18N.dir() === 'rtl';
    bArea = R;
    if (!R) { BT = ID; bMax = { x: 0, y: 0 }; for (const e of [bdZoom, bsV, bsH]) e.classList.remove('on'); return; }
    const fit = full ? 1 : Math.min(R.w / W, R.h / H);
    const z = full ? Math.max(1, Math.min(3, BZ.full)) : (BZ.split ? Math.max(fit, Math.min(3, BZ.split)) : fit);
    bZoomVal = z;
    const cw = W * z, ch = H * z;
    bMax = { x: Math.max(0, cw - R.w), y: Math.max(0, ch - R.h) };
    bScroll.x = Math.max(0, Math.min(bMax.x, bScroll.x)); bScroll.y = Math.max(0, Math.min(bMax.y, bScroll.y));
    const x = cw <= R.w ? R.x + (R.w - cw) / 2 : rtl ? R.x + R.w - cw + bScroll.x : R.x - bScroll.x;
    const y = ch <= R.h ? R.y + (R.h - ch) / 2 : R.y - bScroll.y;
    BT = { s: z, x, y };
    bdZoom.classList.add('on');
    const atFit = full ? z <= 1.001 : !BZ.split;
    bdZoom.querySelector('.n').textContent = atFit ? I18N.t('ملاءمة') : Math.round(z / (full ? 1 : 1) * 100) + '%';
    sbar(bsV, bMax.y > 0, { x: rtl ? R.x + 2 : R.x + R.w - 14, y: R.y + 4, w: 12, h: R.h - 8 }, R.h / ch, bMax.y ? bScroll.y / bMax.y : 0);
    sbar(bsH, bMax.x > 0, { x: R.x + 4, y: R.y + R.h - 14, w: R.w - 8, h: 12 }, R.w / cw, bMax.x ? (rtl ? 1 - bScroll.x / bMax.x : bScroll.x / bMax.x) : 0);
  }
  function layoutSplit() {
    const r = stage.getBoundingClientRect(), W = r.width, H = r.height;
    document.body.classList.toggle('lpSplit', splitOn);
    tabs.forEach(t => { if (t !== active || !splitOn) clearTab(t); });
    if (!splitOn || !active || W < 50 || H < 50) {
      LT = ID; LR = BR = null; setBox(board, null);
      for (const e of [spBar, spZoom, sbV, sbH]) e.classList.remove('on');
      layoutBoard(boardMode > 0 && W >= 50 && H >= 50 ? { x: 0, y: 0, w: W, h: H } : null, true);
      updPg(); return;
    }
    const rtl = I18N.dir() === 'rtl', dv = 10;
    let L, B, D;
    if (SP.dir === 'h') {
      const lw = Math.round((W - dv) * SP.ratio), bw = W - dv - lw;
      const lessonRight = rtl ? !SP.swap : SP.swap;      // العرض في جهة بداية القراءة، والسبورة بجانبه
      L = { x: lessonRight ? bw + dv : 0, y: 0, w: lw, h: H }; B = { x: lessonRight ? 0 : lw + dv, y: 0, w: bw, h: H }; D = { x: lessonRight ? bw : lw, y: 0, w: dv, h: H };
    } else {
      const lh = Math.round((H - dv) * SP.ratio), bh = H - dv - lh, top = !SP.swap;
      L = { x: 0, y: top ? 0 : bh + dv, w: W, h: lh }; B = { x: 0, y: top ? lh + dv : 0, w: W, h: bh }; D = { x: 0, y: top ? lh : bh, w: W, h: dv };
    }
    LR = L; BR = B;
    const fit = Math.min(L.w / W, L.h / H), z = SP.z ? Math.max(fit, SP.z) : fit;
    spZoomVal = z;
    const cw = W * z, ch = H * z, isPpt = active.kind === 'ppt';
    spMax = { x: isPpt ? Math.max(0, cw - L.w) : 0, y: isPpt ? Math.max(0, ch - L.h) : 0 };
    spScroll.x = Math.max(0, Math.min(spMax.x, spScroll.x)); spScroll.y = Math.max(0, Math.min(spMax.y, spScroll.y));
    let C;
    if (isPpt) {
      const cx = cw <= L.w ? L.x + (L.w - cw) / 2 : rtl ? L.x + L.w - cw + spScroll.x : L.x - spScroll.x;
      const cy = ch <= L.h ? L.y + (L.h - ch) / 2 : L.y - spScroll.y;
      C = { x: cx, y: cy, w: cw, h: ch };
    } else {
      // صفحات الويب وPDF: تصغر بنفس النسبة، وإن كانت أكبر من جهتها تتمرّر بنفسها
      const w = Math.min(cw, L.w), h = Math.min(ch, L.h);
      C = { x: L.x + (L.w - w) / 2, y: L.y + (L.h - h) / 2, w, h };
    }
    const box = inter(C, L);
    LT = { s: z, x: C.x, y: C.y };
    setBox(active.wv, box);
    const im = active.wv.querySelector && active.wv.querySelector('.slidesImg img, img');
    if (active.kind === 'ppt' && active.ppt && active.ppt.images && im) setBox(im, { x: C.x - box.x, y: C.y - box.y, w: cw, h: ch });
    active.spRect = C;
    if (active.kind !== 'ppt') applyZoom(active);
    else if (active.ppt && !active.ppt.images) { clearTimeout(pptT); pptT = setTimeout(() => pptSyncRect(active), 40); }
    // ما حول الدرس داخل جهته
    setBox(mats[0], { x: L.x, y: L.y, w: L.w, h: box.y - L.y });
    setBox(mats[1], { x: L.x, y: box.y + box.h, w: L.w, h: L.y + L.h - box.y - box.h });
    setBox(mats[2], { x: L.x, y: box.y, w: box.x - L.x, h: box.h });
    setBox(mats[3], { x: box.x + box.w, y: box.y, w: L.x + L.w - box.x - box.w, h: box.h });
    // السبورة
    setBox(board, B);
    layoutBoard(B, false);
    setBox(spDiv, D); spDiv.classList.toggle('v', SP.dir === 'v');
    // أدوات التحكم
    spBar.classList.add('on'); spBar.style.left = (B.x + B.w / 2) + 'px'; spBar.style.top = (B.y + 8) + 'px';
    spBar.querySelector('[data-a="dir"]').textContent = SP.dir === 'h' ? '⇅' : '⇆';
    spBar.querySelector('[data-a="dir"]').title = I18N.t(SP.dir === 'h' ? 'الدرس فوق والسبورة تحت' : 'الدرس والسبورة جنباً إلى جنب');
    spBar.querySelector('[data-a="color"]').textContent = boardColor === 2 ? '⬜' : '🟩';
    spBar.querySelector('[data-a="color"]').title = I18N.t(boardColor === 2 ? 'سبورة بيضاء' : 'سبورة خضراء');
    spZoom.classList.add('on'); spZoom.style.left = (L.x + L.w / 2) + 'px'; spZoom.style.top = (L.y + L.h - 44) + 'px';
    spZoom.querySelector('.n').textContent = SP.z ? Math.round(z * 100) + '%' : I18N.t('ملاءمة');
    // أشرطة التمرير (للعرض والصور؛ صفحات الويب لها تمريرها)
    const bar = sbar;
    bar(sbV, spMax.y > 0, { x: rtl ? L.x + 2 : L.x + L.w - 14, y: L.y + 4, w: 12, h: L.h - 8 }, L.h / ch, spMax.y ? spScroll.y / spMax.y : 0);
    bar(sbH, spMax.x > 0, { x: L.x + 4, y: L.y + L.h - 14, w: L.w - 8, h: 12 }, L.w / cw, spMax.x ? (rtl ? 1 - spScroll.x / spMax.x : spScroll.x / spMax.x) : 0);
    updPg();
  }
  window.__lpSplitLayout = layoutSplit;
  function updPg() {
    const on = boardMode > 0 || splitOn;
    bdPg.classList.toggle('on', on);
    if (!on) return;
    bdPg.querySelector('.n').textContent = `${boardPage + 1} / ${boardPages.length}`;
    bdPg.querySelector('[data-a="split"]').style.display = splitOn ? 'none' : '';
    const R = splitOn && BR ? BR : { x: 0, y: 0, w: stage.clientWidth, h: stage.clientHeight };
    const pw = bdPg.offsetWidth, zw = bdZoom.classList.contains('on') ? bdZoom.offsetWidth + 8 : 0, start = R.x + R.w / 2 - (pw + zw) / 2;
    const top = R.y + R.h - 44 - (bMax.x > 0 ? 12 : 0);
    bdPg.style.left = (start + pw / 2) + 'px'; bdPg.style.top = top + 'px';
    if (zw) { bdZoom.style.left = (start + pw + 8 + (zw - 8) / 2) + 'px'; bdZoom.style.top = top + 'px'; }
  }
  function goBoardPage(i) {
    i = Math.max(0, Math.min(boardPages.length - 1, i)); if (i === boardPage) return;
    if (layer === 'board') { commitText(); current = null; const d = boardPages[boardPage]; d.shapes = shapes; d.undo = undoStack; d.redo = redoStack; boardPage = i; const n = boardPages[i]; shapes = n.shapes; undoStack = n.undo; redoStack = n.redo; }
    else boardPage = i;
    redraw(); updPg();
  }
  function setView(v) {
    commitText(); current = null;
    const was = splitOn;
    splitOn = v === 'split'; boardMode = v === 'board' ? boardColor : 0;
    if (v === 'lesson') useLayer('lesson'); else if (v === 'board') useLayer('board');
    board.className = v === 'lesson' ? '' : 'on' + (boardColor === 2 ? ' dark' : '');
    $('#boardBtn').classList.toggle('on', v === 'board');
    $('#splitBtn').classList.toggle('on', splitOn);
    if (v === 'board' && tool === 'mouse') setTool('pen');
    layoutSplit();
    if (was !== splitOn) { tabs.forEach(t => { if (t.kind === 'ppt') pptSyncRect(t); else if (t === active) applyZoom(t); }); }
    updateHole(); updZoom(); redraw(); updPg();
  }
  const saveSP = () => { try { window.api.setSettings({ split: { ...SP } }); } catch {} };
  $('#boardBtn').onclick = () => {
    if (splitOn) { setView('board'); toast(I18N.t('تكبير السبورة')); return; }
    const next = (boardMode + 1) % 3;
    if (next) boardColor = next;
    setView(next ? 'board' : 'lesson');
    toast(I18N.t(['عودة إلى الدرس', 'سبورة بيضاء', 'سبورة خضراء'][next]));
  };
  $('#splitBtn').onclick = () => {
    if (splitOn) { setView('lesson'); toast(I18N.t('عودة إلى الدرس')); return; }
    setView('split'); toast(I18N.t('نصف درس ونصف سبورة'));
  };
  spBar.addEventListener('click', (e) => {
    const a = e.target.closest('[data-a]'); if (!a) return; const k = a.dataset.a;
    if (k === 'swap') { SP.swap = !SP.swap; saveSP(); }
    else if (k === 'dir') { SP.dir = SP.dir === 'h' ? 'v' : 'h'; SP.swap = false; spScroll.x = spScroll.y = 0; saveSP(); }
    else if (k === 'color') { boardColor = boardColor === 2 ? 1 : 2; board.className = 'on' + (boardColor === 2 ? ' dark' : ''); }
    else if (k === 'full') { setView('board'); return; }
    else if (k === 'close') { setView('lesson'); return; }
    layoutSplit(); redraw();
  });
  bdPg.addEventListener('click', (e) => {
    const a = e.target.closest('[data-a]'); if (!a) return; const k = a.dataset.a;
    if (k === 'prev') goBoardPage(boardPage - 1);
    else if (k === 'next') goBoardPage(boardPage + 1);
    else if (k === 'add') { boardPages.push({ shapes: [], undo: [], redo: [] }); goBoardPage(boardPages.length - 1); toast(I18N.t('صفحة جديدة في السبورة')); }
    else if (k === 'split') setView('split');
  });
  const ZS2 = [0.25, 0.33, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.15, 1.3, 1.5];
  spZoom.addEventListener('click', (e) => {
    const b = e.target.closest('[data-z]'); if (!b) return; const d = +b.dataset.z;
    const fit = LR ? Math.min(LR.w / stage.clientWidth, LR.h / stage.clientHeight) : 1;
    if (d === 0) SP.z = 0;
    else {
      const z = spZoomVal;
      const nx = d > 0 ? ZS2.find(v => v > z + 0.001) : [...ZS2].reverse().find(v => v < z - 0.001);
      SP.z = !nx || nx <= fit + 0.001 ? (d > 0 ? (nx || z) : 0) : nx;
    }
    saveSP(); layoutSplit(); redraw();
  });
  // تكبير السبورة مع إبقاء وسط المنطقة في مكانه
  const ZB = [0.25, 0.33, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.25, 1.5, 1.75, 2, 2.5, 3];
  function boardZoomTo(nz, full) {
    const R = bArea; if (!R) return;
    const rtl = I18N.dir() === 'rtl', px = (R.x + R.w / 2 - BT.x) / BT.s, py = (R.y + R.h / 2 - BT.y) / BT.s;
    if (full) BZ.full = nz; else BZ.split = nz;
    layoutBoard(R, full);
    const z = bZoomVal, cw = stage.clientWidth * z, dx = R.x + R.w / 2 - px * z, dy = R.y + R.h / 2 - py * z;
    bScroll.x = rtl ? dx - (R.x + R.w - cw) : R.x - dx; bScroll.y = R.y - dy;
    layoutSplit(); redraw();
  }
  function boardZoomStep(d) {
    const full = !splitOn, R = bArea; if (!R) return;
    const fit = full ? 1 : Math.min(R.w / stage.clientWidth, R.h / stage.clientHeight), z = bZoomVal;
    if (d === 0) return boardZoomTo(full ? 1 : 0, full);
    const nx = d > 0 ? ZB.find(v => v > z + 0.001) : [...ZB].reverse().find(v => v < z - 0.001);
    if (d > 0) return boardZoomTo(nx || z, full);
    boardZoomTo(!nx || nx <= fit + 0.001 ? (full ? 1 : 0) : nx, full);
  }
  bdZoom.addEventListener('click', (e) => { const b = e.target.closest('[data-z]'); if (b) boardZoomStep(+b.dataset.z); });
  const bScrollBy = (dx, dy) => { if (!bMax.x && !bMax.y) return false; bScroll.x += dx; bScroll.y += dy; layoutSplit(); redraw(); return true; };
  for (const sb of [bsV, bsH]) sb.addEventListener('pointerdown', (e) => {
    e.preventDefault(); e.stopPropagation(); sb.setPointerCapture(e.pointerId);
    const vert = sb === bsV, rtl = I18N.dir() === 'rtl';
    const set = (ev) => {
      const R = sb.getBoundingClientRect(), th = sb.querySelector('i'), tl = vert ? th.offsetHeight : th.offsetWidth, len = (vert ? R.height : R.width) - tl;
      let f = len > 0 ? ((vert ? ev.clientY - R.top : ev.clientX - R.left) - tl / 2) / len : 0; f = Math.max(0, Math.min(1, f));
      if (vert) bScroll.y = f * bMax.y; else bScroll.x = (rtl ? 1 - f : f) * bMax.x;
      layoutSplit(); redraw();
    };
    set(e);
    const up = () => sb.removeEventListener('pointermove', set);
    sb.addEventListener('pointermove', set); sb.addEventListener('pointerup', up, { once: true });
  });
  // العجلة فوق السبورة: تمرير (Shift أفقي)، وCtrl + العجلة تكبير وتصغير
  stage.addEventListener('wheel', (e) => {
    if (tool === 'spot' || !bArea || !(boardMode > 0 || splitOn)) return;
    const r = stage.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    if (splitOn && !inR(BR, x, y)) return;
    if (e.ctrlKey) { e.preventDefault(); e.stopPropagation(); boardZoomStep(e.deltaY < 0 ? 1 : -1); return; }
    const k = e.deltaMode === 1 ? 40 : 1, rtl = I18N.dir() === 'rtl';
    if (bScrollBy(e.shiftKey ? (rtl ? -1 : 1) * e.deltaY * k : (rtl ? -1 : 1) * e.deltaX * k, e.shiftKey ? 0 : e.deltaY * k)) { e.preventDefault(); e.stopPropagation(); }
  }, { capture: true, passive: false });
  // سحب الفاصل
  spDiv.addEventListener('pointerdown', (e) => {
    e.preventDefault(); spDiv.setPointerCapture(e.pointerId); document.body.classList.add('spDrag');
    const r = stage.getBoundingClientRect(), rtl = I18N.dir() === 'rtl';
    const move = (ev) => {
      let f;
      if (SP.dir === 'h') { const x = (ev.clientX - r.left) / r.width; const lessonRight = rtl ? !SP.swap : SP.swap; f = lessonRight ? 1 - x : x; }
      else { const y = (ev.clientY - r.top) / r.height; f = SP.swap ? 1 - y : y; }
      SP.ratio = Math.max(0.25, Math.min(0.8, f)); layoutSplit(); redraw();
    };
    const up = () => { spDiv.removeEventListener('pointermove', move); document.body.classList.remove('spDrag'); saveSP(); };
    spDiv.addEventListener('pointermove', move); spDiv.addEventListener('pointerup', up, { once: true });
  });
  // التمرير: الأشرطة، والعجلة فوق جهة الدرس
  const scrollBy = (dx, dy) => { if (!spMax.x && !spMax.y) return false; spScroll.x += dx; spScroll.y += dy; layoutSplit(); redraw(); return true; };
  for (const sb of [sbV, sbH]) sb.addEventListener('pointerdown', (e) => {
    e.preventDefault(); e.stopPropagation(); sb.setPointerCapture(e.pointerId);
    const vert = sb === sbV, rtl = I18N.dir() === 'rtl';
    const set = (ev) => {
      const R = sb.getBoundingClientRect(), th = sb.querySelector('i'), tl = vert ? th.offsetHeight : th.offsetWidth, len = (vert ? R.height : R.width) - tl;
      let f = len > 0 ? ((vert ? ev.clientY - R.top : ev.clientX - R.left) - tl / 2) / len : 0; f = Math.max(0, Math.min(1, f));
      if (vert) spScroll.y = f * spMax.y; else spScroll.x = (rtl ? 1 - f : f) * spMax.x;
      layoutSplit(); redraw();
    };
    set(e);
    const up = () => sb.removeEventListener('pointermove', set);
    sb.addEventListener('pointermove', set); sb.addEventListener('pointerup', up, { once: true });
  });
  stage.addEventListener('wheel', (e) => {
    if (!splitOn || tool === 'spot' || !LR || !active || active.kind !== 'ppt') return;
    const r = stage.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    if (!inR(LR, x, y)) return;
    const k = e.deltaMode === 1 ? 40 : 1, rtl = I18N.dir() === 'rtl';
    if (scrollBy(e.shiftKey ? (rtl ? -1 : 1) * e.deltaY * k : (rtl ? -1 : 1) * e.deltaX * k, e.shiftKey ? 0 : e.deltaY * k)) { e.preventDefault(); e.stopPropagation(); }
  }, { capture: true, passive: false });
  document.addEventListener('lp-auth', async (e) => { if (e.detail && e.detail.user) { try { const p = await window.api.getSettings(); if (p.split) Object.assign(SP, p.split); if (splitOn) { layoutSplit(); redraw(); } } catch {} } });

  // ---------- لقطة شاشة ----------
  $('#shot').onclick = async () => {
    commitText();
    app.classList.add('barHidden');
    await new Promise(r => setTimeout(r, 350));
    const data = await window.api.capture();
    app.classList.remove('barHidden');
    if (data && await window.api.savePng(data)) toast(I18N.t('تم حفظ الصورة'));
  };

  // ---------- التنقل ----------
  // يقبل كود التضمين الملصوق كما هو (<iframe src="…">) فيأخذ الرابط منه
  function pickUrl(v) {
    v = String(v || '').trim();
    const m = v.match(/<iframe[^>]*?\ssrc\s*=\s*["']([^"']+)["']/i);
    return m ? m[1].replace(/&amp;/g, '&').trim() : v;
  }
  function normalize(v) {
    v = pickUrl(v); if (!v) return null;
    if (/^(https?|file):/i.test(v)) return v;
    if (/^[a-z]:\\/i.test(v)) return 'file:///' + v.replace(/\\/g, '/');
    if (/^[^\s]+\.[^\s]{2,}/.test(v)) return 'https://' + v;
    return 'https://www.google.com/search?q=' + encodeURIComponent(v);
  }
  let welcomeUrl = null;
  // صفحة البداية: نفس العنوان بلا الاستعلام، مع .html أو بدونها (Cloudflare يحذف .html من العنوان)
  const bareUrl = (u) => { try { return new URL(String(u), location.href).href.split(/[?#]/)[0].replace(/\.html$/, ''); } catch { return ''; } };
  const isWelcome = u => !!(u && welcomeUrl) && bareUrl(u) === bareUrl(welcomeUrl);

  // ---------- التبويبات ----------
  const tabsEl = $('#tabs');
  let tabs = [], active = null, partition = 'persist:lessons';

  // الرسم محفوظ لكل صفحة (صفحة PDF أو شريحة باوربوينت) داخل كل تبويب
  const pageData = (t) => (t.pages[t.page] ||= { shapes: [], undo: [], redo: [] });
  // (عندما تكون طبقة السبورة هي النشطة، رسم الدرس يبقى محفوظاً في مكانه)
  function saveActive() {
    if (!active) return;
    if (layer === 'lesson') { const d = pageData(active); d.shapes = shapes; d.undo = undoStack; d.redo = redoStack; }
    active.home = homeUrl;
  }
  function loadActive() {
    if (layer === 'lesson') { const d = pageData(active); shapes = d.shapes; undoStack = d.undo; redoStack = d.redo; }
    homeUrl = active.home;
  }
  function setPage(t, key) {
    key = String(key);
    if (t.page === key) return;
    if (t === active && layer === 'lesson') { commitText(); current = null; saveActive(); t.page = key; loadActive(); redraw(); }
    else { t.page = key; if (t === active) redraw(); }
  }
  // ---------- تكبير الدرس نفسه على الشاشة («＋ 100% −») لصفحات الويب ----------
  const zoomCtl = document.createElement('div'); zoomCtl.id = 'zoomCtl';
  zoomCtl.innerHTML = `<button data-z="1">＋</button><button class="zv" data-z="0"></button><button data-z="-1">−</button>`;
  stage.appendChild(zoomCtl);
  let zoomPref = true;
  const ZS = [0.3, 0.4, 0.5, 0.67, 0.75, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3];
  function applyZoom(t) { try { t.wv.setZoomFactor((t.zoom || 1) * (splitOn && t === active && t.kind !== 'ppt' ? LT.s : 1)); } catch {} }
  function updZoom() {
    const ok = zoomPref && !splitOn && active && active.kind === 'web' && !isWelcome(active.wv.getURL ? (() => { try { return active.wv.getURL(); } catch { return ''; } })() : '');
    zoomCtl.classList.toggle('on', !!ok);
    if (ok) zoomCtl.querySelector('.zv').textContent = Math.round((active.zoom || 1) * 100) + '%';
  }
  zoomCtl.addEventListener('click', (e) => {
    const b = e.target.closest('[data-z]'); if (!b || !active) return;
    const d = +b.dataset.z, z = active.zoom || 1;
    let i = ZS.findIndex(x => Math.abs(x - z) < 0.001); if (i < 0) i = ZS.indexOf(1);
    active.zoom = d === 0 ? 1 : ZS[Math.max(0, Math.min(ZS.length - 1, i + d))];
    applyZoom(active); updZoom();
  });
  zoomCtl.querySelector('.zv').title = I18N.t('رجوع إلى 100%');
  zoomCtl.querySelector('[data-z="1"]').title = I18N.t('تكبير الدرس');
  zoomCtl.querySelector('[data-z="-1"]').title = I18N.t('تصغير الدرس');
  document.addEventListener('lp-auth', async (e) => { if (e.detail && e.detail.user) { try { const p = await window.api.getSettings(); zoomPref = p.zoomCtl !== false; if (LP_frame) LP_frame.set(p.pptFrame); if (LP_full) LP_full.set(p.pptMode || 'full', p.fsAuto); } catch {} updZoom(); } });

  function renderTabs() {
    updZoom();
    tabsEl.innerHTML = '';
    tabs.forEach((t, i) => {
      const el = document.createElement('div');
      el.className = 'tab' + (t === active ? ' on' : '');
      el.title = t.title || I18N.t('صفحة جديدة');
      const icon = t.kind === 'pdf' ? '📄 ' : t.kind === 'ppt' ? '📊 ' : '';
      el.innerHTML = `<span class="n">${i + 1}</span><span class="tt" dir="auto"></span>${tabs.length > 1 ? `<span class="x" title="${I18N.t('إغلاق التبويب')}">×</span>` : ''}`;
      el.querySelector('.tt').textContent = icon + (t.title || I18N.t('صفحة جديدة'));
      el.addEventListener('mousedown', e => {
        if (e.button === 1) { e.preventDefault(); closeTab(t); return; }
        if (e.target.classList.contains('x')) { closeTab(t); return; }
        switchTab(t);
      });
      tabsEl.appendChild(el);
    });
    fitTabs();
  }
  // عند كثرة التبويبات: شكل مختصر، وتمرير، وزر «كل التبويبات»
  // عند ضيق المكان: لا تصغر التبويبات إلى أرقام، بل يظهر التبويب الحالي باسمه + زر يفتح قائمة بأسماء كل المفتوحات
  function fitTabs() {
    tabsEl.classList.remove('compact', 'collapsed');
    if (tabs.length > 1 && tabsEl.scrollWidth > tabsEl.clientWidth + 2) tabsEl.classList.add('collapsed');
    const over = tabsEl.classList.contains('collapsed');
    $('#allTabs').classList.toggle('show', over || tabs.length > 6);
    $('#allTabs').classList.toggle('big', over);
    $('#allTabsCnt').textContent = tabs.length;
    const on = tabsEl.querySelector('.tab.on');
    if (on) on.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }
  new ResizeObserver(() => fitTabs()).observe($('.drag'));
  tabsEl.addEventListener('wheel', e => {
    if (tabsEl.scrollWidth <= tabsEl.clientWidth) return;
    e.preventDefault();
    const rtl = getComputedStyle(tabsEl).direction === 'rtl';
    tabsEl.scrollLeft += (rtl ? -1 : 1) * (e.deltaY || e.deltaX);
  }, { passive: false });
  // قائمة كل التبويبات
  $('#allTabs').addEventListener('click', () => {
    const pop = $('#tabsPop');
    pop.innerHTML = '';
    tabs.forEach((t, i) => {
      const b = document.createElement('button');
      b.className = 'tabrow' + (t === active ? ' on' : '');
      const icon = t.kind === 'pdf' ? '📄 ' : t.kind === 'ppt' ? '📊 ' : '';
      b.innerHTML = `<span class="n">${i + 1}</span><span class="tt" dir="auto"></span>${tabs.length > 1 ? `<span class="x" title="${I18N.t('إغلاق التبويب')}">×</span>` : ''}`;
      b.querySelector('.tt').textContent = icon + (t.title || I18N.t('صفحة جديدة'));
      b.addEventListener('click', e => {
        if (e.target.classList.contains('x')) { e.stopPropagation(); closeTab(t); b.remove(); return; }
        switchTab(t);
        pop.classList.remove('on'); $('#allTabs').classList.remove('popOpen');
      });
      pop.appendChild(b);
    });
  }, true);
  function switchTab(t) {
    if (t === active) return;
    commitText(); current = null;
    saveActive();
    tabs.forEach(x => x.wv.classList.toggle('hidden', x !== t));
    active = t; view = t.wv;
    loadActive();
    closePop(); if (splitOn) layoutSplit(); redraw(); renderTabs();
    if (t.kind === 'ppt') pptSyncRect(t);
    updateLock();
    updateHole();
  }
  // ---------- منطقة باوربوينت الشفافة ----------
  let holeOn = false, ignoring = false;
  function setIgnore(v) { if (v === ignoring) return; ignoring = v; window.api.ignoreMouse(v); }
  function updateHole() {
    if (window.__lpFull) window.__lpFull();
    const on = !!(active && active.kind === 'ppt' && active.ppt && active.ppt.embed && !active.ppt.gone && !boardMode && !document.body.classList.contains('mini'));
    holeOn = on;
    document.documentElement.classList.toggle('pptHole', on);
    if (!on) setIgnore(false);
    if (window.__lpCastSync) window.__lpCastSync();
  }
  // فوق الشريحة (والأداة «مؤشر») تمر الفأرة إلى باوربوينت، وفوق أي أداة أو بطاقة تبقى للبرنامج
  document.addEventListener('mousemove', e => {
    if (document.body.classList.contains('mini') && window.__lpCastRect && window.__lpCastRect()) { setIgnore(document.elementFromPoint(e.clientX, e.clientY) === castVid); return; }
    if (!holeOn || tool !== 'mouse') { if (ignoring) setIgnore(false); return; }
    const el = document.elementFromPoint(e.clientX, e.clientY);
    setIgnore(!!el && (el === active.wv || el === stage || el === castVid || el.id === 'draw' || el.id === 'laser'));
  }, true);
  document.addEventListener('mouseleave', () => { if (holeOn && tool === 'mouse') setIgnore(true); });
  new MutationObserver(updateHole).observe(document.body, { attributes: true, attributeFilter: ['class'] });

  // ---------- 📡 وضع Teams ----------
  // نافذتنا شفافة فوق نافذة باوربوينت، فإذا شاركها Teams وحدها ظهرت الشريحة سوداء.
  // هنا نعرض بثاً حياً من نافذة العرض داخل نافذتنا في مكان الشريحة تماماً، ولا نقصّ مكانها من النافذة؛
  // والنقر فوق البث يمرّ إلى باوربوينت الحقيقي تحته (الأسئلة التفاعلية والروابط).
  // - البث يبقى قائماً لكل عرض (لا يُعاد عند ملء الشاشة أو إخراج الأدوات)، ويُعاد تلقائياً إن انقطع.
  // - إن صار البث أسود يُخفى فوراً فتظهر الشريحة الحقيقية (والشريحة السوداء فعلاً تبقى سوداء في الحالتين).
  let castOn = false; try { castOn = localStorage.getItem('lpTeamsCast') === '1'; } catch {}
  let cast = null, castRetry = 0, castRetryT = null;
  const castLog = (m) => { try { window.api.castLog && window.api.castLog(m); } catch {} };
  const castVid = document.createElement('video');
  castVid.id = 'pptCast'; castVid.muted = true; castVid.autoplay = true; castVid.playsInline = true;
  stage.insertBefore(castVid, stage.firstChild);
  const casting = () => !!(cast && cast.stream && cast.live);
  const isMiniOv = () => document.body.classList.contains('mini') && document.body.classList.contains('ovf');
  let castMiniRect = null;
  async function placeCast() {
    if (!cast) return;
    const sr = stage.getBoundingClientRect();
    let R;
    if (isMiniOv()) {
      // الأدوات خارج البرنامج: النافذة تغطي الشاشة، والعرض باقٍ في مكانه على الشاشة
      try { castMiniRect = await window.api.pptCastRect(cast.id); } catch { castMiniRect = null; }
      if (!castMiniRect) return;
      R = { x: castMiniRect.x - sr.left, y: castMiniRect.y - sr.top, w: castMiniRect.width, h: castMiniRect.height };
      castVid.classList.add('miniOut');
    } else {
      castMiniRect = null; castVid.classList.remove('miniOut');
      const c = splitOn && active && active.spRect;
      R = c ? { x: c.x, y: c.y, w: c.w, h: c.h } : { x: 0, y: 0, w: sr.width, h: sr.height };
    }
    Object.assign(castVid.style, { left: R.x + 'px', top: R.y + 'px', width: R.w + 'px', height: R.h + 'px' });
    if (window.__lpMiniMeasure && isMiniOv()) window.__lpMiniMeasure();
  }
  window.__lpCastRect = () => (casting() && isMiniOv() && castMiniRect) ? { x: castMiniRect.x, y: castMiniRect.y, width: castMiniRect.width, height: castMiniRect.height } : null;
  function setLive(v) {
    if (!cast || cast.live === v) return;
    cast.live = v;
    document.documentElement.classList.toggle('pptCast', v);
    castLog(v ? 'live (frames ok)' : 'hidden: black frames → real slide shown');
    lastShape = ''; queueShape();
    if (window.__lpMiniMeasure && isMiniOv()) window.__lpMiniMeasure();
  }
  // فحص السواد: صورة صغيرة من البث كل 0.6 ثانية
  const probe = document.createElement('canvas'); probe.width = 24; probe.height = 14;
  const pctx = probe.getContext('2d', { willReadFrequently: true });
  let blackN = 0, okN = 0;
  setInterval(() => {
    if (!cast || !cast.stream || castVid.readyState < 2) return;
    try {
      pctx.drawImage(castVid, 0, 0, 24, 14);
      const d = pctx.getImageData(0, 0, 24, 14).data; let mx = 0;
      for (let i = 0; i < d.length; i += 4) { const l = d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11; if (l > mx) mx = l; }
      if (mx < 14) { okN = 0; if (++blackN >= 2) setLive(false); }
      else { blackN = 0; if (++okN >= 1) setLive(true); }
    } catch {}
  }, 600);
  function stopCast(why) {
    clearTimeout(castRetryT);
    if (cast && cast.stream) cast.stream.getTracks().forEach(t => t.stop());
    if (cast) castLog('stop ' + (why || ''));
    cast = null; castVid.srcObject = null; blackN = okN = 0;
    document.documentElement.classList.remove('pptCast');
    lastShape = ''; queueShape();
    if (window.__lpMiniMeasure && isMiniOv()) window.__lpMiniMeasure();
  }
  function retryLater(id, why) {
    castLog('fail: ' + why + ' (try ' + (castRetry + 1) + ')');
    if (castRetry >= 3) { castLog('giving up'); toast(I18N.t('تعذّر بث العرض داخل البرنامج — يمكن مشاركة «الشاشة» في Teams بدلاً منه'), null, null, 6000); return; }
    castRetry++;
    clearTimeout(castRetryT);
    if (/could not start|ended/i.test(why)) window.api.pptRestore && window.api.pptRestore(id);   // نافذة العرض مصغّرة؟ نعيدها
    castRetryT = setTimeout(() => { if (wantCast() === id && (!cast || cast.id !== id || !cast.stream)) { cast = null; castStart(id); } }, 1500);
  }
  async function castStart(id, src) {
    const me = cast = { id, live: false };
    try {
      src = src || await window.api.pptCastSrc(id);
      if (cast !== me) return false;
      if (!src) { cast = null; retryLater(id, 'no source'); return false; }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: src, maxFrameRate: 30 } } });
      if (cast !== me) { stream.getTracks().forEach(t => t.stop()); return false; }
      me.stream = stream; castVid.srcObject = stream; castVid.play().catch(() => {});
      castLog('start ' + src + ' ' + (stream.getVideoTracks()[0].getSettings().width || '?') + 'x' + (stream.getVideoTracks()[0].getSettings().height || '?'));
      placeCast();
      stream.getVideoTracks()[0].addEventListener('ended', () => {
        if (cast !== me) return;
        castLog('track ended'); stopCast('ended');
        retryLater(id, 'ended');
      });
      return true;
    } catch (e) {
      if (cast === me) { cast = null; retryLater(id, e && e.message || 'getUserMedia'); }
      return false;
    }
  }
  function wantCast() {
    if (!castOn || !active || !active.ppt || !active.ppt.embed || active.ppt.gone || boardMode) return null;
    if (document.body.classList.contains('mini') && !isMiniOv()) return null;
    if (!holeOn && !isMiniOv()) return null;
    return active.ppt.id;
  }
  function castSync() {
    const want = wantCast();
    if (cast && cast.id === want) { placeCast(); return; }
    if (cast) stopCast('switch');
    if (want) { castRetry = 0; castStart(want); }
  }
  function setTeamsCast(v) {
    castOn = !!v; try { localStorage.setItem('lpTeamsCast', castOn ? '1' : '0'); } catch {}
    document.documentElement.classList.toggle('teamsMode', castOn);
    castLog('teams mode ' + (castOn ? 'on' : 'off'));
    castSync();
    document.dispatchEvent(new Event('lp-teams'));
  }
  document.documentElement.classList.toggle('teamsMode', castOn);
  window.__lpCastSync = castSync;
  { const ls0 = layoutSplit; layoutSplit = function () { const r = ls0.apply(this, arguments); if (cast) placeCast(); return r; }; }
  // تغيّر الوضع (الأدوات خارج البرنامج، ملء الشاشة…): نعيد الوضع والمكان فقط، دون إعادة البث
  new MutationObserver(() => { if (castOn) castSync(); }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  window.addEventListener('resize', () => { if (cast) placeCast(); });
  // زر «📡 وضع Teams» في قائمة «المزيد» (يظهر فقط حيث يعمل باوربوينت داخل البرنامج)
  const teamsBtn = document.getElementById('teamsMode');
  if (teamsBtn) {
    const paint = () => teamsBtn.classList.toggle('on', castOn);
    window.api.uiTransp().then(v => { teamsBtn.hidden = !v; }).catch(() => { teamsBtn.hidden = true; });
    teamsBtn.addEventListener('click', () => toggleTeams());
    document.addEventListener('lp-teams', paint);
    paint();
  }
  function toggleTeams(v) {
    setTeamsCast(v === undefined ? !castOn : v);
    if (castOn) toast(I18N.t('📡 وضع Teams: في Teams اختر مشاركة نافذة «عارض الدروس». ولصوت الفيديو فعّل «تضمين صوت الكمبيوتر».'), null, null, 9000);
    else toast(I18N.t('أُوقف وضع Teams'), null, null, 3000);
  }
  // تذكير عند بدء المشاركة في Teams (شريط «Sharing control bar») ووضع Teams غير مفعّل
  const HINT_KEY = 'lpTeamsHintOff';
  let hintOpen = false;
  function teamsHint(force) {
    let off = false; try { off = localStorage.getItem(HINT_KEY) === '1'; } catch {}
    if (off || castOn || hintOpen) return;
    if (!force && !teamsSharing) return;
    if (!tabs.some(x => x.ppt && x.ppt.embed && !x.ppt.gone)) return;
    hintOpen = true;
    const d = document.createElement('div'); d.className = 'gdlg on';
    d.innerHTML = `<div class="gdlg-card"><h3>📡 ${I18N.t('مشاركة العرض في Teams؟')}</h3>
      <p>${I18N.t('لتظهر الشريحة للطلاب عند مشاركة نافذة البرنامج، يلزم تشغيل وضع Teams. (عند مشاركة «الشاشة» كاملة لا يلزم.)')}</p>
      <div class="gdlg-row"><button class="pri" data-r="on">📡 ${I18N.t('تشغيل وضع Teams')}</button><button data-r="no">${I18N.t('ليس الآن')}</button></div>
      <label class="chk" style="margin-top:10px;display:flex;gap:6px;align-items:center"><input type="checkbox" id="thOff"> ${I18N.t('لا تظهر هذه الرسالة مرة أخرى')}</label></div>`;
    document.body.appendChild(d);
    const done = (r) => {
      if (d.querySelector('#thOff').checked) { try { localStorage.setItem(HINT_KEY, '1'); } catch {} }
      d.remove(); hintOpen = false;
      if (r === 'on') toggleTeams(true);
    };
    d.addEventListener('click', e => { const b = e.target.closest('[data-r]'); if (b) done(b.dataset.r); });
  }
  const paintTeamsBtns = () => document.querySelectorAll('.teams-btn').forEach(b => b.classList.toggle('on', castOn));
  document.addEventListener('lp-teams', paintTeamsBtns); setTimeout(paintTeamsBtns, 0);
  document.addEventListener('lp-tabs', paintTeamsBtns);
  let teamsSharing = false;
  window.api.onTeamsSharing && window.api.onTeamsSharing((on) => { teamsSharing = !!on; if (on) teamsHint(); });
  const teamsApi = { get on() { return castOn; }, set: setTeamsCast, get casting() { return casting(); }, _start: castStart, _stop: stopCast, _live: setLive, _hint: (f) => teamsHint(f), _sharing: (v) => { teamsSharing = v; } };
  document.addEventListener('lp-tool', () => { if (tool !== 'mouse') setIgnore(false); });

  // ---------- وضع الإطار: مكان الشريحة لا يغطيه شيء من البرنامج ----------
  // النافذة الشفافة فوق عرض باوربوينت تُبطئ رسمه، فنقصّ مكان الشريحة من نافذتنا ما دامت الأداة «مؤشر»،
  // ونُبقي فقط ما يظهر فعلاً فوق الشريحة (القوائم واللوحات والتنبيهات والكتابة). عند اختيار القلم يعود الغطاء كاملاً.
  let framePref = true, lastShape = '', shapeQ = false, frameForce = false;
  const NOT_OVER = new Set(['board', 'draw', 'laser']);
  function visibleRect(el) {
    if (!el.getClientRects().length) return null;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || +cs.opacity < 0.05 || cs.display === 'none') return null;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 ? r : null;
  }
  function inkRect() {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    let add = (x, y, pad) => { if (!isFinite(x) || !isFinite(y)) return; x0 = Math.min(x0, x - pad); y0 = Math.min(y0, y - pad); x1 = Math.max(x1, x + pad); y1 = Math.max(y1, y + pad); };
    const T = LT, list = boardMode > 0 ? [] : layer === 'lesson' ? shapes : (active ? pageData(active).shapes : []);
    const add0 = add;
    add = (x, y, pad) => add0(T.x + x * T.s, T.y + y * T.s, pad * T.s);
    for (const sh of list) {
      if (sh.type === 'erase') continue;
      const pad = (sh.width || 4) * 3 + (sh.size || 0) + 20;
      if (sh.points) for (const p of sh.points) add(p[0], p[1], pad);
      for (const [a, b] of [['x', 'y'], ['x1', 'y1'], ['x2', 'y2'], ['x0', 'y0']]) if (a in sh) add(+sh[a], +sh[b], pad);
      if (sh.type === 'branch') add(sh.cx, sh.cy, pad + Math.max(sh.w, sh.h) / 2);
      if (sh.type === 'text') { add(+sh.x - 600, +sh.y, pad); add(+sh.x + 600, +sh.y + (sh.size || 30) * 1.3 * (String(sh.text).split('\n').length), pad); }
    }
    if (x1 < x0) return null;
    const r = stage.getBoundingClientRect();
    return { left: r.left + x0, top: r.top + y0, right: r.left + x1, bottom: r.top + y1 };
  }
  function computeShape() {
    const pass = tool === 'mouse' || (fullOn && (tool === 'pen' || tool === 'eraser'));   // القلم في العرض الكامل = قلم باوربوينت نفسه
    if (!(holeOn || frameForce) || !pass || current || casting()) return [];
    if (!framePref && !fullOn) return [];
    const H = stage.getBoundingClientRect(), W = window.innerWidth, Hh = window.innerHeight;
    const hx = Math.ceil(H.left), hy = Math.ceil(H.top), hr = Math.floor(H.right), hb = Math.floor(H.bottom);
    if (hr - hx < 100 || hb - hy < 100) return [];
    const R = [];
    const push = (x, y, w, h) => { x = Math.floor(x); y = Math.floor(y); w = Math.ceil(w); h = Math.ceil(h); if (w > 0 && h > 0) R.push({ x, y, width: w, height: h }); };
    push(0, 0, W, hy); push(0, hb, W, Hh - hb); push(0, hy, hx, hb - hy); push(hr, hy, W - hr, hb - hy);
    // ما يظهر فوق الشريحة يبقى جزءاً من النافذة
    const over = [];
    for (const el of stage.children) {
      if ((NOT_OVER.has(el.id) && !(splitOn && el.id === 'board')) || el.tagName === 'WEBVIEW') continue;
      if (el.classList.contains('mirror')) { el.querySelectorAll('.pptbar, .pptGone').forEach(b => { const r = visibleRect(b); if (r) over.push(r); }); continue; }
      const r = visibleRect(el); if (r) over.push(r);
      el.querySelectorAll('.on, .mw-pop, .mw-fx').forEach(c => { const rc = visibleRect(c); if (rc) over.push(rc); });
    }
    const ink = inkRect(); if (ink) over.push(ink);
    // العرض الكامل: الأشرطة والعمود عائمة فوق الشريحة (وفي «الإخفاء التلقائي» حواف رفيعة فقط حتى تقترب الفأرة)
    if (fullOn) {
      const hidden = document.body.classList.contains('fsHide') && !document.body.classList.contains('fsReveal');
      if (hidden) { over.push({ left: 0, top: 0, right: W, bottom: 6 }, { left: 0, top: Hh - 6, right: W, bottom: Hh }, { left: 0, top: 0, right: 6, bottom: Hh }, { left: W - 6, top: 0, right: W, bottom: Hh }); }
      else for (const q of ['#grpBar', '#bar', '#dock', '#showBar']) { const el = document.querySelector(q); const r = el && visibleRect(el); if (r) over.push(r); }
      for (const el of document.querySelectorAll('#app > .menu.on, #app > .panel.on')) { const r = visibleRect(el); if (r) over.push(r); }
    }
    for (const r of over) {
      const x = Math.max(hx, r.left - 2), y = Math.max(hy, r.top - 2), x2 = Math.min(hr, r.right + 2), y2 = Math.min(hb, r.bottom + 2);
      if (x2 > x && y2 > y) push(x, y, x2 - x, y2 - y);
    }
    return R;
  }
  function applyShape() {
    shapeQ = false;
    const R = computeShape(), key = JSON.stringify(R);
    if (key === lastShape) return;
    lastShape = key;
    window.api.setShape(R);
  }
  const queueShape = () => { if (shapeQ) return; shapeQ = true; requestAnimationFrame(applyShape); };
  // أي تغيير في الصفحة (فتح قائمة، تنبيه، بطاقة…) يعيد الحساب
  new MutationObserver(queueShape).observe(document.body, { attributes: true, subtree: true, childList: true, attributeFilter: ['class', 'style', 'hidden'] });
  window.addEventListener('resize', queueShape);
  document.addEventListener('lp-tool', queueShape);
  new ResizeObserver(queueShape).observe(stage);
  window.__lpQS = queueShape; window.__lpFull = () => updateFull(); window.__lpShapeReset = () => { lastShape = ''; };
  setInterval(queueShape, 1500);   // احتياط (التنبيهات التي تختفي بالشفافية)
  // ---------- وضع العرض الكامل لباوربوينت ----------
  // باوربوينت يعرض بملء الشاشة الحقيقي (بسرعته الطبيعية)، والبرنامج يصبح أشرطة ولوحة عائمة فوقه
  let fullPref = 'full', fullOn = false, fsAuto = false, fullForce = false;
  const hexRgb = (h) => { const m = /^#?([0-9a-f]{6})$/i.exec(h || ''); if (!m) return 255; const v = parseInt(m[1], 16); return ((v >> 16) & 255) + ((v >> 8) & 255) * 256 + (v & 255) * 65536; };
  function updateFull() {
    const want = fullForce || !!(active && active.kind === 'ppt' && active.ppt && active.ppt.embed && fullPref === 'full' && !splitOn && !document.body.classList.contains('mini'));
    if (want === fullOn) return;
    fullOn = want;
    document.body.classList.toggle('fullShow', want);
    document.body.classList.toggle('fsHide', want && fsAuto);
    window.api.fullShow(want);
    if (want) pptPointer();
    queueShape();
  }
  function pptPointer() {
    if (!fullOn || !active || !active.ppt) return;
    const type = tool === 'pen' ? 2 : tool === 'eraser' ? 5 : 1;
    window.api.pptPointer(active.ppt.id, type, type === 2 ? hexRgb(color) : null);
  }
  document.addEventListener('lp-tool', pptPointer);
  // الشريط السفلي فوق مكان شريط مهام ويندوز (لا يغطيه أبداً)
  window.api.onFsInset((m) => { const st = document.body.style; st.setProperty('--fsBottom', (m.bottom || 0) + 'px'); st.setProperty('--fsTop', (m.top || 0) + 'px'); queueShape(); });
  document.addEventListener('lp-pen', () => { if (tool === 'pen') pptPointer(); });
  new MutationObserver(updateFull).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  // الإخفاء التلقائي: تظهر الأشرطة عند اقتراب الفأرة من حافة الشاشة، وتختفي بعد ثانيتين
  let revealT = null;
  const reveal = () => { if (!document.body.classList.contains('fsHide')) return; document.body.classList.add('fsReveal'); clearTimeout(revealT); revealT = setTimeout(() => { document.body.classList.remove('fsReveal'); queueShape(); }, 2200); queueShape(); };
  document.addEventListener('mousemove', (e) => { if (fullOn && fsAuto) reveal(); }, true);
  LP_full = { set: (mode, auto) => { if (mode) fullPref = mode; if (auto !== undefined) fsAuto = !!auto; const was = fullOn; fullOn = false; document.body.classList.remove('fullShow', 'fsHide'); if (was) window.api.fullShow(false); updateFull(); }, get on() { return fullOn; }, _force: (v) => { fullForce = !!v; updateFull(); } };
  LP_frame = { set: (on) => { framePref = on !== false; queueShape(); }, get on() { return lastShape !== '[]' && lastShape !== ''; }, shape: () => computeShape(), _force: (v) => { frameForce = !!v; queueShape(); } };
  function addTab(t) {
    stage.insertBefore(t.wv, $('#board'));
    tabs.push(t);
    switchTab(t);
    return t;
  }
  function newTab(url) {
    const wv = document.createElement('webview');
    wv.setAttribute('partition', partition);
    wv.setAttribute('allowpopups', '');
    wv.className = 'hidden';
    const t = { kind: 'web', wv, pages: {}, page: '', home: null, title: '' };
    wire(t);
    wv.src = url || welcomeUrl;
    if (url && !isWelcome(url)) t.home = url;
    return addTab(t);
  }
  function closeTab(t) {
    if (tabs.length === 1) { if (t.kind !== 'web') { newTab(); } else return; }
    const i = tabs.indexOf(t);
    tabs.splice(i, 1);
    if (t === active) { active = null; switchTab(tabs[Math.min(i, tabs.length - 1)]); }
    updateHole();
    if (t.kind === 'ppt') pptCloseTab(t);
    t.wv.remove();
    renderTabs();
  }
  $('#newTab').onclick = () => newTab();

  function wire(t) {
    const wv = t.wv;
    const isActive = () => t === active;
    wv.addEventListener('focus', closePop);
    wv.addEventListener('page-title-updated', e => { if (t.kind === 'pdf') return; t.title = isWelcome(wv.getURL()) ? '' : e.title; renderTabs(); });
    wv.addEventListener('did-navigate', e => { if (isWelcome(e.url)) { t.title = ''; renderTabs(); } if (isActive()) { updateLock(); updZoom(); } });
    wv.addEventListener('did-finish-load', () => { if (t.zoom && t.zoom !== 1 && t.kind === 'web') applyZoom(t); });
    wv.addEventListener('did-navigate-in-page', () => { if (isActive()) updateLock(); });
    wv.addEventListener('did-fail-load', e => { if (isActive() && e.isMainFrame && e.errorCode !== -3) toast(I18N.t('تعذّر فتح الرابط، تأكد من الاتصال بالإنترنت')); });
    wv.addEventListener('console-message', e => {
      const m = e.message || '';
      if (m.startsWith('__KEY__')) {
        if (isActive()) try { const [k, c, s] = JSON.parse(m.slice(7)); handleKey(k, c, s); } catch {}
        return;
      }
      if (m.startsWith('__PAGE__')) { setPage(t, 'p' + m.slice(8)); return; }      // عارض PDF غيّر الصفحة
      if (!isWelcome(wv.getURL())) return;
      if (m === '__OPEN_FILE__') $('#openFile').click();
      else if (m.startsWith('__GO__')) go(normalize(m.slice(6)));
    });
    // اختصارات تعمل أيضاً عندما يكون التركيز داخل الدرس
    wv.addEventListener('dom-ready', () => {
      if (!t.ready) { t.ready = true; if (t.pending) { const u = t.pending; t.pending = null; wv.loadURL(u).catch(() => {}); return; } }
      wv.executeJavaScript(`
        if (!window.__lp) { window.__lp = 1;
          window.addEventListener('keydown', e => {
            const ed = e.target && (e.target.isContentEditable || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName));
            const c = e.ctrlKey || e.metaKey;
            if (ed && e.key !== 'Escape' && !(c && /^[tw1-9]$|^Tab$/i.test(e.key))) return;
            if (['Escape','F11','F5'].includes(e.key) || (c && /^[zytw1-9]$|^Tab$/i.test(e.key))) {
              console.log('__KEY__' + JSON.stringify([e.key, c, e.shiftKey]));
              if (e.key !== 'Escape' && !/^[zy]$/i.test(e.key)) e.preventDefault();
            }
          }, true);
        }`).catch(() => {});
    });
  }

  // ---------- ملفات PDF ----------
  const fileName = (p) => /^blob:/.test(p) ? decodeURIComponent(String(p).split('#')[1] || '') : String(p).split(/[\\/]/).pop();
  async function openPdf(path, inNew) {
    const url = await window.api.viewerUrl(path);
    if (!inNew && active && active.kind === 'web' && isWelcome(view.getURL())) { load(active, url); active.home = url; active.doc = 'pdf:' + path; active.kind = 'pdf'; active.title = fileName(path); }
    else { const t = newTab(url); t.kind = 'pdf'; t.doc = 'pdf:' + path; t.title = fileName(path); }
    renderTabs();
  }

  // ---------- باوربوينت: بث مباشر من العرض الحقيقي ----------
  function stageRect() { const r = stage.getBoundingClientRect(); return { x: r.left, y: r.top, width: r.width, height: r.height }; }
  function pptSyncRect(t) {
    if (!t || !t.ppt || t.ppt.images) return;
    if (splitOn && t === active && t.spRect) { const s = stageRect(), c = t.spRect; window.api.pptRect(t.ppt.id, { x: s.x + c.x, y: s.y + c.y, width: c.w, height: c.h }); return; }
    window.api.pptRect(t.ppt.id, stageRect());
  }
  // تغيير مقاس نافذة العرض مرة واحدة بعد انتهاء التغيير (وليس أثناء سحب حافة العمود)
  let syncT;
  const syncAllPpt = () => { clearTimeout(syncT); syncT = setTimeout(() => { if (document.body.classList.contains('dkResizing')) return; tabs.forEach(t => { if (t.kind === 'ppt') pptSyncRect(t); }); }, 120); };
  new ResizeObserver(syncAllPpt).observe(stage);
  new MutationObserver(() => { if (!document.body.classList.contains('dkResizing')) syncAllPpt(); }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  // عرض باوربوينت بقي مفتوحاً من تشغيل سابق للبرنامج (إغلاق مفاجئ): إعادته داخل البرنامج أو إغلاقه
  document.addEventListener('lp-auth', async (e) => {
    if (!(e.detail && e.detail.user) || !window.api.pptOrphansCheck) return;
    let r = null; try { r = await window.api.pptOrphansCheck(); } catch {}
    if (!r || !r.n) return;
    const files = (r.files || []).filter(Boolean);
    const b = document.createElement('div'); b.id = 'pptOrphan';
    b.innerHTML = `<span class="um-ic">🖥️</span><span class="um-t"><b>${I18N.t('عرض باوربوينت من الجلسة السابقة ما زال مفتوحاً خلف البرنامج')}</b><small>${I18N.t('يمكن إعادته داخل البرنامج أو إغلاقه.')}</small></span>
      ${files.length ? `<button class="pri" id="poBack">${I18N.t('إعادته داخل البرنامج')}</button>` : ''}<button id="poClose">${I18N.t('إغلاقه')}</button>`;
    document.body.appendChild(b);
    requestAnimationFrame(() => b.classList.add('on'));
    const hide = () => { b.classList.remove('on'); setTimeout(() => b.remove(), 400); };
    b.querySelector('#poClose').onclick = async () => { hide(); try { await window.api.pptOrphansClose(); } catch {} toast(I18N.t('أُغلق العرض')); };
    if (b.querySelector('#poBack')) b.querySelector('#poBack').onclick = async () => { hide(); try { await window.api.pptOrphansClose(); } catch {} for (const f of files) await openPpt(f); };
  });
  // أسهم التنقل على الشاشة: في العربية الأيسر = التالية والأيمن = السابقة (لوحة المفاتيح لا تتغير)
  function rtlNav(root) {
    if (!root || I18N.dir() !== 'rtl') return;
    const p = root.querySelector('[data-a="prev"]'), n = root.querySelector('[data-a="next"]');
    if (!p || !n || p.dataset.rtl) return;
    const ph = document.createComment(''); p.replaceWith(ph); n.replaceWith(p); ph.replaceWith(n);
    p.textContent = '›'; n.textContent = '‹'; p.dataset.rtl = n.dataset.rtl = '1';
  }
  // العرض نفسه مفتوح مسبقاً؟ إن كان قد أُغلق يُعاد فتحه في تبويبه، وإن كان يعمل نسأل
  function pptAsk(t) {
    return new Promise(res => {
      const d = document.createElement('div'); d.className = 'gdlg on';
      d.innerHTML = `<div class="gdlg-card"><h3>📂 ${I18N.t('هذا العرض مفتوح مسبقاً (التبويب {n})', { n: tabs.indexOf(t) + 1 })}</h3>
        <p>${I18N.t('يمكن الانتقال إليه كما هو، أو إعادة فتحه من جديد (يُغلق العرض القديم) إن كان لا يعمل جيداً.')}</p>
        <div class="gdlg-row"><button class="pri" data-r="go">${I18N.t('الانتقال إليه')}</button><button data-r="re">🔄 ${I18N.t('إعادة فتحه')}</button><button data-r="no">${I18N.t('إلغاء')}</button></div></div>`;
      document.body.appendChild(d);
      const done = (r) => { d.remove(); document.removeEventListener('keydown', esc, true); res(r); };
      const esc = (e) => { if (e.key === 'Escape') { e.stopPropagation(); done('no'); } };
      document.addEventListener('keydown', esc, true);
      d.addEventListener('click', e => { const b = e.target.closest('[data-r]'); if (b) done(b.dataset.r); else if (e.target === d) done('no'); });
    });
  }
  // عرض واحد فقط يُفتح في كل مرة (باوربوينت ينفّذ طلباً واحداً في وقته، والضغط المتكرر كان يفتح العرض مرتين)
  let pptOpening = null;
  const openBar = document.createElement('div'); openBar.id = 'pptOpening'; document.body.appendChild(openBar);
  function openingUI(name) {
    clearInterval(openBar._t);
    if (!name) { openBar.classList.remove('on'); return; }
    const t0 = Date.now();
    const paint = () => { const s = Math.round((Date.now() - t0) / 1000); openBar.textContent = '⏳ ' + I18N.t('جارٍ فتح «{n}»…', { n: name }) + (s >= 5 ? ' ' + s + 's' : ''); };
    paint(); openBar.classList.add('on'); openBar._t = setInterval(paint, 1000);
  }
  async function openPpt(path, reuse) {
    if (pptOpening) { toast(I18N.t('⏳ جارٍ فتح عرض «{n}» — لحظة من فضلك', { n: fileName(pptOpening) }), null, null, 3000); return; }
    pptOpening = path;
    try { return await openPptNow(path, reuse); } finally { pptOpening = null; openingUI(null); }
  }
  async function openPptNow(path, reuse) {
    if (!reuse) {
      const old = tabs.find(x => x.doc === 'ppt:' + path && x.ppt && !x.ppt.images);
      if (old) {
        const alive = !old.ppt.gone && await window.api.pptAlive(old.ppt.id).catch(() => null);
        if (alive === false || old.ppt.gone) { toast(I18N.t('العرض السابق كان قد أُغلق — يُعاد فتحه'), null, null, 4000); reuse = old; }
        else {
          const r = await pptAsk(old);
          if (r === 'go') { switchTab(old); return; }
          if (r !== 're') return;
          reuse = old;
        }
      }
    }
    if (reuse) {
      if (reuse.ppt) { clearInterval(reuse.ppt.timer); const oid = reuse.ppt.id; reuse.ppt.gone = true; if (window.__lpCastSync) window.__lpCastSync(); if (oid) window.api.pptClose(oid); }
      const g = reuse.wv.querySelector('.pptGone'); if (g) g.remove();
      if (reuse !== active) switchTab(reuse);
    }
    openingUI(fileName(path));
    // إن تأخر باوربوينت: نعرض صور الشرائح المحفوظة من قبل (إن وُجدت) حتى يصل العرض الكامل
    let interim = null;
    const interimT = setTimeout(async () => {
      const c = await window.api.pptCached(path).catch(() => null);
      if (c && c.count && (c.ready || []).includes(1) && pptOpening === path) { interim = await openSlidesImages(path, c); if (interim) toast(I18N.t('العرض الكامل يُفتح — هذه صور الشرائح إلى أن يصل'), null, null, 5000); }
    }, 8000);
    const has = await window.api.pptCheck();
    if (!has) {
      toast(I18N.t('باوربوينت غير مثبت على هذا الجهاز — افتح العرض من OneDrive في باوربوينت أونلاين'), null, null, 6000);
      newTab('https://www.office.com/launch/powerpoint');
      return;
    }
    const r = await window.api.pptOpen(path, stageRect());
    clearTimeout(interimT);
    if (!r || !r.ok || !r.embed) {
      if (r && r.ok && r.id) window.api.pptClose(r.id);
      if (reuse) closeTab(reuse);
      if (interim && tabs.includes(interim)) return;        // صور الشرائح معروضة أصلاً
      openingUI(null);
      return openSlidesImages(path);
    }
    // وصل العرض الكامل: نغلق الصور المؤقتة ونكمل من الشريحة نفسها
    const fromSlide = interim && tabs.includes(interim) ? interim.ppt.slide : 0;
    if (interim && tabs.includes(interim)) { closeTab(interim); toast(I18N.t('وصل العرض الكامل ✓ (بالحركات والفيديو)'), null, null, 4000); }
    if (reuse) {
      const t = reuse;
      t.ppt = { id: r.id, count: r.count, slide: 1, embed: true, ar: r.ar > 0.3 && r.ar < 4 ? r.ar : 16 / 9 };
      t.ppt.timer = setInterval(() => pptPoll(t), 700);
      pptSyncRect(t); updateHole(); pptPoll(t);
      toast(I18N.t('العرض جاهز: اضغط على الشريحة مباشرة، والأسهم تعمل من أي مكان'), null, null, 4000);
      return;
    }
    // العرض الحقيقي خلف منطقة شفافة في البرنامج: نراه ونضغط عليه مباشرة، وأدوات البرنامج فوقه
    const box = document.createElement('div');
    box.className = 'mirror hidden pptLive';
    box.innerHTML = '<div class="pptbar"><button data-a="prev">‹</button><span class="pg"></span><button data-a="next">›</button><button data-a="back" title="' + I18N.t('العودة للعرض (إن ظهرت كل الشرائح مصغّرة)') + '">↩</button><button data-a="mode" class="pmode-btn" title="' + I18N.t('ملء الشاشة / داخل البرنامج') + '">⛶</button><button data-a="teams" class="teams-btn" title="' + I18N.t('وضع Teams (مشاركة النافذة)') + '">📡</button></div>'; rtlNav(box.querySelector('.pptbar'));
    const t = { kind: 'ppt', wv: box, pages: {}, page: 's1', home: null, title: fileName(path), doc: 'ppt:' + path, ppt: { id: r.id, count: r.count, slide: 1, embed: true, ar: r.ar > 0.3 && r.ar < 4 ? r.ar : 16 / 9 } };
    Object.assign(box, {
      getURL: () => t.doc, getTitle: () => t.title,
      canGoBack: () => true, canGoForward: () => true,
      goBack: () => pptGo(t, 'prev'), goForward: () => pptGo(t, 'next'), reload: () => pptGo(t, 'first'),
      capturePage: async () => null
    });
    box.querySelector('.pptbar').addEventListener('click', async e => {
      const a = e.target.dataset.a; if (!a) return; e.stopPropagation();
      if (a === 'teams') { toggleTeams(); return; }
      if (a === 'mode') { const m = fullPref === 'full' ? 'inside' : 'full'; await window.api.setSettings({ pptMode: m }); LP_full.set(m); toast(I18N.t(m === 'full' ? 'العرض بملء الشاشة' : 'العرض داخل البرنامج')); return; }
      pptGo(t, a);
    });
    addTab(t);
    t.ppt.timer = setInterval(() => pptPoll(t), 700);
    if (fromSlide > 1) pptShow(t, await window.api.pptCmd(t.ppt.id, 'goto', fromSlide));
    pptPoll(t);
    if (!fromSlide) toast(I18N.t('العرض جاهز: اضغط على الشريحة مباشرة، والأسهم تعمل من أي مكان'), null, null, 4000);
    teamsHint();
  }
  // بديل: الشرائح كصور داخل البرنامج (بدون حركات)، عندما لا يمكن عرض باوربوينت داخل الإطار
  // البرنامج يحفظ الصور بعد أول تحويل (تُفتح فوراً في المرات القادمة)، ويبدأ العرض من أول شريحة جاهزة
  const slideJobsR = new Map();     // dir → tab
  window.api.onSlideReady((m) => { const t = slideJobsR.get(m.dir); if (t && t.ppt && t.ppt.onReady) t.ppt.onReady(m); });
  async function openSlidesImages(path, pre) {
    if (!pre) toast(I18N.t('جارٍ تجهيز الشرائح…'), null, null, 8000);
    const r = pre || await window.api.pptExport(path);
    if (!r || !r.count) { toast(I18N.t('تعذّر فتح العرض في باوربوينت'), null, null, 4000); return null; }
    const box = document.createElement('div');
    box.className = 'mirror hidden slidesImg';
    box.innerHTML = '<img draggable="false"><div class="sl-wait"></div><div class="pptbar"><button data-a="prev">‹</button><span class="pg"></span><button data-a="next">›</button><span class="sl-prog"></span></div>'; rtlNav(box.querySelector('.pptbar'));
    const img = box.querySelector('img'), wait = box.querySelector('.sl-wait'), prog = box.querySelector('.sl-prog');
    const base = 'file:///' + r.dir.replace(/\\/g, '/').replace(/^\/+/, '') + '/';
    const ready = new Set(r.ready || []);
    const t = { kind: 'ppt', wv: box, pages: {}, page: 's1', home: null, title: fileName(path), doc: 'ppt:' + path, ppt: { id: null, images: true, count: r.count, slide: 1, dir: r.dir } };
    const progress = () => {
      const done = ready.size >= t.ppt.count;
      prog.textContent = done ? '' : '⏳ ' + I18N.t('{d} من {n} جاهزة', { d: ready.size, n: t.ppt.count });
      prog.style.display = done ? 'none' : '';
      if (done) slideJobsR.delete(r.dir);
    };
    const show = (n) => {
      t.ppt.slide = Math.max(1, Math.min(t.ppt.count, n));
      const k = t.ppt.slide;
      if (ready.has(k)) { img.src = base + 's' + k + '.png'; img.style.visibility = ''; wait.classList.remove('on'); }
      else { img.style.visibility = 'hidden'; wait.textContent = I18N.t('جارٍ تجهيز الشريحة {n}…', { n: k }); wait.classList.add('on'); window.api.pptExportWant(r.dir, k); }
      setPage(t, 's' + k);
      box.querySelector('.pg').textContent = `${k} / ${t.ppt.count}`;
    };
    t.ppt.onReady = (m) => { ready.add(m.n); progress(); if (m.n === t.ppt.slide) show(m.n); };
    t.ppt.go = (cmd) => show(cmd === 'prev' ? t.ppt.slide - 1 : cmd === 'first' ? 1 : t.ppt.slide + 1);
    Object.assign(box, {
      getURL: () => t.doc, getTitle: () => t.title,
      canGoBack: () => t.ppt && t.ppt.slide > 1, canGoForward: () => t.ppt && t.ppt.slide < t.ppt.count,
      goBack: () => t.ppt.go('prev'), goForward: () => t.ppt.go('next'), reload: () => t.ppt.go('first'),
      capturePage: async () => {
        const c = document.createElement('canvas'); c.width = img.naturalWidth || 640; c.height = img.naturalHeight || 360;
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        const d = c.toDataURL('image/jpeg', 0.8);
        return { isEmpty: () => false, toDataURL: () => d };
      }
    });
    box.addEventListener('click', e => t.ppt && t.ppt.go(e.target.dataset.a || 'next'));
    box.addEventListener('contextmenu', e => { e.preventDefault(); t.ppt && t.ppt.go('prev'); });
    if (ready.size < r.count) slideJobsR.set(r.dir, t);
    addTab(t);
    show(1); progress();
    if (!pre) toast(I18N.t(ready.size >= r.count ? 'العرض كصور (بدون الحركات)' : 'العرض جاهز — بقية الشرائح تُجهَّز أثناء الشرح'), null, null, 4000);
    return t;
  }
  function pptShow(t, st) {
    if (!st) return;
    t.ppt.slide = st.slide || st.pos || t.ppt.slide;
    t.ppt.count = st.count || t.ppt.count;
    setPage(t, 's' + t.ppt.slide);
    const pg = t.wv.querySelector('.pg'); if (pg) pg.textContent = `${t.ppt.slide} / ${t.ppt.count}`;
    if (st.state === 5 && !t.ppt.ended) { t.ppt.ended = true; if (t === active) toast(I18N.t('انتهى العرض')); }
    if (st.state !== 5) t.ppt.ended = false;
  }
  async function pptGo(t, cmd) { if (!t.ppt) return; if (t.ppt.images) return t.ppt.go(cmd);
    if (cmd === 'back') { pptShow(t, await window.api.pptCmd(t.ppt.id, 'goto', t.ppt.slide || 1)); return; } pptShow(t, await window.api.pptCmd(t.ppt.id, cmd)); }
  async function pptPoll(t) {
    if (!t.ppt || t.ppt.busy || t.ppt.gone) return; t.ppt.busy = true;
    const p = t.ppt;
    try {
      const st = await window.api.pptCmd(p.id, 'state');
      if (st) { p.nulls = 0; pptShow(t, st); }
      else if ((p.nulls = (p.nulls || 0) + 1) >= 4 && !p.checking) {
        // لا رد من العرض عدة مرات: هل ما زالت نافذته موجودة؟
        p.checking = true;
        const alive = await window.api.pptAlive(p.id).catch(() => null);
        p.checking = false; p.nulls = 0;
        if (alive === false && t.ppt === p) pptGone(t);
      }
    } finally { p.busy = false; }
  }
  // العرض اختفى (أُغلق باوربوينت أو نافذة العرض): شريط واضح لإعادة فتحه في التبويب نفسه
  function pptGone(t) {
    if (!t.ppt || t.ppt.gone) return;
    t.ppt.gone = true; clearInterval(t.ppt.timer);
    try { window.api.castLog && window.api.castLog('ppt show vanished id=' + t.ppt.id + ' file=' + t.title); } catch {}
    if (window.__lpCastSync) window.__lpCastSync();
    const box = t.wv; if (box.querySelector('.pptGone')) return;
    const g = document.createElement('div'); g.className = 'pptGone';
    g.innerHTML = `<span>⚠️ ${I18N.t('توقف عرض الباوربوينت')}</span><button class="pri">🔄 ${I18N.t('إعادة فتحه')}</button>`;
    g.querySelector('button').onclick = () => openPpt(t.doc.replace(/^ppt:/, ''), t);
    box.appendChild(g);
    if (t === active) { updateHole(); toast(I18N.t('توقف عرض الباوربوينت — يمكن إعادة فتحه من الزر'), null, null, 5000); }
  }
  function pptCloseTab(t) {
    if (!t.ppt) return;
    if (t.ppt.images) { t.ppt = null; return; }
    clearInterval(t.ppt.timer);
    try { t.ppt.stream && t.ppt.stream.getTracks().forEach(x => x.stop()); } catch {}
    window.api.pptClose(t.ppt.id);
    t.ppt = null;
  }

  // فتح أي ملف حسب نوعه
  async function openPath(p) {
    if (!p) return;
    if (window.LP_WEB && /\.(pptx?|ppsx?|docx?|xlsx?)$/i.test(p)) return toast(I18N.t('هذا الملف لا يُعرض في نسخة الويب. يمكن حفظه PDF، أو فتحه برابط من OneDrive أو Google Drive.'));
    if (/\.pdf$/i.test(p)) return openPdf(p);
    if (window.LP_WEB && /^blob:/.test(p)) { const url = p.split('#')[0]; if (active && isWelcome(view.getURL())) go(url); else newTab(url); return; }
    if (/\.(pptx?|ppsx?)$/i.test(p)) return openPpt(p);
    const url = 'file:///' + p.replace(/\\/g, '/').replace(/^\/+/, '');
    if (active && isWelcome(view.getURL())) go(url); else newTab(url);
  }
  window.api.onOpenPath(openPath);
  // السحب والإفلات على البرنامج
  window.addEventListener('dragover', e => { e.preventDefault(); });
  window.addEventListener('drop', e => {
    e.preventDefault();
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) openPath(window.api.pathOfFile(f));
  });

  // ---------- قفل حسابات مايكروسوفت وGoogle بعد عدم الاستخدام ----------
  const ACCOUNT_HOSTS = /(^|\.)((login\.)?microsoftonline\.com|login\.live\.com|onedrive\.live\.com|live\.com|office\.com|office365\.com|sharepoint\.com|officeapps\.live\.com|outlook\.(com|office\.com|live\.com)|teams\.microsoft\.com|teams\.live\.com|account\.microsoft\.com|accounts\.google\.com|docs\.google\.com|drive\.google\.com|mail\.google\.com|classroom\.google\.com|myaccount\.google\.com|calendar\.google\.com|meet\.google\.com|slides\.google\.com|sheets\.google\.com)$/i;
  let locked = false;
  // المواقع المكتشفة (دخول بكلمة مرور أو بحساب Google/Microsoft) تُقفل أيضاً، إلا ما اختار المعلم «لا تقفل»
  let acctSites = [];
  const siteOfHost = (h) => acctSites.find(x => h === x.host || h.endsWith('.' + x.host));
  function isAccountUrl(u) {
    let h; try { h = new URL(u).hostname.toLowerCase(); } catch { return false; }
    if (ACCOUNT_HOSTS.test(h)) { const key = /google\./.test(h) ? 'google' : 'microsoft'; const o = acctSites.find(x => x.host === key); return !(o && o.nolock); }
    const o = siteOfHost(h.replace(/^www\./, '')); return !!(o && !o.nolock);
  }
  // لا يظهر القفل أثناء ملء الشاشة (لعبة أو عرض أمام الطلاب)، ولا على صفحة لا يوجد فيها دخول فعلي
  let signed = { google: true, microsoft: true }, signedAt = 0;
  const isFull = () => !!(document.fullscreenElement || document.body.classList.contains('fullShow') || ($('#full') && $('#full').classList.contains('on')));
  const needsLock = (u) => { let h = ''; try { h = new URL(u).hostname; } catch { return false; } if (!ACCOUNT_HOSTS.test(h)) return true; return /google\.com$/i.test(h) ? signed.google : signed.microsoft; };
  async function refreshSigned() { if (Date.now() - signedAt < 4000 || !window.api.acctSigned) return; signedAt = Date.now(); try { signed = await window.api.acctSigned(); const p = await window.api.getSettings(); acctSites = Array.isArray(p.loginSites) ? p.loginSites : []; } catch {} }
  const loadSites = async () => { signedAt = 0; await refreshSigned(); };
  document.addEventListener('lp-auth', loadSites);
  window.api.onAcctChanged && window.api.onAcctChanged(loadSites);
  let lockFocusT = null;
  async function updateLock() {
    const el = $('#acctLock'); if (!el) return;
    let show = locked && active && active.kind === 'web' && isAccountUrl(view.getURL()) && !isFull();
    if (show) { await refreshSigned(); show = needsLock(view.getURL()); }
    const was = el.classList.contains('on');
    el.classList.toggle('on', !!show);
    clearInterval(lockFocusT);
    if (show) {
      if (!was) setTimeout(() => { const i = $('#lockPin'); if (i) { i.value = ''; i.focus(); } }, 30);
      // تبقى الكتابة في خانة القفل حتى لو أخذت الصفحة التي خلفها المؤشر
      lockFocusT = setInterval(() => { const i = $('#lockPin'); if (i && document.activeElement !== i && !(document.activeElement && document.activeElement.closest && document.activeElement.closest('#acctLock'))) i.focus(); }, 400);
    }
  }
  document.addEventListener('fullscreenchange', () => updateLock());
  new MutationObserver(() => { if (locked) updateLock(); }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  // صفحات الدخول تعرف حالة القفل: لا عدّ تنازلي ولا تعبئة والقفل ظاهر
  window.api.onIdleLock(() => { locked = true; window.api.acctLocked && window.api.acctLocked(true); updateLock(); });
  LP_unlock = async (pin) => { const r = await window.api.authUnlock(pin); if (r.ok) { locked = false; window.api.acctLocked && window.api.acctLocked(false); updateLock(); } return r; };

  function load(t, u) {
    if (t.ready) t.wv.loadURL(u).catch(() => {});
    else t.pending = u;
  }
  function go(u) {
    if (!u) return;
    if (active.kind === 'pdf') { active.kind = 'web'; active.doc = null; setPage(active, ''); }
    load(active, u);
    if (!isWelcome(u)) homeUrl = u;
  }
  const pop = $('#urlPop');
  const closePop = () => { pop.classList.remove('on'); urlBox.blur(); };
  $('#linkBtn').onclick = () => {
    if (pop.classList.toggle('on')) { urlBox.value = homeUrl || ''; setTimeout(() => { urlBox.focus(); urlBox.select(); }, 0); }
  };
  const submitUrl = () => { const u = normalize(urlBox.value); if (u) { go(u); closePop(); } };
  $('#urlGo').onclick = submitUrl;
  urlBox.addEventListener('keydown', e => {
    e.stopPropagation();
    if (e.key === 'Enter') submitUrl();
    if (e.key === 'Escape') closePop();
  });
  cv.addEventListener('pointerdown', closePop);
  $('#back').onclick = () => view.canGoBack() && view.goBack();
  $('#fwd').onclick = () => view.canGoForward() && view.goForward();
  $('#reload').onclick = () => view.reload();
  $('#home').onclick = () => { if (active.kind === 'ppt') return pptGo(active, 'first'); load(active, homeUrl || welcomeUrl); };
  $('#home').addEventListener('contextmenu', () => { if (active.kind === 'web') load(active, welcomeUrl); });
  $('#openFile').onclick = async () => { const r = await window.api.openFile(); if (r) openPath(r.path); };

  // ---------- النافذة ----------
  // تصغير البرنامج والأدوات خارج العمود: تبقى ظاهرة فوق البرنامج الذي تعمل فيه
  $('#min').onclick = async () => {
    const free = LP.dockFree ? [['wheel', () => $('#mw').classList.contains('on')], ['goals', () => $('#goalsCard') && $('#goalsCard').classList.contains('on')], ['timer', () => LP.timerState && LP.timerState().active]]
      .filter(([k, on]) => LP.dockFree(k) && on()).map(([k]) => k) : [];
    if (free.length && LP.popOut) { for (const k of free) await LP.popOut(k); return; }
    window.api.minimize();
  };
  $('#max').onclick = () => window.api.maximize();
  $('#max').addEventListener('contextmenu', e => { e.preventDefault(); window.api.layoutMenu(); });
  $('#full').onclick = () => window.api.fullscreen();
  $('#close').onclick = () => window.api.close();
  $('#hideBar').onclick = () => app.classList.add('barHidden');
  $('#showBar').onclick = () => app.classList.remove('barHidden');
  window.api.onState(s => {
    $('#full').classList.toggle('on', s.fullscreen);
    $('#max').innerHTML = s.maximized
      ? '<svg viewBox="0 0 24 24"><rect x="4" y="8" width="12" height="12" rx="1.5"/><path d="M8 8V5a1 1 0 011-1h10a1 1 0 011 1v10a1 1 0 01-1 1h-3"/></svg>'
      : '<svg viewBox="0 0 24 24"><rect x="5" y="5" width="14" height="14" rx="1.5"/></svg>';
  });

  // ---------- اختصارات لوحة المفاتيح ----------
  const keys = { p: 'pen', h: 'hl', l: 'laser', r: 'rect', o: 'ellipse', a: 'arrow', t: 'text', e: 'eraser', s: 'spot', v: 'select' };
  function handleKey(k, ctrl, shift) {
    k = k.toLowerCase();
    if (!ctrl && tool === 'spot' && ['+', '=', ']'].includes(k)) { $('#spotPlus').click(); return true; }
    if (!ctrl && tool === 'spot' && ['-', '_', '['].includes(k)) { $('#spotMinus').click(); return true; }
    if (ctrl && k === 'z') { shift ? redo() : undo(); return true; }
    if (ctrl && k === 'y') { redo(); return true; }
    if (ctrl && k === 't') { newTab(); return true; }
    if (ctrl && k === 'w') { closeTab(active); return true; }
    if (ctrl && k === 'tab') { const i = tabs.indexOf(active); switchTab(tabs[(i + (shift ? -1 : 1) + tabs.length) % tabs.length]); return true; }
    if (ctrl && /^[1-9]$/.test(k)) { const t = tabs[+k - 1]; if (t) switchTab(t); return true; }
    if (!ctrl && selValid()) {
      const st = shift ? 10 : 1, mv = { arrowleft: [-st, 0], arrowright: [st, 0], arrowup: [0, -st], arrowdown: [0, st] }[k];
      if (mv) return nudge(...mv);
      if (k === 'delete' || k === 'backspace') return deleteSel();
      if (k === 'escape') { if (!(window.LP && LP.closePanels())) { sel = null; redraw(); } return true; }
    }
    if (ctrl || shift) return false;
    if (active && active.kind !== 'web' && !shift && /^(arrowright|arrowleft|arrowdown|arrowup|pagedown|pageup| |home|end)$/.test(k)) {
      const next = /^(arrowright|arrowdown|pagedown| )$/.test(k);
      if (active.kind === 'ppt') pptGo(active, k === 'home' ? 'first' : next ? 'next' : 'prev');
      else view.executeJavaScript(`window.LPV && LPV.${k === 'home' ? 'first' : k === 'end' ? 'last' : next ? 'next' : 'prev'}()`).catch(() => {});
      return true;
    }
    if (k === 'escape') { if (window.LP && LP.closePanels()) return true; setTool('mouse'); return true; }
    if (k === 'f11') { window.api.fullscreen(); return true; }
    if (k === 'f5') { if (active.kind === 'ppt') pptGo(active, 'first'); else view.reload(); return true; }
    if (k === 'delete') { clearAll(); return true; }
    if (k === 'b') { app.classList.toggle('barHidden'); return true; }
    if (k === 'w') { $('#boardBtn').click(); return true; }
    if (k === 'q') { $('#splitBtn').click(); return true; }
    if (window.LP && LP.miniWheelKey && LP.miniWheelKey(k)) return true;
    if (k === 'g' && LP.toggleMiniWheel) { LP.toggleMiniWheel(); return true; }
    if (k === 'n' && LP.toggleGroupBar) { LP.toggleGroupBar(); return true; }
    if (keys[k]) { setTool(keys[k]); return true; }
    return false;
  }
  window.addEventListener('keydown', e => {
    const tg = e.target; if (tg && (tg.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName))) return;
    if (document.querySelector('.panel.on') && e.key !== 'Escape') return;
    if (handleKey(e.key, e.ctrlKey || e.metaKey, e.shiftKey)) e.preventDefault();
  });

  // ---------- واجهة للأدوات الإضافية ----------
  window.LP = {
    teamsCast: teamsApi,
    slideAr: () => (active && active.ppt && active.ppt.ar) || 16 / 9,
    pickUrl,
    refreshWelcome: async () => { welcomeUrl = await window.api.welcomeUrl(); tabs.forEach(t => { try { if (t.kind === 'web' && isWelcome(t.wv.getURL())) t.wv.loadURL(welcomeUrl); } catch {} }); },
    setZoomCtl: (on) => { zoomPref = on !== false; updZoom(); },
    get view() { return view; },
    get tab() { return active; },
    get homeUrl() { return homeUrl; },
    isWelcome, newTab, go, load, toast, setTool, normalize, get tool() { return tool; },
    setEraser(r) { eraserR = r; setTool('eraser'); }, get eraserR() { return eraserR; },
    setStamp(ch) { stampCh = ch; setTool('stamp'); }, get stamp() { return stampCh; },
    setBranch(kind, n) { if (kind) branchKind = kind; if (n) branchN = n; try { localStorage.setItem('lpBranchKind', branchKind); localStorage.setItem('lpBranchN', branchN); } catch {} setTool('branch'); }, get branch() { return { kind: branchKind, n: branchN }; },
    get selected() { return selValid() ? sel : null; },
    setStampSize(n) { stampSize = n; try { localStorage.setItem('lpStampSize', n); } catch {} }, get stampSize() { return stampSize; }, clearAll: () => clearAll(),
    openUrl(u) {
      if (/^pdf:/.test(u)) return openPdf(u.slice(4));
      if (/^ppt:/.test(u)) return openPpt(u.slice(4));
      if (active && active.kind === 'web' && isWelcome(view.getURL())) go(u); else newTab(u);
    },
    currentUrl() { return active ? (active.doc || view.getURL()) : ''; },
    currentTitle() { return active ? (active.title || (view.getTitle && view.getTitle()) || '') : ''; },
    openPath, stageRect,
    closePanels: () => false
  };

  // ---------- البدء ----------
  (async () => {
    // ننتظر تحميل كل أجزاء الصفحة أولاً
    if (document.readyState === 'loading') await new Promise(r => document.addEventListener('DOMContentLoaded', r, { once: true }));
    const st = await window.api.authState();
    I18N.setLang(st.lang);
    document.documentElement.lang = st.lang; document.documentElement.dir = I18N.dir();
    I18N.translateDOM(document.body);
    welcomeUrl = await window.api.welcomeUrl();
    window.LP.auth = st;
    document.dispatchEvent(new CustomEvent('lp-auth', { detail: st }));
    if (!st.user) return;                      // تظهر شاشة الدخول
    partition = st.partition;
    newTab();
  })();
  resize();
})();
