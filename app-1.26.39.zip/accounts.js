// حسابات المعلمات: الرمز السري، المديرة، الضيفة، الاسترجاع بالبريد، وتسجيل الخروج من الحسابات
const { session } = require('electron');
const crypto = require('crypto');
const store = require('./store');
const I = require('./i18n');

let current = null;                 // معرّف المستخدم الحالية، أو 'guest'، أو null
let guestPart = 'guest_' + crypto.randomBytes(4).toString('hex');
const fails = new Map();            // محاولات خاطئة: id → { n, until }
const MAX_FAILS = 5, LOCK_MS = 60 * 1000;

const hash = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString('hex');
const newId = () => crypto.randomBytes(6).toString('hex');
const validPin = (p) => /^\d{4,12}$/.test(String(p || ''));
const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || '').trim());
const pub = (u) => u && ({ id: u.id, name: u.name, email: u.email, admin: !!u.admin, cloud: !!u.cloudUid, cloudPw: !!u.cloudPw, qrOnly: !!(u.cloudUid && !u.salt) });

function partitionOf(id) {
  if (id === 'guest') return guestPart;
  return 'persist:u_' + id;
}
async function clearSessionOf(id) {
  try {
    const ses = session.fromPartition(partitionOf(id));
    await ses.clearStorageData();
    await ses.clearCache();
    await ses.clearAuthCache();
  } catch {}
}

function checkLock(id) {
  const f = fails.get(id);
  if (f && f.until > Date.now()) return Math.ceil((f.until - Date.now()) / 1000);
  return 0;
}
function failed(id) {
  const f = fails.get(id) || { n: 0, until: 0 };
  f.n += 1;
  if (f.n >= MAX_FAILS) { f.until = Date.now() + LOCK_MS; f.n = 0; }
  fails.set(id, f);
}
function verify(u, pin) {
  const wait = checkLock(u.id);
  if (wait) return { ok: false, wait };
  if (hash(pin, u.salt) === u.hash) { fails.delete(u.id); return { ok: true }; }
  failed(u.id);
  const w = checkLock(u.id);
  return w ? { ok: false, wait: w } : { ok: false };
}
function setPin(u, pin) {
  u.salt = crypto.randomBytes(16).toString('hex');
  u.hash = hash(pin, u.salt);
}

// ---------- الحالة ----------
function state() {
  const g = store.global.get();
  const u = current && current !== 'guest' ? store.users.get(current) : null;
  const prof = current ? store.profiles.get(current) : {};
  return {
    setup: store.users.all().length === 0,
    user: current === 'guest' ? { id: 'guest', name: I.t('ضيف'), guest: true } : pub(u),
    users: store.users.all().map(x => ({ id: x.id, name: x.name, admin: !!x.admin, cloud: !!x.cloudUid, cloudPw: !!x.cloudPw, qrOnly: !!(x.cloudUid && !x.salt) })),
    lang: prof.lang || g.lang || installLang() || 'ar',
    idleMin: g.idleMin || 10,
    partition: current ? partitionOf(current) : null,
    personal: u ? store.device.isPersonal(u.id) : false
  };
}

// ---------- الإنشاء والدخول ----------
function create({ name, email, pin }, admin) {
  name = String(name || '').trim();
  email = String(email || '').trim();
  if (!name) return { ok: false, err: 'name' };
  if (!validEmail(email)) return { ok: false, err: 'email' };
  if (!validPin(pin)) return { ok: false, err: 'pin' };
  if (store.users.byEmail(email)) return { ok: false, err: 'exists' };
  const u = { id: newId(), name, email, admin: !!admin, created: Date.now() };
  setPin(u, pin);
  store.users.add(u);
  current = u.id;
  return { ok: true };
}
function login(id, pin) {
  const u = store.users.get(id);
  if (!u) return { ok: false };
  if (!u.salt) return { ok: false, nohash: true, email: u.email };   // دخلت بالباركود فقط على هذا الجهاز
  const r = verify(u, pin);
  if (r.ok) { current = u.id; lastFresh = openData(u, pin).fresh; }
  return r;
}
// ---------- فتح القفل بعد عدم الاستخدام ----------
// يقبل: رمز القفل السريع لهذا الجهاز، أو رمز/كلمة مرور الدخول، أو «بصمة القفل» المحفوظة بعد أول تحقق سحابي
// (جهاز دُخل إليه بالباركود فقط ليس فيه بصمة دخول؛ لا نلمس salt/hash الدخول حتى لا يتغير فتح البيانات)
const QP_MAX = 5;
function unlockLocal(pin) {
  if (!current || current === 'guest') return { ok: true };
  const u = store.users.get(current); if (!u) return { ok: false };
  const wait = checkLock(u.id); if (wait) return { ok: false, wait };
  pin = String(pin || '');
  if (u.qpHash && /^\d{4,6}$/.test(pin)) {
    if (hash(pin, u.qpSalt) === u.qpHash) { u.qpFails = 0; store.users.save(); fails.delete(u.id); return { ok: true }; }
  }
  if ((u.salt && hash(pin, u.salt) === u.hash) || (u.ulSalt && hash(pin, u.ulSalt) === u.ulHash)) { if (u.qpFails) { u.qpFails = 0; store.users.save(); } fails.delete(u.id); return { ok: true, full: true }; }
  // خطأ: إن كان المكتوب بشكل رمز سريع نعدّ محاولة عليه، وبعد ٥ يتوقف الرمز السريع
  if (u.qpHash && /^\d{4,6}$/.test(pin)) {
    u.qpFails = (u.qpFails || 0) + 1;
    if (u.qpFails >= QP_MAX) { delete u.qpHash; delete u.qpSalt; u.qpFails = 0; u.qpOff = true; store.users.save(); fails.delete(u.id); return { ok: false, err: 'qpoff' }; }
    store.users.save();
  }
  return { ok: false, cloud: !!u.cloudUid, noLocal: !u.salt && !u.ulSalt, uid: u.cloudUid };
}
function unlockFail() { if (current && current !== 'guest') { failed(current); const w = checkLock(current); if (w) return { ok: false, wait: w }; } return { ok: false }; }
function rememberUnlock(pin) {
  const u = current && current !== 'guest' ? store.users.get(current) : null; if (!u) return;
  u.ulSalt = crypto.randomBytes(16).toString('hex'); u.ulHash = hash(String(pin), u.ulSalt); store.users.save(); fails.delete(u.id);
}
function quickPin(pin) {              // '' = إزالة
  const u = current && current !== 'guest' ? store.users.get(current) : null; if (!u) return { ok: false };
  if (!pin) { delete u.qpHash; delete u.qpSalt; u.qpFails = 0; store.users.save(); return { ok: true }; }
  if (!/^\d{4,6}$/.test(String(pin))) return { ok: false, err: 'qpfmt' };
  u.qpSalt = crypto.randomBytes(16).toString('hex'); u.qpHash = hash(String(pin), u.qpSalt); u.qpFails = 0; delete u.qpOff; store.users.save();
  return { ok: true };
}
function quickPinState() { const u = current && current !== 'guest' ? store.users.get(current) : null; return { has: !!(u && u.qpHash), off: !!(u && u.qpOff) }; }
function unlock(pin) { const r = unlockLocal(pin); return r.ok || r.wait || r.err ? r : unlockFail(); }
async function logout(wipe) {
  if (current && current !== 'guest') {
    const u = store.users.get(current);
    if (wipe && u && u.cloudUid) { await clearSessionOf(current); store.device.setPersonal(current, false); store.users.remove(current); current = null; }
    else store.profiles.dropKey(current);
  }
  if (current) {
    const u = current !== 'guest' ? store.users.get(current) : null;
    if (!u || !store.device.isPersonal(u.id)) await clearSessionOf(current);
  }
  current = null;
  guestPart = 'guest_' + crypto.randomBytes(4).toString('hex');
}
// عند إغلاق البرنامج: الخروج من حسابات كل من ليس على «جهازها الشخصي»
async function cleanupOnQuit() {
  let ch = false;
  for (const u of store.users.all()) if (!store.device.isPersonal(u.id)) { await clearSessionOf(u.id); if (u.cloudTok) { delete u.cloudTok; ch = true; } }
  if (ch) store.users.save();
  await clearSessionOf('guest');
}

// ---------- إعدادات المعلمة لنفسها ----------
function changePin(oldPin, newPin) {
  const u = store.users.get(current);
  if (!u) return { ok: false };
  if (u.cloudPw) return { ok: false, err: 'cloudpw' };
  const r = verify(u, oldPin);
  if (!r.ok) return r;
  if (!validPin(newPin)) return { ok: false, err: 'pin' };
  setPin(u, newPin);
  const dek = store.profiles.keyOf(u.id); if (u.dek && dek) wrapDek(u, newPin, dek);
  store.users.save();
  return { ok: true };
}
function updateMe({ name, email }) {
  const u = store.users.get(current);
  if (!u) return { ok: false };
  if (name !== undefined) { name = String(name).trim(); if (!name) return { ok: false, err: 'name' }; u.name = name; }
  if (email !== undefined) {
    email = String(email).trim();
    if (!validEmail(email)) return { ok: false, err: 'email' };
    const other = store.users.byEmail(email);
    if (other && other.id !== u.id) return { ok: false, err: 'exists' };
    u.email = email;
  }
  store.users.save();
  return { ok: true };
}
function setPersonal(on) { if (current && current !== 'guest') store.device.setPersonal(current, !!on); }
const signOutAccounts = () => current ? clearSessionOf(current) : null;


// ---------- تشفير بيانات الحساب السحابي على الجهاز ----------
// مفتاح عشوائي للبيانات، محفوظ مقفلاً بكلمة المرور (أو رمز الجهاز لحساب Google)
const kek = (secret, salt) => crypto.scryptSync(String(secret), Buffer.from(salt, 'hex'), 32);
function wrapDek(u, secret, dek, field = 'dek') {
  const salt = crypto.randomBytes(16).toString('hex'), iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', kek(secret, salt), iv);
  const d = Buffer.concat([c.update(dek), c.final()]);
  u[field] = { s: salt, iv: iv.toString('hex'), tag: c.getAuthTag().toString('hex'), d: d.toString('hex') };
}
function unwrapDek(u, secret, field = 'dek') {
  const w = u[field];
  if (!w || secret === undefined || secret === null) return null;
  try {
    const c = crypto.createDecipheriv('aes-256-gcm', kek(secret, w.s), Buffer.from(w.iv, 'hex'));
    c.setAuthTag(Buffer.from(w.tag, 'hex'));
    return Buffer.concat([c.update(Buffer.from(w.d, 'hex')), c.final()]);
  } catch { return null; }
}
// يفتح بيانات المعلمة بكلمة المرور، أو بمفتاح الجوال (lk) عند الدخول بالباركود.
// إن تعذّر الفتح (تغيّرت كلمة المرور من جهاز آخر) تُستبدل نسخة الجهاز وتُنزَّل من السحابة
function openData(u, secret, lk, lkAlt = []) {
  if (!u.cloudUid) return { fresh: false };
  let dek = unwrapDek(u, secret) || unwrapDek(u, lk, 'dekQ'), fresh = false;
  for (const a of lkAlt || []) if (!dek) dek = unwrapDek(u, a, 'dekQ');      // مفتاح جوال قديم (قبل 1.26.17)
  if (!dek) {
    if (u.dek || u.dekQ || store.profiles.isEncrypted(u.id)) { store.profiles.wipe(u.id); fresh = true; }
    dek = crypto.randomBytes(32);
  }
  if (secret !== undefined && secret !== null) wrapDek(u, secret, dek);
  if (lk) wrapDek(u, lk, dek, 'dekQ');
  store.users.save();
  if (!store.profiles.setKey(u.id, dek)) { store.profiles.wipe(u.id); store.profiles.setKey(u.id, dek); fresh = true; }
  return { fresh };
}
// بعد معرفة مفتاح الجوال (lk) لأول مرة: نقفل نفس مفتاح البيانات به أيضاً، ليعمل الدخول بالباركود لاحقاً
function addQrWrap(lk) {
  const u = store.users.get(current), dek = u && store.profiles.keyOf(u.id);
  if (!u || !lk || !dek) return;
  const cur = unwrapDek(u, lk, 'dekQ');
  if (cur && cur.equals(dek)) return;
  wrapDek(u, lk, dek, 'dekQ'); store.users.save();
}
// الدخول بالباركود: المعلمة وافقت من جوالها
function qrAttach({ uid, email, name, lk, lkAlt, linkPin }) {
  if (!uid) return { ok: false, err: 'cfail' };
  email = String(email || '').trim();
  let u = store.users.all().find(x => x.cloudUid === uid);
  if (!u) {
    const old = store.users.byEmail(email);
    if (old && !old.cloudUid) {
      if (linkPin === undefined || linkPin === null) return { ok: false, need: 'link', user: pub(old) };
      const r = verify(old, linkPin); if (!r.ok) return r;
      u = old; u.cloudUid = uid;
    } else if (old && old.cloudUid !== uid) return { ok: false, err: 'ctaken' };
    else { u = { id: newId(), name: String(name || '').trim() || email.split('@')[0], email, admin: store.users.all().length === 0, created: Date.now(), cloudUid: uid }; store.users.add(u); }
  }
  store.users.save();
  current = u.id; fails.delete(u.id);
  return { ok: true, id: u.id, fresh: openData(u, linkPin, lk, lkAlt).fresh };
}
let lastFresh = false;

// ---------- الربط بالحساب السحابي ----------
// كلمة مرور الحساب السحابي تصبح أيضاً رمز الدخول على هذا الجهاز (تعمل دون إنترنت)
function setCloudPw(u, password) { setPin(u, password); u.cloudPw = true; }
// بعد نجاح الدخول السحابي: نجد حساب الجهاز المرتبط، أو نربط حساباً قديماً بنفس البريد، أو ننشئ حساباً جديداً
function cloudAttach({ uid, email, name, password, linkPin, pin, lk }) {
  if (!uid) return { ok: false, err: 'cfail' };
  email = String(email || '').trim();
  let u = store.users.all().find(x => x.cloudUid === uid);
  if (!u) {
    const old = store.users.byEmail(email);
    if (old && !old.cloudUid) {
      if (linkPin === undefined || linkPin === null) return { ok: false, need: 'link', user: pub(old) };
      const r = verify(old, linkPin);
      if (!r.ok) return r;
      u = old; u.cloudUid = uid;
    } else if (old && old.cloudUid && old.cloudUid !== uid) {
      return { ok: false, err: 'ctaken' };
    } else {
      if (!password && !validPin(pin)) return { ok: false, need: 'pin' };
      u = { id: newId(), name: String(name || '').trim() || email.split('@')[0], email, admin: store.users.all().length === 0, created: Date.now(), cloudUid: uid };
      store.users.add(u);
    }
  }
  let secret = password;
  if (password) setCloudPw(u, password);
  else if (pin && validPin(pin)) { setPin(u, pin); secret = pin; }
  else if (u.dek) {                                   // Google على جهاز سبق الدخول فيه: رمز الجهاز يفتح البيانات
    if (linkPin === undefined || linkPin === null) return { ok: false, need: 'devpin', user: pub(u) };
    const r = verify(u, linkPin); if (!r.ok) return r;
    secret = linkPin;
  } else if (linkPin !== undefined && linkPin !== null) secret = linkPin;
  if (!u.salt) return { ok: false, need: 'pin' };
  if (secret === undefined || secret === null) return { ok: false, need: 'pin' };
  if (email && u.email !== email && !store.users.byEmail(email)) u.email = email;
  store.users.save();
  current = u.id; fails.delete(u.id);
  const fresh = openData(u, secret, lk).fresh;
  return { ok: true, id: u.id, fresh };
}
// ربط حساب الجهاز الحالي (الذي أُنشئ دون إنترنت) بحساب سحابي
function linkCurrent(uid, email, password) {
  const u = store.users.get(current);
  if (!u) return { ok: false };
  const other = store.users.all().find(x => x.cloudUid === uid && x.id !== u.id);
  if (other) return { ok: false, err: 'ctaken' };
  u.cloudUid = uid; if (email) u.email = String(email).trim();
  if (password) {
    setCloudPw(u, password);
    const dek = store.profiles.keyOf(u.id);
    if (dek) wrapDek(u, password, dek);          // تغيّرت كلمة المرور أو أُضيفت: نقفل نفس المفتاح
    else { store.users.save(); openData(u, password); }
  }
  store.users.save();
  return { ok: true };
}
function cloudToken(id, sealed) {
  const u = store.users.get(id || current); if (!u) return null;
  if (sealed === undefined) return u.cloudTok || null;
  if (sealed) u.cloudTok = sealed; else delete u.cloudTok;
  store.users.save(); return true;
}

// ---------- المديرة ----------
const isAdmin = () => { const u = current && store.users.get(current); return !!(u && u.admin); };
function adminUsers() {
  if (!isAdmin()) return [];
  return store.users.all().map(u => ({ ...pub(u), created: u.created, me: u.id === current }));
}
async function adminResetPin(id, pin) {
  if (!isAdmin()) return { ok: false };
  const u = store.users.get(id);
  // الحساب السحابي: لا تستطيع المديرة تغيير كلمة مروره (تسترجعها المعلمة بنفسها من بريدها)
  if (u && u.cloudUid) return { ok: false, err: 'cloudreset' };
  if (!u || !validPin(pin)) return { ok: false, err: 'pin' };
  setPin(u, pin); fails.delete(id); store.users.save();
  // لحماية خصوصية المعلمة: تخرج من حساباتها في مايكروسوفت وGoogle
  if (id !== current) { await clearSessionOf(id); store.device.setPersonal(id, false); }
  return { ok: true };
}
async function adminDelete(id) {
  if (!isAdmin() || id === current) return { ok: false };
  await clearSessionOf(id);
  store.device.setPersonal(id, false);
  store.users.remove(id);
  return { ok: true };
}
function adminSetAdmin(id, on) {
  if (!isAdmin() || id === current) return { ok: false };
  const u = store.users.get(id); if (!u) return { ok: false };
  u.admin = !!on; store.users.save(); return { ok: true };
}
function adminSetIdle(min) { if (isAdmin()) store.global.patch({ idleMin: Math.max(1, Math.min(120, +min || 10)) }); }
// نسيان رمز حساب محلي ولا مدير آخر على الجهاز: حذف الحساب وبياناته على هذا الجهاز للبدء من جديد
// (لا يُسمح للحسابات السحابية، ويلزم كتابة بريد الحساب، ولا يُسمح إن وُجد مدير آخر يستطيع إعادة تعيين الرمز)
async function startOver(id, email) {
  const u = store.users.get(id);
  if (!u || u.cloudUid) return { ok: false, err: 'invalid' };
  if (String(email || '').trim().toLowerCase() !== String(u.email || '').trim().toLowerCase()) return { ok: false, err: 'nomatch' };
  if (store.users.all().some(x => x.admin && x.id !== id)) return { ok: false, err: 'hasadmin' };
  await clearSessionOf(id);
  store.device.setPersonal(id, false);
  store.users.remove(id);
  const rest = store.users.all();
  if (rest.length && !rest.some(x => x.admin)) { rest[0].admin = true; store.users.save(); }
  return { ok: true };
}
function checkResetToken(uid, token) {
  const u = store.users.get(uid);
  return !!(u && u.reset && Date.now() <= u.reset.exp && hash(token, u.id) === u.reset.token);
}

// اللغة التي اختيرت في ملف التنصيب (install-lang.txt بجانب البرنامج)
function installLang() { try { const v = require('fs').readFileSync(require('path').join(require('./store').baseDir(), 'install-lang.txt'), 'utf8').trim(); return ['ar', 'en', 'fr'].includes(v) ? v : ''; } catch { return ''; } }
module.exports = {
  state, create, login, unlock, logout, cleanupOnQuit, guest: () => { current = 'guest'; },
  current: () => current, currentUser: () => (current && current !== 'guest' ? store.users.get(current) : null),
  isAdmin, partitionOf, changePin, unlockLocal, unlockFail, rememberUnlock, quickPin, quickPinState, updateMe, setPersonal, signOutAccounts,
  adminUsers, adminResetPin, adminDelete, adminSetAdmin, adminSetIdle, startOver,
  checkResetToken, cloudAttach, linkCurrent, cloudToken, qrAttach, addQrWrap, takeFresh: () => { const f = lastFresh; lastFresh = false; return f; }, verifyCurrent: (pin) => { const u = store.users.get(current); return u ? verify(u, pin) : { ok: false }; }
};
