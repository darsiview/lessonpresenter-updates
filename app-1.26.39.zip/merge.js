// 🔗 دمج فصلين: قائمة مطابقة الأسماء قبل الدمج، ثم بطاقة ملخص مع «تراجع».
// - الحصص (بنقاطها ومشاركاتها وغيابها وشكرها) تُضم حسب التاريخ، فتُجمع النقاط تلقائياً.
// - فصل المدرسة يبقى دائماً ويُحذف الشخصي؛ وبين فصلين من النوع نفسه يُختار الباقي.
// - لكل دمج تراجع مستقل مدة 7 أيام؛ والحصص المعطاة بعد الدمج تبقى في الفصل الباقي.
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const btn = $('#classMergeBtn'), undoBox = $('#mergeUndo');
  if (!btn) return;
  const KEEP = 7 * 864e5;
  const key = (c) => (LP.classKey ? LP.classKey(c) : c.name);
  const where = (c) => c.home ? '🏫 ' + (LP.ctxName ? LP.ctxName(c.home) : '') : '👤 ' + T('شخصي');
  const lbl = (c, o) => c.name === o.name || (c.home || '') !== (o.home || '') ? c.name + ' · ' + where(c) : c.name;   // يميّز الفصلين إن تشابها
  const clone = (o) => JSON.parse(JSON.stringify(o ?? null));

  // ---------- مطابقة الأسماء ----------
  const norm = (s) => String(s || '').replace(/[ً-ْـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي')
    .replace(/(^|\s)عبد\s+/g, '$1عبد').replace(/\s+/g, ' ').trim();
  const words = (s) => norm(s).split(' ').filter(Boolean);
  function similar(a, b) {
    const x = words(a), y = words(b); if (!x.length || !y.length) return false;
    const n = Math.min(x.length, y.length);
    if (n >= 2 && x.slice(0, n).join(' ') === y.slice(0, n).join(' ')) return true;   // ثلاثي مقابل رباعي
    return n >= 3 && x[0] === y[0] && x[x.length - 1] === y[y.length - 1];            // الاسم الأول والعائلة
  }
  // لكل اسم في الفصل المحذوف: اسم مطابق في الباقي، أو مقترح، أو إضافة
  function propose(src, tgt) {
    const used = new Set(), out = [];
    const byNorm = new Map(tgt.map(n => [norm(n), n]));
    for (const n of src) {
      const m = byNorm.get(norm(n));
      if (m && !used.has(m)) { used.add(m); out.push({ n, to: m, kind: 'same' }); } else out.push({ n, to: null, kind: '' });
    }
    for (const r of out) {
      if (r.to) continue;
      const m = tgt.find(t => !used.has(t) && similar(r.n, t));
      if (m) { used.add(m); r.to = m; r.kind = 'sug'; } else { r.to = '+'; r.kind = 'new'; }
    }
    return out;
  }

  // ---------- إعادة تسمية الأسماء داخل بيانات الحصص ----------
  function renamer(map, skip) {
    const rn = (v) => {
      if (typeof v === 'string') return map.has(v) ? map.get(v) : v;
      if (Array.isArray(v)) return v.filter(x => !(typeof x === 'string' && skip.has(x))).map(rn);
      if (v && typeof v === 'object') {
        const o = {};
        for (const [k, x] of Object.entries(v)) {
          if (skip.has(k)) continue;
          const nk = map.has(k) ? map.get(k) : k, nv = rn(x);
          if (nk in o && typeof o[nk] === 'number' && typeof nv === 'number') o[nk] += nv; else o[nk] = nv;
        }
        return o;
      }
      return v;
    };
    return rn;
  }
  // سجل الأحداث وسجل الشكر: نتجاهل ما يخص الأسماء غير المضافة
  const keepEntry = (skip) => (e) => !(e && skip.has(e.n || e.name));

  function mergeData(cdT, cdS, map, skip) {
    const rn = renamer(map, skip);
    const out = clone(cdT) || { sessions: [], cur: null, ngroups: 0 };
    const S = rn(clone(cdS) || { sessions: [] });
    out.sessions ||= []; out.archive ||= []; out.log ||= [];
    // معرّفات الحصص لا تتكرر
    const ids = new Set([...out.sessions, ...out.archive].map(s => s.id)), remap = new Map();
    const fresh = (id) => { let n = id, i = 1; while (ids.has(n)) n = id + '_m' + (i++); ids.add(n); if (n !== id) remap.set(id, n); return n; };
    const added = [];
    for (const s of S.sessions || []) { s.id = fresh(s.id); added.push(s.id); }
    for (const s of S.archive || []) { s.id = fresh(s.id); added.push(s.id); }
    const fix = (sid) => remap.get(sid) || sid;
    const tlT = out.thanksLog || out.sessions.flatMap(s => (s.thanks || []).map(t => ({ ...t, sid: s.id })));
    const tlS = (cdS.thanksLog ? S.thanksLog : (S.sessions || []).flatMap(s => (s.thanks || []).map(t => ({ ...t, sid: s.id })))) || [];
    out.thanksLog = [...tlT, ...tlS.filter(keepEntry(skip)).map(t => ({ ...t, sid: fix(t.sid) }))].sort((a, b) => (a.at || 0) - (b.at || 0));
    out.log = [...out.log, ...(S.log || []).filter(keepEntry(skip)).map(e => ({ ...e, sid: fix(e.sid) }))].sort((a, b) => (a.t || 0) - (b.t || 0));
    const all = [...out.sessions, ...(S.sessions || [])].sort((a, b) => (b.created || 0) - (a.created || 0));
    out.sessions = all.slice(0, 30);
    for (const o of all.slice(30)) out.archive.push({ id: o.id, created: o.created, pts: o.pts || {}, turns: o.turns || {}, absent: o.absent || {}, n: (o.groups || []).flat().length });
    out.archive = [...out.archive, ...(S.archive || [])].sort((a, b) => (a.created || 0) - (b.created || 0));
    if (!out.cur && cdS.cur) out.cur = fix(cdS.cur);
    if (!out.ngroups && S.ngroups) out.ngroups = S.ngroups;
    if (!(out.gnames || []).length && (S.gnames || []).length) out.gnames = S.gnames;
    return { cd: out, added, sessions: (S.sessions || []).length + (S.archive || []).length };
  }

  // ---------- نافذة الدمج ----------
  let dlg = null;
  const close = () => { if (dlg) { dlg.remove(); dlg = null; } };
  async function open() {
    if (LP.groupsFlush) await LP.groupsFlush();
    const p = await api.getSettings(), list = p.classes || [];
    const ci = Math.min(p.classIdx || 0, list.length - 1), cur = list[ci];
    if (!cur) return;
    const others = list.map((c, i) => ({ c, i })).filter(x => x.i !== ci);
    if (!others.length) { LP.toast(T('لا يوجد فصل آخر للدمج معه')); return; }
    close();
    dlg = document.createElement('div'); dlg.className = 'gdlg on mg-dlg';
    document.body.appendChild(dlg);
    let other = others[0].i, keep = 'auto', rows = null;
    const pair = () => {
      const a = list[ci], b = list[other];
      if (!!a.home !== !!b.home) return a.home ? { tI: ci, sI: other, forced: true } : { tI: other, sI: ci, forced: true };
      return keep === 'other' ? { tI: other, sI: ci } : { tI: ci, sI: other };
    };
    function step1() {
      const pr = pair(), t = list[pr.tI], s = list[pr.sI];
      dlg.innerHTML = `<div class="gdlg-card mg-card">
        <h3>🔗 ${T('دمج فصلين')}</h3>
        <p>${T('مفيد حين يكون الفصل نفسه مسجلاً مرتين، مثل نسخة شخصية ونسخة في المدرسة. تُضم الحصص حسب التاريخ وتُجمع النقاط.')}</p>
        <div class="mg-row"><label>${T('الفصل الحالي')}</label><b>${esc(cur.name)}</b> <small>${esc(where(cur))}</small></div>
        <div class="mg-row"><label>${T('يُدمج مع')}</label><select id="mgOther">${others.map(x => `<option value="${x.i}" ${x.i === other ? 'selected' : ''}>${esc(x.c.name)} — ${esc(where(x.c))}</option>`).join('')}</select></div>
        ${pr.forced ? `<p class="mg-note">🏫 ${T('فصل المدرسة «{t}» يبقى، ويُحذف الفصل الشخصي «{s}» بعد ضمه إليه.', { t: esc(t.name), s: esc(s.name) })}</p>`
          : `<div class="mg-row"><label>${T('الفصل الذي يبقى')}</label><span class="mg-keep"><label><input type="radio" name="mgKeep" value="cur" ${keep !== 'other' ? 'checked' : ''}> ${esc(cur.name)}</label><label><input type="radio" name="mgKeep" value="other" ${keep === 'other' ? 'checked' : ''}> ${esc(list[other].name)}</label></span></div>
             <p class="mg-note">${T('يُحذف الفصل الآخر بعد ضمه.')}</p>`}
        <div class="gdlg-row"><button class="pri" id="mgNext">${T('التالي: مطابقة الأسماء')}</button><button id="mgCancel">${T('إلغاء')}</button></div></div>`;
      $('#mgOther').onchange = (e) => { other = +e.target.value; rows = null; step1(); };
      dlg.querySelectorAll('[name=mgKeep]').forEach(r => r.onchange = () => { keep = r.value; rows = null; step1(); });
      $('#mgNext').onclick = step2; $('#mgCancel').onclick = close;
    }
    function step2() {
      const pr = pair(), t = list[pr.tI], s = list[pr.sI];
      const tN = (t.students || []).filter(Boolean), sN = (s.students || []).filter(Boolean);
      if (!rows) rows = propose(sN, tN);
      const counts = { same: 0, sug: 0, new: 0 }; rows.forEach(r => { counts[r.kind] = (counts[r.kind] || 0) + 1; });
      const opt = (r) => `<option value="+" ${r.to === '+' ? 'selected' : ''}>＋ ${T('إضافة')}</option><option value="-" ${r.to === '-' ? 'selected' : ''}>— ${T('عدم إضافة')}</option>`
        + tN.map(n => `<option value="${esc(n)}" ${r.to === n ? 'selected' : ''}>${esc(n)}</option>`).join('');
      const order = { sug: 0, new: 1, same: 2 };
      const shown = rows.map((r, i) => ({ r, i })).sort((a, b) => order[a.r.kind] - order[b.r.kind] || a.i - b.i);
      dlg.innerHTML = `<div class="gdlg-card mg-card mg-wide">
        <h3>${T('مطابقة الأسماء')}</h3>
        <p>${T('من «{s}» إلى «{t}». الأسماء المتطابقة تُدمج تلقائياً، والمتشابهة مقترحة ويمكن تغييرها.', { s: esc(s.name), t: esc(t.name) })}</p>
        <div class="mg-sum"><span class="k-same">✓ ${T('متطابقة: {n}', { n: counts.same })}</span><span class="k-sug">≈ ${T('مقترحة: {n}', { n: counts.sug })}</span><span class="k-new">＋ ${T('غير موجودة: {n}', { n: counts.new })}</span></div>
        <div class="mg-list">${shown.length ? shown.map(({ r, i }) => `<div class="mg-item k-${r.kind}"><span class="mg-n">${esc(r.n)}</span><span class="mg-ar">←</span><select data-i="${i}">${opt(r)}</select><em>${r.kind === 'same' ? T('متطابق') : r.kind === 'sug' ? T('مقترح') : ''}</em></div>`).join('') : `<p class="mg-note">${T('لا توجد أسماء في الفصل الآخر.')}</p>`}</div>
        <div class="gdlg-row"><button class="pri" id="mgGo">🔗 ${T('دمج')}</button><button id="mgBack">${T('رجوع')}</button><button id="mgCancel">${T('إلغاء')}</button></div></div>`;
      dlg.querySelectorAll('.mg-list select').forEach(sel => sel.onchange = () => { rows[+sel.dataset.i].to = sel.value; });
      $('#mgBack').onclick = step1; $('#mgCancel').onclick = close;
      $('#mgGo').onclick = async (e) => {
        const b = e.target;
        if (!b.dataset.sure) {
          b.dataset.sure = 1;
          b.textContent = T('تأكيد: يُحذف «{s}» بعد ضمه', { s: s.name });
          setTimeout(() => { if (b.isConnected) { delete b.dataset.sure; b.textContent = '🔗 ' + T('دمج'); } }, 4000);
          return;
        }
        b.disabled = true;
        const res = await doMerge(pr.tI, pr.sI, rows);
        close();
        if (res) summary(res.rec, true);
      };
    }
    step1();
  }

  // ---------- التنفيذ ----------
  async function doMerge(tI, sI, rows) {
    if (LP.groupsFlush) await LP.groupsFlush();
    const p = await api.getSettings(), list = p.classes || [], grp = p.grp || {};
    const t = list[tI], s = list[sI]; if (!t || !s) return null;
    const tK = key(t), sK = key(s);
    const map = new Map(), skip = new Set(), addN = [];
    const res = { same: [], linked: [], added: [], skipped: [] };
    for (const r of rows) {
      if (r.to === '-') { skip.add(r.n); res.skipped.push(r.n); }
      else if (r.to === '+' || !r.to) { addN.push(r.n); res.added.push(r.n); }
      else { if (r.to !== r.n) map.set(r.n, r.to); (r.to === r.n || r.kind === 'same' ? res.same : res.linked).push(r.to === r.n ? r.n : [r.n, r.to]); }
    }
    const rec = {
      id: Date.now().toString(36), at: Date.now(), tName: lbl(t, s), sName: lbl(s, t), tKey: tK,
      src: clone(s), srcGrp: clone(grp[sK]), tgtStudents: (t.students || []).slice(), tgtHadGrp: !!grp[tK],
      addedNames: addN.slice(), res
    };
    const m = mergeData(grp[tK], grp[sK] || { sessions: [] }, map, skip);
    rec.sessIds = m.added; res.sessions = m.sessions;
    const names = (t.students || []).slice(); for (const n of addN) if (!names.includes(n)) names.push(n);
    t.students = names;
    grp[tK] = m.cd; if (sK !== tK) delete grp[sK];
    list.splice(sI, 1);
    const undo = [...(p.mergeUndo || []).filter(u => Date.now() - u.at < KEEP), rec];
    await api.setSettings({ classes: list, classIdx: list.indexOf(t), grp, mergeUndo: undo });
    // ننتقل إلى مكان الفصل الباقي (شخصي أو المدرسة) ونفتحه
    if (LP.setCtx && (t.home || '') !== (LP.ctxHome ? LP.ctxHome() : '')) await LP.setCtx(t.home || '');
    const p2 = await api.getSettings(), ti = (p2.classes || []).findIndex(c => key(c) === tK);
    if (ti >= 0 && ti !== p2.classIdx) await api.setSettings({ classIdx: ti });
    if (LP.reloadTools) await LP.reloadTools();
    document.dispatchEvent(new Event('lp-classes'));
    renderUndo();
    return { rec };
  }

  // ---------- بطاقة الملخص ----------
  function summary(rec, fresh) {
    close();
    const r = rec.res, li = (a) => a.map(x => Array.isArray(x) ? `${esc(x[0])} ← ${esc(x[1])}` : esc(x)).join('، ');
    dlg = document.createElement('div'); dlg.className = 'gdlg on mg-dlg';
    dlg.innerHTML = `<div class="gdlg-card mg-card">
      <h3>${fresh ? '✅ ' + T('تم دمج «{s}» في «{t}»', { s: esc(rec.sName), t: esc(rec.tName) }) : '🔗 ' + T('دمج «{s}» في «{t}»', { s: esc(rec.sName), t: esc(rec.tName) })}</h3>
      <ul class="mg-res">
        <li>✓ ${T('{n} متطابقة — دُمجت نقاطها', { n: r.same.length })}</li>
        ${r.linked.length ? `<li>≈ ${T('{n} رُبطت يدوياً أو بالاقتراح', { n: r.linked.length })}: <small>${li(r.linked)}</small></li>` : ''}
        ${r.added.length ? `<li>＋ ${T('{n} أُضيفت', { n: r.added.length })}: <small>${li(r.added)}</small></li>` : ''}
        ${r.skipped.length ? `<li>— ${T('{n} لم تُضف', { n: r.skipped.length })}: <small>${li(r.skipped)}</small></li>` : ''}
        <li>📚 ${T('{n} حصة ضُمّت حسب التاريخ', { n: r.sessions || 0 })}</li>
      </ul>
      <p class="mg-note">${T('يمكن التراجع عن هذا الدمج خلال 7 أيام من «الفصول والأسماء».')}</p>
      <div class="gdlg-row"><button class="pri" id="mgOk">${T('تم')}</button><button id="mgUndo">↶ ${T('تراجع عن الدمج')}</button></div></div>`;
    document.body.appendChild(dlg);
    $('#mgOk').onclick = close;
    $('#mgUndo').onclick = () => askUndo(rec.id);
  }

  // ---------- التراجع (لكل دمج على حدة) ----------
  async function askUndo(id) {
    if (LP.groupsFlush) await LP.groupsFlush();
    const p = await api.getSettings(), rec = (p.mergeUndo || []).find(u => u.id === id);
    if (!rec) { close(); LP.toast(T('انتهت مدة التراجع عن هذا الدمج')); renderUndo(); return; }
    const cd = (p.grp || {})[rec.tKey] || { sessions: [] }, srcIds = new Set(rec.sessIds || []);
    const after = (cd.sessions || []).filter(s => !srcIds.has(s.id) && (s.created || 0) > rec.at).length;
    close();
    dlg = document.createElement('div'); dlg.className = 'gdlg on mg-dlg';
    dlg.innerHTML = `<div class="gdlg-card mg-card">
      <h3>↶ ${T('التراجع عن الدمج')}</h3>
      <p>${T('يعود الفصل «{s}» كما كان قبل الدمج، وتُزال حصصه وأسماؤه المضافة من «{t}».', { s: esc(rec.sName), t: esc(rec.tName) })}</p>
      ${after ? `<p class="mg-note">⚠️ ${T('{n} حصة أُعطيت بعد الدمج ستبقى في «{t}».', { n: after, t: esc(rec.tName) })}</p>` : ''}
      <div class="gdlg-row"><button class="pri" id="mgDoUndo">↶ ${T('تراجع')}</button><button id="mgCancel">${T('إلغاء')}</button></div></div>`;
    document.body.appendChild(dlg);
    $('#mgCancel').onclick = close;
    $('#mgDoUndo').onclick = async () => { close(); const ok = await undo(id); if (ok) LP.toast(T('تم التراجع عن الدمج ✓ — عاد الفصل «{s}»', { s: ok.sName }), null, null, 5000); };
  }
  async function undo(id) {
    if (LP.groupsFlush) await LP.groupsFlush();
    const p = await api.getSettings(), list = p.classes || [], grp = p.grp || {};
    const rec = (p.mergeUndo || []).find(u => u.id === id); if (!rec) return null;
    // الفصل الباقي: نزيل ما جاء من الفصل المحذوف، ونُبقي كل ما حدث بعد الدمج
    const t = list.find(c => key(c) === rec.tKey);
    if (t) {
      const used = new Set();
      const cd = grp[rec.tKey];
      const ids = new Set(rec.sessIds || []);
      if (cd) {
        cd.sessions = (cd.sessions || []).filter(s => !ids.has(s.id));
        cd.archive = (cd.archive || []).filter(s => !ids.has(s.id));
        cd.log = (cd.log || []).filter(e => !ids.has(e.sid));
        if (cd.thanksLog) cd.thanksLog = cd.thanksLog.filter(e => !ids.has(e.sid));
        if (cd.cur && ids.has(cd.cur)) cd.cur = null;
        for (const s of cd.sessions) for (const g of s.groups || []) g.forEach(n => used.add(n));
        if (!rec.tgtHadGrp && !cd.sessions.length && !cd.archive.length) delete grp[rec.tKey];
      }
      // الأسماء المضافة بالدمج تُزال، إلا من ظهرت في حصة بعد الدمج
      const addedSet = new Set(rec.addedNames || []);
      t.students = (t.students || []).filter(n => !addedSet.has(n) || used.has(n) || rec.tgtStudents.includes(n));
    }
    // الفصل المحذوف يعود (باسم غير مكرر)
    const s = clone(rec.src), base = s.name; let n = 2;
    while (list.some(c => (c.home || '') === (s.home || '') && c.name === s.name)) s.name = `${base} (${n++})`;
    // فصل فارغ «فصلي» أُنشئ تلقائياً بعد الدمج في المكان نفسه: لم يعد له داعٍ
    for (let j = list.length - 1; j >= 0; j--) { const c = list[j]; if ((c.home || '') === (s.home || '') && c.name === T('فصلي') && !(c.students || []).length && !grp[key(c)]) list.splice(j, 1); }
    list.push(s);
    if (rec.srcGrp) grp[key(s)] = rec.srcGrp;
    await api.setSettings({ classes: list, grp, mergeUndo: (p.mergeUndo || []).filter(u => u.id !== id) });
    if (LP.reloadTools) await LP.reloadTools();
    document.dispatchEvent(new Event('lp-classes'));
    renderUndo();
    return rec;
  }

  // سطر لكل دمج يمكن التراجع عنه (7 أيام)
  async function renderUndo() {
    if (!undoBox) return;
    const p = await api.getSettings().catch(() => ({}));
    const all = p.mergeUndo || [], live = all.filter(u => Date.now() - u.at < KEEP);
    if (live.length !== all.length) await api.setSettings({ mergeUndo: live });
    const ago = (t) => { const d = Math.floor((Date.now() - t) / 864e5); return d <= 0 ? T('اليوم') : d === 1 ? T('أمس') : T('منذ {n} أيام', { n: d }); };
    undoBox.innerHTML = live.length ? `<p class="tlbl">↶ ${T('التراجع عن دمج')}</p>` + live.slice().reverse().map(u =>
      `<div class="trow mg-u"><span>«${esc(u.sName)}» ← «${esc(u.tName)}» <small>(${ago(u.at)})</small></span><button class="tb" data-sum="${u.id}">${T('الملخص')}</button><button class="tb" data-undo="${u.id}">↶ ${T('تراجع')}</button></div>`).join('') : '';
    undoBox.querySelectorAll('[data-undo]').forEach(b => b.onclick = () => askUndo(b.dataset.undo));
    undoBox.querySelectorAll('[data-sum]').forEach(b => b.onclick = () => { const u = live.find(x => x.id === b.dataset.sum); if (u) summary(u, false); });
  }

  btn.onclick = open;
  document.addEventListener('lp-tools', renderUndo);
  document.addEventListener('lp-auth', renderUndo);
  document.addEventListener('keydown', (e) => { if (dlg && e.key === 'Escape') { e.stopPropagation(); close(); } }, true);
  LP.mergeClasses = { propose, mergeData, open, undo };
})();
