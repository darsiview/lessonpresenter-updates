// حسابات المعلمات: الرمز السري، المديرة، الضيفة، الاسترجاع بالبريد، وتسجيل الخروج من الحسابات
const { session } = require('electron');
const crypto = require('crypto');
const store = require('./store');
const mailer = require('./mailer');
const I = require('./i18n');

let current = null;                 // معرّف المستخدمة الحالية، أو 'guest'، أو null
let guestPart = 'guest_' + crypto.randomBytes(4).toString('hex');
const fails = new Map();            // محاولات خاطئة: id → { n, until }
const MAX_FAILS = 5, LOCK_MS = 60 * 1000;

const hash = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString('hex');
const newId = () => crypto.randomBytes(6).toString('hex');
const validPin = (p) => /^\d{4,12}$/.test(String(p || ''));
const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || '').trim());
const pub = (u) => u && ({ id: u.id, name: u.name, email: u.email, admin: !!u.admin, cloud: !!u.cloudUid, cloudPw: !!u.cloudPw, qrOnly: !!(u.cloudUid && !u.salt) });

function partitionOf(id) {
  if (id === 'guest') return guestPart;
  return 'persist:u_' + id;
}
async function clearSessionOf(id) {
  try {
    const ses = session.fromPartition(partitionOf(id));
    await ses.clearStorageData();
    await ses.clearCache();
    await ses.clearAuthCache();
  } catch {}
}

function checkLock(id) {
  const f = fails.get(id);
  if (f && f.until > Date.now()) return Math.ceil((f.until - Date.now()) / 1000);
  return 0;
}
function failed(id) {
  const f = fails.get(id) || { n: 0, until: 0 };
  f.n += 1;
  if (f.n >= MAX_FAILS) { f.until = Date.now() + LOCK_MS; f.n = 0; }
  fails.set(id, f);
}
function verify(u, pin) {
  const wait = checkLock(u.id);
  if (wait) return { ok: false, wait };
  if (hash(pin, u.salt) === u.hash) { fails.delete(u.id); return { ok: true }; }
  failed(u.id);
  const w = checkLock(u.id);
  return w ? { ok: false, wait: w } : { ok: false };
}
function setPin(u, pin) {
  u.salt = crypto.randomBytes(16).toString('hex');
  u.hash = hash(pin, u.salt);
}

// ---------- الحالة ----------
function state() {
  const g = store.global.get();
  const u = current && current !== 'guest' ? store.users.get(current) : null;
  const prof = current ? store.profiles.get(current) : {};
  return {
    setup: store.users.all().length === 0,
    user: current === 'guest' ? { id: 'guest', name: I.t('ضيفة'), guest: true } : pub(u),
    users: store.users.all().map(x => ({ id: x.id, name: x.name, admin: !!x.admin, cloud: !!x.cloudUid, cloudPw: !!x.cloudPw, qrOnly: !!(x.cloudUid && !x.salt) })),
    lang: prof.lang || g.lang || installLang() || 'ar',
    idleMin: g.idleMin || 10,
    partition: current ? partitionOf(current) : null,
    personal: u ? store.device.isPersonal(u.id) : false,
    mailReady: !!(g.mailer && g.mailer.user && g.mailer.pass)
  };
}

// ---------- الإنشاء والدخول ----------
function create({ name, email, pin }, admin) {
  name = String(name || '').trim();
  email = String(email || '').trim();
  if (!name) return { ok: false, err: 'name' };
  if (!validEmail(email)) return { ok: false, err: 'email' };
  if (!validPin(pin)) return { ok: false, err: 'pin' };
  if (store.users.byEmail(email)) return { ok: false, err: 'exists' };
  const u = { id: newId(), name, email, admin: !!admin, created: Date.now() };
  setPin(u, pin);
  store.users.add(u);
  current = u.id;
  return { ok: true };
}
function login(id, pin) {
  const u = store.users.get(id);
  if (!u) return { ok: false };
  if (!u.salt) return { ok: false, nohash: true, email: u.email };   // دخلت بالباركود فقط على هذا الجهاز
  const r = verify(u, pin);
  if (r.ok) { current = u.id; lastFresh = openData(u, pin).fresh; }
  return r;
}
function unlock(pin) {
  if (!current || current === 'guest') return { ok: true };
  const u = store.users.get(current);
  if (u && !u.salt) return { ok: false };
  return u ? verify(u, pin) : { ok: false };
}
async function logout(wipe) {
  if (current && current !== 'guest') {
    const u = store.users.get(current);
    if (wipe && u && u.cloudUid) { await clearSessionOf(current); store.device.setPersonal(current, false); store.users.remove(current); current = null; }
    else store.profiles.dropKey(current);
  }
  if (current) {
    const u = current !== 'guest' ? store.users.get(current) : null;
    if (!u || !store.device.isPersonal(u.id)) await clearSessionOf(current);
  }
  current = null;
  guestPart = 'guest_' + crypto.randomBytes(4).toString('hex');
}
// عند إغلاق البرنامج: الخروج من حسابات كل من ليس على «جهازها الشخصي»
async function cleanupOnQuit() {
  let ch = false;
  for (const u of store.users.all()) if (!store.device.isPersonal(u.id)) { await clearSessionOf(u.id); if (u.cloudTok) { delete u.cloudTok; ch = true; } }
  if (ch) store.users.save();
  await clearSessionOf('guest');
}

// ---------- إعدادات المعلمة لنفسها ----------
function changePin(oldPin, newPin) {
  const u = store.users.get(current);
  if (!u) return { ok: false };
  if (u.cloudPw) return { ok: false, err: 'cloudpw' };
  const r = verify(u, oldPin);
  if (!r.ok) return r;
  if (!validPin(newPin)) return { ok: false, err: 'pin' };
  setPin(u, newPin);
  const dek = store.profiles.keyOf(u.id); if (u.dek && dek) wrapDek(u, newPin, dek);
  store.users.save();
  return { ok: true };
}
function updateMe({ name, email }) {
  const u = store.users.get(current);
  if (!u) return { ok: false };
  if (name !== undefined) { name = String(name).trim(); if (!name) return { ok: false, err: 'name' }; u.name = name; }
  if (email !== undefined) {
    email = String(email).trim();
    if (!validEmail(email)) return { ok: false, err: 'email' };
    const other = store.users.byEmail(email);
    if (other && other.id !== u.id) return { ok: false, err: 'exists' };
    u.email = email;
  }
  store.users.save();
  return { ok: true };
}
function setPersonal(on) { if (current && current !== 'guest') store.device.setPersonal(current, !!on); }
const signOutAccounts = () => current ? clearSessionOf(current) : null;


// ---------- تشفير بيانات الحساب السحابي على الجهاز ----------
// مفتاح عشوائي للبيانات، محفوظ مقفلاً بكلمة المرور (أو رمز الجهاز لحساب Google)
const kek = (secret, salt) => crypto.scryptSync(String(secret), Buffer.from(salt, 'hex'), 32);
function wrapDek(u, secret, dek, field = 'dek') {
  const salt = crypto.randomBytes(16).toString('hex'), iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', kek(secret, salt), iv);
  const d = Buffer.concat([c.update(dek), c.final()]);
  u[field] = { s: salt, iv: iv.toString('hex'), tag: c.getAuthTag().toString('hex'), d: d.toString('hex') };
}
function unwrapDek(u, secret, field = 'dek') {
  const w = u[field];
  if (!w || secret === undefined || secret === null) return null;
  try {
    const c = crypto.createDecipheriv('aes-256-gcm', kek(secret, w.s), Buffer.from(w.iv, 'hex'));
    c.setAuthTag(Buffer.from(w.tag, 'hex'));
    return Buffer.concat([c.update(Buffer.from(w.d, 'hex')), c.final()]);
  } catch { return null; }
}
// يفتح بيانات المعلمة بكلمة المرور، أو بمفتاح الجوال (lk) عند الدخول بالباركود.
// إن تعذّر الفتح (تغيّرت كلمة المرور من جهاز آخر) تُستبدل نسخة الجهاز وتُنزَّل من السحابة
function openData(u, secret, lk) {
  if (!u.cloudUid) return { fresh: false };
  let dek = unwrapDek(u, secret) || unwrapDek(u, lk, 'dekQ'), fresh = false;
  if (!dek) {
    if (u.dek || u.dekQ || store.profiles.isEncrypted(u.id)) { store.profiles.wipe(u.id); fresh = true; }
    dek = crypto.randomBytes(32);
  }
  if (secret !== undefined && secret !== null) wrapDek(u, secret, dek);
  if (lk) wrapDek(u, lk, dek, 'dekQ');
  store.users.save();
  if (!store.profiles.setKey(u.id, dek)) { store.profiles.wipe(u.id); store.profiles.setKey(u.id, dek); fresh = true; }
  return { fresh };
}
// بعد معرفة مفتاح الجوال (lk) لأول مرة: نقفل نفس مفتاح البيانات به أيضاً، ليعمل الدخول بالباركود لاحقاً
function addQrWrap(lk) {
  const u = store.users.get(current), dek = u && store.profiles.keyOf(u.id);
  if (!u || !lk || !dek) return;
  const cur = unwrapDek(u, lk, 'dekQ');
  if (cur && cur.equals(dek)) return;
  wrapDek(u, lk, dek, 'dekQ'); store.users.save();
}
// الدخول بالباركود: المعلمة وافقت من جوالها
function qrAttach({ uid, email, name, lk, linkPin }) {
  if (!uid) return { ok: false, err: 'cfail' };
  email = String(email || '').trim();
  let u = store.users.all().find(x => x.cloudUid === uid);
  if (!u) {
    const old = store.users.byEmail(email);
    if (old && !old.cloudUid) {
      if (linkPin === undefined || linkPin === null) return { ok: false, need: 'link', user: pub(old) };
      const r = verify(old, linkPin); if (!r.ok) return r;
      u = old; u.cloudUid = uid;
    } else if (old && old.cloudUid !== uid) return { ok: false, err: 'ctaken' };
    else { u = { id: newId(), name: String(name || '').trim() || email.split('@')[0], email, admin: store.users.all().length === 0, created: Date.now(), cloudUid: uid }; store.users.add(u); }
  }
  store.users.save();
  current = u.id; fails.delete(u.id);
  return { ok: true, id: u.id, fresh: openData(u, linkPin, lk).fresh };
}
let lastFresh = false;

// ---------- الربط بالحساب السحابي ----------
// كلمة مرور الحساب السحابي تصبح أيضاً رمز الدخول على هذا الجهاز (تعمل دون إنترنت)
function setCloudPw(u, password) { setPin(u, password); u.cloudPw = true; }
// بعد نجاح الدخول السحابي: نجد حساب الجهاز المرتبط، أو نربط حساباً قديماً بنفس البريد، أو ننشئ حساباً جديداً
function cloudAttach({ uid, email, name, password, linkPin, pin, lk }) {
  if (!uid) return { ok: false, err: 'cfail' };
  email = String(email || '').trim();
  let u = store.users.all().find(x => x.cloudUid === uid);
  if (!u) {
    const old = store.users.byEmail(email);
    if (old && !old.cloudUid) {
      if (linkPin === undefined || linkPin === null) return { ok: false, need: 'link', user: pub(old) };
      const r = verify(old, linkPin);
      if (!r.ok) return r;
      u = old; u.cloudUid = uid;
    } else if (old && old.cloudUid && old.cloudUid !== uid) {
      return { ok: false, err: 'ctaken' };
    } else {
      if (!password && !validPin(pin)) return { ok: false, need: 'pin' };
      u = { id: newId(), name: String(name || '').trim() || email.split('@')[0], email, admin: store.users.all().length === 0, created: Date.now(), cloudUid: uid };
      store.users.add(u);
    }
  }
  let secret = password;
  if (password) setCloudPw(u, password);
  else if (pin && validPin(pin)) { setPin(u, pin); secret = pin; }
  else if (u.dek) {                                   // Google على جهاز سبق الدخول فيه: رمز الجهاز يفتح البيانات
    if (linkPin === undefined || linkPin === null) return { ok: false, need: 'devpin', user: pub(u) };
    const r = verify(u, linkPin); if (!r.ok) return r;
    secret = linkPin;
  } else if (linkPin !== undefined && linkPin !== null) secret = linkPin;
  if (!u.salt) return { ok: false, need: 'pin' };
  if (secret === undefined || secret === null) return { ok: false, need: 'pin' };
  if (email && u.email !== email && !store.users.byEmail(email)) u.email = email;
  store.users.save();
  current = u.id; fails.delete(u.id);
  const fresh = openData(u, secret, lk).fresh;
  return { ok: true, id: u.id, fresh };
}
// ربط حساب الجهاز الحالي (الذي أُنشئ دون إنترنت) بحساب سحابي
function linkCurrent(uid, email, password) {
  const u = store.users.get(current);
  if (!u) return { ok: false };
  const other = store.users.all().find(x => x.cloudUid === uid && x.id !== u.id);
  if (other) return { ok: false, err: 'ctaken' };
  u.cloudUid = uid; if (email) u.email = String(email).trim();
  if (password) {
    setCloudPw(u, password);
    const dek = store.profiles.keyOf(u.id);
    if (dek) wrapDek(u, password, dek);          // تغيّرت كلمة المرور أو أُضيفت: نقفل نفس المفتاح
    else { store.users.save(); openData(u, password); }
  }
  store.users.save();
  return { ok: true };
}
function cloudToken(id, sealed) {
  const u = store.users.get(id || current); if (!u) return null;
  if (sealed === undefined) return u.cloudTok || null;
  if (sealed) u.cloudTok = sealed; else delete u.cloudTok;
  store.users.save(); return true;
}

// ---------- المديرة ----------
const isAdmin = () => { const u = current && store.users.get(current); return !!(u && u.admin); };
function adminUsers() {
  if (!isAdmin()) return [];
  return store.users.all().map(u => ({ ...pub(u), created: u.created, me: u.id === current }));
}
async function adminResetPin(id, pin) {
  if (!isAdmin()) return { ok: false };
  const u = store.users.get(id);
  // الحساب السحابي: لا تستطيع المديرة تغيير كلمة مروره (تسترجعها المعلمة بنفسها من بريدها)
  if (u && u.cloudUid) return { ok: false, err: 'cloudreset' };
  if (!u || !validPin(pin)) return { ok: false, err: 'pin' };
  setPin(u, pin); fails.delete(id); store.users.save();
  // لحماية خصوصية المعلمة: تخرج من حساباتها في مايكروسوفت وGoogle
  if (id !== current) { await clearSessionOf(id); store.device.setPersonal(id, false); }
  return { ok: true };
}
async function adminDelete(id) {
  if (!isAdmin() || id === current) return { ok: false };
  await clearSessionOf(id);
  store.device.setPersonal(id, false);
  store.users.remove(id);
  return { ok: true };
}
function adminSetAdmin(id, on) {
  if (!isAdmin() || id === current) return { ok: false };
  const u = store.users.get(id); if (!u) return { ok: false };
  u.admin = !!on; store.users.save(); return { ok: true };
}
function adminSetIdle(min) { if (isAdmin()) store.global.patch({ idleMin: Math.max(1, Math.min(120, +min || 10)) }); }
function adminSetMailer(user, pass) {
  if (!isAdmin()) return { ok: false };
  if (!validEmail(user)) return { ok: false, err: 'email' };
  const m = { user: String(user).trim(), pass: pass ? obf(String(pass).replace(/\s+/g, '')) : (store.global.get().mailer || {}).pass };
  store.global.patch({ mailer: m });
  return { ok: true };
}
function adminMailerInfo() {
  if (!isAdmin()) return null;
  const m = store.global.get().mailer || {};
  return { user: m.user || '', hasPass: !!m.pass };
}

// تشويش بسيط لكلمة مرور التطبيق المحفوظة (ليست تشفيراً قوياً؛ لذلك نوصي ببريد خاص بالبرنامج)
const OBF = Buffer.from('lesson-presenter-mailer-key-2026');
const obf = (s) => Buffer.from([...Buffer.from(s, 'utf8')].map((b, i) => b ^ OBF[i % OBF.length])).toString('base64');
const deobf = (s) => Buffer.from([...Buffer.from(s, 'base64')].map((b, i) => b ^ OBF[i % OBF.length])).toString('utf8');

async function sendMail(to, subject, text, html) {
  const m = store.global.get().mailer;
  if (!m || !m.user || !m.pass) return { ok: false, err: 'nomailer' };
  try {
    await mailer.send({ user: m.user, pass: deobf(m.pass), to, subject, text, html, fromName: I.t('عارض الدروس') });
    return { ok: true };
  } catch (e) { return { ok: false, err: 'send', detail: String(e.message || e) }; }
}
async function adminTestMail() {
  const u = store.users.get(current);
  if (!isAdmin() || !u) return { ok: false };
  return sendMail(u.email, I.t('رسالة تجربة من عارض الدروس'),
    I.t('إعداد البريد يعمل بنجاح ✓'), `<div dir="${I.dir()}" style="font-family:Tahoma,Arial">${I.t('إعداد البريد يعمل بنجاح ✓')}</div>`);
}

// ---------- الاسترجاع بالبريد ----------
async function forgot(email) {
  const u = store.users.byEmail(email);
  // لا نكشف هل البريد مسجّل أم لا
  if (!u) return { ok: true };
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  const token = crypto.randomBytes(20).toString('hex');
  u.reset = { code: hash(code, u.id), token: hash(token, u.id), exp: Date.now() + 10 * 60 * 1000, tries: 0 };
  store.users.save();
  const link = `lessonpresenter://reset/?u=${u.id}&t=${token}`;
  const dir = I.dir();
  const text = `${I.t('استرجاع الرمز السري')}\n\n${I.t('رمز الاسترجاع:')} ${code}\n${I.t('صالح لمدة 10 دقائق.')}\n\n${link}\n\n${I.t('إذا لم تطلبي هذا، تجاهلي الرسالة.')}`;
  const html = `<div dir="${dir}" style="font-family:Tahoma,Arial;font-size:15px;color:#222;line-height:1.8">
    <h2 style="color:#f2662a;margin:0 0 10px">${I.t('استرجاع الرمز السري')}</h2>
    <p>${I.t('مرحباً {name}،', { name: u.name.replace(/</g, '&lt;') })}</p>
    <p>${I.t('رمز الاسترجاع:')}</p>
    <div style="font-size:34px;font-weight:bold;letter-spacing:8px;direction:ltr;text-align:center;background:#fff3ec;border-radius:12px;padding:14px">${code}</div>
    <p style="text-align:center;margin:18px 0"><a href="${link}" style="background:#f2662a;color:#fff;text-decoration:none;padding:10px 22px;border-radius:10px;font-weight:bold">${I.t('إعادة تعيين الرمز السري')}</a></p>
    <p style="color:#888;font-size:13px">${I.t('صالح لمدة 10 دقائق.')} ${I.t('إذا لم تطلبي هذا، تجاهلي الرسالة.')}</p></div>`;
  const r = await sendMail(u.email, I.t('استرجاع الرمز السري'), text, html);
  return r.ok ? { ok: true } : r;
}
function resetWith({ email, uid, code, token, pin }) {
  const u = uid ? store.users.get(uid) : store.users.byEmail(email);
  if (!u || !u.reset) return { ok: false, err: 'invalid' };
  if (Date.now() > u.reset.exp || u.reset.tries >= 5) { delete u.reset; store.users.save(); return { ok: false, err: 'expired' }; }
  const good = (code && hash(String(code).replace(/\s/g, ''), u.id) === u.reset.code) || (token && hash(token, u.id) === u.reset.token);
  if (!good) { u.reset.tries++; store.users.save(); return { ok: false, err: 'invalid' }; }
  if (!validPin(pin)) return { ok: false, err: 'pin' };
  setPin(u, pin); delete u.reset; fails.delete(u.id); store.users.save();
  current = u.id;
  return { ok: true };
}
function checkResetToken(uid, token) {
  const u = store.users.get(uid);
  return !!(u && u.reset && Date.now() <= u.reset.exp && hash(token, u.id) === u.reset.token);
}

// اللغة التي اختيرت في ملف التنصيب (install-lang.txt بجانب البرنامج)
function installLang() { try { const v = require('fs').readFileSync(require('path').join(require('./store').baseDir(), 'install-lang.txt'), 'utf8').trim(); return ['ar', 'en', 'fr'].includes(v) ? v : ''; } catch { return ''; } }
module.exports = {
  state, create, login, unlock, logout, cleanupOnQuit, guest: () => { current = 'guest'; },
  current: () => current, currentUser: () => (current && current !== 'guest' ? store.users.get(current) : null),
  isAdmin, partitionOf, changePin, updateMe, setPersonal, signOutAccounts,
  adminUsers, adminResetPin, adminDelete, adminSetAdmin, adminSetIdle, adminSetMailer, adminMailerInfo, adminTestMail,
  forgot, resetWith, checkResetToken, cloudAttach, linkCurrent, cloudToken, qrAttach, addQrWrap, takeFresh: () => { const f = lastFresh; lastFresh = false; return f; }, verifyCurrent: (pin) => { const u = store.users.get(current); return u ? verify(u, pin) : { ok: false }; }
};
