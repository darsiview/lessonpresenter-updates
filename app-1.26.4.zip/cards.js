// سحب موحّد للبطاقات العائمة (العجلة، المؤقّت، الأهداف) مع التصاق مغناطيسي
(() => {
  const $ = (s) => document.querySelector(s);
  const api = window.api;
  const stage = $('#stage');
  // ================= سحب موحّد + التصاق =================
  // el: البطاقة، handle: مقبض السحب، key: مفتاح حفظ الموضع في الإعدادات
  const SNAP = 14;
  LP.floatDrag = function (el, handle, key, onMove, onEnd) {
    let d = null;
    const others = () => [...stage.querySelectorAll('.fcard.on, #mw.on, .timerW.on')].filter(x => x !== el);
    handle.addEventListener('pointerdown', e => {
      if (e.target.closest('button,input,textarea,select,[contenteditable="true"]') || document.body.classList.contains('mini') || el.closest('#dock')) return;
      d = { x: e.clientX - el.offsetLeft, y: e.clientY - el.offsetTop }; handle.setPointerCapture(e.pointerId);
      el.classList.add('dragging');
    });
    handle.addEventListener('pointermove', e => {
      if (!d) return;
      const W = stage.clientWidth, H = stage.clientHeight, w = el.offsetWidth, h = el.offsetHeight;
      let x = e.clientX - d.x, y = e.clientY - d.y;
      // التصاق بحواف المسرح
      const xs = [[4, 0], [W - w - 4, 0]], ys = [[4, 0], [H - h - 4, 0]];
      // التصاق بالبطاقات الأخرى (جنباً إلى جنب أو فوق بعض) ومحاذاة حوافها
      for (const o of others()) {
        const L = o.offsetLeft, Tp = o.offsetTop, R = L + o.offsetWidth, B = Tp + o.offsetHeight, G = 6;
        xs.push([R + G], [L - w - G], [L], [R - w]);
        ys.push([B + G], [Tp - h - G], [Tp], [B - h]);
      }
      let bx = null, by = null;
      for (const [v] of xs) if (Math.abs(x - v) < SNAP && (bx === null || Math.abs(x - v) < Math.abs(x - bx))) bx = v;
      for (const [v] of ys) if (Math.abs(y - v) < SNAP && (by === null || Math.abs(y - v) < Math.abs(y - by))) by = v;
      if (bx !== null) x = bx; if (by !== null) y = by;
      x = Math.max(4, Math.min(W - w - 4, x)); y = Math.max(4, Math.min(H - h - 4, y));
      el.style.left = x + 'px'; el.style.top = y + 'px';
      el.classList.toggle('snapped', bx !== null || by !== null);
      if (onMove) onMove(x, y);
    });
    const up = () => {
      if (!d) return; d = null; el.classList.remove('dragging', 'snapped');
      const W = stage.clientWidth - el.offsetWidth, H = stage.clientHeight - el.offsetHeight;
      const pos = { x: W > 0 ? el.offsetLeft / W : 0, y: H > 0 ? el.offsetTop / H : 0 };
      if (key) api.setSettings({ [key]: pos });
      el._pos = pos;
      if (onEnd) onEnd(pos);
    };
    handle.addEventListener('pointerup', up); handle.addEventListener('pointercancel', up);
  };
  LP.floatPlace = function (el, pos, def) {
    if (el.closest('#dock')) { el._pos = pos || def; return; }       // داخل العمود الجانبي: مكانه ثابت
    const W = stage.clientWidth, H = stage.clientHeight, w = el.offsetWidth, h = el.offsetHeight;
    const p = pos || def || { x: 0, y: 0 };
    el._pos = p;
    el.style.left = Math.max(4, Math.min(W - w - 4, p.x * (W - w))) + 'px';
    el.style.top = Math.max(4, Math.min(H - h - 4, p.y * (H - h))) + 'px';
  };


  // ================= التاريخ: ميلادي / هجري / الاثنان =================
  LP.dateMode = 'g';
  const loc = (cal) => ({ ar: 'ar-SA', en: 'en-GB', fr: 'fr-FR' }[I18N.lang] || 'ar-SA') + '-u-ca-' + cal + (I18N.lang === 'ar' ? '-nu-arab' : '');
  const f = (ts, cal, o) => { try { return new Date(ts).toLocaleDateString(loc(cal), o); } catch { return new Date(ts).toLocaleDateString(); } };
  LP.fmtDay = (ts, mode) => {
    mode = mode || LP.dateMode || 'g';
    const day = f(ts, 'gregory', { weekday: 'long' });
    const g = f(ts, 'gregory', { day: 'numeric', month: 'long', year: 'numeric' });
    const h = f(ts, 'islamic-umalqura', { day: 'numeric', month: 'long', year: 'numeric' });
    return mode === 'h' ? `${day}، ${h}` : mode === 'both' ? `${day}، ${g} · ${h}` : `${day}، ${g}`;
  };
  LP.toggleDateMode = () => {
    LP.dateMode = { g: 'h', h: 'both', both: 'g' }[LP.dateMode] || 'g';
    api.setSettings({ dateMode: LP.dateMode });
    document.dispatchEvent(new Event('lp-date'));
  };
  document.addEventListener('lp-auth', async (e) => { if (e.detail && e.detail.user) { const p = await api.getSettings(); LP.dateMode = p.dateMode || 'g'; document.dispatchEvent(new Event('lp-date')); } });
})();
