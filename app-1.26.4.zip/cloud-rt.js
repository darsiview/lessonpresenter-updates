// الاستماع الفوري (Firebase SDK الرسمية): يُبلَّغ البرنامج فوراً عند تعديل من جهاز آخر أو طلب إخراج من الجوال.
// طبقة إضافية فقط: إن تعذّرت لأي سبب تبقى المزامنة العادية (كل دقيقتين) تعمل كما هي.
(() => {
  const api = window.api;
  const KEYDB = 'firebaseLocalStorageDb';
  let loaded = null, cur = null, unsubs = [];

  function loadSdk() {
    if (loaded) return loaded;
    const one = (src) => new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('load ' + src)); document.head.appendChild(s); });
    loaded = one('vendor/firebase-app-compat.js').then(() => Promise.all([one('vendor/firebase-auth-compat.js'), one('vendor/firebase-firestore-compat.js')]));
    return loaded;
  }
  // يمسح أي جلسة محفوظة للأداة (لا تبقى على الأجهزة المشتركة)
  function purge() {
    try { Object.keys(localStorage).filter(k => k.startsWith('firebase:')).forEach(k => localStorage.removeItem(k)); } catch {}
    try { indexedDB.deleteDatabase(KEYDB); } catch {}
  }
  async function stop() {
    unsubs.forEach(u => { try { u(); } catch {} }); unsubs = [];
    if (cur && window.firebase && firebase.apps.length) { try { await firebase.auth().signOut(); } catch {} }
    cur = null; purge();
  }
  // نبدأ جلسة الأداة من جلسة البرنامج نفسها (نفس رمز التجديد)، دون طلب كلمة المرور مرة أخرى
  async function start(s) {
    if (cur && cur.uid === s.uid) return;
    await stop();
    cur = s;
    try {
      purge();
      const now = Date.now();
      localStorage.setItem(`firebase:authUser:${s.apiKey}:[DEFAULT]`, JSON.stringify({
        uid: s.uid, email: s.email || undefined, emailVerified: !!s.verified, isAnonymous: false, providerData: [],
        stsTokenManager: { refreshToken: s.refreshToken, accessToken: s.idToken, expirationTime: s.exp || now + 30 * 60000 },
        createdAt: String(now), lastLoginAt: String(now), apiKey: s.apiKey, appName: '[DEFAULT]'
      }));
      await loadSdk();
      if (cur !== s) return;
      if (!firebase.apps.length) firebase.initializeApp({ apiKey: s.apiKey, authDomain: s.authDomain, projectId: s.projectId, appId: s.appId });
      const auth = firebase.auth();
      const u = await new Promise((res) => { const off = auth.onAuthStateChanged(x => { off(); res(x); }); setTimeout(() => res(auth.currentUser), 8000); });
      if (!u || u.uid !== s.uid || cur !== s) { api.rtEvent({ type: 'state', ok: false, why: 'auth' }); return; }
      const db = firebase.firestore();
      try { db.settings({ experimentalAutoDetectLongPolling: true, merge: true }); } catch {}
      const err = (e) => api.rtEvent({ type: 'state', ok: false, why: String(e && (e.code || e.message) || e) });
      let live = false;
      unsubs.push(db.doc(`users/${s.uid}`).onSnapshot({ includeMetadataChanges: true }, d => {
        // نعدّ الاستماع «فعّالاً» فقط بعد أول رد حقيقي من الخادم (لا من الذاكرة المؤقتة)
        if (!live && !d.metadata.fromCache) { live = true; api.rtEvent({ type: 'state', ok: true }); }
        const ts = (d.data() || {}).ts || {};
        api.rtEvent({ type: 'meta', ts, local: d.metadata.hasPendingWrites });
      }, err));
      unsubs.push(db.doc(`users/${s.uid}/devices/${s.devId}`).onSnapshot(d => {
        const v = (d.data() || {}).revoke;
        if (v) api.rtEvent({ type: 'revoke', how: v });
      }, err));
    } catch (e) { api.rtEvent({ type: 'state', ok: false, why: String(e && e.message || e) }); }
  }
  api.onRt((m) => { if (m && m.start) start(m.start); else stop(); });
  // عند فتح البرنامج على شاشة الدخول: لا جلسة للأداة
  document.addEventListener('lp-auth', (e) => { if (!e.detail || !e.detail.user || !e.detail.user.cloud) stop(); else api.rtReady(); });
})();
