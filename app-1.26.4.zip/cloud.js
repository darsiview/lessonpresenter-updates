// الحساب السحابي (Firebase) عبر واجهات REST الرسمية: الدخول، الإنشاء، الاسترجاع، Google، وملف المعلمة في Firestore
// لا يحفظ كلمات المرور أبداً. «رمز التجديد» يُحفظ مشفّراً بتشفير ويندوز فقط على «جهازي الشخصي».
const { safeStorage, shell } = require('electron');
const http = require('http');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

let CFG = {};
try { CFG = JSON.parse(fs.readFileSync(path.join(__dirname, 'cloud-config.json'), 'utf8')); } catch {}
// يمكن توجيهها إلى خادم تجريبي أثناء الاختبار
const AUTH = process.env.LP_FB_AUTH || 'https://identitytoolkit.googleapis.com/v1';
const TOKEN = process.env.LP_FB_TOKEN || 'https://securetoken.googleapis.com/v1';
const FS = process.env.LP_FB_FS || 'https://firestore.googleapis.com/v1';
const GOAUTH = process.env.LP_G_OAUTH || 'https://accounts.google.com/o/oauth2/v2/auth';
const GTOKEN = process.env.LP_G_TOKEN || 'https://oauth2.googleapis.com/token';

const configured = () => !!(CFG.apiKey && CFG.projectId);
const googleReady = () => !!(configured() && CFG.googleClientId);

// ---------- الطلبات ----------
const ERRMAP = {
  EMAIL_EXISTS: 'cexists', INVALID_LOGIN_CREDENTIALS: 'cwrong', INVALID_PASSWORD: 'cwrong', EMAIL_NOT_FOUND: 'cwrong',
  USER_DISABLED: 'cdisabled', TOO_MANY_ATTEMPTS_TRY_LATER: 'cmany', WEAK_PASSWORD: 'cweak', INVALID_EMAIL: 'email',
  MISSING_PASSWORD: 'cweak', OPERATION_NOT_ALLOWED: 'coff', TOKEN_EXPIRED: 'cexpired', INVALID_REFRESH_TOKEN: 'cexpired',
  USER_NOT_FOUND: 'cexpired', INVALID_ID_TOKEN: 'cexpired', CREDENTIAL_TOO_OLD_LOGIN_AGAIN: 'cexpired'
};
class CloudErr extends Error { constructor(code, detail) { super(code); this.code = code; this.detail = detail; } }
async function post(url, body, form) {
  let res;
  try {
    res = await fetch(url, {
      method: 'POST', signal: AbortSignal.timeout(15000),
      headers: { 'Content-Type': form ? 'application/x-www-form-urlencoded' : 'application/json' },
      body: form ? new URLSearchParams(body).toString() : JSON.stringify(body)
    });
  } catch (e) { throw new CloudErr('net', String(e.message || e)); }
  let j = {}; try { j = await res.json(); } catch {}
  if (!res.ok) {
    const m = String((j.error && (j.error.message || j.error)) || res.status);
    const key = m.split(/[ :]/)[0];
    throw new CloudErr(ERRMAP[key] || 'cfail', m);
  }
  return j;
}
const authUrl = (op) => `${AUTH}/accounts:${op}?key=${encodeURIComponent(CFG.apiKey)}`;

// ---------- الجلسة الحالية (في الذاكرة) ----------
let S = null;               // { uid, email, name, idToken, refreshToken, exp, verified, google }
let listeners = [];
const onChange = (fn) => listeners.push(fn);
const emit = () => listeners.forEach(f => { try { f(status()); } catch {} });
function setSession(j, extra = {}) {
  S = {
    uid: j.localId || j.user_id || (S && S.uid), email: j.email || (S && S.email) || extra.email || '',
    name: j.displayName || (S && S.name) || '', idToken: j.idToken || j.id_token,
    refreshToken: j.refreshToken || j.refresh_token, exp: Date.now() + (+(j.expiresIn || j.expires_in || 3600) - 120) * 1000,
    verified: j.emailVerified !== undefined ? !!j.emailVerified : (S ? S.verified : false), google: !!extra.google || !!(S && S.google)
  };
  emit();
  return S;
}
function clear() { S = null; emit(); }
function status() {
  return { configured: configured(), googleReady: googleReady(), connected: !!S, uid: S && S.uid, email: S && S.email, verified: !!(S && S.verified) };
}
async function idToken() {
  if (!S) throw new CloudErr('cnot');
  if (Date.now() < S.exp) return S.idToken;
  const j = await post(`${TOKEN}/token?key=${encodeURIComponent(CFG.apiKey)}`, { grant_type: 'refresh_token', refresh_token: S.refreshToken }, true);
  setSession(j);
  return S.idToken;
}

// ---------- العمليات ----------
async function lookup() {
  try {
    const j = await post(authUrl('lookup'), { idToken: await idToken() });
    const u = (j.users || [])[0];
    if (u && S) { S.verified = !!u.emailVerified; S.name = u.displayName || S.name; S.google = (u.providerUserInfo || []).some(p => p.providerId === 'google.com'); emit(); }
  } catch {}
}
async function signIn(email, password) {
  if (!configured()) throw new CloudErr('coff');
  const j = await post(authUrl('signInWithPassword'), { email: String(email).trim(), password: String(password), returnSecureToken: true });
  setSession(j); await lookup();
  return S;
}
async function signUp(name, email, password) {
  if (!configured()) throw new CloudErr('coff');
  const j = await post(authUrl('signUp'), { email: String(email).trim(), password: String(password), returnSecureToken: true });
  setSession(j);
  try { await post(authUrl('update'), { idToken: S.idToken, displayName: String(name || '').trim(), returnSecureToken: false }); S.name = String(name || '').trim(); } catch {}
  sendVerify().catch(() => {});
  return S;
}
async function sendVerify() { return post(authUrl('sendOobCode'), { requestType: 'VERIFY_EMAIL', idToken: await idToken() }); }
async function sendReset(email) {
  if (!configured()) throw new CloudErr('coff');
  try { await post(authUrl('sendOobCode'), { requestType: 'PASSWORD_RESET', email: String(email).trim() }); }
  catch (e) { if (e.code !== 'cwrong') throw e; }        // لا نكشف هل البريد مسجّل
  return true;
}
async function resume(refreshToken) {
  if (!configured() || !refreshToken) throw new CloudErr('cnot');
  const j = await post(`${TOKEN}/token?key=${encodeURIComponent(CFG.apiKey)}`, { grant_type: 'refresh_token', refresh_token: refreshToken }, true);
  setSession(j); await lookup();
  return S;
}

// ---------- الدخول بحساب Google (المتصفح الخارجي + عنوان محلي مؤقت) ----------
const b64url = (b) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function googleSignIn(doneHtml) {
  return new Promise((resolve, reject) => {
    if (!googleReady()) return reject(new CloudErr('coff'));
    const verifier = b64url(crypto.randomBytes(32));
    const challenge = b64url(crypto.createHash('sha256').update(verifier).digest());
    const state = b64url(crypto.randomBytes(16));
    let finished = false;
    const srv = http.createServer(async (req, res) => {
      const u = new URL(req.url, 'http://127.0.0.1');
      if (u.pathname !== '/') { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(doneHtml);
      if (finished) return;
      finished = true; clearTimeout(tm); srv.close();
      try {
        if (u.searchParams.get('state') !== state || !u.searchParams.get('code')) throw new CloudErr('ccancel');
        const tok = await post(GTOKEN, {
          code: u.searchParams.get('code'), client_id: CFG.googleClientId, client_secret: CFG.googleClientSecret || '',
          redirect_uri: redirect, grant_type: 'authorization_code', code_verifier: verifier
        }, true);
        const j = await post(authUrl('signInWithIdp'), {
          postBody: `id_token=${encodeURIComponent(tok.id_token)}&providerId=google.com`, requestUri: 'http://localhost',
          returnSecureToken: true, returnIdpCredential: true
        });
        setSession(j, { google: true }); S.verified = true; S.name = j.displayName || j.fullName || S.name;
        resolve(S);
      } catch (e) { reject(e instanceof CloudErr ? e : new CloudErr('cfail', String(e.message || e))); }
    });
    let redirect = '';
    const tm = setTimeout(() => { if (!finished) { finished = true; srv.close(); reject(new CloudErr('ccancel')); } }, 4 * 60 * 1000);
    srv.listen(0, '127.0.0.1', () => {
      redirect = `http://127.0.0.1:${srv.address().port}`;
      const q = new URLSearchParams({ client_id: CFG.googleClientId, redirect_uri: redirect, response_type: 'code', scope: 'openid email profile',
        code_challenge: challenge, code_challenge_method: 'S256', state, prompt: 'select_account' });
      shell.openExternal(`${GOAUTH}?${q}`);
    });
  });
}

// ---------- إعادة التحقق من صاحبة الحساب (لعمليات حساسة) دون تغيير الجلسة ----------
async function verifyPassword(password) {
  if (!S) throw new CloudErr('cnot');
  const j = await post(authUrl('signInWithPassword'), { email: S.email, password: String(password), returnSecureToken: true });
  return j.localId === S.uid;
}
async function verifyGoogle(doneHtml) {
  if (!S) throw new CloudErr('cnot');
  const snap = { ...S }; let ok = false;
  try { const T = await googleSignIn(doneHtml); ok = T.uid === snap.uid; }
  finally { if (!ok) { S = snap; emit(); } }
  return ok;
}

// ---------- ملف المعلمة في Firestore (users/{uid}) ----------
const fsv = (v) => typeof v === 'boolean' ? { booleanValue: v } : v instanceof Date ? { timestampValue: v.toISOString() } : { stringValue: String(v ?? '') };
async function touchProfile(extra = {}) {
  if (!S) return false;
  const fields = { name: S.name || '', email: S.email || '', lastSeen: new Date(), ...extra };
  const mask = Object.keys(fields).map(k => 'updateMask.fieldPaths=' + k).join('&');
  const url = `${FS}/projects/${CFG.projectId}/databases/(default)/documents/users/${S.uid}?${mask}`;
  try {
    const res = await fetch(url, {
      method: 'PATCH', signal: AbortSignal.timeout(15000),
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + await idToken() },
      body: JSON.stringify({ fields: Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, fsv(v)])) })
    });
    return res.ok;
  } catch { return false; }
}

// ---------- حفظ رمز التجديد مشفّراً (لجهازي الشخصي فقط) ----------
function seal(tok) {
  try { if (tok && safeStorage.isEncryptionAvailable()) return safeStorage.encryptString(tok).toString('base64'); } catch {}
  return null;
}
function unseal(s) {
  try { if (s && safeStorage.isEncryptionAvailable()) return safeStorage.decryptString(Buffer.from(s, 'base64')); } catch {}
  return null;
}

module.exports = {
  verifyPassword, verifyGoogle, CloudErr, configured, googleReady, status, onChange, signIn, signUp, sendVerify, sendReset, resume, googleSignIn,
  touchProfile, lookup, clear, seal, unseal, session: () => S, idToken
};
