// صيغة المخاطبة في الواجهة: معلم/معلمة لكل حساب، وبنين/بنات/مختلط لكل فصل (وفي المختلط: لكل طفل)
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let prof = {};

  // ---------- اقتراح الجنس من الاسم الأول (للفصل المختلط) ----------
  const GIRLS = 'فاطمة عائشة مريم نورة نوره سارة ساره ريم هند لمى دانة دانه ليان لين ليلى رهف رغد شهد جنى جوري ديما رنا رنيم سلمى سما سمية هيا هيفاء غادة غاده منى ملك ميار ميرا مها أمل امل أسماء اسماء بشرى تالا تولين جمانة جمانه حلا حنين خديجة خلود دعاء ديم رزان روان رؤى رؤى ريما ريناد زينب سجى سديم سلاف شوق عبير عفاف غلا فجر فرح لانا لجين لولوة لولو مرام مشاعل منيرة نجلاء ندى نوف هالة هاله هديل وجدان وعد يارا ياسمين آلاء الاء آية اية أروى اروى العنود الجوهرة الجازي الهنوف بسمة بسمه رفيف فايزة هدباء'.split(' ');
  const BOYS = 'محمد أحمد احمد عبدالله عبدالرحمن عبدالعزيز خالد فهد سعد سعود فيصل تركي ناصر عمر علي حسن حسين يوسف إبراهيم ابراهيم إسماعيل اسماعيل سلمان سلطان ماجد مازن مشاري نايف نواف بدر بندر راكان ريان زياد سامي صالح طلال عادل عبدالمجيد عبدالملك عبدالإله عثمان فارس مالك مهند ياسر يزيد هشام وليد أنس انس أيمن ايمن حمد حمزة حمزه طارق عمار عمرو مصعب معاذ هاني وائل ثامر جاسم حامد راشد سيف عزام غازي لؤي مشعل منصور نادر هتان'.split(' ');
  const BOTH = 'جود نور ضي ضحى عدن غيث رحمة'.split(' ');
  function guess(name) {
    const f = String(name).trim().split(/\s+/)[0] || '';
    if (BOTH.includes(f)) return '?';
    if (GIRLS.includes(f)) return 'g';
    if (BOYS.includes(f) || /^عبد/.test(f)) return 'b';
    if (/(ة|اء|ى)$/.test(f)) return 'g';
    return '?';
  }
  const classes = () => prof.classes || [];
  const cur = () => classes()[Math.min(prof.classIdx || 0, Math.max(0, classes().length - 1))];
  const defCg = () => (prof.teacherG === 'm' ? 'b' : 'g');
  const cgOf = (c) => (c && ['g', 'b', 'mix'].includes(c.gender) ? c.gender : defCg());
  // جنس طالب بعينه: من نوع الفصل، أو اختيار المعلمة في المختلط (والاقتراح إن لم تختر)
  LP.genderOf = (name) => {
    const c = cur(), g = cgOf(c);
    if (g !== 'mix') return g;
    const v = (c.sg || {})[name] || guess(name);
    return v === '?' ? 'b' : v;
  };
  LP.studentCtx = (name) => ({ cg: LP.genderOf(name) });

  // شاشة الدخول: صيغة آخر مستخدم على هذا الجهاز
  if (api.genderLast) api.genderLast().then(tg => { if (!LP.auth || !LP.auth.user) { LPG.set({ tg }); I18N.translateDOM(document.body); } }).catch(() => {});
  let asked = false;
  function askOnce() {
    asked = true;
    const d = document.createElement('div'); d.className = 'gdlg on'; d.id = 'tgAsk';
    d.innerHTML = `<div class="gdlg-card" style="max-width:420px;text-align:center">
      <h3>👋 ${esc(I18N.t('كيف يخاطبكِ البرنامج؟', null, { tg: 'f' }))} / ${esc(I18N.t('كيف يخاطبكِ البرنامج؟', null, { tg: 'm' }))}</h3>
      <p>${T('تُستخدم في رسائل البرنامج والشهادات. يمكن تغييرها لاحقاً من الإعدادات ← حسابي.')}</p>
      <div class="gdlg-row" style="justify-content:center"><button class="pri" data-g="f">👩‍🏫 ${T('معلمة')}</button><button class="pri" data-g="m">👨‍🏫 ${T('معلم')}</button></div></div>`;
    document.body.appendChild(d);
    d.querySelectorAll('[data-g]').forEach(b => b.onclick = async () => { d.remove(); await api.setSettings({ teacherG: b.dataset.g }); apply(); });
  }
  async function apply(p) {
    prof = p || await api.getSettings();
    if (prof.teacherG === undefined && !asked && LP.auth && LP.auth.user && !LP.auth.user.guest) askOnce();
    LPG.set({ tg: prof.teacherG === 'f' ? 'f' : 'm', cg: cgOf(cur()) });
    I18N.translateDOM(document.body);
    renderClassG();
  }
  LP.applyGender = apply;
  document.addEventListener('lp-auth', (e) => { if (e.detail && e.detail.user) apply(); });
  document.addEventListener('lp-classes', () => apply());
  document.addEventListener('lp-tools', () => apply());

  // ---------- أدوات المعلمة: نوع الفصل، وقائمة الأطفال في المختلط ----------
  const t1 = $('#classGrade') && $('#classGrade').closest('.trow');
  const row = document.createElement('div'); row.className = 'trow';
  row.innerHTML = `<label data-gt="الطلاب">${T('الطلاب')}</label><select id="classGender">
      <option value="g">👧 ${T('بنات')}</option><option value="b">👦 ${T('بنين')}</option><option value="mix">👦👧 ${T('مختلط')}</option></select>`;
  if (t1) t1.after(row);
  const mixBox = document.createElement('div'); mixBox.id = 'mixBox'; mixBox.className = 'mixbox';
  const namesRow = $('#namesSave') && $('#namesSave').closest('.trow');
  if (namesRow) namesRow.after(mixBox);
  async function save(patch) { Object.assign(prof, patch); await api.setSettings(patch); document.dispatchEvent(new Event('lp-classes')); }
  $('#classGender').onchange = async (e) => {
    const p = await api.getSettings(); prof = p; const c = cur(); if (!c) return;
    c.gender = e.target.value;
    await save({ classes: classes() });
  };
  function renderClassG() {
    const sel = $('#classGender'); if (!sel) return;
    const c = cur(); sel.value = cgOf(c);
    if (!c || cgOf(c) !== 'mix' || !(c.students || []).length) { mixBox.innerHTML = ''; mixBox.hidden = true; return; }
    mixBox.hidden = false;
    const sg = c.sg || {};
    const unsure = c.students.filter(n => !sg[n] && guess(n) === '?').length;
    mixBox.innerHTML = `<div class="mixh">${T('اضغطي على الرمز لتغييره')} ${unsure ? `<b class="mixq">· ${T('{n} أسماء تحتاج اختياركِ', { n: unsure })}</b>` : ''}</div>
      <div class="mixl">${c.students.map(n => { const v = sg[n] || guess(n); return `<button class="mixc ${v === '?' ? 'q' : ''} ${sg[n] ? 'set' : ''}" data-n="${esc(n)}">${v === 'b' ? '👦' : v === 'g' ? '👧' : '❔'} ${esc(n.split(/\s+/).slice(0, 2).join(' '))}</button>`; }).join('')}</div>`;
    mixBox.querySelectorAll('[data-n]').forEach(b => b.onclick = async () => {
      const p = await api.getSettings(); prof = p; const cc = cur(); const n = b.dataset.n;
      cc.sg = cc.sg || {}; const v = cc.sg[n] || guess(n);
      cc.sg[n] = v === 'g' ? 'b' : 'g';
      await save({ classes: classes() });
    });
  }

  // ---------- أول دخول: صيغة الحساب ----------
  LP.teacherGPicker = (val) => `<div class="tgpick"><label><input type="radio" name="tgPick" value="f" ${val !== 'm' ? 'checked' : ''}> 👩‍🏫 ${T('معلمة')}</label><label><input type="radio" name="tgPick" value="m" ${val === 'm' ? 'checked' : ''}> 👨‍🏫 ${T('معلم')}</label></div>`;
})();
