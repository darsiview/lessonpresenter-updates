// إرسال البريد عبر Gmail (SMTP) بدون مكتبات خارجية
const tls = require('tls');
const net = require('net');

const b64 = (s) => Buffer.from(String(s), 'utf8').toString('base64');
const wrap = (s) => s.replace(/.{1,76}/g, '$&\r\n');
const encHeader = (s) => /^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`;

function buildMessage({ from, fromName, to, subject, text, html }) {
  const boundary = 'lp' + Date.now().toString(36) + Math.random().toString(36).slice(2);
  const domain = (from.split('@')[1] || 'localhost');
  return [
    `From: ${encHeader(fromName || 'Lesson Presenter')} <${from}>`,
    `To: <${to}>`,
    `Subject: ${encHeader(subject)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${Date.now()}.${Math.random().toString(36).slice(2)}@${domain}>`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrap(b64(text)),
    `--${boundary}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrap(b64(html)),
    `--${boundary}--`,
    ''
  ].join('\r\n');
}

// opts: { user, pass, to, subject, text, html, fromName, host?, port?, secure? }
function send(opts) {
  const host = opts.host || 'smtp.gmail.com', port = opts.port || 465, secure = opts.secure !== false;
  return new Promise((resolve, reject) => {
    const sock = secure ? tls.connect({ host, port, servername: host }) : net.connect({ host, port });
    let buf = '', waiter = null, done = false;
    const timer = setTimeout(() => fail(new Error('timeout')), 25000);
    function fail(e) { if (done) return; done = true; clearTimeout(timer); try { sock.destroy(); } catch {} reject(e); }
    function ok(v) { if (done) return; done = true; clearTimeout(timer); try { sock.end(); } catch {} resolve(v); }
    sock.setEncoding('utf8');
    sock.on('error', fail);
    sock.on('close', () => { if (!done) fail(new Error('closed')); });
    sock.on('data', d => {
      buf += d;
      // رد كامل: آخر سطر بالشكل "123 نص"
      const lines = buf.split('\r\n');
      for (let i = 0; i < lines.length - 1; i++) {
        if (/^\d{3} /.test(lines[i])) {
          const resp = lines.slice(0, i + 1).join('\n');
          buf = lines.slice(i + 1).join('\r\n');
          const w = waiter; waiter = null;
          if (w) w(resp);
          return;
        }
      }
    });
    const read = () => new Promise(r => { waiter = r; });
    const cmd = async (line, expect) => {
      if (line !== null) sock.write(line + '\r\n');
      const r = await read();
      if (!r.startsWith(expect)) throw new Error('SMTP: ' + r.split('\n').pop());
      return r;
    };
    (async () => {
      await cmd(null, '220');
      await cmd('EHLO lesson-presenter', '250');
      await cmd('AUTH LOGIN', '334');
      await cmd(b64(opts.user), '334');
      await cmd(b64(opts.pass), '235');
      await cmd(`MAIL FROM:<${opts.user}>`, '250');
      await cmd(`RCPT TO:<${opts.to}>`, '250');
      await cmd('DATA', '354');
      const msg = buildMessage({ from: opts.user, fromName: opts.fromName, to: opts.to, subject: opts.subject, text: opts.text, html: opts.html });
      await cmd(msg.replace(/\r\n\./g, '\r\n..') + '\r\n.', '250');
      sock.write('QUIT\r\n');
      ok(true);
    })().catch(fail);
  });
}

module.exports = { send, buildMessage };
