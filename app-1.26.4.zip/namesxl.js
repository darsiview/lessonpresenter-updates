// أسماء الطلاب من إكسل: تنزيل قالب جاهز، ورفع الملف بعد تعبئته (أو ملف نظام نور كما هو)
(() => {
  const $ = (s) => document.querySelector(s);
  const api = window.api;
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const clean = (s) => String(s ?? '').replace(/[\t ]+/g, ' ').replace(/\s+/g, ' ').trim();
  const norm = (s) => clean(s).replace(/[إأآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');

  // ---------- الأزرار تحت مربع الأسماء ----------
  const row = $('#namesSave') && $('#namesSave').closest('.trow');
  if (!row) return;
  const bar = document.createElement('div'); bar.className = 'trow nxl';
  bar.innerHTML = `<button class="tb" id="nxTpl" title="${esc(T('ملف إكسل فيه أعمدة الفصل والاسم، تُكتب فيه الأسماء ثم يُرفع'))}">📥 ${T('قالب إكسل للأسماء')}</button>
    <button class="tb" id="nxUp" title="${esc(T('رفع القالب بعد تعبئته، أو ملف نظام نور كما هو'))}">📤 ${T('رفع ملف الأسماء')}</button>`;
  row.after(bar);

  // ---------- القالب ----------
  $('#nxTpl').onclick = async () => {
    const p = await api.getSettings();
    const head = [T('الفصل'), T('اسم الطالب / الطالبة'), T('بنت / ولد (للفصل المختلط فقط)')];
    const rows = [head];
    for (const c of p.classes || []) for (const n of c.students || []) {
      const g = (c.sg || {})[n];
      rows.push([c.name, n, c.gender === 'mix' && g ? (g === 'b' ? T('ولد') : T('بنت')) : '']);
    }
    if (rows.length === 1) rows.push(['5/1', T('سارة محمد العتيبي'), ''], ['5/1', T('نورة عبدالله القحطاني'), ''], ['5/2', T('ريم خالد الشهري'), '']);
    const help = [[T('طريقة التعبئة')], [T('١. في ورقة «الأسماء»: اكتبي الفصل (مثل 5/1) في العمود الأول، والاسم في الثاني. كل اسم في سطر.')],
      [T('٢. يمكن وضع كل الفصول في الورقة نفسها، أو ورقة لكل فصل باسم الفصل (عندها يكفي عمود الاسم).')],
      [T('٣. عمود «بنت / ولد» للفصول المختلطة فقط (رياض الأطفال والصفوف الأولى)، ويمكن تركه فارغاً.')],
      [T('٤. احفظي الملف، ثم من البرنامج: أدوات المعلمة ← «📤 رفع ملف الأسماء».')],
      [T('يمكن أيضاً رفع ملف الطلاب المصدَّر من نظام نور كما هو (بصيغة xlsx).')]];
    const r = await api.xlsxSave([{ name: T('الأسماء'), rows, widths: [12, 40, 26], boldRows: [0] }, { name: T('طريقة التعبئة'), rows: help, widths: [100], boldRows: [0] }], { name: T('قالب أسماء الطلاب') });
    if (r && r.ok) LP.toast(T('تم حفظ القالب — اكتبي الأسماء فيه ثم ارفعيه'));
  };

  // ---------- قراءة الملف ----------
  const isName = (h) => /(^|\s)(ال)?اسم|name/i.test(h) && !/ولي|الاب|الأب|الام|الأم|المعلم|المدرس|المدرسه|المدرسة|الفصل|الصف|المرحله|المرحلة|المادة/.test(h);
  const isClass = (h) => /^(ال)?فصل$|الفصل|الشعبه|الشعبة|شعبة|class|section/i.test(h) && !/اسم|دراسي/.test(h);
  const isGrade = (h) => /^(ال)?صف$|^الصف\b|grade|المستوى/i.test(h) && !/اسم/.test(h);
  const isGender = (h) => /بنت|ولد|الجنس|جنس|gender|sex|النوع/i.test(h);
  const gOf = (v) => { v = clean(v).toLowerCase(); if (/^(بنت|طالبه|طالبة|انثى|أنثى|girl|f|g|female|👧)$/.test(v)) return 'g'; if (/^(ولد|طالب|ذكر|boy|m|b|male|👦)$/.test(v)) return 'b'; return ''; };
  const GENERIC = /^(sheet\d*|ورقة\d*|الاسماء|الأسماء|طالبات|طلاب|الطلاب|الطالبات|students|names|ورقه\d*)$/i;
  function classLabel(grade, cls) {
    cls = clean(cls); grade = clean(grade);
    if (/\d+\s*[\/\-]\s*\d+/.test(cls)) return cls.replace(/\s*[\/\-]\s*/, '/');
    if (!grade) return cls;
    const g = LP.parseGrade ? LP.parseGrade(grade) : 0;
    return g ? `${g}/${cls}` : `${grade} ${cls}`.trim();
  }
  // → { classes: Map(اسم → {names:[], sg:{}}), loose: [{name,g}] (بلا فصل), dups, empty }
  function parse(book) {
    const out = new Map(), loose = []; let dups = 0;
    const put = (cls, n, g) => {
      n = clean(n); if (!n || /^\d+$/.test(n)) return;
      if (!cls) { if (!loose.some(x => x.name === n)) loose.push({ name: n, g }); else dups++; return; }
      if (!out.has(cls)) out.set(cls, { names: [], sg: {} });
      const c = out.get(cls); if (c.names.includes(n)) { dups++; return; }
      c.names.push(n); if (g) c.sg[n] = g;
    };
    for (const sh of book.sheets || []) {
      const rows = (sh.rows || []).map(r => (r || []).map(clean));
      if (!rows.some(r => r.some(Boolean))) continue;
      if (/^(طريقة التعبئة|instructions)$/i.test(clean(sh.name))) continue;
      let hi = -1, nc = -1, cc = -1, gc = -1, xc = -1;
      for (let i = 0; i < Math.min(rows.length, 20) && hi < 0; i++) {
        const r = rows[i], k = r.findIndex(h => h && isName(norm(h)) || isName(h || ''));
        if (k >= 0) { hi = i; nc = k; cc = r.findIndex(h => h && isClass(h)); gc = r.findIndex(h => h && isGrade(h)); xc = r.findIndex(h => h && isGender(h)); }
      }
      const sheetCls = GENERIC.test(clean(sh.name)) ? '' : clean(sh.name).replace(/\s*-\s*/, '/');
      if (hi < 0) {
        // بلا عناوين: أطول عمود نصّي هو الأسماء
        const w = Math.max(...rows.map(r => r.length)); let best = 0, bl = -1;
        for (let c = 0; c < w; c++) { const l = rows.filter(r => r[c] && !/^\d+$/.test(r[c])).reduce((a, r) => a + r[c].length, 0); if (l > bl) { bl = l; best = c; } }
        rows.forEach(r => put(sheetCls, r[best], ''));
        continue;
      }
      for (const r of rows.slice(hi + 1)) {
        const cls = cc >= 0 && r[cc] ? classLabel(gc >= 0 ? r[gc] : '', r[cc]) : sheetCls;
        put(cls, r[nc], xc >= 0 ? gOf(r[xc]) : '');
      }
    }
    return { classes: out, loose, dups };
  }

  // ---------- نافذة المراجعة ----------
  const dlg = document.createElement('div'); dlg.className = 'gdlg'; dlg.id = 'nxDlg'; dlg.innerHTML = '<div class="gdlg-card" style="max-width:620px"></div>';
  document.body.appendChild(dlg);
  const card = dlg.querySelector('.gdlg-card');
  const close = () => dlg.classList.remove('on');
  dlg.addEventListener('click', e => { if (e.target === dlg) close(); });

  $('#nxUp').onclick = async () => {
    const book = await api.xlsxOpenBook(T('اختاري ملف الأسماء'));
    if (!book) return;
    if (book.err === 'xls') { LP.toast(T('هذا ملف إكسل قديم (xls). افتحيه في إكسل واحفظيه بصيغة xlsx ثم ارفعيه.'), null, null, 7000); return; }
    if (book.err) { LP.toast(T('تعذّرت قراءة الملف'), null, null, 4000); return; }
    const res = parse(book);
    if (!res.classes.size && !res.loose.length) { LP.toast(T('لم أجد أسماء في الملف. تأكدي أن فيه عموداً عنوانه «الاسم».'), null, null, 6000); return; }
    review(res, book.file);
  };

  async function review(res, fileName) {
    const p = await api.getSettings(), mine = (p.classes || []).filter(c => !LP.classVisible || LP.classVisible(c));
    const curName = (mine[Math.min(p.classIdx || 0, Math.max(0, mine.length - 1))] || {}).name || '';
    const list = [...res.classes.entries()].map(([name, v]) => ({ name, ...v, on: true }));
    if (res.loose.length) list.push({ name: '', loose: true, names: res.loose.map(x => x.name), sg: Object.fromEntries(res.loose.filter(x => x.g).map(x => [x.name, x.g])), on: true, target: curName || '' });
    const exists = (n) => mine.find(c => norm(c.name) === norm(n));
    const opts = (sel) => mine.map(c => `<option ${c.name === sel ? 'selected' : ''}>${esc(c.name)}</option>`).join('') + `<option value="__new" ${!sel ? 'selected' : ''}>＋ ${T('فصل جديد')}</option>`;
    const rowsHtml = list.map((c, i) => {
      const ex = c.loose ? null : exists(c.name);
      const st = c.loose ? `${T('إلى الفصل:')} <select data-t="${i}">${opts(c.target)}</select> <input data-nn="${i}" placeholder="${esc(T('اسم الفصل الجديد'))}" value="${esc(fileName || '')}" style="${c.target ? 'display:none' : ''}">`
        : ex ? `<span class="nx-ex">${T('موجود: {n} اسماً', { n: (ex.students || []).length })}</span>` : `<span class="nx-new">${T('فصل جديد')}</span>`;
      return `<tr><td><input type="checkbox" data-on="${i}" checked></td><td><b>${c.loose ? T('أسماء بلا فصل') : esc(c.name)}</b></td><td>${T('{n} اسماً', { n: c.names.length })}</td><td>${st}</td></tr>`;
    }).join('');
    card.innerHTML = `<h3>📤 ${T('مراجعة الأسماء قبل الحفظ')}</h3>
      <p class="muted">${esc(fileName || '')}${res.dups ? ' · ' + T('تم تجاهل {n} اسماً مكرراً', { n: res.dups }) : ''}</p>
      <div class="nx-wrap"><table class="nx-tbl"><tbody>${rowsHtml}</tbody></table></div>
      <div class="nx-mode"><b>${T('للفصول الموجودة:')}</b>
        <label><input type="radio" name="nxm" value="add" checked> ${T('إضافة الأسماء الناقصة فقط')}</label>
        <label><input type="radio" name="nxm" value="replace"> ${T('استبدال الأسماء بأسماء الملف')}</label></div>
      <p class="tnote">${T('النقاط والمجموعات السابقة لا تُحذف.')}</p>
      <div class="gdlg-row"><button class="pri" id="nxOk">✓ ${T('حفظ الأسماء')}</button><button id="nxNo">${T('إلغاء')}</button></div>`;
    dlg.classList.add('on');
    card.querySelectorAll('[data-on]').forEach(b => b.onchange = () => { list[+b.dataset.on].on = b.checked; });
    card.querySelectorAll('[data-t]').forEach(s => s.onchange = () => { const c = list[+s.dataset.t]; c.target = s.value === '__new' ? '' : s.value; card.querySelector(`[data-nn="${s.dataset.t}"]`).style.display = c.target ? 'none' : ''; });
    $('#nxNo').onclick = close;
    $('#nxOk').onclick = async () => {
      const mode = card.querySelector('[name="nxm"]:checked').value;
      const pp = await api.getSettings(), cls = JSON.parse(JSON.stringify(pp.classes || []));
      let nNew = 0, nNames = 0, lastIdx = -1;
      list.forEach((c, i) => {
        if (!c.on) return;
        let name = c.loose ? (c.target || clean((card.querySelector(`[data-nn="${i}"]`) || {}).value) || T('فصل {n}', { n: cls.length + 1 })) : c.name;
        const home = LP.ctxHome ? LP.ctxHome() : '';
        let k = cls.findIndex(x => norm(x.name) === norm(name) && (x.home || '') === home);
        if (k < 0) { const nc = { name, students: [] }; if (home) nc.home = home; cls.push(nc); k = cls.length - 1; nNew++; }
        const t = cls[k]; t.students = t.students || [];
        const before = t.students.length;
        if (mode === 'replace') t.students = [...c.names];
        else for (const n of c.names) if (!t.students.some(x => norm(x) === norm(n))) t.students.push(n);
        if (Object.keys(c.sg).length) { t.sg = { ...(t.sg || {}), ...c.sg }; if (!t.gender) t.gender = 'mix'; }
        nNames += mode === 'replace' ? t.students.length : t.students.length - before;
        lastIdx = k;
      });
      const patch = { classes: cls }; if (lastIdx >= 0) patch.classIdx = lastIdx;
      await api.setSettings(patch);
      close();
      document.dispatchEvent(new Event('lp-classes'));
      if (LP.reloadTools) await LP.reloadTools();
      LP.toast(T('تم حفظ {n} اسماً', { n: nNames }) + (nNew ? ' · ' + T('{n} فصول جديدة', { n: nNew }) : ''), null, null, 4000);
    };
  }
  LP.namesImportParse = parse;   // للاختبار
})();
