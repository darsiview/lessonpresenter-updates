// بداية عام دراسي (أو فصل دراسي) جديد: تصدير لإكسل + نسخة احتياطية + أرشيف داخل البرنامج، ثم التصفير
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const hijriYear = () => { try { return new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', { year: 'numeric' }).format(new Date()).replace(/\D/g, ''); } catch { return ''; } };

  const dlg = document.createElement('div'); dlg.className = 'gdlg'; dlg.id = 'nyDlg';
  dlg.innerHTML = '<div class="gdlg-card ny-card" id="nyCard"></div>';
  $('#stage').appendChild(dlg);
  const card = dlg.querySelector('#nyCard');
  const close = () => dlg.classList.remove('on');
  dlg.addEventListener('click', e => { if (e.target === dlg) close(); });
  const guard = () => card.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => { if (e.key !== 'Escape') e.stopPropagation(); }));

  // ---------- ملخص كل فصل (من بيانات المجموعات المحفوظة) ----------
  function summarize(prof) {
    const G = prof.grp || {};
    return (prof.classes || []).map(c => {
      const cd = G[LP.classKey ? LP.classKey(c) : c.name] || null;
      const tt = cd && LP.classTotals ? LP.classTotals(0, Infinity, cd) : { by: {}, sessions: 0 };
      const names = [...new Set([...(c.students || []), ...Object.keys(tt.by)])];
      const rows = names.map(n => ({ n, ...(tt.by[n] || { pts: 0, turns: 0, abs: 0, thanks: 0 }) }))
        .sort((a, b) => b.pts - a.pts || b.turns - a.turns || a.n.localeCompare(b.n, 'ar'));
      return { name: c.name, grade: c.grade || 0, gender: c.gender || '', sessions: tt.sessions, rows };
    });
  }
  const HEAD = () => [T('الترتيب'), T('الاسم'), T('النقاط'), T('المشاركات'), T('الشكر'), T('الغياب')];
  const sheetsOf = (arch) => arch.classes.map(c => ({
    name: c.name, widths: [8, 34, 10, 12, 10, 10], boldRows: [0, 2],
    rows: [[`${arch.label} — ${c.name}`], [T('{n} حصة', { n: c.sessions })], HEAD(), ...c.rows.map((r, i) => [i + 1, r.n, r.pts, r.turns, r.thanks, r.abs])]
  }));

  // ---------- النافذة: الخطوة ١ ----------
  async function open(kind) {
    if (LP.groupsFlush) await LP.groupsFlush();
    const prof = await api.getSettings();
    kind = kind || 'year';
    const hy = hijriYear();
    // من التقويم الدراسي إن وُجد: الفصل الذي انتهى (أو الحالي)، والعام من أول فصل إلى آخره
    const iso = (t) => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
    const terms = (LP.cal && LP.cal.terms) || [];
    const tm = kind === 'term' && LP.cal ? ((LP.cal.at() || {}).term || LP.cal.lastEnded()) : null;
    const prevArch = (prof.yearArchive || []).slice(-1)[0];
    let dFrom = tm ? tm.start : kind === 'year' && terms.length ? terms[0].start : prevArch && prevArch.to ? iso(new Date(prevArch.to).getTime() + 864e5) : iso(firstLesson(prof) || Date.now());
    let dTo = tm ? tm.end : kind === 'year' && terms.length ? terms[terms.length - 1].end : iso(Date.now());
    const def = tm ? `${tm.name} ${hy} هـ` : kind === 'year' ? T('العام الدراسي {y} هـ', { y: hy }) : T('الفصل الدراسي — {y} هـ', { y: hy });
    const sum = summarize(prof), nStu = sum.reduce((a, c) => a + c.rows.length, 0), nSess = sum.reduce((a, c) => a + c.sessions, 0);
    card.innerHTML = `<div class="res-head"><h3>🎓 ${T('بداية جديدة')}</h3><span style="flex:1"></span><button class="rbtn" id="nyX">✕</button></div>
      <div class="tchips"><button class="tchip ${kind === 'year' ? 'on' : ''}" data-k="year">🎓 ${T('عام دراسي جديد')}</button><button class="tchip ${kind === 'term' ? 'on' : ''}" data-k="term">📘 ${T('فصل دراسي جديد')}</button></div>
      <p class="muted">${kind === 'year' ? T('للطلاب الجدد: تُصفَّر النقاط وتُحذف الأسماء، وتبقى الفصول فارغة جاهزة.') : T('لنفس الطلاب: تُصفَّر النقاط وتبقى الأسماء.')}</p>
      <div class="ny-sum">${T('الآن: {c} فصول، {s} طالباً، {n} حصة مسجّلة', { c: sum.length, s: nStu, n: nSess })}</div>
      <label class="ny-l">${T('اسم الأرشيف')}</label><input class="sinput" id="nyLabel" value="${esc(def)}">
      <div class="ny-dates"><label>${T('من')}<input type="date" id="nyFrom" value="${esc(dFrom)}"></label><label>${T('إلى')}<input type="date" id="nyTo" value="${esc(dTo)}"></label></div>
      <h4 class="rs-h">${T('قبل التصفير')}</h4>
      <label class="chk"><input type="checkbox" id="nyXl" checked> 📊 ${T('ملف إكسل للعام فيه ورقة لكل فصل')}</label>
      <label class="chk"><input type="checkbox" id="nyBk" checked> 💾 ${T('نسخة احتياطية كاملة من بياناتي')}</label>
      <label class="chk"><input type="checkbox" checked disabled> 📚 ${T('حفظ التقارير في «الأعوام السابقة» داخل البرنامج')}</label>
      <h4 class="rs-h">${T('ما يُصفَّر')}</h4>
      <p class="ny-z">✖ ${T('النقاط والمشاركات والغياب والشكر والحصص في كل الفصول')}</p>
      <label class="chk"><input type="checkbox" id="nyKeep" ${kind === 'term' ? 'checked' : ''}> ${T('إبقاء أسماء الطلاب في فصولها')}</label>
      <p class="ny-k">✔ ${T('تبقى: الفصول (أسماؤها وصفوفها ونوعها)، والدروس والمكتبة والمواد والإعدادات والحساب')}</p>
      <div class="gdlg-row"><button class="pri" id="nyNext">${T('متابعة')} ←</button><button id="nyNo">${T('إلغاء')}</button></div>`;
    guard();
    $('#nyX').onclick = close; $('#nyNo').onclick = close;
    card.querySelectorAll('[data-k]').forEach(b => b.onclick = () => open(b.dataset.k));
    $('#nyNext').onclick = () => confirmView(kind, { label: $('#nyLabel').value.trim() || def, from: $('#nyFrom').value, to: $('#nyTo').value, termId: tm ? tm.id : null, xl: $('#nyXl').checked, bk: $('#nyBk').checked, keep: $('#nyKeep').checked }, sum);
    dlg.classList.add('on');
  }
  // ---------- الخطوة ٢: التأكيد والتنفيذ ----------
  function confirmView(kind, o, sum) {
    card.innerHTML = `<div class="res-head"><h3>⚠ ${T('تأكيد')}</h3><span style="flex:1"></span><button class="rbtn" id="nyX">✕</button></div>
      <p>${T('سيُحفظ «{l}» في الأعوام السابقة، ثم تُصفَّر نقاط كل الفصول ({c} فصول).', { l: esc(o.label), c: sum.length })}</p>
      ${o.keep ? '' : `<p class="ny-z">${T('وستُحذف أسماء الطلاب من كل الفصول.')}</p>`}
      ${o.xl || o.bk ? `<p class="muted">${T('ستختارين بعدها مجلداً لحفظ الملفات.')}</p>` : ''}
      <div class="gdlg-row"><button class="pri warn" id="nyGo">${T(kind === 'year' ? 'ابدئي العام الجديد' : 'ابدئي الفصل الجديد')}</button><button id="nyBack">→ ${T('رجوع')}</button></div>
      <p class="smsg" id="nyMsg"></p>`;
    $('#nyX').onclick = close; $('#nyBack').onclick = () => open(kind);
    $('#nyGo').onclick = async () => {
      const btn = $('#nyGo'); btn.disabled = true;
      const msg = (t) => { $('#nyMsg').textContent = t; };
      if (LP.groupsFlush) await LP.groupsFlush();
      const prof = await api.getSettings();
      const arch = { id: Date.now().toString(36), label: o.label, kind, at: Date.now(), from: o.from || '', to: o.to || '', termId: o.termId || null, classes: summarize(prof).map(c => ({ ...c, rows: c.rows.filter(r => r.pts || r.turns || r.abs || r.thanks || (prof.classes.find(x => x.name === c.name) || { students: [] }).students.includes(r.n)) })) };
      const files = [];
      if (o.xl || o.bk) {
        const dir = await api.pickDir(T('اختاري مجلداً لحفظ ملفات {l}', { l: o.label }));
        if (!dir) { btn.disabled = false; msg(T('لم يُختر مجلد — لم يتغير شيء.')); return; }
        if (o.xl) { msg(T('جارٍ حفظ ملف إكسل…')); const r = await api.xlsxSave(sheetsOf(arch), { dir, name: o.label }); if (!r || !r.ok) { btn.disabled = false; msg(T('تعذّر حفظ ملف إكسل — لم يتغير شيء.')); return; } files.push(r.file); }
        if (o.bk) { msg(T('جارٍ حفظ النسخة الاحتياطية…')); const r = await api.dataExport({ dir, name: T('نسخة {l}', { l: o.label }) }); if (!r || !r.ok) { btn.disabled = false; msg(T('تعذّر حفظ النسخة الاحتياطية — لم يتغير شيء.')); return; } files.push(r.file); }
      }
      // الأرشيف ثم التصفير
      const yearArchive = [...(prof.yearArchive || []), arch];
      const classes = (prof.classes || []).map(c => ({ ...c, students: o.keep ? (c.students || []) : [], sg: o.keep ? (c.sg || {}) : {} }));
      const grp = {};
      for (const [k, v] of Object.entries(prof.grp || {})) grp[k] = { sessions: [], cur: null, ngroups: v.ngroups || 0, gnames: v.gnames || [] };
      await api.setSettings({ yearArchive, classes, grp, lessonNow: null });
      card.innerHTML = `<div class="res-head"><h3>✅ ${T('تمت البداية الجديدة')}</h3></div>
        <p>${T('حُفظ «{l}» في «📚 الأعوام السابقة».', { l: esc(o.label) })}</p>
        ${files.map(f => `<p class="ny-f"><button class="rbtn" data-f="${esc(f)}">📂</button> <span dir="ltr">${esc(f)}</span></p>`).join('')}
        <div class="gdlg-row"><button class="pri" id="nyDone">${T('تم')}</button></div>`;
      card.querySelectorAll('[data-f]').forEach(b => b.onclick = () => api.showFile(b.dataset.f));
      $('#nyDone').onclick = () => { close(); api.authReload(); };
    };
  }

  function firstLesson(prof) { let m = 0; for (const v of Object.values(prof.grp || {})) for (const x of v.sessions || []) if (x.created && (!m || x.created < m)) m = x.created; return m; }
  const fmtD = (d) => { if (!d) return ''; const [y, mo, dd] = d.split('-').map(Number); const t = new Date(y, mo - 1, dd).getTime(); return LP.cal ? LP.cal.short(t) : d; };
  const span = (a) => a.from || a.to ? `${fmtD(a.from)} — ${fmtD(a.to)}` : LP.fmtDay(a.at);
  // تعديل اسم الأرشيف وتاريخيه
  function editArch(a) {
    card.innerHTML = `<div class="res-head"><h3>✎ ${T('تعديل الأرشيف')}</h3></div>
      <label class="ny-l">${T('اسم الأرشيف')}</label><input class="sinput" id="naLabel" value="${esc(a.label)}">
      <div class="ny-dates"><label>${T('من')}<input type="date" id="naFrom" value="${esc(a.from || '')}"></label><label>${T('إلى')}<input type="date" id="naTo" value="${esc(a.to || '')}"></label></div>
      <p class="muted">${T('التعديل يغيّر الاسم والتاريخين فقط، ولا يغيّر الأرقام المحفوظة.')}</p>
      <div class="gdlg-row"><button class="pri" id="naOk">${T('حفظ')}</button><button id="naNo">${T('إلغاء')}</button></div>`;
    guard();
    $('#naNo').onclick = () => archive(a.id, 0);
    $('#naOk').onclick = async () => {
      const p = await api.getSettings();
      const list = (p.yearArchive || []).map(x => x.id === a.id ? { ...x, label: $('#naLabel').value.trim() || x.label, from: $('#naFrom').value, to: $('#naTo').value } : x);
      await api.setSettings({ yearArchive: list }); archive(a.id, 0);
    };
  }

  // ---------- الأعوام السابقة ----------
  async function archive(id, ci) {
    const prof = await api.getSettings(), list = (prof.yearArchive || []).slice().reverse();
    if (!id) {
      card.innerHTML = `<div class="res-head"><h3>📚 ${T('الأعوام السابقة')}</h3><span style="flex:1"></span><button class="rbtn" id="nyX">✕</button></div>
        ${list.length ? list.map(a => `<button class="rp-top" data-a="${esc(a.id)}">${a.kind === 'year' ? '🎓' : '📘'} ${esc(a.label)} <small>${T('{c} فصول', { c: a.classes.length })} · ${esc(span(a))}</small></button>`).join('') : `<p class="muted">${T('لا يوجد أرشيف بعد. يُحفظ هنا تلقائياً عند «بداية عام دراسي جديد».')}</p>`}`;
      $('#nyX').onclick = close;
      card.querySelectorAll('[data-a]').forEach(b => b.onclick = () => archive(b.dataset.a, 0));
      dlg.classList.add('on'); return;
    }
    const a = list.find(x => x.id === id); if (!a) return archive();
    const c = a.classes[ci || 0] || { rows: [] };
    const topT = c.rows.slice().sort((x, y) => y.turns - x.turns).filter(x => x.turns > 0).slice(0, 3), topP = c.rows.filter(x => x.pts > 0).slice(0, 3);
    card.innerHTML = `<div class="res-head"><button class="rbtn" id="nyBack">→ ${T('رجوع')}</button><h3>📚 ${esc(a.label)}</h3><button class="rbtn" id="nyEdit" title="${T('تعديل الاسم والتاريخين')}">✎</button><span style="flex:1"></span><button class="rbtn" id="nyX">✕</button></div>
      <p class="rs-sub">📅 ${esc(span(a))}</p>
      <div class="tchips">${a.classes.map((x, i) => `<button class="tchip ${i === (ci || 0) ? 'on' : ''}" data-c="${i}">${esc(x.name)}</button>`).join('')}</div>
      <p class="rs-sub">${T('{n} حصة', { n: c.sessions || 0 })}</p>
      <div class="rp-tops"><div><h4>🙋 ${T('الأكثر مشاركة')}</h4>${topT.map((x, i) => `<div class="rp-top">${['🥇', '🥈', '🥉'][i]} ${esc(x.n)} <small>${T('{n} مشاركة', { n: x.turns })}</small></div>`).join('') || '—'}</div>
        <div><h4>⭐ ${T('الأكثر تفاعلاً (نقاطاً)')}</h4>${topP.map((x, i) => `<div class="rp-top">${['🥇', '🥈', '🥉'][i]} ${esc(x.n)} <small>${T('{n} نقطة', { n: x.pts })}</small></div>`).join('') || '—'}</div></div>
      <table class="rp-tb"><tr>${HEAD().map(h => `<th>${esc(h)}</th>`).join('')}</tr>${c.rows.map((r, i) => `<tr><td>${i + 1}</td><td>${esc(r.n)}</td><td>${r.pts}</td><td>${r.turns}</td><td>${r.thanks || ''}</td><td>${r.abs || ''}</td></tr>`).join('')}</table>
      <div class="rs-acts"><button class="pri" id="nyXl2">📊 ${T('حفظ ملف إكسل')}</button><button id="nyDel" class="warn">🗑 ${T('حذف هذا الأرشيف')}</button></div>`;
    $('#nyX').onclick = close; $('#nyBack').onclick = () => archive(); $('#nyEdit').onclick = () => editArch(a);
    card.querySelectorAll('[data-c]').forEach(b => b.onclick = () => archive(id, +b.dataset.c));
    $('#nyXl2').onclick = () => api.xlsxSave(sheetsOf(a), { name: a.label });
    LP.sureBtn($('#nyDel'), async () => { const p = await api.getSettings(); await api.setSettings({ yearArchive: (p.yearArchive || []).filter(x => x.id !== id) }); archive(); });
  }
  LP.newYear = open; LP.openArchive = () => archive();

  // ---------- الأزرار في «أدوات المعلمة» ----------
  const col = $('#tpYear');
  if (col) {
    const b1 = document.createElement('button'); b1.className = 'tb'; b1.id = 'tpNewYear'; b1.textContent = '🎓 ' + T('عام / فصل دراسي جديد');
    const b2 = document.createElement('button'); b2.className = 'tb'; b2.id = 'tpArchive'; b2.textContent = '📚 ' + T('الأعوام السابقة');
    col.append(b1, b2);
    b1.onclick = () => { LP.closePanels && LP.closePanels(); open('year'); };
    b2.onclick = () => { LP.closePanels && LP.closePanels(); archive(); };
  }
})();
