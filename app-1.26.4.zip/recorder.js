(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const api = window.api;
  const panel = $('#recPanel'), pill = $('#recPill');
  let opts = { mode: 'lesson', mic: true, micId: '', sys: false, cam: false, camId: '' };

  // ---------- اللوحة ----------
  const prevClose = LP.closePanels;
  LP.closePanels = () => { const a = panel.classList.contains('on'); panel.classList.remove('on'); const b = prevClose(); return a || b; };
  $('[data-rclose]').onclick = () => panel.classList.remove('on');

  async function fillDevices() {
    try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach(t => t.stop()); } catch {}
    let devs = [];
    try { devs = await navigator.mediaDevices.enumerateDevices(); } catch {}
    const fill = (sel, kind, cur, none) => {
      const list = devs.filter(d => d.kind === kind);
      sel.innerHTML = list.length ? list.map((d, i) => `<option value="${d.deviceId}">${(d.label || (none + ' ' + (i + 1))).replace(/</g, '&lt;')}</option>`).join('')
        : `<option value="">${I18N.t(none === 'مايكروفون' ? 'لا يوجد مايكروفون' : 'لا توجد كاميرا')}</option>`;
      if (cur && list.some(d => d.deviceId === cur)) sel.value = cur;
    };
    fill($('#recMicSel'), 'audioinput', opts.micId, 'مايكروفون');
    fill($('#recCamSel'), 'videoinput', opts.camId, 'كاميرا');
  }
  function showOpts() {
    $$('#recMode button').forEach(b => b.classList.toggle('on', b.dataset.v === opts.mode));
    $('#recMic').checked = opts.mic; $('#recSys').checked = opts.sys; $('#recCam').checked = opts.cam;
    $('#recMicSel').disabled = !opts.mic; $('#recCamSel').disabled = !opts.cam;
    $('#recNote').innerHTML = I18N.t(opts.mode === 'lesson'
      ? '«الدرس فقط»: يسجل منطقة الدرس مع رسمك عليه، بدون الشريط.'
      : '«الشاشة كاملة»: يسجل كل ما يظهر على الشاشة، حتى لو انتقلتِ إلى وورد أو أي برنامج.')
      + '<br>' + I18N.t('عند البدء يسألك البرنامج أين تحفظين الفيديو.');
  }
  const saveOpts = () => api.setSettings({ rec: opts });
  $$('#recMode button').forEach(b => b.onclick = () => { opts.mode = b.dataset.v; showOpts(); saveOpts(); });
  $('#recMic').onchange = e => { opts.mic = e.target.checked; showOpts(); saveOpts(); };
  $('#recSys').onchange = e => { opts.sys = e.target.checked; saveOpts(); };
  $('#recCam').onchange = e => { opts.cam = e.target.checked; showOpts(); saveOpts(); };
  $('#recMicSel').onchange = e => { opts.micId = e.target.value; saveOpts(); };
  $('#recCamSel').onchange = e => { opts.camId = e.target.value; saveOpts(); };

  $('#recBtn').onclick = () => {
    if (rec) { LP.toast(I18N.t('التسجيل يعمل الآن — استخدمي ⏹ في الشريط لإنهائه')); return; }
    LP.closePanels();
    panel.classList.add('on');
    showOpts(); fillDevices();
  };
  $('#recStart').onclick = () => { panel.classList.remove('on'); start(); };

  // ---------- التسجيل ----------
  let rec = null;            // { recorder, streams, timer, draw, file, chain, t0, pausedMs, pauseAt }
  const pickMime = () => {
    const c = ['video/mp4;codecs=avc1.42E01F,mp4a.40.2', 'video/mp4;codecs=avc1.4D401F,mp4a.40.2', 'video/mp4;codecs=avc1.42E01F,opus', 'video/mp4',
      'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    return c.find(m => { try { return MediaRecorder.isTypeSupported(m); } catch { return false; } }) || '';
  };
  const desktopVideo = (id) => ({ mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: id, maxWidth: 1920, maxHeight: 1080, maxFrameRate: 30 } });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const fmt = s => { s = Math.floor(s); const h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, x = s % 60;
    return (h ? h + ':' : '') + String(m).padStart(2, '0') + ':' + String(x).padStart(2, '0'); };

  async function countdown() {
    const cd = $('#countdown'), n = $('#cdNum');
    cd.classList.add('on');
    for (const k of [3, 2, 1]) {
      n.textContent = k; n.style.animation = 'none'; void n.offsetWidth; n.style.animation = '';
      await sleep(1000);
    }
    cd.classList.remove('on');
    await sleep(120);                    // حتى يختفي العدّ من الصورة
  }

  async function start() {
    const streams = [];
    const stopAll = () => streams.forEach(s => s.getTracks().forEach(t => t.stop()));
    try {
      const src = await api.recSources();
      const vid = opts.mode === 'lesson' ? src.window : src.screen;
      if (!vid) throw new Error('nosource');
      const desk = await navigator.mediaDevices.getUserMedia({ audio: false, video: desktopVideo(vid) });
      streams.push(desk);

      // الصوت
      const actx = new AudioContext();
      // يبدأ «خلّاط الصوت» صامتاً إن لم يُشغَّل مباشرة بعد ضغطة الزر (بعد العدّ التنازلي) — نشغّله إجبارياً
      try { await actx.resume(); } catch {}
      const dest = actx.createMediaStreamDestination();
      let hasAudio = false;
      if (opts.mic) {
        try {
          const m = await navigator.mediaDevices.getUserMedia({ audio: opts.micId ? { deviceId: { exact: opts.micId }, echoCancellation: true, noiseSuppression: true } : { echoCancellation: true, noiseSuppression: true } });
          streams.push(m); actx.createMediaStreamSource(m).connect(dest); hasAudio = true;
        } catch { LP.toast(I18N.t('تعذّر تشغيل المايكروفون — سيكون التسجيل بدون صوتك'), null, null, 3500); }
      }
      if (opts.sys && src.screen) {
        try {
          const sys = await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: 'desktop' } }, video: desktopVideo(src.screen) });
          streams.push(sys); sys.getVideoTracks().forEach(t => t.stop());
          if (sys.getAudioTracks().length) { actx.createMediaStreamSource(new MediaStream(sys.getAudioTracks())).connect(dest); hasAudio = true; }
        } catch { LP.toast(I18N.t('تعذّر تسجيل صوت الجهاز'), null, null, 3000); }
      }

      if ((opts.mic || opts.sys) && (!hasAudio || actx.state !== 'running')) LP.toast(I18N.t('تنبيه: التسجيل سيكون بدون صوت'), null, null, 4000);

      // الكاميرا
      let camV = null;
      if (opts.cam) {
        try {
          const c = await navigator.mediaDevices.getUserMedia({ video: opts.camId ? { deviceId: { exact: opts.camId }, width: 640, height: 480 } : { width: 640, height: 480 } });
          streams.push(c);
          camV = document.createElement('video'); camV.muted = true; camV.playsInline = true; camV.srcObject = c; await camV.play();
        } catch { LP.toast(I18N.t('تعذّر تشغيل الكاميرا'), null, null, 3000); }
      }

      // تجهيز الصورة
      const v = document.createElement('video'); v.muted = true; v.srcObject = desk; await v.play();
      for (let i = 0; i < 40 && !v.videoWidth; i++) await sleep(50);
      const canvas = document.createElement('canvas'), cx = canvas.getContext('2d');
      const crop = () => {
        if (opts.mode !== 'lesson') return { x: 0, y: 0, w: v.videoWidth, h: v.videoHeight };
        const k = v.videoWidth / window.innerWidth, r = $('#stage').getBoundingClientRect();
        return { x: r.left * k, y: r.top * k, w: r.width * k, h: r.height * k };
      };
      const c0 = crop();
      let W = Math.min(1920, Math.round(c0.w)), H = Math.round(W * c0.h / c0.w);
      W -= W % 2; H -= H % 2;
      canvas.width = W; canvas.height = H;
      const draw = () => {
        if (!v.videoWidth) return;
        const c = crop();
        cx.drawImage(v, c.x, c.y, c.w, c.h, 0, 0, W, H);
        if (camV && camV.videoWidth) {
          const r = Math.round(H * 0.12), px = r + 24, py = H - r - 24;
          cx.save(); cx.beginPath(); cx.arc(px, py, r, 0, Math.PI * 2); cx.closePath(); cx.clip();
          const s = Math.min(camV.videoWidth, camV.videoHeight);
          // صورة معكوسة مثل المرآة
          cx.translate(px * 2, 0); cx.scale(-1, 1);
          cx.drawImage(camV, (camV.videoWidth - s) / 2, (camV.videoHeight - s) / 2, s, s, px - r, py - r, r * 2, r * 2);
          cx.restore();
          cx.beginPath(); cx.arc(px, py, r, 0, Math.PI * 2); cx.lineWidth = 5; cx.strokeStyle = '#fff'; cx.stroke();
        }
      };
      draw();
      const drawT = setInterval(draw, 1000 / 30);
      const out = canvas.captureStream(30);
      if (hasAudio) dest.stream.getAudioTracks().forEach(t => out.addTrack(t));

      const mime = pickMime();
      const ext = mime.startsWith('video/mp4') ? 'mp4' : 'webm';
      const title = (!LP.isWelcome(LP.currentUrl()) && LP.currentTitle()) || I18N.t('شرح');

      const target = await api.recChoose({ name: title, ext });
      if (!target) { stopAll(); clearInterval(drawT); try { actx.close(); } catch {} LP.toast(I18N.t('أُلغي التسجيل')); return; }
      await countdown();
      const file = await api.recBegin(target);
      if (!file) throw new Error('nofile');
      const recorder = new MediaRecorder(out, { mimeType: mime || undefined, videoBitsPerSecond: 5000000, audioBitsPerSecond: 128000 });
      rec = { recorder, streams, drawT, file, chain: Promise.resolve(), t0: Date.now(), pausedMs: 0, pauseAt: 0, actx, stopAll };
      recorder.ondataavailable = e => {
        if (!e.data || !e.data.size) return;
        const r = rec;
        r.chain = r.chain.then(async () => { await api.recChunk(await e.data.arrayBuffer()); });
      };
      recorder.onstop = finish;
      recorder.start(1000);
      pill.classList.add('on'); pill.classList.remove('paused');
      rec.timer = setInterval(updateTime, 500); updateTime();
      LP.toast(I18N.t('بدأ التسجيل 🔴'), null, null, 1500);
    } catch (e) {
      stopAll();
      LP.toast(I18N.t('تعذّر بدء التسجيل'), null, null, 3000);
      console.error(e);
    }
  }

  function updateTime() {
    if (!rec) return;
    const now = rec.pauseAt || Date.now();
    $('#recTime').textContent = fmt((now - rec.t0 - rec.pausedMs) / 1000);
  }
  function pause() {
    if (!rec) return;
    const r = rec.recorder;
    if (r.state === 'recording') { r.pause(); rec.pauseAt = Date.now(); pill.classList.add('paused'); $('#recPause').textContent = '▶'; api.recPaused(true); }
    else if (r.state === 'paused') { r.resume(); rec.pausedMs += Date.now() - rec.pauseAt; rec.pauseAt = 0; pill.classList.remove('paused'); $('#recPause').textContent = '⏸'; api.recPaused(false); }
    updateTime();
  }
  function stop() {
    if (!rec || rec.stopping) return;
    rec.stopping = true;
    try { rec.recorder.stop(); } catch { finish(); }
  }
  async function finish() {
    const r = rec; if (!r) return;
    clearInterval(r.drawT); clearInterval(r.timer);
    try { await r.chain; } catch {}
    r.stopAll();
    try { r.actx.close(); } catch {}
    const file = await api.recEnd();
    rec = null;
    pill.classList.remove('on', 'paused'); $('#recPause').textContent = '⏸';
    if (file) LP.toast(I18N.t('تم حفظ التسجيل ✓'), I18N.t('فتح المجلد'), () => api.recShow(file), 9000);
  }
  $('#recPause').onclick = pause;
  $('#recStop').onclick = stop;
  api.onRecStopRequest(stop);

  (async () => { const s = await api.getSettings(); if (s.rec) opts = { ...opts, ...s.rec }; })();
})();
