// صفحة النتائج + الشهادات الثابتة + شهادات الشكر + إعدادات الشهادة
(() => {
  const $ = (s) => document.querySelector(s);
  const T = (s, v) => I18N.t(s, v);
  const api = window.api;
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const L = () => LP.session;
  const S = () => L() && L().S;

  const THANKS = [
    { id: 'hw', icon: '📚', label: 'الواجب', reason: 'لتميّزها في أداء الواجب' },
    { id: 'part', icon: '🙋‍♀️', label: 'المشاركة المتميزة', reason: 'لمشاركتها المتميزة في الحصة' },
    { id: 'coop', icon: '🤝', label: 'التعاون', reason: 'لتعاونها مع زميلاتها' },
    { id: 'crea', icon: '💡', label: 'الإبداع', reason: 'لإبداعها وأفكارها المميزة' },
    { id: 'order', icon: '📏', label: 'النظام', reason: 'لالتزامها بالنظام والانضباط' },
    { id: 'impr', icon: '📈', label: 'التحسّن', reason: 'لتحسّنها الملحوظ' }
  ];

  let prof = {};
  const cfg = () => (prof.cert ||= {});
  const saveCfg = () => api.setSettings({ cert: prof.cert });
  const types = () => [...THANKS.map(t => ({ ...t, icon: t.id === 'part' && window.LPG && LPG.ctx.cg === 'b' ? '🙋‍♂️' : t.icon, label: T(t.label), reason: T(t.reason) })), ...(prof.thanksTypes || [])];

  // ================= شارات الشكر (تتراكم عبر كل حصص الفصل) =================
  // كل شكر يظهر برمز نوعه، وكل عشرة تتجمع في ميدالية واحدة مكتوب داخلها 10
  const iconOf = (t) => t.icon || (types().find(x => x.id === t.type) || {}).icon || '🎖';
  function thanksLog() {
    const cd = L() && L().cd; if (!cd) return (S() && S().thanks) || [];
    if (!cd.thanksLog) { cd.thanksLog = []; for (const ss of cd.sessions || []) for (const t of ss.thanks || []) cd.thanksLog.push({ ...t, sid: ss.id }); }
    return cd.thanksLog;
  }
  const MEDAL = (n) => `<svg class="bd10" viewBox="0 0 40 48" aria-label="${n}"><path d="M8 0h9l5 14-6 6zM32 0h-9l-5 14 6 6z" fill="#3b82c4"/><path d="M13 0h4l5 14-3 3zM27 0h-4l-5 14 3 3z" fill="#e5484d"/><circle cx="20" cy="31" r="15" fill="#f5b400" stroke="#c98a00" stroke-width="2.5"/><circle cx="20" cy="31" r="11" fill="none" stroke="#fff3c4" stroke-width="1.2" opacity=".8"/><text x="20" y="31" text-anchor="middle" dominant-baseline="central" font-size="${n >= 100 ? 10 : 13}" font-weight="900" fill="#5c4500" font-family="Segoe UI,Tahoma,sans-serif">${n}</text></svg>`;
  function badgesHTML(name) {
    const list = thanksLog().filter(t => t.name === name).sort((a, b) => (a.at || 0) - (b.at || 0));
    if (!list.length) return '';
    const tens = Math.floor(list.length / 10), rest = list.slice(tens * 10);
    let h = tens > 3 ? MEDAL(tens * 10) : Array.from({ length: tens }, () => MEDAL(10)).join('');
    h += rest.map(t => `<span class="bdi" title="${esc(t.label || '')}">${esc(iconOf(t))}</span>`).join('');
    return ` <span class="bdg" title="${esc(T('{n} شكر', { n: list.length }))}">${h}</span>`;
  }
  LP.badgesHTML = badgesHTML;

  // ================= النقاط التراكمية وتقارير الفترة =================
  // من كل حصص الفصل (الحديثة كاملة + ملخصات القديمة)
  function totals(from, to, cdx) {
    const cd = cdx || (L() && L().cd); const by = {}; const sids = new Set();
    const add = (name) => (by[name] ||= { pts: 0, turns: 0, abs: 0, thanks: 0 });
    const log = (cd && cd.log) || [], logged = new Set(log.map(e => e.sid));
    // الحصص القديمة (قبل سجل الأحداث): تُحسب بتاريخ الحصة
    const all = [...((cd && cd.sessions) || []), ...((cd && cd.archive) || [])];
    const byCreated = new Map(all.map(x => [x.created, x]));
    for (const ss of all) {
      if (logged.has(ss.id)) continue;
      const t = ss.created || 0; if (t < from || t > to) continue; sids.add(ss.id);
      // الحصة المتابَعة نسخت نقاط الأصلية: نحسب الزيادة فقط
      const o = ss.from ? byCreated.get(ss.from) : null;
      for (const [k, v] of Object.entries(ss.pts || {})) add(k).pts += v - ((o && o.pts && o.pts[k]) || 0);
      for (const [k, v] of Object.entries(ss.turns || {})) add(k).turns += v - ((o && o.turns && o.turns[k]) || 0);
      for (const k of Object.keys(ss.absent || {})) add(k).abs++;
    }
    // الحصص الحديثة: كل حدث بوقته
    for (const e of log) {
      if (e.t < from || e.t > to) continue; sids.add(e.sid + '|' + new Date(e.t).toDateString());
      const x = add(e.n); if (e.k === 'p') x.pts += e.v; else if (e.k === 't') x.turns += e.v; else if (e.k === 'a') x.abs += e.v;
    }
    const tl = cdx ? (cdx.thanksLog || (cdx.sessions || []).flatMap(x => x.thanks || [])) : thanksLog();
    for (const t of tl) if ((t.at || 0) >= from && (t.at || 0) <= to) add(t.name).thanks++;
    return { by, sessions: sids.size };
  }
  LP.classTotals = totals;
  function rangeOf(r, f, t) {
    const now = new Date(), day = 864e5;
    if (r === 'week') { const d = new Date(now); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - d.getDay()); return [d.getTime(), Infinity, T('هذا الأسبوع')]; }
    if (r === 'month') { const d = new Date(now.getFullYear(), now.getMonth(), 1); return [d.getTime(), Infinity, T('هذا الشهر')]; }
    if (r === 'cweek' && LP.cal) { const n = LP.cal.at(); if (n && n.w) return [n.w.from, n.w.to + 864e5 - 1, n.week ? T('الأسبوع {n}', { n: n.week }) + ' — ' + n.term.name : n.term.name]; }
    if (r === 'term' && LP.cal) { const n = LP.cal.at() || {}, tm = n.term || LP.cal.lastEnded(); if (tm) { const [a, b] = LP.cal.termRange(tm); return [a, b, tm.name]; } }
    if (r === '3m') return [now.getTime() - 92 * day, Infinity, T('آخر 3 أشهر')];
    if (r === 'custom' && f) { const a = new Date(f).getTime(), b = t ? new Date(t).getTime() + day - 1 : Infinity; return [a, b, T('الفترة من {a} إلى {b}', { a: f, b: t || LP.fmtDay(Date.now()) })]; }
    return [0, Infinity, T('كل الحصص')];
  }
  let repF = '', repT = '';
  function reportView(r) {
    r = r || 'month'; prof.repRange = r; api.setSettings({ repRange: r });
    const [from, to, label] = rangeOf(r, repF, repT), tt = totals(from, to), dn = L().shortName;
    const names = L().cls ? (L().cls.students || []) : [];
    const rows = names.map(n => ({ n, ...(tt.by[n] || { pts: 0, turns: 0, abs: 0, thanks: 0 }) })).sort((a, b) => b.pts - a.pts || b.turns - a.turns || a.n.localeCompare(b.n, 'ar'));
    const topT = rows.slice().sort((a, b) => b.turns - a.turns || b.pts - a.pts).filter(x => x.turns > 0).slice(0, 3);
    const topP = rows.filter(x => x.pts > 0).slice(0, 3);
    const chip = (k, t) => `<button class="tchip ${r === k ? 'on' : ''}" data-r="${k}">${t}</button>`;
    card.innerHTML = `<div class="res-head"><button class="rbtn" id="rpBack">→ ${T('رجوع')}</button><h3>📊 ${T('تقرير الفترة')} — ${esc(L().cls ? L().cls.name : '')}</h3><span style="flex:1"></span><button class="rbtn" id="rX">✕</button></div>
      <div class="tchips">${LP.cal && LP.cal.terms.length ? chip('cweek', '📅 ' + T('هذا الأسبوع الدراسي')) + chip('term', '📘 ' + T('هذا الفصل الدراسي')) : ''}${chip('week', T('هذا الأسبوع'))}${chip('month', T('هذا الشهر'))}${chip('3m', T('آخر 3 أشهر'))}${chip('all', T('كل الحصص'))}${chip('custom', '📅 ' + T('من تاريخ إلى تاريخ'))}</div>
      <div class="throw" id="rpCustom" style="display:${r === 'custom' ? 'flex' : 'none'}"><label>${T('من')}</label><input type="date" id="rpF" value="${esc(repF)}"><label>${T('إلى')}</label><input type="date" id="rpT" value="${esc(repT)}"><button class="pri" id="rpGo">${T('عرض')}</button></div>
      <p class="rs-sub">${esc(label)} · ${T('{n} حصة', { n: tt.sessions })}</p>
      <div class="rp-tops">
        <div><h4>🙋 ${T('الأكثر مشاركة')}</h4>${topT.map((x, i) => `<button class="rp-top" data-cert="${esc(x.n)}">${['🥇', '🥈', '🥉'][i]} ${esc(dn(x.n))} <small>${T('{n} مشاركة', { n: x.turns })}</small></button>`).join('') || '<p class="muted">—</p>'}</div>
        <div><h4>⭐ ${T('الأكثر تفاعلاً (نقاطاً)')}</h4>${topP.map((x, i) => `<button class="rp-top" data-cert="${esc(x.n)}">${['🥇', '🥈', '🥉'][i]} ${esc(dn(x.n))} <small>${T('{n} نقطة', { n: x.pts })}</small></button>`).join('') || '<p class="muted">—</p>'}</div>
      </div>
      <p class="muted" style="margin:4px 0 8px">${T('اضغطي على الاسم لشهادة الفترة')}</p>
      <table class="rp-tb"><tr><th>#</th><th>${T('الاسم')}</th><th>${T('النقاط')}</th><th>${T('المشاركات')}</th><th>${T('الشكر')}</th><th>${T('الغياب')}</th></tr>
        ${rows.map((x, i) => `<tr data-cert="${esc(x.n)}"><td>${i + 1}</td><td>${esc(dn(x.n))}</td><td>${x.pts}</td><td>${x.turns}</td><td>${x.thanks || ''}</td><td>${x.abs ? `<em class="absb">${x.abs}</em>` : ''}</td></tr>`).join('')}</table>
      <div class="rs-acts"><button class="pri" id="rpExcel">📋 ${T('نسخ التقرير لإكسل')}</button></div>`;
    guardInputs();
    $('#rX').onclick = close; $('#rpBack').onclick = renderResults;
    card.querySelectorAll('[data-r]').forEach(b => b.onclick = () => reportView(b.dataset.r));
    if ($('#rpGo')) $('#rpGo').onclick = () => { repF = $('#rpF').value; repT = $('#rpT').value; reportView('custom'); };
    card.querySelectorAll('[data-cert]').forEach(b => b.onclick = () => { const x = rows.find(y => y.n === b.dataset.cert) || {}; certView({ kind: 'period', name: b.dataset.cert, label, pts: x.pts, turns: x.turns, range: r }); });
    $('#rpExcel').onclick = () => {
      const lines = [[T('الاسم'), T('النقاط'), T('المشاركات'), T('الشكر'), T('الغياب')].join('\t'), ...rows.map(x => [x.n, x.pts, x.turns, x.thanks, x.abs].join('\t'))];
      navigator.clipboard.writeText(label + '\n' + lines.join('\n')).then(() => LP.toast(T('نُسخ التقرير — الصقيه في إكسل')), () => LP.toast(T('تعذّر النسخ')));
    };
  }
  LP.openReport = async (r) => { await openResults(); reportView(r); };

  // ================= النافذة =================
  const dlg = document.createElement('div'); dlg.className = 'gdlg'; dlg.id = 'resDlg';
  dlg.innerHTML = '<div class="gdlg-card res-card" id="resCard"></div>';
  $('#stage').appendChild(dlg);
  const card = dlg.querySelector('#resCard');
  const close = () => dlg.classList.remove('on');
  dlg.addEventListener('click', e => { if (e.target === dlg) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && dlg.classList.contains('on')) { close(); e.stopPropagation(); e.preventDefault(); } }, true);
  const guardInputs = () => card.querySelectorAll('input,textarea,select').forEach(i => i.addEventListener('keydown', e => { if (e.key !== 'Escape') e.stopPropagation(); }));

  // ================= الحسابات =================
  function stats() {
    const s = S(), off = new Set(s.removed || []);
    const girls = s.groups.flatMap((g, gi) => g.map(n => ({ name: n, gi, pts: s.pts[n] || 0, turns: s.turns[n] || 0, off: off.has(n), thanks: (s.thanks || []).filter(t => t.name === n) })));
    girls.sort((a, b) => b.pts - a.pts || b.turns - a.turns || a.name.localeCompare(b.name, 'ar'));
    const best = Math.max(0, ...girls.map(g => g.pts));
    const tops = best > 0 ? girls.filter(g => g.pts === best).slice(0, 3) : [];
    const lead = Math.max(0, ...s.gpts);
    const groups = s.gpts.map((p, i) => ({ i, p, members: s.groups[i] })).sort((a, b) => b.p - a.p);
    const winners = lead > 0 ? groups.filter(g => g.p === lead) : [];
    return { girls, tops, groups, winners, lead };
  }

  // ================= صفحة النتائج =================
  async function openResults() {
    if (!S()) { await L().ensure(false); if (!S()) return; }
    prof = await api.getSettings();
    S().thanks ||= [];
    renderResults();
    dlg.classList.add('on');
  }
  LP.openResults = openResults;
  LP.thanks = async (name) => { await openResults(); certView({ kind: 'thanks', name }); };

  function renderResults() {
    const s = S(), st = stats(), G = L().GCOL, dn = L().shortName, allT = totals(0, Infinity).by;
    const allTie = st.groups.length > 1 && st.groups.every(g => g.p === st.groups[0].p);
    const banner = !st.winners.length || allTie ? `🌟 ${T('كل المجموعات أبدعت!')}`
      : `🏆 ${T('الفائزة: {g}', { g: st.winners.map(g => L().groupName(g.i)).join(' و ') })}`;
    // الأكثر مشاركة: حسب عدد المشاركات ثم النقاط
    const part = st.girls.slice().sort((a, b) => b.turns - a.turns || b.pts - a.pts || a.name.localeCompare(b.name, 'ar'));
    card.innerHTML = `<div class="rs-top">
        <div class="rs-hero"><div><h2>${T('أحسنتنّ يا نجمات!')}</h2>
          <p>${s.title ? T('تعلّمتنّ اليوم: {t}', { t: esc(s.title) }) : esc(L().cls ? L().cls.name : '')} · ${esc(L().fmtDate(s.created))}</p></div>
          <span class="rs-cup">🏆</span></div>
        <div class="rs-x"><button class="rbtn" id="rSet">⚙ ${T('إعدادات الشهادة')}</button><button class="rbtn" id="rX">✕</button></div>
      </div>
      <div class="rs-banner">${banner}</div>
      <div class="rs-glist">${st.groups.map(g => `<div class="${st.winners.includes(g) && !allTie ? 'win' : ''}"><i style="background:${G[g.i % G.length]}"></i><b>${esc(L().groupName(g.i))}</b><span>${T('{n} نقطة', { n: g.p })}</span></div>`).join('')}</div>
      <h4 class="rs-h">${T('نقاط كل طالبة')} <small>${T('اضغطي على اسم الطالبة لشهادة شكر')}</small></h4>
      <div class="rs-tables">${s.groups.map((g, gi) => `<div class="rs-tb" style="--gc:${G[gi % G.length]}"><div class="rs-tbh"><b>${esc(L().groupName(gi))}</b><span>${T('{n} نقطة', { n: s.gpts[gi] })}</span></div>
          <table><tr><th>${T('الاسم')}</th><th>${T('النقاط')}</th><th>${T('المشاركات')}</th><th title="${T('مجموع نقاطها في كل الحصص')}">${T('التراكمي')}</th></tr>
          ${g.map(n => { const x = st.girls.find(y => y.name === n); return `<tr class="${x.off ? 'off' : ''}" data-n="${esc(n)}"><td>${esc(dn(n))}${badgesHTML(n)}${s.absent && s.absent[n] ? ` <em class="absb">${T('غ')}</em>` : ''}</td><td>${x.pts}</td><td>${x.turns}</td><td class="cum">${(allT[n] || {}).pts || 0}</td></tr>`; }).join('')}</table></div>`).join('')}</div>
      <h4 class="rs-h">${T('من شاركت أكثر')}</h4>
      <ol class="rs-rank">${part.map((g, k) => `<li data-n="${esc(g.name)}"><span class="k">${k + 1}.</span><i style="background:${G[g.gi % G.length]}"></i><b>${esc(dn(g.name))}</b><small>${T('{t} مشاركات · {p} نقطة', { t: g.turns, p: g.pts })}</small></li>`).join('')}</ol>
      <div class="rs-acts"><button class="pri" id="rExcel">📋 ${T('نسخ النتائج لإكسل')}</button><button class="pri" id="rReport">📊 ${T('تقرير فترة (أسبوع، شهر…)')}</button></div>
      <h4 class="rs-h">${T('الشهادات')}</h4>
      <div class="rs-certs">
        <div class="rs-cert"><canvas id="rcTop"></canvas><div class="rs-cb">${st.tops.length ? `<button id="rTopBig">⛶ ${T('عرض كبير')}</button><button id="rTopCert">💾 ${T('فتح وحفظ')}</button>` : `<small>${T('لا توجد نقاط بعد في هذه الحصة.')}</small>`}</div></div>
        <div class="rs-cert"><canvas id="rcGrp"></canvas><div class="rs-cb">${st.winners.length ? `<button id="rGrpBig">⛶ ${T('عرض كبير')}</button><button id="rGroupCert">💾 ${T('فتح وحفظ')}</button>` : `<small>${T('لا توجد نقاط بعد في هذه الحصة.')}</small>`}</div></div>
      </div>
      <div class="rs-acts"><button id="rBack">↩ ${T('العودة إلى الدرس')}</button></div>`;
    $('#rX').onclick = close; $('#rBack').onclick = close;
    $('#rSet').onclick = () => settingsView();
    $('#rExcel').onclick = () => L().copyExcel();
    $('#rReport').onclick = () => reportView(prof.repRange || 'month');
    card.querySelectorAll('[data-n]').forEach(b => b.onclick = () => certView({ kind: 'thanks', name: b.dataset.n }));
    // معاينة الشهادتين
    const topSpec = () => { const g = st.tops[0]; return { title: T('شهادة تميّز'), to: T('تُمنح للطالبة'), name: g ? g.name : T('اسم الطالبة'), reason: T('لأنها الأكثر مشاركة وتفاعلاً في الحصة'), detail: '', extra: g ? `${L().groupName(g.gi)}   ·   ${T('{n} نقطة', { n: g.pts })}` : '' }; };
    const grpSpec = () => { const w = st.winners[0]; return w ? { title: T('شهادة تميّز'), to: T('تُمنح لـ'), name: L().groupName(w.i), reason: T('لفوزها بالمركز الأول في الحصة'), detail: s.groups[w.i].join('، '), extra: T('{n} نقطة', { n: s.gpts[w.i] }) }
      : { title: T('شهادة تميّز'), to: T('تُمنح لـ'), name: T('المجموعة الفائزة'), reason: T('لفوزها بالمركز الأول في الحصة'), detail: '', extra: '' }; };
    paintCert($('#rcTop'), topSpec()); paintCert($('#rcGrp'), grpSpec());
    if ($('#rTopBig')) { $('#rTopBig').onclick = () => bigShow($('#rcTop')); $('#rTopCert').onclick = () => certView({ kind: 'top' }); }
    if ($('#rGrpBig')) { $('#rGrpBig').onclick = () => bigShow($('#rcGrp')); $('#rGroupCert').onclick = () => certView({ kind: 'group' }); }
  }

  // ================= عرض الشهادة =================
  async function certView(o) {
    const st = stats(), s = S();
    let who = o.kind === 'top' ? (st.tops[0] || {}).name : o.name;
    let gi = o.kind === 'group' ? (st.winners[0] || {}).i : -1;
    let ttype = o.type || (prof.lastThanks && types().find(t => t.id === prof.lastThanks)) || types()[0];
    let custom = '';
    const spec = () => {
      if (o.kind === 'group') return { title: T('شهادة تميّز'), to: T('تُمنح لـ'), name: L().groupName(gi), reason: T('لفوزها بالمركز الأول في الحصة'),
        detail: s.groups[gi].join('، '), extra: T('{n} نقطة', { n: s.gpts[gi] }) };
      const sc = LP.studentCtx ? LP.studentCtx(who) : null;     // صيغة الطالب نفسه (في الفصل المختلط)
      if (o.kind === 'period') return { title: T('شهادة تميّز'), to: I18N.t('تُمنح للطالبة', null, sc), name: who, reason: I18N.t('لأنها الأكثر مشاركة وتفاعلاً خلال {p}', { p: o.label }, sc),
        detail: '', extra: T('{n} نقطة', { n: o.pts || 0 }) + '   ·   ' + T('{n} مشاركة', { n: o.turns || 0 }) };
      if (o.kind === 'top') { const g = st.girls.find(x => x.name === who) || {}; return { title: T('شهادة تميّز'), to: I18N.t('تُمنح للطالبة', null, sc), name: who, reason: I18N.t('لأنها الأكثر مشاركة وتفاعلاً في الحصة', null, sc),
        detail: '', extra: `${L().groupName(g.gi)}   ·   ${T('{n} نقطة', { n: g.pts || 0 })}` }; }
      const base = THANKS.find(x => x.id === ttype.id);
      const reason = ttype.id === 'custom' ? custom : base ? I18N.t(base.reason, null, sc) : ttype.reason;
      return { title: T('شهادة شكر وتقدير'), to: I18N.t('تُقدَّم للطالبة', null, sc), name: who, reason, detail: '', extra: '' };
    };
    const head = o.kind === 'group' ? '🏆 ' + T('شهادة المجموعة الفائزة') : o.kind === 'top' || o.kind === 'period' ? '🏅 ' + T('شهادة الأكثر مشاركة') : '🎖 ' + T('شهادة شكر') + ' — ' + esc(who);
    const chooser = o.kind === 'top' && st.tops.length > 1 ? `<div class="gdlg-row" style="margin:0 0 8px">${st.tops.map(g => `<button class="${g.name === who ? 'pri' : ''}" data-w="${esc(g.name)}">${esc(L().shortName(g.name))}</button>`).join('')}</div>`
      : o.kind === 'group' && st.winners.length > 1 ? `<div class="gdlg-row" style="margin:0 0 8px">${st.winners.map(g => `<button class="${g.i === gi ? 'pri' : ''}" data-g="${g.i}">${esc(L().groupName(g.i))}</button>`).join('')}</div>` : '';
    const typeChips = () => o.kind !== 'thanks' ? '' : `<div class="tchips">${types().map(t => `<button class="tchip ${ttype.id === t.id ? 'on' : ''}" data-t="${esc(t.id)}">${t.icon} ${esc(t.label)}${t.mine ? ' <span class="tdel" data-del="' + esc(t.id) + '">✕</span>' : ''}</button>`).join('')}
        <button class="tchip ${ttype.id === 'custom' ? 'on' : ''}" data-t="custom">✎ ${T('نص تكتبينه')}</button><button class="tchip add" id="tAddType">＋ ${T('نوع جديد')}</button></div>
        <div id="tCustomRow" style="display:${ttype.id === 'custom' ? 'flex' : 'none'}" class="throw"><input id="tCustom" dir="auto" placeholder="${T('مثال: لحرصها على الحضور مبكراً')}" value="${esc(custom)}"></div>
        <div id="tAddRow" style="display:none" class="throw"><input id="tAddIcon" value="🌟" style="width:52px;text-align:center"><input id="tAddLabel" placeholder="${T('اسم النوع')}"><input id="tAddReason" dir="auto" placeholder="${T('السبب كما يظهر في الشهادة: لـ…')}" style="flex:2"><button class="pri" id="tAddOk">${T('إضافة')}</button></div>`;
    const draw = async () => {
      card.innerHTML = `<div class="res-head"><button class="rbtn" id="cBack">→ ${T('رجوع')}</button><h3>${head}</h3><span style="flex:1"></span><button class="rbtn" id="cSet">⚙ ${T('إعدادات الشهادة')}</button><button class="rbtn" id="rX">✕</button></div>
        ${chooser}${typeChips()}
        <div class="cert-wrap"><canvas id="certCanvas" width="1200" height="820"></canvas></div>
        <div class="gdlg-row"><button class="pri" id="cSave">💾 ${T('حفظ الشهادة')}</button><button id="cCopy">📋 ${T('نسخ الصورة')}</button>
          ${o.kind === 'thanks' ? `<button id="cLog">✓ ${T('تسجيل الشكر فقط')}</button>` : ''}
          <button id="cBig">⛶ ${T('عرض كبير')}</button>${LP.cal && LP.cal.value() ? `<button id="cVal" class="${cfg().showValue !== false ? 'pri' : ''}">🌟 ${T('قيمة الشهر')}</button>` : ''}</div>`;
      guardInputs();
      $('#rX').onclick = close; $('#cBack').onclick = o.kind === 'period' ? () => reportView(o.range) : renderResults; $('#cSet').onclick = () => settingsView(() => certView({ ...o, name: who, type: ttype }));
      card.querySelectorAll('[data-w]').forEach(b => b.onclick = () => { who = b.dataset.w; draw(); });
      card.querySelectorAll('[data-g]').forEach(b => b.onclick = () => { gi = +b.dataset.g; draw(); });
      card.querySelectorAll('[data-t]').forEach(b => b.onclick = (e) => {
        if (e.target.dataset.del) { prof.thanksTypes = (prof.thanksTypes || []).filter(t => t.id !== e.target.dataset.del); api.setSettings({ thanksTypes: prof.thanksTypes }); if (ttype.id === e.target.dataset.del) ttype = types()[0]; draw(); return; }
        ttype = b.dataset.t === 'custom' ? { id: 'custom', icon: '✎', label: T('نص خاص') } : types().find(t => t.id === b.dataset.t);
        if (ttype.id !== 'custom') { prof.lastThanks = ttype.id; api.setSettings({ lastThanks: ttype.id }); }
        draw();
      });
      if ($('#tCustom')) $('#tCustom').oninput = (e) => { custom = e.target.value; paint(); };
      if (ttype.id === 'custom') setTimeout(() => { const i = $('#tCustom'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 30);
      if ($('#tAddType')) $('#tAddType').onclick = () => { $('#tAddRow').style.display = 'flex'; $('#tAddLabel').focus(); };
      if ($('#tAddOk')) $('#tAddOk').onclick = () => {
        const label = $('#tAddLabel').value.trim(), reason = $('#tAddReason').value.trim();
        if (!label) return $('#tAddLabel').focus();
        const t = { id: 'u' + Date.now(), icon: $('#tAddIcon').value.trim() || '🌟', label, reason: reason || label, mine: true };
        prof.thanksTypes = [...(prof.thanksTypes || []), t]; api.setSettings({ thanksTypes: prof.thanksTypes });
        ttype = t; draw();
      };
      const paint = () => paintCert($('#certCanvas'), spec());
      await paint();
      const fname = () => { const sp = spec(); return `${o.kind === 'thanks' ? T('شهادة شكر') : sp.title} - ${sp.name}`; };
      const logThanks = () => {
        if (o.kind !== 'thanks') return;
        const sp = spec(); if (!sp.reason) return;
        const entry = { name: who, type: ttype.id, icon: ttype.id === 'custom' ? '🎖' : ttype.icon, label: ttype.id === 'custom' ? T('نص خاص') : ttype.label, text: sp.reason, at: Date.now() };
        thanksLog(); s.thanks.push(entry);
        const cd = L().cd; if (cd) cd.thanksLog.push({ ...entry, sid: s.id });
        L().save();
      };
      $('#cSave').onclick = async () => {
        if (o.kind === 'thanks' && !spec().reason) { LP.toast(T('اكتبي نص الشكر أولاً')); return; }
        if (await api.savePng($('#certCanvas').toDataURL('image/png'), fname())) { logThanks(); LP.toast(T('تم حفظ الشهادة')); }
      };
      $('#cCopy').onclick = () => $('#certCanvas').toBlob(async (b) => {
        try { await navigator.clipboard.write([new ClipboardItem({ 'image/png': b })]); logThanks(); LP.toast(T('نُسخت الشهادة — الصقيها في تيمز أو وورد')); }
        catch { LP.toast(T('تعذّر النسخ')); }
      });
      if ($('#cLog')) $('#cLog').onclick = () => { if (!spec().reason) { LP.toast(T('اكتبي نص الشكر أولاً')); return; } logThanks(); LP.toast(T('سُجّل الشكر لـ {n} ✓', { n: L().shortName(who) })); renderResults(); };
      $('#cBig').onclick = () => bigShow($('#certCanvas'));
      if ($('#cVal')) $('#cVal').onclick = () => { cfg().showValue = cfg().showValue === false; saveCfg(); draw(); };
    };
    draw();
  }
  function bigShow(c) {
    const ov = document.createElement('div'); ov.className = 'cert-big';
    const im = new Image(); im.src = c.toDataURL('image/png'); ov.appendChild(im);
    ov.onclick = () => ov.remove();
    document.body.appendChild(ov);
    const k = (e) => { if (e.key === 'Escape') { ov.remove(); document.removeEventListener('keydown', k, true); e.stopPropagation(); } };
    document.addEventListener('keydown', k, true);
  }

  // ================= الرسم =================
  const imgCache = new Map();
  const loadImg = (src) => {
    if (!src) return Promise.resolve(null);
    if (imgCache.has(src)) return imgCache.get(src);
    const p = new Promise(res => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = src; });
    imgCache.set(src, p); return p;
  };
  async function paintCert(c, sp) {
    const cf = cfg(), s = S();
    const [logo, bg] = await Promise.all([loadImg(cf.logo), loadImg(cf.bg)]);
    const W = 1200, H = bg ? Math.round(Math.max(600, Math.min(1700, W * bg.height / bg.width))) : 820;
    c.width = W; c.height = H;
    const x = c.getContext('2d');
    const ac = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#ff7a3d';
    const rtl = I18N.dir() === 'rtl';
    const f = (w, sz) => `${w} ${Math.round(sz * (cf.scale || 1))}px "Segoe UI", Tahoma, Arial`;
    x.direction = rtl ? 'rtl' : 'ltr'; x.textAlign = 'center'; x.textBaseline = 'alphabetic';
    const fit = (txt, w, sz, maxW) => { let k = sz; x.font = f(w, k); while (x.measureText(txt).width > maxW && k > 18) { k -= 2; x.font = f(w, k); } };
    const subject = cf.subject || (s && s.subject) || '';
    const teacher = cf.teacher !== undefined ? cf.teacher : ((LP.auth && LP.auth.user && !LP.auth.user.guest && LP.auth.user.name) || '');
    const date = L().fmtDate(s ? s.created : Date.now());
    const cval = cf.showValue !== false && LP.cal ? LP.cal.value(s ? s.created : Date.now()) : '';
    const valTxt = cval ? T('قيمة الشهر: {v}', { v: cval }) : '';
    if (bg) {
      x.drawImage(bg, 0, 0, W, H);
      const dark = cf.color === 'light' ? '#ffffff' : cf.color && cf.color.startsWith('#') ? cf.color : '#222222';
      const cx = W / 2 + (cf.posX || 0) * W / 100, cy = H * (0.5 + (cf.posY || 0) / 100);
      const lines = [
        [sp.title, 900, 64, cf.color === 'light' ? '#fff' : ac, cf.hideTitle],
        [sp.to, 500, 30, dark],
        [sp.name, 900, 66, cf.color === 'light' ? '#fff' : ac],
        [sp.reason, 700, 34, dark],
        [sp.detail, 500, 26, dark],
        [[sp.extra, date, valTxt].filter(Boolean).join('   ·   '), 500, 26, dark],
        [[subject ? T('المادة: {s}', { s: subject }) : '', teacher ? T('المعلمة: {t}', { t: teacher }) : ''].filter(Boolean).join('   ·   '), 600, 26, dark]
      ].filter(l => l[0] && !l[4]);
      const gap = (sz) => sz * (cf.scale || 1) * 1.55;
      const total = lines.reduce((a, l) => a + gap(l[2]), 0);
      let y = cy - total / 2;
      for (const [t, w, sz, col] of lines) { y += gap(sz); fit(t, w, sz, W * 0.8); x.fillStyle = col; x.fillText(t, cx, y - gap(sz) * 0.3); }
      if (logo && cf.logoOnBg) drawLogo(x, logo, rtl, W);
      return;
    }
    // التصميم الافتراضي
    x.fillStyle = '#fffaf3'; x.fillRect(0, 0, W, H);
    x.strokeStyle = ac; x.lineWidth = 18; x.strokeRect(30, 30, W - 60, H - 60);
    x.strokeStyle = '#f5b400'; x.lineWidth = 4; x.strokeRect(60, 60, W - 120, H - 120);
    const G = L().GCOL; let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 36; i++) { x.fillStyle = G[i % G.length] + '55'; x.beginPath(); x.arc((i % 4 < 2 ? 95 + rnd() * 200 : W - 295 + rnd() * 200), (i % 2 ? H - 170 : 85) + rnd() * 70, 3 + rnd() * 6, 0, 7); x.fill(); }
    if (logo) drawLogo(x, logo, rtl, W);
    let top = 150;
    if (cf.school) { fit(cf.school, 700, 30, W - 420); x.fillStyle = '#555'; x.fillText(cf.school, W / 2, 125); top = 190; }
    fit(sp.title, 900, 70, W - 260); x.fillStyle = '#333'; x.fillText('🏅 ' + sp.title, W / 2, top + 50);
    x.font = f(500, 32); x.fillStyle = '#666'; x.fillText(sp.to, W / 2, top + 120);
    fit(sp.name, 900, 70, W - 240); x.fillStyle = ac; x.fillText(sp.name, W / 2, top + 210);
    fit(sp.reason || ' ', 700, 36, W - 240); x.fillStyle = '#444'; x.fillText(sp.reason || '', W / 2, top + 285);
    let y = top + 345;
    if (sp.detail) {
      // أسماء المجموعة كاملة على عدة أسطر
      x.font = f(500, 22); x.fillStyle = '#666';
      const parts = sp.detail.split('، '), lines = []; let cur = '';
      for (const p of parts) { const t = cur ? cur + '، ' + p : p; if (x.measureText(t).width > W - 280 && cur) { lines.push(cur); cur = p; } else cur = t; }
      if (cur) lines.push(cur);
      lines.slice(0, 4).forEach((l, i) => x.fillText(l, W / 2, y + i * 32 - 6));
      y += Math.min(4, lines.length) * 32 + 14;
    }
    const info = [L().cls ? `${T('الفصل')}: ${L().cls.name}` : '', sp.extra, date, valTxt].filter(Boolean).join('   ·   ');
    fit(info, 500, 27, W - 260); x.fillStyle = '#666'; x.fillText(info, W / 2, y);
    // التذييل: المادة والمعلمة
    const fy = H - 105;
    x.font = f(600, 26); x.fillStyle = '#444';
    if (teacher) { x.font = f(600, 26); x.textAlign = rtl ? 'left' : 'right'; x.fillText(T('المعلمة: {t}', { t: teacher }), rtl ? 130 : W - 130, fy); }
    if (subject) { x.textAlign = rtl ? 'right' : 'left'; x.fillText(T('المادة: {s}', { s: subject }), rtl ? W - 130 : 130, fy); }
    x.textAlign = 'center';
  }
  function drawLogo(x, logo, rtl, W) {
    const h = 110, w = Math.min(220, h * logo.width / logo.height);
    x.drawImage(logo, rtl ? W - 90 - w : 90, 82, w, w * logo.height / logo.width);
  }
  LP.paintCert = paintCert;
  LP.openCertSettings = async () => { prof = await api.getSettings(); if (L() && !S()) await L().ensure(false); settingsView(() => close()); dlg.classList.add('on'); };

  // ================= إعدادات الشهادة =================
  const shrink = (dataUrl, max, type = 'image/png', q) => new Promise(res => {
    const im = new Image();
    im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)); const c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL(type, q)); };
    im.onerror = () => res(null); im.src = dataUrl;
  });
  async function pickImage(max, type, q) {
    const r = await api.readImage(); if (!r) return null;
    if (r.err) { LP.toast(T(r.err === 'big' ? 'الصورة كبيرة جداً (أكثر من 6 ميجا)' : 'تعذّر قراءة الملف')); return null; }
    return shrink(r.data, max, type, q);
  }
  function settingsView(back) {
    const cf = cfg();
    const defTeacher = (LP.auth && LP.auth.user && !LP.auth.user.guest && LP.auth.user.name) || '';
    const sample = { title: T('شهادة شكر وتقدير'), to: T('تُقدَّم للطالبة'), name: T('اسم الطالبة'), reason: T('لمشاركتها المتميزة في الحصة'), detail: '', extra: '' };
    card.innerHTML = `<div class="res-head"><button class="rbtn" id="cBack">→ ${T('رجوع')}</button><h3>⚙ ${T('إعدادات الشهادة')}</h3><span style="flex:1"></span><button class="rbtn" id="rX">✕</button></div>
      <div class="cset">
        <div class="cset-form lform">
          <p class="muted" style="margin:0">${T('كل الحقول اختيارية: اتركي الحقل فارغاً فلا يظهر في الشهادة.')}</p>
          <label>${T('اسم المدرسة')}<input id="csSchool" dir="auto" value="${esc(cf.school || '')}"></label>
          <label>${T('المادة')}<input id="csSubject" dir="auto" value="${esc(cf.subject || '')}" placeholder="${T('تُؤخذ من الدرس إن تركتِها فارغة')}"></label>
          <label>${T('اسم المعلمة')}<input id="csTeacher" dir="auto" value="${esc(cf.teacher !== undefined ? cf.teacher : defTeacher)}"></label>
          <div class="cs-row"><span>${T('الشعار')}</span>${cf.logo ? `<img src="${cf.logo}" class="cs-thumb">` : ''}<button id="csLogo">${cf.logo ? T('تغيير') : T('رفع شعار')}</button>${cf.logo ? `<button id="csLogoX">✕</button>` : ''}</div>
          <div class="cs-row"><span>${T('خلفية خاصة')}</span>${cf.bg ? `<img src="${cf.bg}" class="cs-thumb">` : ''}<button id="csBg">${cf.bg ? T('تغيير') : T('رفع صورة خلفية')}</button>${cf.bg ? `<button id="csBgX">✕</button>` : ''}</div>
          ${cf.bg ? `<div class="cs-bgopts">
            <p class="muted" style="margin:0">${T('يُكتب النص فوق صورتك. حرّكي موضع النص حتى يناسب التصميم.')}</p>
            <label>${T('موضع النص: أعلى ↔ أسفل')}<input type="range" id="csPosY" min="-35" max="35" value="${cf.posY || 0}"></label>
            <label>${T('موضع النص: يمين ↔ يسار')}<input type="range" id="csPosX" min="-30" max="30" value="${-(cf.posX || 0)}"></label>
            <label>${T('حجم الخط')}<input type="range" id="csScale" min="60" max="140" value="${Math.round((cf.scale || 1) * 100)}"></label>
            <div class="cs-row"><span>${T('لون النص')}</span>
              <button data-col="" class="${!cf.color ? 'on' : ''}">${T('غامق')}</button><button data-col="light" class="${cf.color === 'light' ? 'on' : ''}">${T('فاتح')}</button>
              <input type="color" id="csColor" value="${cf.color && cf.color.startsWith('#') ? cf.color : '#222222'}"></div>
            <label class="impT"><input type="checkbox" id="csHideTitle" ${cf.hideTitle ? 'checked' : ''}><span>${T('إخفاء عنوان الشهادة (إن كان مكتوباً في الصورة)')}</span></label>
            <label class="impT"><input type="checkbox" id="csLogoOnBg" ${cf.logoOnBg ? 'checked' : ''}><span>${T('إظهار الشعار فوق الخلفية')}</span></label>
          </div>` : ''}
        </div>
        <div class="cert-wrap"><canvas id="certCanvas" width="1200" height="820"></canvas></div>
      </div>`;
    guardInputs();
    const repaint = () => paintCert($('#certCanvas'), sample);
    const set = (k, v) => { cf[k] = v; saveCfg(); repaint(); };
    $('#rX').onclick = close;
    $('#cBack').onclick = () => (back ? back() : renderResults());
    $('#csSchool').oninput = e => set('school', e.target.value.trim());
    $('#csSubject').oninput = e => set('subject', e.target.value.trim());
    $('#csTeacher').oninput = e => set('teacher', e.target.value.trim());
    $('#csLogo').onclick = async () => { const d = await pickImage(400); if (d) { cf.logo = d; saveCfg(); settingsView(back); } };
    if ($('#csLogoX')) $('#csLogoX').onclick = () => { delete cf.logo; saveCfg(); settingsView(back); };
    $('#csBg').onclick = async () => { const d = await pickImage(1800, 'image/jpeg', 0.88); if (d) { cf.bg = d; saveCfg(); settingsView(back); } };
    if ($('#csBgX')) $('#csBgX').onclick = () => { delete cf.bg; saveCfg(); settingsView(back); };
    if ($('#csPosY')) {
      $('#csPosY').oninput = e => set('posY', +e.target.value);
      $('#csPosX').oninput = e => set('posX', -e.target.value);
      $('#csScale').oninput = e => set('scale', e.target.value / 100);
      card.querySelectorAll('[data-col]').forEach(b => b.onclick = () => { set('color', b.dataset.col); card.querySelectorAll('[data-col]').forEach(y => y.classList.toggle('on', y === b)); });
      $('#csColor').oninput = e => { set('color', e.target.value); card.querySelectorAll('[data-col]').forEach(y => y.classList.remove('on')); };
      $('#csHideTitle').onchange = e => set('hideTitle', e.target.checked);
      $('#csLogoOnBg').onchange = e => set('logoOnBg', e.target.checked);
    }
    repaint();
  }

  document.addEventListener('lp-auth', () => { close(); imgCache.clear(); });
})();
