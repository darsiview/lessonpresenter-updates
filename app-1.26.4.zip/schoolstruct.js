// هيكل المدرسة (مراحل ← صفوف ← فصول)، أسماء كل فصل، ربط المعلمات وطلبات الربط، و«فصول المدرسة» عند المعلمة
(() => {
  const $ = (s) => document.querySelector(s);
  const api = window.api;
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const norm = (s) => String(s ?? '').replace(/\s+/g, ' ').trim().replace(/[إأآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const call = async (op, ...a) => { const r = await api.school(op, ...a); if (r && r.err) { const e = new Error(r.err); throw e; } return r ? r.v : null; };
  const fail = (e) => LP.toast(T(e && e.message === 'net' ? 'لا يوجد اتصال بالإنترنت' : e && e.message === 'cdenied' ? 'لا توجد صلاحية لهذا العمل (أو قواعد السحابة لم تُحدَّث بعد).' : 'تعذّر الاتصال بالسحابة، حاولي لاحقاً'), null, null, 5000);

  const PRESETS = {
    kg: { name: 'رياض الأطفال', grades: [['المستوى الأول', 'ر1'], ['المستوى الثاني', 'ر2'], ['المستوى الثالث', 'ر3']] },
    p: { name: 'الابتدائية', grades: [['الصف الأول', '1'], ['الصف الثاني', '2'], ['الصف الثالث', '3'], ['الصف الرابع', '4'], ['الصف الخامس', '5'], ['الصف السادس', '6']] },
    m: { name: 'المتوسطة', grades: [['الأول المتوسط', '1م'], ['الثاني المتوسط', '2م'], ['الثالث المتوسط', '3م']] },
    s: { name: 'الثانوية', grades: [['الأول الثانوي', '1ث'], ['الثاني الثانوي', '2ث'], ['الثالث الثانوي', '3ث']] }
  };
  const emptyS = () => ({ stages: [], grades: [], classes: [] });
  const loadS = async (sid) => { const d = await call('getData', sid, 'structure'); return d && d.stages ? { stages: d.stages, grades: d.grades || [], classes: d.classes || [] } : emptyS(); };
  const saveS = (sid, S) => call('setData', sid, 'structure', S);
  const gradeOf = (S, gid) => S.grades.find(g => g.id === gid) || {};
  const stageOf = (S, sid2) => S.stages.find(x => x.id === sid2) || {};

  // =============== الإدارة: الهيكل والأسماء ===============
  async function tabStructure(body, info, _call, rerender) {
    const canS = info.perms.includes('structure'), canN = info.perms.includes('students');
    body.innerHTML = '<div class="sc-load">⏳</div>';
    let S, counts = {};
    try { S = await loadS(info.sid); const rs = await call('listRoster', info.sid); for (const r of rs || []) counts[r.id] = (r.names || []).length; }
    catch (e) { fail(e); body.innerHTML = ''; return; }
    const save = async () => { try { await saveS(info.sid, S); } catch (e) { fail(e); } };
    const draw = () => {
      body.innerHTML = `<p class="tnote">${T('المراحل ← الصفوف ← الفصول. اضغطي على الفصل لكتابة أسمائه أو تعديلها.')}</p>
        ${S.stages.map(st => `<section class="ss-stage"><div class="ss-sh"><b>${esc(st.name)}</b>${canS ? `<button class="sc-mini" data-delst="${st.id}" title="${esc(T('حذف المرحلة'))}">🗑</button>` : ''}</div>
          ${S.grades.filter(g => g.stage === st.id).map(g => `<div class="ss-grade"><span class="ss-gn">${esc(g.name)}</span>
            <span class="ss-cls">${S.classes.filter(c => c.grade === g.id).map(c => `<button class="ss-c" data-c="${c.id}">${esc(c.name)} <small>${counts[c.id] ? T('{n} اسماً', { n: counts[c.id] }) : T('بلا أسماء')}</small></button>`).join('')}
            ${canS ? `<button class="ss-add" data-addc="${g.id}">＋ ${T('فصل')}</button>` : ''}</span></div>`).join('')}</section>`).join('')}
        ${canS ? `<div class="gdlg-row ss-addst">${Object.entries(PRESETS).filter(([k]) => !S.stages.some(x => x.kind === k)).map(([k, p]) => `<button data-st="${k}">＋ ${T(p.name)}</button>`).join('')}</div>` : ''}
        ${canN ? `<div class="gdlg-row"><button class="pri" id="ssUp">📤 ${T('رفع أسماء المدرسة (Excel)')}</button><button id="ssTpl">📥 ${T('قالب بفصول المدرسة')}</button></div>
          <p class="tnote">${T('ملف واحد لكل المدرسة (القالب أو ملف نظام نور)، وتتوزع الأسماء على الفصول حسب عمود الفصل.')}</p>` : ''}`;
      body.querySelectorAll('[data-st]').forEach(b => b.onclick = async () => {
        const p = PRESETS[b.dataset.st], st = { id: uid(), kind: b.dataset.st, name: T(p.name) };
        S.stages.push(st);
        p.grades.forEach(([n, sh]) => S.grades.push({ id: uid(), stage: st.id, name: T(n), short: sh }));
        await save(); draw();
      });
      body.querySelectorAll('[data-delst]').forEach(b => LP.sureBtn(b, async () => {
        const id = b.dataset.delst, gs = S.grades.filter(g => g.stage === id).map(g => g.id), cs = S.classes.filter(c => gs.includes(c.grade));
        S.stages = S.stages.filter(x => x.id !== id); S.grades = S.grades.filter(g => g.stage !== id); S.classes = S.classes.filter(c => !gs.includes(c.grade));
        await save(); for (const c of cs) call('delRoster', info.sid, c.id).catch(() => {}); draw();
      }));
      body.querySelectorAll('[data-addc]').forEach(b => b.onclick = async () => {
        const g = gradeOf(S, b.dataset.addc), k = S.classes.filter(c => c.grade === g.id).length + 1;
        S.classes.push({ id: uid(), grade: g.id, name: `${g.short || ''}/${k}` }); await save(); draw();
      });
      body.querySelectorAll('[data-c]').forEach(b => b.onclick = () => classEditor(S.classes.find(c => c.id === b.dataset.c)));
      const up = $('#ssUp'); if (up) up.onclick = uploadBook;
      const tp = $('#ssTpl'); if (tp) tp.onclick = template;
    };
    // محرر فصل: الاسم + الأسماء
    async function classEditor(c) {
      const g = gradeOf(S, c.grade);
      let r = null; try { r = await call('getRoster', info.sid, c.id); } catch {}
      body.innerHTML = `<div class="ss-ed"><div class="sc-row"><button data-back>→ ${T('رجوع')}</button><b>${esc(g.name)}</b></div>
        <div class="sc-row"><label>${T('اسم الفصل')}</label><input id="ssCn" value="${esc(c.name)}" ${canS ? '' : 'disabled'}></div>
        <label class="tlbl">${T('الأسماء (اسم في كل سطر)')}</label>
        <textarea id="ssNames" ${canN ? '' : 'disabled'} spellcheck="false">${esc(((r && r.names) || []).join('\n'))}</textarea>
        <div class="gdlg-row"><button class="pri" id="ssSave">${T('حفظ')}</button>${canS ? `<button class="warn" id="ssDel">🗑 ${T('حذف الفصل')}</button>` : ''}</div></div>`;
      body.querySelector('textarea').addEventListener('keydown', e => e.stopPropagation());
      body.querySelector('#ssCn').addEventListener('keydown', e => e.stopPropagation());
      body.querySelector('[data-back]').onclick = draw;
      $('#ssSave').onclick = async () => {
        try {
          const nm = $('#ssCn').value.trim(); if (canS && nm && nm !== c.name) { c.name = nm; await save(); }
          if (canN) { const names = [...new Set($('#ssNames').value.split('\n').map(x => x.replace(/\s+/g, ' ').trim()).filter(Boolean))]; await call('setRoster', info.sid, c.id, { grade: c.grade, stage: g.stage, name: c.name, names, sg: (r && r.sg && JSON.parse(r.sg || '{}')) || {} }); counts[c.id] = names.length; }
          LP.toast(T('تم الحفظ')); draw();
        } catch (e) { fail(e); }
      };
      const d = $('#ssDel'); if (d) LP.sureBtn(d, async () => { S.classes = S.classes.filter(x => x.id !== c.id); try { await save(); await call('delRoster', info.sid, c.id); } catch (e) { fail(e); } draw(); });
    }
    async function template() {
      const head = [T('الفصل'), T('اسم الطالب / الطالبة'), T('بنت / ولد (للفصل المختلط فقط)')];
      const rows = [head]; for (const c of S.classes) rows.push([c.name, '', '']);
      const r = await api.xlsxSave([{ name: T('الأسماء'), rows, widths: [12, 40, 26], boldRows: [0] }], { name: T('قالب أسماء {s}', { s: info.name }) });
      if (r && r.ok) LP.toast(T('تم حفظ القالب — اكتبي الأسماء فيه ثم ارفعيه'));
    }
    async function uploadBook() {
      const book = await api.xlsxOpenBook(T('اختاري ملف الأسماء')); if (!book) return;
      if (book.err) { LP.toast(T(book.err === 'xls' ? 'هذا ملف إكسل قديم (xls). افتحيه في إكسل واحفظيه بصيغة xlsx ثم ارفعيه.' : 'تعذّرت قراءة الملف'), null, null, 6000); return; }
      const res = LP.namesImportParse(book);
      const rows = [...res.classes.entries()].map(([name, v]) => {
        const c = S.classes.find(x => norm(x.name) === norm(name));
        const sh = String(name).split('/')[0].trim(), g = c ? null : S.grades.find(x => norm(x.short) === norm(sh));
        return { name, ...v, c, g, on: !!(c || g) };
      });
      body.innerHTML = `<h4>📤 ${T('مراجعة أسماء المدرسة')}</h4>
        <div class="nx-wrap"><table class="nx-tbl"><tbody>${rows.map((x, i) => `<tr><td><input type="checkbox" data-i="${i}" ${x.on ? 'checked' : ''} ${x.c || x.g ? '' : 'disabled'}></td><td><b>${esc(x.name)}</b></td><td>${T('{n} اسماً', { n: x.names.length })}</td>
          <td>${x.c ? `<span class="nx-ex">${T('يستبدل أسماء الفصل')}</span>` : x.g ? `<span class="nx-new">${T('فصل جديد في {g}', { g: esc(x.g.name) })}</span>` : `<span class="nx-ex">${T('لا يوجد صف مناسب — أضيفي المرحلة أولاً')}</span>`}</td></tr>`).join('')}</tbody></table></div>
        ${res.loose.length ? `<p class="tnote">${T('{n} اسماً بلا فصل لم تُضَف (أضيفي عمود «الفصل»).', { n: res.loose.length })}</p>` : ''}
        <div class="gdlg-row"><button class="pri" id="ssGo">✓ ${T('رفع الأسماء')}</button><button id="ssNo">${T('إلغاء')}</button></div>`;
      body.querySelectorAll('[data-i]').forEach(b => b.onchange = () => { rows[+b.dataset.i].on = b.checked; });
      $('#ssNo').onclick = draw;
      $('#ssGo').onclick = async () => {
        $('#ssGo').disabled = true; let n = 0;
        try {
          for (const x of rows.filter(r => r.on)) {
            let c = x.c; if (!c) { c = { id: uid(), grade: x.g.id, name: x.name }; S.classes.push(c); }
            const g = gradeOf(S, c.grade);
            await call('setRoster', info.sid, c.id, { grade: c.grade, stage: g.stage, name: c.name, names: x.names, sg: x.sg }); counts[c.id] = x.names.length; n++;
          }
          await save(); LP.toast(T('تم رفع أسماء {n} فصول', { n }), null, null, 4000);
        } catch (e) { fail(e); }
        draw();
      };
    }
    draw();
  }

  // =============== الإدارة: الربط والطلبات ===============
  async function tabLinks(body, info, _call, rerender) {
    body.innerHTML = '<div class="sc-load">⏳</div>';
    let S, ms, as, rq;
    try { [S, ms, as, rq] = await Promise.all([loadS(info.sid), call('members', info.sid), call('listAssign', info.sid), call('listRequests', info.sid)]); }
    catch (e) { fail(e); body.innerHTML = ''; return; }
    const A = Object.fromEntries((as || []).map(a => [a.id, a]));
    const lbl = (a) => [...(a.stages || []).map(id => stageOf(S, id).name), ...(a.grades || []).map(id => gradeOf(S, id).name), ...(a.classes || []).map(id => (S.classes.find(c => c.id === id) || {}).name)].filter(Boolean);
    const draw = () => {
      body.innerHTML = `${rq.length ? `<h4>🔔 ${T('طلبات الربط')} (${rq.length})</h4><div class="sc-list">${rq.map((r, i) => `<div class="sc-mem"><div class="sc-who"><b>${esc(r.name)}</b><small>${T('تطلب الربط بالفصل {c}', { c: esc((S.classes.find(c => c.id === r.cid) || {}).name || r.cname) })}</small></div>
          <button class="pri" data-ok="${i}">✓ ${T('موافقة')}</button><button data-no="${i}">✕</button></div>`).join('')}</div>` : ''}
        <h4>🔗 ${T('ربط المعلمات')}</h4><p class="tnote">${T('اربطي المعلمة بمرحلة أو صف أو فصل: ترى أسماء طالباته تلقائياً، ومنها أي فصل يُضاف لاحقاً لنفس الصف.')}</p>
        <div class="sc-list">${ms.filter(m => m.role !== 'owner').map(m => `<div class="sc-mem"><div class="sc-who"><b>${esc(m.name || m.email)}</b><small>${A[m.id] && lbl(A[m.id]).length ? esc(lbl(A[m.id]).join('، ')) : T('غير مربوطة')}</small></div><button data-ed="${esc(m.id)}">✎ ${T('ربط')}</button></div>`).join('') || `<p class="tnote">${T('لا توجد معلمات بعد.')}</p>`}</div>`;
      body.querySelectorAll('[data-ok]').forEach(b => b.onclick = async () => { const r = rq[+b.dataset.ok]; try { await call('approve', info.sid, r); A[r.uid] = { ...(A[r.uid] || {}), classes: [...new Set([...((A[r.uid] || {}).classes || []), r.cid])] }; rq.splice(+b.dataset.ok, 1); draw(); LP.toast(T('تمت الموافقة')); } catch (e) { fail(e); } });
      body.querySelectorAll('[data-no]').forEach(b => b.onclick = async () => { const r = rq[+b.dataset.no]; try { await call('delRequest', info.sid, r.id); rq.splice(+b.dataset.no, 1); draw(); } catch (e) { fail(e); } });
      body.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => picker(ms.find(m => m.id === b.dataset.ed)));
    };
    function picker(m) {
      const a = A[m.id] || {}, sel = { stages: new Set(a.stages || []), grades: new Set(a.grades || []), classes: new Set(a.classes || []) };
      body.innerHTML = `<div class="sc-row"><button data-back>→ ${T('رجوع')}</button><b>${esc(m.name || m.email)}</b></div>
        ${S.stages.map(st => `<section class="ss-stage"><label class="ss-pk"><input type="checkbox" data-k="stages" value="${st.id}" ${sel.stages.has(st.id) ? 'checked' : ''}> <b>${esc(st.name)}</b> <small>${T('(المرحلة كاملة)')}</small></label>
          ${S.grades.filter(g => g.stage === st.id).map(g => `<div class="ss-grade"><label class="ss-pk"><input type="checkbox" data-k="grades" value="${g.id}" ${sel.grades.has(g.id) ? 'checked' : ''}> ${esc(g.name)}</label>
            <span class="ss-cls">${S.classes.filter(c => c.grade === g.id).map(c => `<label class="ss-pk sm"><input type="checkbox" data-k="classes" value="${c.id}" ${sel.classes.has(c.id) ? 'checked' : ''}> ${esc(c.name)}</label>`).join('')}</span></div>`).join('')}</section>`).join('') || `<p class="tnote">${T('أضيفي المراحل والفصول أولاً من تبويب «الهيكل والأسماء».')}</p>`}
        <div class="gdlg-row"><button class="pri" data-save>${T('حفظ الربط')}</button></div>`;
      body.querySelector('[data-back]').onclick = draw;
      body.querySelectorAll('[data-k]').forEach(c => c.onchange = () => { c.checked ? sel[c.dataset.k].add(c.value) : sel[c.dataset.k].delete(c.value); });
      body.querySelector('[data-save]').onclick = async () => {
        const o = { stages: [...sel.stages], grades: [...sel.grades], classes: [...sel.classes] };
        try { await call('setAssign', info.sid, m.id, o); A[m.id] = o; LP.toast(T('تم حفظ الربط')); draw(); } catch (e) { fail(e); }
      };
    }
    draw();
  }

  LP.schoolExtraTabs = [
    { key: 'struct', label: () => '🏛 ' + T('الهيكل والأسماء'), show: (i) => i.perms.includes('structure') || i.perms.includes('students'), render: tabStructure },
    { key: 'links', label: () => '🔗 ' + T('الربط والطلبات'), show: (i) => i.perms.includes('structure') || i.perms.includes('members'), render: tabLinks }
  ];

  // =============== المعلمة: «🏫 فصول المدرسة» ===============
  const dlg = document.createElement('div'); dlg.className = 'gdlg'; dlg.id = 'scCls';
  dlg.innerHTML = '<div class="gdlg-card" style="max-width:620px;width:min(620px,94vw);max-height:88vh;overflow:auto"></div>';
  document.body.appendChild(dlg);
  const card = dlg.firstElementChild;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.classList.remove('on'); });
  const staffPerms = (sid) => { const s = LP.schoolOf(sid); return !!s && (s.perms || []).some(p => p === 'students' || p === 'structure'); };
  const pendingOf = (p, sid) => ((p.schoolReq || {})[sid] || []);

  async function openClasses() {
    const sid = LP.ctxHome(); if (!sid) return;
    dlg.classList.add('on');
    card.innerHTML = `<h3>🏫 ${T('فصول المدرسة')}</h3><div class="sc-load">⏳</div>`;
    let S, A;
    try { [S, A] = await Promise.all([loadS(sid), call('getAssign', sid)]); } catch (e) { fail(e); dlg.classList.remove('on'); return; }
    A = A || {};
    const all = staffPerms(sid);
    const can = (c) => all || (A.classes || []).includes(c.id) || (A.grades || []).includes(c.grade) || (A.stages || []).includes(gradeOf(S, c.grade).stage);
    const p = await api.getSettings(), mine = (p.classes || []).filter(c => c.home === sid);
    const pend = pendingOf(p, sid);
    const local = (c) => mine.find(x => x.src && x.src.cid === c.id);
    const rosters = {};
    // تحقق من التحديثات للفصول المضافة
    await Promise.all(S.classes.filter(c => can(c) && local(c)).map(async c => { try { rosters[c.id] = await call('getRoster', sid, c.id); } catch {} }));
    const row = (c) => {
      const L = local(c), r = rosters[c.id];
      let act;
      if (!can(c)) act = pend.includes(c.id) ? `<span class="nx-ex">⏳ ${T('بانتظار موافقة الإدارة')}</span>` : `<button data-req="${c.id}">🔑 ${T('طلب ربط')}</button>`;
      else if (L && r && (r.updated || 0) > (L.src.updated || 0)) act = `<button class="pri" data-upd="${c.id}">↻ ${T('تحديث متاح')}</button>`;
      else if (L) act = `<span class="nx-new">✓ ${T('في فصولي')}</span>`;
      else act = `<button class="pri" data-add="${c.id}">＋ ${T('إضافة إلى فصولي')}</button>`;
      return `<div class="sc-mem ${can(c) ? '' : 'locked'}"><div class="sc-who"><b>${esc(c.name)}</b><small>${can(c) ? '' : '🔒 ' + T('الأسماء تظهر بعد الربط')}</small></div>${act}</div>`;
    };
    const sorted = (cs) => cs.slice().sort((a, b) => (can(b) - can(a)));
    card.innerHTML = `<div class="sc-head" style="display:flex;align-items:center"><h3 style="margin:0">🏫 ${T('فصول المدرسة')}</h3><span style="flex:1"></span><button class="sc-x" data-x>✕</button></div>
      <p class="tnote">${T('فصولك المربوطة بها تظهر أسماؤها. ولغيرها اطلبي الربط، فتوافق الإدارة.')}</p>
      ${S.stages.map(st => `<section class="ss-stage"><div class="ss-sh"><b>${esc(st.name)}</b></div>${S.grades.filter(g => g.stage === st.id && S.classes.some(c => c.grade === g.id)).map(g => `<div class="ss-gt">${esc(g.name)}</div><div class="sc-list">${sorted(S.classes.filter(c => c.grade === g.id)).map(row).join('')}</div>`).join('')}</section>`).join('') || `<p class="muted">${T('لم تضع الإدارة فصول المدرسة بعد.')}</p>`}`;
    card.querySelector('[data-x]').onclick = () => dlg.classList.remove('on');
    card.querySelectorAll('[data-req]').forEach(b => b.onclick = async () => {
      const c = S.classes.find(x => x.id === b.dataset.req);
      try { await call('requestClass', sid, c.id, c.name); const pp = await api.getSettings(), all2 = { ...(pp.schoolReq || {}) }; all2[sid] = [...new Set([...(all2[sid] || []), c.id])]; await api.setSettings({ schoolReq: all2 }); LP.toast(T('أُرسل الطلب للإدارة')); openClasses(); }
      catch (e) { fail(e); }
    });
    card.querySelectorAll('[data-add]').forEach(b => b.onclick = () => addClass(sid, S.classes.find(x => x.id === b.dataset.add)));
    card.querySelectorAll('[data-upd]').forEach(b => b.onclick = () => updateClass(sid, S.classes.find(x => x.id === b.dataset.upd), rosters[b.dataset.upd]));
  }
  LP.openSchoolClasses = openClasses;

  const sgOf = (r) => { try { return JSON.parse(r.sg || '{}'); } catch { return {}; } };
  async function addClass(sid, c) {
    let r; try { r = await call('getRoster', sid, c.id); } catch (e) { fail(e); return; }
    const names = (r && r.names) || [], sg = r ? sgOf(r) : {};
    const p = await api.getSettings(), cls = p.classes || [];
    const same = cls.findIndex(x => x.home === sid && norm(x.name) === norm(c.name) && !(x.src && x.src.cid));
    const finish = async (mode) => {
      const pp = await api.getSettings(), list = pp.classes || [];
      let k = same >= 0 ? same : -1;
      if (k < 0) { list.push({ name: c.name, students: [], home: sid }); k = list.length - 1; }
      const t = list[k], cur = t.students || [];
      t.students = mode === 'mine' ? cur : mode === 'school' ? names.slice() : [...cur, ...names.filter(n => !cur.some(x => norm(x) === norm(n)))];
      if (Object.keys(sg).length) { t.sg = { ...(t.sg || {}), ...sg }; if (!t.gender) t.gender = 'mix'; }
      t.src = { cid: c.id, updated: (r && r.updated) || Date.now() };
      // «فصلي» الفارغ الذي أُنشئ تلقائياً لهذه المدرسة لم يعد لازماً
      const grp = pp.grp || {};
      for (let j = list.length - 1; j >= 0; j--) { const x = list[j]; if (j !== k && x.home === sid && x.name === T('فصلي') && !(x.students || []).length && !grp[LP.classKey(x)]) { list.splice(j, 1); if (j < k) k--; } }
      await api.setSettings({ classes: list, classIdx: k });
      document.dispatchEvent(new Event('lp-classes')); if (LP.reloadTools) LP.reloadTools();
      LP.toast(T('أُضيف الفصل {c} إلى فصولكِ', { c: c.name }), null, null, 3500);
      openClasses();
    };
    if (same < 0 || !(cls[same].students || []).length) return finish('school');
    card.innerHTML = `<h3>${T('الفصل {c} موجود عندكِ', { c: esc(c.name) })}</h3>
      <p>${T('عندكِ {a} اسماً، وفي المدرسة {b} اسماً. ماذا تختارين؟', { a: cls[same].students.length, b: names.length })}</p>
      <div class="gdlg-row" style="flex-direction:column;align-items:stretch"><button class="pri" data-m="merge">${T('دمج: إضافة الأسماء الناقصة فقط')}</button><button data-m="school">${T('استخدام أسماء المدرسة')}</button><button data-m="mine">${T('إبقاء أسمائي')}</button><button data-m="no">${T('إلغاء')}</button></div>
      <p class="tnote">${T('النقاط والمجموعات لا تُحذف في كل الأحوال.')}</p>`;
    card.querySelectorAll('[data-m]').forEach(b => b.onclick = () => b.dataset.m === 'no' ? openClasses() : finish(b.dataset.m));
  }
  async function updateClass(sid, c, r) {
    const p = await api.getSettings(), list = p.classes || [], k = list.findIndex(x => x.home === sid && x.src && x.src.cid === c.id); if (k < 0) return;
    const cur = list[k].students || [], names = (r && r.names) || [];
    const add = names.filter(n => !cur.some(x => norm(x) === norm(n))), rem = cur.filter(x => !names.some(n => norm(n) === norm(x)));
    card.innerHTML = `<h3>↻ ${T('تحديث أسماء {c}', { c: esc(c.name) })}</h3>
      ${add.length ? `<p><b>＋ ${T('جديدة ({n})', { n: add.length })}:</b> ${esc(add.join('، '))}</p>` : ''}
      ${rem.length ? `<p><b>− ${T('ليست في قائمة المدرسة ({n})', { n: rem.length })}:</b> ${esc(rem.join('، '))}</p>` : ''}
      ${!add.length && !rem.length ? `<p>${T('لا اختلاف في الأسماء.')}</p>` : ''}
      <div class="gdlg-row" style="flex-direction:column;align-items:stretch">${add.length ? `<button class="pri" data-m="add">${T('إضافة الجديدة فقط')}</button>` : ''}${rem.length || add.length ? `<button data-m="match">${T('مطابقة قائمة المدرسة تماماً')}</button>` : ''}<button data-m="skip">${T('تجاهل هذا التحديث')}</button></div>
      <p class="tnote">${T('نقاط الطالبات ومشاركاتهن السابقة لا تُحذف.')}</p>`;
    card.querySelectorAll('[data-m]').forEach(b => b.onclick = async () => {
      const m = b.dataset.m;
      if (m === 'add') list[k].students = [...cur, ...add]; else if (m === 'match') list[k].students = names.slice();
      if (r && r.sg) list[k].sg = { ...(list[k].sg || {}), ...sgOf(r) };
      list[k].src = { cid: c.id, updated: (r && r.updated) || Date.now() };
      await api.setSettings({ classes: list }); document.dispatchEvent(new Event('lp-classes')); if (LP.reloadTools) LP.reloadTools();
      if (m !== 'skip') LP.toast(T('تم تحديث أسماء {c}', { c: c.name }));
      openClasses();
    });
  }

  // =============== تنبيهات: موافقة الطلب (للمعلمة) وطلبات جديدة (للإدارة) ===============
  let staffTold = {};
  async function checks(sid) {
    if (!sid) return;
    const p = await api.getSettings(), pend = pendingOf(p, sid);
    if (pend.length) {
      let A = null, S = null, left = [];
      for (const cid of pend) {
        let r = null; try { r = await call('getRequest', sid, cid); } catch { left.push(cid); continue; }
        if (r) { left.push(cid); continue; }
        try { A = A || (await call('getAssign', sid)) || {}; S = S || await loadS(sid); } catch { left.push(cid); continue; }
        const c = S.classes.find(x => x.id === cid) || {}, ok = (A.classes || []).includes(cid) || (A.grades || []).includes(c.grade) || (A.stages || []).includes(gradeOf(S, c.grade).stage);
        LP.toast(ok ? T('وافقت الإدارة على ربطكِ بالفصل {c} ✓', { c: c.name || '' }) : T('لم تتم الموافقة على الفصل {c}', { c: c.name || '' }), ok ? T('فصول المدرسة') : null, ok ? openClasses : null, 8000);
      }
      const all = { ...(p.schoolReq || {}) }; all[sid] = left; await api.setSettings({ schoolReq: all });
    }
    const s = LP.schoolOf(sid);
    if (s && (s.perms || []).some(x => x === 'structure' || x === 'members') && !staffTold[sid]) {
      try { const rq = await call('listRequests', sid); if (rq && rq.length) { staffTold[sid] = 1; LP.toast(T('طلبات ربط جديدة ({n})', { n: rq.length }), T('عرض'), () => LP.openSchoolTab && LP.openSchoolTab(sid, 'links'), 10000); } } catch {}
    }
  }
  document.addEventListener('lp-ctx', (e) => setTimeout(() => checks(e.detail), 2500));

  // زر في «الفصول والأسماء» (يظهر داخل المدرسة فقط)
  const btn = $('#schoolClsBtn'); if (btn) btn.onclick = openClasses;
})();
