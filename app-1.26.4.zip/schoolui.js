// وضع المدرسة: الإنشاء برمز، الانضمام، الأعضاء، الأدوار (من «أدوات المعلمة» ← 🏫 المدرسة)
(() => {
  const $ = (s) => document.querySelector(s);
  const api = window.api;
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const PERM_LABEL = {
    structure: 'الهيكل والفصول', students: 'أسماء الطلاب', calendar: 'التقويم وقيم الشهر', adminLessons: 'الدروس الإدارية',
    library: 'المكتبة المشتركة', members: 'الأعضاء (القبول والإزالة وتغيير الأدوار)', reports: 'التقارير'
  };
  const PERMS = Object.keys(PERM_LABEL);
  const ERR = {
    cnot: 'وضع المدرسة يحتاج ربط الحساب بالسحابة (الإعدادات ← حسابي).', net: 'لا يوجد اتصال بالإنترنت', badcode: 'رمز المدرسة غير صحيح',
    cdenied: 'لا توجد صلاحية لهذا العمل (أو قواعد السحابة لم تُحدَّث بعد).', gone: 'لم يعد هذا الحساب عضواً في هذه المدرسة', cexpired: 'انتهت جلسة الحساب السحابي، يلزم الدخول مرة أخرى'
  };
  const GEN = { g: 'قسم بنات', b: 'قسم بنين', mix: 'مشترك' };

  let prof = {}, info = null, tab = 'school', busy = false;
  const call = async (op, ...a) => {
    const r = await api.school(op, ...a);
    if (r && r.err) { LP.toast(T(ERR[r.err] || 'تعذّر الاتصال بالسحابة، حاولي لاحقاً'), null, null, 5000); throw new Error(r.err); }
    return r.v;
  };

  // ---------- النافذة ----------
  const dlg = document.createElement('div'); dlg.className = 'gdlg'; dlg.id = 'scDlg';
  dlg.innerHTML = '<div class="gdlg-card sc-card"></div>';
  document.body.appendChild(dlg);
  const card = dlg.querySelector('.sc-card');
  const close = () => dlg.classList.remove('on');
  dlg.addEventListener('click', e => { if (e.target === dlg) close(); });
  dlg.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') close(); });

  const head = (sub) => `<div class="sc-head"><h3>🏫 ${T('المدرسة')}</h3><span style="flex:1"></span><button class="sc-x" data-x>✕</button></div>${sub || ''}`;
  const wireX = () => card.querySelectorAll('[data-x]').forEach(b => b.onclick = close);
  const loading = (msg) => { card.innerHTML = head() + `<div class="sc-load">⏳ ${esc(msg || T('جارٍ الاتصال بالسحابة…'))}</div>`; wireX(); };

  // المدارس: كل مدرسة انضمت لها تظهر كزر ملوّن في أعلى النافذة، و«＋» للانضمام لمدرسة أخرى أو إنشائها
  let dlgSid = '';
  const pills = (active) => `<div class="sc-mode">${LP.schools().map(sc => `<button class="sc-pill ${sc.sid === active ? 'on' : ''}" data-sid="${esc(sc.sid)}" style="--cc:${LP.ctxColor(sc.sid)}"><span class="ctx-dot"></span>🏫 ${esc(sc.name)}</button>`).join('')}
    <button class="sc-pill ${active === '+' ? 'on' : ''}" data-plus style="--cc:#2a9d8f">＋ ${T(LP.schools().length ? 'مدرسة أخرى' : 'الانضمام / إنشاء مدرسة')}</button></div>`;
  const wirePills = () => {
    card.querySelectorAll('.sc-mode [data-sid]').forEach(b => b.onclick = () => { dlgSid = b.dataset.sid; tab = 'school'; open(); });
    const pl = card.querySelector('.sc-mode [data-plus]'); if (pl) pl.onclick = () => renderPersonal();
  };
  async function open(sid) {
    if (typeof sid === 'string') dlgSid = sid;
    prof = await api.getSettings(); if (LP.reloadCtx) await LP.reloadCtx();
    dlg.classList.add('on');
    const cs = await api.cloudState().catch(() => ({}));
    if (!cs.connected) return renderNoCloud(cs);
    const list = LP.schools();
    if (!list.length) return renderPersonal();
    const target = list.some(x => x.sid === dlgSid) ? dlgSid : (LP.ctxHome() || list[0].sid);
    dlgSid = target;
    loading();
    try { info = await call('info', target); }
    catch (e) {
      if (e.message === 'gone') { await LP.schoolLeft(target); dlgSid = ''; return open(); }
      card.innerHTML = head(pills(target)) + `<div class="sc-load">${T('تعذّر فتح بيانات المدرسة الآن.')}</div><div class="gdlg-row"><button data-retry>${T('إعادة المحاولة')}</button></div>`; wireX(); wirePills();
      card.querySelector('[data-retry]').onclick = () => open(); return;
    }
    await LP.schoolSaved(info);
    updBtn();
    renderSchool();
  }

  function renderNoCloud(cs) {
    card.innerHTML = head() + `<div class="sc-mode"><span class="sc-pill on">👤 ${T('الوضع الشخصي')}</span></div>
      <p>${T('البرنامج يعمل كاملاً في الوضع الشخصي. وضع المدرسة يجمع معلمات المدرسة: تقويم موحد، ودروس إدارية، ومكتبة مشتركة.')}</p>
      <p class="sc-warn">☁️ ${T(cs && cs.linked ? 'الحساب غير متصل بالسحابة الآن. تأكدي من الإنترنت ثم حاولي مرة أخرى.' : 'وضع المدرسة يحتاج ربط الحساب بالسحابة: الإعدادات ← حسابي.')}</p>
      <div class="gdlg-row"><button data-x>${T('إغلاق')}</button></div>`;
    wireX();
  }

  function renderPersonal() {
    card.innerHTML = head(pills('+')) + `
      <p class="muted">${T('بياناتكِ الشخصية (الدروس، الفصول، النقاط، الشهادات) تبقى لكِ في الحالتين، والمدرسة تعرض خياراتها ولا تغيّر شيئاً منها.')}</p>
      <div class="sc-two">
        <section class="sc-box"><h4>🔑 ${T('الانضمام لمدرسة')}</h4>
          <p class="tnote">${T('اطلبي رمز المدرسة من الإدارة.')}</p>
          <input id="scCode" class="sc-code-in" placeholder="ABC-123" maxlength="8" dir="ltr">
          <button class="pri" id="scJoin">${T('انضمام')}</button></section>
        <section class="sc-box"><h4>🏫 ${T('إنشاء مدرسة')}</h4>
          <p class="tnote">${T('للمديرة: تُنشأ المدرسة ويظهر رمزها لتشاركيه مع المعلمات.')}</p>
          <input id="scName" placeholder="${esc(T('اسم المدرسة'))}">
          <select id="scGen">${Object.entries(GEN).map(([k, v]) => `<option value="${k}" ${k === (prof.teacherG === 'm' ? 'b' : 'g') ? 'selected' : ''}>${T(v)}</option>`).join('')}</select>
          <button class="pri" id="scCreate">${T('إنشاء المدرسة')}</button></section>
      </div>`;
    wireX(); wirePills();
    const code = $('#scCode');
    code.addEventListener('input', () => { let v = code.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6); code.value = v.length > 3 ? v.slice(0, 3) + '-' + v.slice(3) : v; });
    $('#scJoin').onclick = async () => {
      if (busy) return; const v = code.value.replace(/-/g, ''); if (v.length !== 6) { LP.toast(T('الرمز 6 حروف وأرقام')); code.focus(); return; }
      busy = true; try { info = await call('join', v); const isNew = await saved(); dlgSid = info.sid; LP.toast(T('تم الانضمام إلى {s} 🎉', { s: info.name }), null, null, 4000); renderSchool(); if (isNew) { close(); LP.askMoveClasses(info); } } catch {} finally { busy = false; }
    };
    $('#scCreate').onclick = async () => {
      if (busy) return; const n = $('#scName').value.trim(); if (!n) { $('#scName').focus(); return; }
      const gender = $('#scGen').value;
      busy = true; loading(T('جارٍ إنشاء المدرسة…'));
      try { info = await call('create', { name: n, gender }); await saved(); dlgSid = info.sid; LP.toast(T('تم إنشاء المدرسة 🎉 شاركي الرمز مع المعلمات'), null, null, 5000); renderSchool(); LP.askMoveClasses(info); }
      catch { renderPersonal(); } finally { busy = false; }
    };
  }
  async function saved() {
    const isNew = await LP.schoolSaved(info);
    prof = await api.getSettings(); updBtn();
    document.dispatchEvent(new CustomEvent('lp-school', { detail: info }));
    return isNew;
  }

  // نافذة تأكيد صغيرة فوق نافذة المدرسة
  function confirmBox(title, text, okLabel, onOk, onCancel, danger) {
    const d = document.createElement('div'); d.className = 'gdlg on sc-confirm';
    d.innerHTML = `<div class="gdlg-card" style="max-width:420px"><h3>${title}</h3><p>${text}</p>
      <div class="gdlg-row"><button class="${danger ? 'warn' : 'pri'}" data-ok>${esc(okLabel)}</button><button data-no>${T('إلغاء')}</button></div></div>`;
    document.body.appendChild(d);
    const end = (ok) => { d.remove(); (ok ? onOk : onCancel) && (ok ? onOk : onCancel)(); };
    d.querySelector('[data-ok]').onclick = () => end(true);
    d.querySelector('[data-no]').onclick = () => end(false);
    d.addEventListener('click', e => { if (e.target === d) end(false); });
  }
  LP.scConfirm = confirmBox;
  // ---------- واجهة المدرسة ----------
  const roleLabel = (r, roles) => r === 'owner' ? T('المالكة (إدارة المدرسة)') : r === 'teacher' ? T('معلمة') : ((roles || []).find(x => x.id === r) || {}).name || T('دور محذوف');
  function renderSchool() {
    const tabs = [['school', '🏫 ' + T('المدرسة')], ['members', '👥 ' + T('الأعضاء')]];
    if (info.owner) tabs.push(['roles', '🛡 ' + T('الأدوار والصلاحيات')]);
    const extra = (LP.schoolExtraTabs || []).filter(x => x.show(info));
    extra.forEach(x => tabs.splice(x.at ?? tabs.length, 0, [x.key, x.label(info)]));
    if (!tabs.some(t => t[0] === tab)) tab = 'school';
    card.innerHTML = head(`${pills(info.sid)}
      <div class="sc-tabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${k === tab ? 'on' : ''}">${l}</button>`).join('')}</div><div class="sc-body"></div>`);
    wireX(); wirePills();
    card.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { tab = b.dataset.tab; renderSchool(); });
    const body = card.querySelector('.sc-body');
    const ex = extra.find(x => x.key === tab);
    if (ex) ex.render(body, info, call, renderSchool);
    else if (tab === 'school') tabSchool(body); else if (tab === 'members') tabMembers(body); else tabRoles(body);
  }
  function tabSchool(body) {
    const own = info.owner;
    body.innerHTML = `
      <div class="sc-row"><label>${T('اسم المدرسة')}</label>${own ? `<input id="scRn" value="${esc(info.name)}"><select id="scRg">${Object.entries(GEN).map(([k, v]) => `<option value="${k}" ${k === info.gender ? 'selected' : ''}>${T(v)}</option>`).join('')}</select><button id="scRnOk">${T('حفظ')}</button>` : `<b>${esc(info.name)}</b> · ${T(GEN[info.gender] || '')}`}</div>
      <div class="sc-row"><label>${T('دوري')}</label><b>${esc(info.role === 'owner' ? T('المالكة (إدارة المدرسة)') : info.role === 'teacher' ? T('معلمة') : info.roleName)}</b>
        ${info.perms.length && !own ? `<span class="tnote">${info.perms.map(p => T(PERM_LABEL[p])).join('، ')}</span>` : ''}</div>
      <div class="sc-row"><label>${T('اللون')}</label><span class="sc-colors">${['#2563eb', '#9333ea', '#db2777', '#ea580c', '#0891b2', '#16a34a', '#ca8a04', '#4f46e5', '#be123c', '#0d9488'].map(c => `<button class="sc-sw ${c === LP.ctxColor(info.sid) ? 'on' : ''}" data-c="${c}" style="background:${c}"></button>`).join('')}</span><span class="tnote">${T('يظهر في زر مكان العمل في الشريط السفلي (لكِ فقط)')}</span></div>
      <div class="sc-codebox"><div>${T('رمز المدرسة')}</div><div class="sc-code" dir="ltr">${esc(info.codeShow)}</div>
        <div class="gdlg-row" style="justify-content:center"><button id="scCopy">📋 ${T('نسخ الرمز')}</button>${own ? `<button id="scNewCode" title="${esc(T('إن انتشر الرمز: يتوقف القديم فوراً، ومن انضمت سابقاً تبقى'))}">↻ ${T('رمز جديد')}</button>` : ''}</div>
        <p class="tnote">${T('تكتبه المعلمة مرة واحدة: أدوات المعلمة ← 🏫 المدرسة ← الانضمام.')}</p></div>
      <div class="gdlg-row sc-danger">${own ? `<button class="warn" id="scDel">🗑 ${T('حذف المدرسة')}</button>` : `<button class="warn" id="scLeave">${T('الخروج من المدرسة')}</button>`}</div>
      <p class="tnote">${own ? T('لتسليم المدرسة لغيركِ: ⚙ الإعدادات ← حسابي ← «مدارسي» ← نقل الملكية.') : T('عند الخروج تبقى كل بياناتكِ الشخصية كما هي.')}</p>`;
    body.querySelectorAll('.sc-sw').forEach(b => b.onclick = async () => { await LP.schoolColorSet(info.sid, b.dataset.c); renderSchool(); });
    $('#scCopy').onclick = () => { navigator.clipboard.writeText(info.codeShow).then(() => LP.toast(T('تم نسخ الرمز'))).catch(() => {}); };
    if (own) {
      $('#scRnOk').onclick = async () => { try { await call('rename', info.sid, { name: $('#scRn').value, gender: $('#scRg').value }); info = await call('info', info.sid); await saved(); LP.toast(T('تم الحفظ')); renderSchool(); } catch {} };
      LP.sureBtn($('#scNewCode'), async () => { try { await call('newCode', info.sid); info = await call('info', info.sid); renderSchool(); LP.toast(T('تم إنشاء رمز جديد')); } catch {} });
      LP.sureBtn($('#scDel'), async () => { loading(); try { await call('delete', info.sid); await leftSchool(T('تم حذف المدرسة')); } catch { renderSchool(); } });
    } else LP.sureBtn($('#scLeave'), async () => { loading(); try { await call('leave', info.sid); await leftSchool(T('تم الخروج من المدرسة')); } catch { renderSchool(); } });
  }
  async function leftSchool(msg) {
    const sid = info.sid, n = await LP.schoolLeft(sid); info = null; dlgSid = ''; updBtn();
    if (n) msg += ' · ' + T('عادت فصولها إلى «شخصي»');
    document.dispatchEvent(new CustomEvent('lp-school', { detail: null }));
    LP.toast(msg, null, null, 4000); open();
  }
  async function tabMembers(body) {
    body.innerHTML = `<div class="sc-load">⏳</div>`;
    let ms = [], roles = [];
    try { [ms, roles] = await Promise.all([call('members', info.sid), call('roles', info.sid)]); } catch { body.innerHTML = ''; return; }
    const canManage = info.owner || info.perms.includes('members');
    const me = ms.find(m => m.role === 'owner' && info.owner) || {};
    ms.sort((a, b) => (a.role === 'owner' ? -1 : b.role === 'owner' ? 1 : 0) || String(a.name).localeCompare(String(b.name), 'ar'));
    const opt = (sel) => [['teacher', T('معلمة')], ...roles.map(r => [r.id, r.name])].map(([v, l]) => `<option value="${esc(v)}" ${v === sel ? 'selected' : ''}>${esc(l)}</option>`).join('');
    body.innerHTML = `<p class="tnote">${T('{n} عضواً', { n: ms.length })}${canManage ? ' · ' + T('غيّري الدور من القائمة بجانب الاسم.') : ''}</p>
      <div class="sc-list">${ms.map(m => `<div class="sc-mem" data-uid="${esc(m.id)}"><div class="sc-who"><b>${esc(m.name || m.email || '—')}</b><small dir="ltr">${esc(m.email || '')}</small></div>
        ${m.role === 'owner' ? `<span class="sc-role own">👑 ${T('المالكة')}</span>` : canManage ? `<select data-role>${opt(m.role)}</select>` : `<span class="sc-role">${esc(roleLabel(m.role, roles))}</span>`}
        ${m.role !== 'owner' && canManage ? `<button class="sc-rm" data-rm>${T('إزالة')}</button>` : ''}</div>`).join('')}</div>
      ${!roles.length && info.owner ? `<p class="tnote">${T('لإعطاء صلاحيات (وكيلة، مشرفة…): أنشئي الأدوار من تبويب «الأدوار والصلاحيات».')}</p>` : ''}`;
    body.querySelectorAll('.sc-mem').forEach(row => {
      const uid = row.dataset.uid, sel = row.querySelector('[data-role]'), rm = row.querySelector('[data-rm]'), m = ms.find(x => x.id === uid) || {};
      const who = m.name || m.email || '';
      // تغيير الدور لا يُحفظ إلا بعد تأكيد واضح
      if (sel) sel.onchange = () => {
        const prev = m.role, to = sel.value, r = roles.find(x => x.id === to);
        const perms = to === 'teacher' ? T('دروسها وفصولها فقط') : ((r && r.perms) || []).map(p => T(PERM_LABEL[p])).join('، ') || T('بلا صلاحيات إضافية');
        confirmBox(`${T('تغيير دور «{w}» إلى «{r}»؟', { w: esc(who), r: esc(to === 'teacher' ? T('معلمة') : r ? r.name : '') })}`, `${T('الصلاحيات:')} ${esc(perms)}`, T('تأكيد التغيير'),
          async () => { try { await call('setRole', info.sid, uid, to); m.role = to; LP.toast(T('تم تغيير الدور')); } catch { sel.value = prev; } },
          () => { sel.value = prev; });
      };
      if (rm) rm.onclick = () => confirmBox(T('إزالة «{w}» من المدرسة؟', { w: esc(who) }), T('تبقى بياناتها الشخصية عندها، وتستطيع الانضمام مرة أخرى بالرمز.'), T('إزالة'),
        async () => { try { await call('remove', info.sid, uid); row.remove(); LP.toast(T('تمت الإزالة')); } catch {} }, null, true);
    });
    void me;
  }
  async function tabRoles(body) {
    body.innerHTML = `<div class="sc-load">⏳</div>`;
    let roles = [];
    try { roles = await call('roles', info.sid); } catch { body.innerHTML = ''; return; }
    const SUG = ['وكيلة', 'مشرفة', 'رائدة نشاط', 'موجهة طلابية', 'منسقة'];
    const roleCard = (r, i) => `<div class="sc-rolec" data-i="${i}"><div class="sc-row"><input data-n value="${esc(r.name || '')}" placeholder="${esc(T('اسم الدور'))}">
        <button class="pri" data-save>${T('حفظ')}</button>${r.id ? `<button class="warn" data-del>${T('حذف')}</button>` : ''}</div>
      <div class="sc-perms">${PERMS.map(p => `<label><input type="checkbox" value="${p}" ${(r.perms || []).includes(p) ? 'checked' : ''}> ${T(PERM_LABEL[p])}</label>`).join('')}</div></div>`;
    const draw = () => {
      body.innerHTML = `<p class="tnote">${T('سمّي الدور كما تريدين، واختاري ما يستطيعه. المالكة لها كل الصلاحيات دائماً، و«معلمة» هو الدور الافتراضي.')}</p>
        ${roles.map(roleCard).join('')}
        <div class="gdlg-row"><button id="scAddRole">＋ ${T('دور جديد')}</button>${SUG.filter(s => !roles.some(r => r.name === s)).map(s => `<button class="sc-sug" data-sug="${esc(s)}">${esc(s)}</button>`).join('')}</div>`;
      $('#scAddRole').onclick = () => { roles.push({ name: '', perms: [] }); draw(); const ins = body.querySelectorAll('[data-n]'); ins[ins.length - 1].focus(); };
      body.querySelectorAll('[data-sug]').forEach(b => b.onclick = () => { roles.push({ name: b.dataset.sug, perms: b.dataset.sug === 'وكيلة' ? ['structure', 'students', 'calendar', 'adminLessons', 'members', 'reports'] : b.dataset.sug === 'مشرفة' ? ['adminLessons', 'library', 'reports'] : ['adminLessons'] }); draw(); });
      body.querySelectorAll('.sc-rolec').forEach(c => {
        const r = roles[+c.dataset.i];
        c.querySelector('[data-n]').addEventListener('keydown', e => e.stopPropagation());
        c.querySelector('[data-save]').onclick = async () => {
          const name = c.querySelector('[data-n]').value.trim(); if (!name) return c.querySelector('[data-n]').focus();
          const perms = [...c.querySelectorAll('.sc-perms input:checked')].map(x => x.value);
          try { r.id = await call('saveRole', info.sid, { id: r.id, name, perms }); r.name = name; r.perms = perms; LP.toast(T('تم حفظ الدور')); draw(); } catch {}
        };
        const d = c.querySelector('[data-del]');
        if (d) LP.sureBtn(d, async () => { try { await call('deleteRole', info.sid, r.id); roles.splice(+c.dataset.i, 1); draw(); LP.toast(T('تم حذف الدور، ومن كان لها هذا الدور أصبحت «معلمة»')); } catch {} });
      });
    };
    draw();
  }

  // ---------- زر في أدوات المعلمة ----------
  let btn = null;
  const col = $('#tpSchoolA');
  if (col) { btn = document.createElement('button'); btn.className = 'tb'; btn.id = 'scBtn'; col.prepend(btn); btn.onclick = () => { LP.closePanels && LP.closePanels(); open(); }; }
  function updBtn() { if (!btn) return; const n = LP.schools ? LP.schools().length : 0; btn.textContent = '🏫 ' + (n ? T('مدارسي ({n})', { n }) : T('الانضمام لمدرسة / إنشاء مدرسة')); }
  updBtn();
  document.addEventListener('lp-auth', () => setTimeout(updBtn, 300));
  document.addEventListener('lp-ctx', updBtn);
  LP.openSchool = open;
  LP.openSchoolTab = (sid, t) => { tab = t; open(sid); };
})();
