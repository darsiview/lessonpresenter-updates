// تخزين البيانات: كل شيء في مجلد «بيانات» بجانب البرنامج (يعمل من الفلاش)
const { app } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// ملف خاص بهذا الجهاز فقط (لا ينتقل مع الفلاش): لخيار «جهازي الشخصي» ولتذكّر أماكن البيانات السابقة
const DEVICE_FILE = path.join(app.getPath('appData'), 'LessonPresenter-device.json');
function readJSON0(f, def) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return def; } }

// ---------- مكان البيانات ----------
// مجلد البرنامج الأساسي: في الترتيب الجديد يكون البرنامج داخل مجلد مخفي «app» وبجانبه ملف app.root، فالأساس هو المجلد الأعلى
function baseDir() {
  const exeDir = path.dirname(process.execPath), up = path.dirname(exeDir);
  return path.basename(exeDir).toLowerCase() === 'app' && fs.existsSync(path.join(up, 'app.root')) ? up : exeDir;
}
function pickDataRoot() {
  if (process.env.LP_DATA) return process.env.LP_DATA;
  // مثبّت على الجهاز (ملف installed.mode بجانب البرنامج) ← البيانات في مجلد المستخدم حتى لا يحذفها إلغاء التثبيت
  if (app.isPackaged && !fs.existsSync(path.join(baseDir(), 'installed.mode'))) {
    const d = path.join(baseDir(), 'بيانات');
    try { fs.mkdirSync(d, { recursive: true }); fs.accessSync(d, fs.constants.W_OK); return d; } catch {}
  }
  return path.join(app.getPath('appData'), 'LessonPresenter');
}
const ROOT = pickDataRoot();
fs.mkdirSync(path.join(ROOT, 'profiles'), { recursive: true });

// كل نسخة تعمل بمجلد «بيانات» الخاص بها فقط (لا نقل تلقائي من نسخ أخرى)
const migratedFrom = null;

// بيانات المتصفح (تسجيل الدخول) أيضاً داخل نفس المجلد
app.setPath('userData', ROOT);

const P = {
  global: path.join(ROOT, 'global.json'),
  users: path.join(ROOT, 'users.json'),
  shared: path.join(ROOT, 'shared.json'),
  profile: (id) => path.join(ROOT, 'profiles', id + '.json')
};

function readJSON(f, def) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return def; }
}
function writeJSON(f, data) {
  // كتابة آمنة: ملف مؤقت ثم استبدال (حتى لا يتلف الملف لو نُزع الفلاش)
  const tmp = f + '.tmp';
  try { fs.writeFileSync(tmp, JSON.stringify(data)); fs.renameSync(tmp, f); return true; }
  catch { try { fs.writeFileSync(f, JSON.stringify(data)); return true; } catch { return false; } }
}

// ---------- الإعدادات العامة ----------
let G = readJSON(P.global, {});
const global = {
  get: () => G,
  patch: (p) => { G = { ...G, ...p }; writeJSON(P.global, G); return G; }
};

// ---------- المستخدمات ----------
let U = readJSON(P.users, []);
const users = {
  all: () => U,
  get: (id) => U.find(u => u.id === id) || null,
  byEmail: (e) => U.find(u => (u.email || '').toLowerCase() === String(e || '').trim().toLowerCase()) || null,
  save: () => writeJSON(P.users, U),
  add: (u) => { U.push(u); writeJSON(P.users, U); return u; },
  remove: (id) => { U = U.filter(u => u.id !== id); writeJSON(P.users, U); profiles.wipe(id); }
};

// ---------- ملف كل معلمة ----------
// الحساب السحابي: يُحفظ ملفه مشفّراً (AES-256-GCM) بمفتاح لا يُفتح إلا بكلمة مرورها.
// _ts: وقت آخر تعديل لكل مفتاح (للمزامنة)، _sync: آخر ما رُفع للسحابة.
const profCache = new Map();
const keys = new Map();            // id → مفتاح البيانات (في الذاكرة فقط أثناء الدخول)
const locked = new Set();          // ملفات مشفّرة لم تُفتح بعد (لا نكتب فوقها أبداً)
let onPatch = null;
function encObj(key, obj) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const d = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
  return { $enc: 1, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), d: d.toString('base64') };
}
function decObj(key, e) {
  const c = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64'));
  c.setAuthTag(Buffer.from(e.tag, 'base64'));
  return JSON.parse(Buffer.concat([c.update(Buffer.from(e.d, 'base64')), c.final()]).toString('utf8'));
}
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
function writeProf(id, obj) {
  if (id === 'guest' || locked.has(id)) return;
  const k = keys.get(id);
  writeJSON(P.profile(id), k ? encObj(k, obj) : obj);
}
const profiles = {
  get(id) {
    if (!id) return {};
    if (!profCache.has(id)) {
      const raw = readJSON(P.profile(id), {});
      if (raw && raw.$enc) {
        const k = keys.get(id);
        try { if (!k) throw 0; profCache.set(id, decObj(k, raw)); locked.delete(id); }
        catch { locked.add(id); return {}; }
      } else profCache.set(id, raw || {});
    }
    return profCache.get(id);
  },
  // opts.t: وقت قادم من السحابة؛ opts.meta: حقول داخلية لا تُعدّ تعديلاً
  patch(id, p, opts = {}) {
    const old = profiles.get(id);
    if (locked.has(id)) return old;
    const cur = { ...old, ...p };
    if (!opts.meta) {
      const ts = { ...(old._ts || {}) }; const changed = [];
      for (const k of Object.keys(p)) if (k[0] !== '_' && !same(old[k], p[k])) { ts[k] = opts.t || Date.now(); changed.push(k); }
      cur._ts = ts;
      if (changed.length && !opts.t && onPatch) setImmediate(() => onPatch(id, changed));
    }
    profCache.set(id, cur);
    writeProf(id, cur);
    return cur;
  },
  isEncrypted: (id) => { const raw = readJSON(P.profile(id), null); return !!(raw && raw.$enc); },
  // يُستدعى بعد الدخول: يفتح الملف المشفّر، أو يشفّر الملف العادي لأول مرة
  setKey(id, key) {
    keys.set(id, key); locked.delete(id); profCache.delete(id);
    const raw = readJSON(P.profile(id), null);
    if (raw && raw.$enc) {
      try { profCache.set(id, decObj(key, raw)); return true; } catch { keys.delete(id); locked.add(id); return false; }
    }
    profCache.set(id, raw || {});
    writeProf(id, raw || {});
    return true;
  },
  keyOf: (id) => keys.get(id) || null,
  dropKey(id) { if (keys.has(id)) { keys.delete(id); profCache.delete(id); } },
  wipe(id) { profCache.delete(id); keys.delete(id); locked.delete(id); try { fs.unlinkSync(P.profile(id)); } catch {} },
  onPatch: (fn) => { onPatch = fn; }
};

// ---------- مكتبة القسم المشتركة ----------
let S = readJSON(P.shared, { items: [] });
const shared = {
  get: () => S,
  save: () => writeJSON(P.shared, S),
  purgeOld: () => {
    const limit = Date.now() - 30 * 24 * 3600 * 1000;
    const before = S.items.length;
    S.items = S.items.filter(i => !(i.deleted && i.deleted.at < limit));
    if (S.items.length !== before) writeJSON(P.shared, S);
  }
};

// ---------- هذا الجهاز ----------
let D = readJSON(DEVICE_FILE, null);
if (!D || !D.id) { D = { ...(D || {}), id: crypto.randomBytes(8).toString('hex'), personal: (D && D.personal) || [] }; writeJSON(DEVICE_FILE, D); }
const device = {
  id: () => D.id,
  isPersonal: (uid) => (D.personal || []).includes(uid),
  logoutChoice: (uid, v) => {
    D.logout = D.logout || {};
    if (v === undefined) return D.logout[uid] || null;
    if (v) D.logout[uid] = v; else delete D.logout[uid];
    writeJSON(DEVICE_FILE, D);
  },
  setPersonal: (uid, on) => {
    const s = new Set(D.personal || []);
    on ? s.add(uid) : s.delete(uid);
    D.personal = [...s]; writeJSON(DEVICE_FILE, D);
  }
};

// ---------- النسخ الاحتياطي ----------
function backupTo(dir) {
  const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  const dest = path.join(dir, 'LessonPresenter-backup-' + stamp);
  fs.mkdirSync(path.join(dest, 'profiles'), { recursive: true });
  for (const f of [P.global, P.users, P.shared]) if (fs.existsSync(f)) fs.copyFileSync(f, path.join(dest, path.basename(f)));
  for (const f of fs.readdirSync(path.join(ROOT, 'profiles'))) if (f.endsWith('.json')) fs.copyFileSync(path.join(ROOT, 'profiles', f), path.join(dest, 'profiles', f));
  return dest;
}
function restoreFrom(dir) {
  if (!fs.existsSync(path.join(dir, 'users.json'))) return false;
  for (const n of ['global.json', 'users.json', 'shared.json']) {
    const f = path.join(dir, n);
    if (fs.existsSync(f)) fs.copyFileSync(f, path.join(ROOT, n));
  }
  const pd = path.join(dir, 'profiles');
  if (fs.existsSync(pd)) for (const f of fs.readdirSync(pd)) if (f.endsWith('.json')) fs.copyFileSync(path.join(pd, f), path.join(ROOT, 'profiles', f));
  G = readJSON(P.global, {}); U = readJSON(P.users, []); S = readJSON(P.shared, { items: [] }); profCache.clear();
  return true;
}

module.exports = { baseDir, ROOT, get migratedFrom() { return migratedFrom; }, global, users, profiles, shared, device, backupTo, restoreFrom };
