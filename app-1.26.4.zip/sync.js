// مزامنة بيانات المعلمة مع السحابة (Firestore) — كل مفتاح من ملفها مستند مستقل، والأحدث يفوز لكل مفتاح على حدة
// users/{uid}          → ts: { مفتاح: وقت آخر تعديل }   (قراءة واحدة تكفي لمعرفة ما تغيّر)
// users/{uid}/prof/{k} → t, n, c0 (+ مستندات k~1 … للقيم الكبيرة)
const cloud = require('./cloud');
const store = require('./store');

const FS = process.env.LP_FB_FS || 'https://firestore.googleapis.com/v1';
let CFG = {}; try { CFG = require('./cloud-config.json'); } catch {}
const docBase = () => `${FS}/projects/${CFG.projectId}/databases/(default)/documents`;
// مفاتيح خاصة بهذا الجهاز (مواضع النوافذ ومسارات المجلدات) لا تُزامَن
const LOCAL_ONLY = /^_|Pos$|^floatSlots$|^pptFolders$|^goalsSize$|^miniPos$|^dockScale$/;
const CHUNK = 300000;           // حروف لكل مستند (أقل بكثير من حد 1MB)

let ctx = null;                 // { id: معرّف المعلمة على الجهاز, uid }
let meta = {};                  // ts كما في السحابة (آخر قراءة)
let lastSync = 0, busy = null, pushT = null, listeners = [];
const onChange = (fn) => listeners.push(fn);
const emit = (extra) => listeners.forEach(f => { try { f({ ...state(), ...extra }); } catch {} });

async function req(method, url, body) {
  const tok = await cloud.idToken();
  let res;
  try {
    res = await fetch(url, { method, signal: AbortSignal.timeout(20000), headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: body ? JSON.stringify(body) : undefined });
  } catch (e) { throw new cloud.CloudErr('net', String(e.message || e)); }
  if (res.status === 404) return null;
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new cloud.CloudErr(res.status === 403 ? 'cdenied' : 'cfail', JSON.stringify(j.error || res.status));
  return j;
}
const num = (v) => v ? +(v.integerValue ?? v.doubleValue ?? 0) : 0;

function pendingKeys() {
  if (!ctx) return [];
  const p = store.profiles.get(ctx.id), ts = p._ts || {}, sy = p._sync || {};
  return Object.keys(p).filter(k => !LOCAL_ONLY.test(k) && (ts[k] || 1) > (sy[k] || 0) && (ts[k] || 1) > (meta[k] || 0));
}
function state() { return { active: !!ctx, lastSync, pending: ctx ? pendingKeys().length : 0, syncing: !!busy }; }

// ---------- القراءة ----------
async function readMeta() {
  const d = await req('GET', `${docBase()}/users/${ctx.uid}`);
  const f = d && d.fields && d.fields.ts && d.fields.ts.mapValue && d.fields.ts.mapValue.fields || {};
  meta = Object.fromEntries(Object.entries(f).map(([k, v]) => [k, num(v)]));
  return meta;
}
async function readKey(k) {
  const d = await req('GET', `${docBase()}/users/${ctx.uid}/prof/${encodeURIComponent(k)}`);
  if (!d || !d.fields) return undefined;
  const n = num(d.fields.n) || 1;
  let str = (d.fields.c0 && d.fields.c0.stringValue) || '';
  for (let i = 1; i < n; i++) {
    const x = await req('GET', `${docBase()}/users/${ctx.uid}/prof/${encodeURIComponent(k + '~' + i)}`);
    str += (x && x.fields && x.fields.c && x.fields.c.stringValue) || '';
  }
  try { return { v: JSON.parse(str), t: num(d.fields.t) }; } catch { return undefined; }
}
// تنزيل ما هو أحدث في السحابة. full: نسخة جهاز جديدة/فارغة تأخذ كل شيء
async function pull(full) {
  if (!ctx) return [];
  await readMeta();
  const p = store.profiles.get(ctx.id), ts = p._ts || {};
  const changed = [];
  for (const [k, t] of Object.entries(meta)) {
    if (LOCAL_ONLY.test(k)) continue;
    const lt = ts[k] || (k in p ? 1 : 0);
    if (t > lt || (full && !(k in p))) {
      const r = await readKey(k); if (!r) continue;
      store.profiles.patch(ctx.id, { [k]: r.v }, { t: r.t || t });
      const sy = { ...(store.profiles.get(ctx.id)._sync || {}), [k]: r.t || t };
      store.profiles.patch(ctx.id, { _sync: sy }, { meta: true });
      changed.push(k);
    }
  }
  return changed;
}

// ---------- الرفع ----------
async function writeKey(k, v, t) {
  const str = JSON.stringify(v === undefined ? null : v);
  const parts = []; for (let i = 0; i < str.length || i === 0; i += CHUNK) parts.push(str.slice(i, i + CHUNK));
  for (let i = 1; i < parts.length; i++)
    await req('PATCH', `${docBase()}/users/${ctx.uid}/prof/${encodeURIComponent(k + '~' + i)}`, { fields: { c: { stringValue: parts[i] } } });
  await req('PATCH', `${docBase()}/users/${ctx.uid}/prof/${encodeURIComponent(k)}`,
    { fields: { t: { integerValue: String(t) }, n: { integerValue: String(parts.length) }, c0: { stringValue: parts[0] } } });
}
async function push() {
  if (!ctx) return 0;
  const keys = pendingKeys(); if (!keys.length) return 0;
  const p = store.profiles.get(ctx.id), ts = p._ts || {};
  const done = {};
  for (const k of keys) { const t = ts[k] || 1; await writeKey(k, p[k], t); done[k] = t; }
  const mask = Object.keys(done).map(k => 'updateMask.fieldPaths=' + encodeURIComponent('ts.`' + k + '`')).join('&');
  await req('PATCH', `${docBase()}/users/${ctx.uid}?${mask}`,
    { fields: { ts: { mapValue: { fields: Object.fromEntries(Object.entries(done).map(([k, t]) => [k, { integerValue: String(t) }])) } } } });
  Object.assign(meta, done);
  const sy = { ...(store.profiles.get(ctx.id)._sync || {}), ...done };
  store.profiles.patch(ctx.id, { _sync: sy }, { meta: true });
  return keys.length;
}

// ---------- التشغيل ----------
// sync: تنزيل ثم رفع. يُرجع المفاتيح التي وصلت من جهاز آخر
function run(full) {
  if (busy) return busy;
  if (!ctx) return Promise.resolve([]);
  emit();
  busy = (async () => {
    try { const ch = await pull(full); await push(); lastSync = Date.now(); return ch; }
    finally { busy = null; emit(); }
  })();
  return busy;
}
function start(id, uid) {
  if (ctx && ctx.id === id && ctx.uid === uid) return;
  ctx = { id, uid }; meta = {}; emit();
}
function stop() { ctx = null; meta = {}; clearTimeout(pushT); emit(); }
// رفع كل ما لم يُرفع قبل الخروج (بحد أقصى للوقت)
async function flush(ms = 6000) {
  if (!ctx || !cloud.session()) return state().pending;
  try { await Promise.race([(async () => { if (busy) await busy.catch(() => {}); await push(); })(), new Promise(r => setTimeout(r, ms))]); } catch {}
  emit();
  return state().pending;
}
// عند أي تعديل: رفع مؤجّل قليلاً (يجمع التعديلات المتتالية)
store.profiles.onPatch((id) => {
  if (!ctx || ctx.id !== id) return;
  emit();
  clearTimeout(pushT);
  pushT = setTimeout(() => { if (ctx && cloud.session() && !busy) { busy = push().then(() => { lastSync = Date.now(); }).catch(() => {}).finally(() => { busy = null; emit(); }); } }, 4000);
});

// هل في السحابة ما هو أحدث مما على الجهاز؟ (يأتي من الاستماع الفوري)
function hasNewer(ts) {
  if (!ctx || !ts) return false;
  const p = store.profiles.get(ctx.id), lt = p._ts || {}, sy = p._sync || {};
  return Object.entries(ts).some(([k, t]) => !LOCAL_ONLY.test(k) && +t > (lt[k] || 0) && +t > (sy[k] || 0));
}
module.exports = { start, stop, run, flush, state, onChange, pendingKeys, hasNewer };
