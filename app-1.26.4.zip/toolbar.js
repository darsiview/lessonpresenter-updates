(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const stage = $('#stage');

  // ---------- فتح وإغلاق القوائم ----------
  function closeMenus() {
    let any = false;
    $$('.menu.on').forEach(m => { m.classList.remove('on'); any = true; });
    $$('.popOpen').forEach(b => b.classList.remove('popOpen'));
    return any;
  }
  function place(menu, btn) {
    const sr = stage.getBoundingClientRect(), br = btn.getBoundingClientRect();
    menu.style.left = '0px';
    const w = menu.offsetWidth;
    let left = br.left + br.width / 2 - w / 2 - sr.left;
    left = Math.max(8, Math.min(left, sr.width - w - 8));
    menu.style.left = left + 'px';
  }
  $$('[data-pop]').forEach(btn => {
    const menu = document.getElementById(btn.dataset.pop);
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const open = menu.classList.contains('on');
      closeMenus();
      if (window.LP) LP.closePanels();
      if (!open) { menu.classList.add('on'); btn.classList.add('popOpen'); place(menu, btn); }
    });
  });
  // الضغط على عنصر داخل القائمة يغلقها (ما عدا مربع اختيار اللون)
  $$('.menu').forEach(m => m.addEventListener('click', e => {
    if (e.target.closest('.cc')) return;
    if (e.target.closest('.mi, .sw, .wd, [data-st]')) setTimeout(closeMenus, 0);
  }));
  document.addEventListener('pointerdown', e => {
    if (!e.target.closest('.menu') && !e.target.closest('[data-pop]')) closeMenus();
  }, true);
  window.addEventListener('blur', closeMenus);       // عند الضغط داخل الدرس
  window.addEventListener('resize', closeMenus);
  $('#customColor').addEventListener('change', () => setTimeout(closeMenus, 0));

  // Esc يغلق القوائم أولاً
  const prevClose = LP.closePanels;
  LP.closePanels = () => { const a = closeMenus(); const b = prevClose(); return a || b; };

  // ---------- زر الأشكال يعرض الأداة المختارة ----------
  const shapesBtn = $('#shapesBtn');
  const shapeTools = ['rect', 'ellipse', 'arrow', 'text', 'spot'];
  const defaultShapeIcon = shapesBtn.innerHTML;
  document.addEventListener('lp-tool', e => {
    const t = e.detail;
    if (shapeTools.includes(t)) {
      const src = document.querySelector(`#shapesPop [data-tool="${t}"] svg`);
      shapesBtn.innerHTML = src ? src.outerHTML : defaultShapeIcon;
      shapesBtn.classList.add('on');
    } else {
      shapesBtn.innerHTML = defaultShapeIcon;
      shapesBtn.classList.remove('on');
    }
  });

  // ---------- الممحاة والأختام ----------
  const eraserBtn = $('#eraserBtn'), stampBtn = $('#stampBtn');
  $$('#eraserSizes [data-r]').forEach(b => b.addEventListener('click', () => {
    $$('#eraserSizes [data-r]').forEach(x => x.classList.toggle('on', x === b));
    LP.setEraser(+b.dataset.r);
  }));
  $('#eraseAll').addEventListener('click', () => LP.clearAll());
  $$('#stampPop [data-st]').forEach(b => b.addEventListener('click', () => {
    LP.setStamp(b.dataset.st);
    stampBtn.querySelector('.stampIc').textContent = b.dataset.st;
    stampBtn.querySelector('.stampIc').style.color = b.style.color || '';
  }));
  const syncSS = () => $$('#stampSizes [data-ss]').forEach(x => x.classList.toggle('on', +x.dataset.ss === LP.stampSize));
  $$('#stampSizes [data-ss]').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); LP.setStampSize(+b.dataset.ss); syncSS(); }));
  syncSS();
  document.addEventListener('lp-tool', e => {
    eraserBtn.classList.toggle('on', e.detail === 'eraser');
    stampBtn.classList.toggle('on', e.detail === 'stamp');
  });

  // ---------- زر اللون يعرض اللون والسُمك ----------
  const pdot = $('#penBtn .pdot'), pdotI = $('#penBtn .pdot i');
  document.addEventListener('lp-pen', e => {
    const { color, width } = e.detail;
    pdot.style.background = color;
    const s = Math.min(14, 3 + width);
    pdotI.style.width = pdotI.style.height = s + 'px';
    pdotI.style.background = /^#f{3,6}$/i.test(color) ? '#333' : 'rgba(255,255,255,.9)';
  });

  // ---------- نسخ أزرار التنقل في قائمة "المزيد" للشاشات الصغيرة ----------
  $('#back2').onclick = () => $('#back').click();
  $('#fwd2').onclick = () => $('#fwd').click();
  $('#link2').onclick = () => setTimeout(() => $('#linkBtn').click(), 10);

  // ---------- الكشّاف على كل الشاشة ----------
  const gBtn = $('#globalSpot');
  gBtn.onclick = () => window.api.toggleGlobalSpot();
  window.api.onGlobalSpot(on => {
    gBtn.classList.toggle('active-glob', on);
    gBtn.querySelector('span').textContent = I18N.t(on ? 'إيقاف الكشّاف على كل الشاشة' : 'كشّاف على كل الشاشة');
    if (on) LP.toast(I18N.t('الكشّاف يعمل فوق كل البرامج — حرّكي العجلة (أو إصبعين على لوحة اللمس) لتغيير حجمه، و Esc للإيقاف'), null, null, 4000);
  });

  // ---------- اختيار برنامج لدائرة من الزر العائم ----------
  window.api.onPickSlot(i => {
    if (window.LP && LP.openAppsPicker) LP.openAppsPicker(i);
  });
})();
