// أدوات المعلمة: بطاقات «على العجلة» و«المجموعات» و«النقاط ووقت الحصة» و«الشهادات»
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const T = (s, v) => I18N.t(s, v);
  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const g = () => LP._groups;
  const open = () => $('#toolsPanel').classList.contains('on');

  async function render() {
    if (!open()) return;
    await g().ensure(false);
    const S = g().S, names = g().roster();
    // على العجلة
    const off = new Set(S ? S.removed : []);
    const on = names.filter(n => !off.has(n));
    $('#twTitle').textContent = T('على العجلة ({n})', { n: on.length });
    $('#twList').innerHTML = !names.length ? `<p class="tnote">${T('لا توجد أسماء بعد. الصقيها في خانة الأسماء.')}</p>`
      : on.map(n => `<span class="twchip">${esc(g().dn(n))}<button data-out="${esc(n)}" title="${T('إخراج من العجلة')}">−</button></span>`).join('')
        + (off.size ? `<div class="twoff">${T('خارج العجلة')}: ${[...off].map(n => `<span class="twchip out">${esc(g().dn(n))}<button data-back="${esc(n)}" title="${T('إرجاع إلى العجلة')}">↺</button></span>`).join('')}</div>` : '');
    $$('#twList [data-out]').forEach(b => b.onclick = () => { g().removeGirl(b.dataset.out); render(); });
    $$('#twList [data-back]').forEach(b => b.onclick = () => { g().returnGirl(b.dataset.back); render(); });
    $('#twAuto').checked = g().autoHide;
    // المجموعات
    const k = S ? S.groups.length : g().defaultCount(names.length);
    $('#tgCount').innerHTML = [2, 3, 4, 5, 6, 7, 8].map(i => `<option value="${i}" ${i === k ? 'selected' : ''}>${i}</option>`).join('');
    $('#tgInfo').textContent = !names.length ? T('أضيفي أسماء الطالبات أولاً، ثم كوّني المجموعات.') : S ? T('تم تكوين {n} مجموعات.', { n: S.groups.length }) : '';
    const GC = LP.session.GCOL;
    $('#tgPrev').innerHTML = S ? S.groups.map((gr, i) => `<div><b style="color:${GC[i % GC.length]}">${esc(LP.session.groupName(i))} · ${S.gpts[i]}</b><small>${gr.map(n => esc(g().dn(n))).join('، ')}</small></div>`).join('') : '';
  }
  $('#twAuto').onchange = () => LP.setAutoHide($('#twAuto').checked);
  $('#tgMake').onclick = async () => {
    const k = +$('#tgCount').value;             // نقرأ اختيار المعلمة قبل أي تحديث للوحة
    if (!(await g().ensure(false))) { LP.toast(T('أضيفي أسماء الطالبات أولاً')); return; }
    g().rebalance(k); g().render(); render();
    LP.toast(T('تم تكوين المجموعات ✓'));
  };
  $('#tgSession').onclick = async () => { if (await g().ensure(false)) g().sessionDialog(); };
  LP.sureBtn($('#tpReset'), () => { g().resetPoints(); render(); LP.toast(T('صُفّرت كل النقاط')); });
  $('#tpClock').onclick = () => { g().resetClock(); LP.toast(T('أُعيدت ساعة الحصة إلى الصفر')); };
  $('#tpExcel').onclick = () => { if (g().S) g().copyExcel(); };
  $('#tcResults').onclick = () => { LP.closePanels(); LP.openResults && LP.openResults(); };
  $('#tcDesign').onclick = () => { LP.closePanels(); LP.openCertSettings && LP.openCertSettings(); };
  document.addEventListener('lp-tools', render);
  document.addEventListener('lp-classes', () => setTimeout(render, 300));
  LP.renderTools = render;
})();
