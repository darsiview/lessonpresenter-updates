// نقل ملكية المدرسة بمصافحة: من «الإعدادات ← حسابي ← مدارسي»، وتوافق المالكة الجديدة بنفسها بعد التحقق من حسابها
(() => {
  const api = window.api;
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const call = async (op, ...a) => { const r = await api.school(op, ...a); if (r && r.err) throw new Error(r.err); return r ? r.v : null; };
  const fail = (e) => LP.toast(T(e && e.message === 'net' ? 'لا يوجد اتصال بالإنترنت' : e && e.message === 'expired' ? 'انتهت مدة طلب النقل أو أُلغي' : e && e.message === 'cdenied' ? 'لا توجد صلاحية لهذا العمل (أو قواعد السحابة لم تُحدَّث بعد).' : 'تعذّر الاتصال بالسحابة، حاولي لاحقاً'), null, null, 5000);
  const days = (at) => Math.max(0, Math.ceil((at + 7 * 864e5 - Date.now()) / 864e5));
  const box = (html) => { const d = document.createElement('div'); d.className = 'gdlg on tr-dlg'; d.innerHTML = `<div class="gdlg-card" style="max-width:480px">${html}</div>`; document.body.appendChild(d); d.addEventListener('keydown', e => e.stopPropagation()); return d; };

  // ---------- قسم «مدارسي» في الإعدادات ----------
  LP.renderMySchools = async (host) => {
    if (!host) return;
    const list = LP.schools ? LP.schools() : [];
    if (!list.length) { host.style.display = 'none'; return; }
    host.style.display = '';
    host.innerHTML = `<h3>🏫 ${T('مدارسي')}</h3><div class="ms-list">${list.map(s => `<div class="ms-row" data-sid="${esc(s.sid)}"><span class="ctx-dot" style="background:${LP.ctxColor(s.sid)}"></span><b>${esc(s.name)}</b>
      <small>${s.role === 'owner' ? '👑 ' + T('المالكة') : s.role === 'teacher' ? T('معلمة') : T('دور إداري')}</small><span style="flex:1"></span>
      <button class="pbtn" data-open>${T('فتح')}</button>${s.role === 'owner' ? `<span class="ms-tr"></span>` : ''}</div>`).join('')}</div>`;
    host.querySelectorAll('.ms-row').forEach(async row => {
      const sid = row.dataset.sid;
      row.querySelector('[data-open]').onclick = () => { if (LP.closePanels) LP.closePanels(); LP.openSchool(sid); };
      const tr = row.querySelector('.ms-tr'); if (!tr) return;
      let info = null; try { info = await call('info', sid); } catch { return; }
      if (info.pendingOwner && days(info.pendingAt) > 0) {
        tr.innerHTML = `<span class="ms-pend">⏳ ${T('بانتظار موافقة {w} ({d} أيام)', { w: esc(info.pendingName), d: days(info.pendingAt) })}</span><button class="pbtn" data-cancel>${T('إلغاء الطلب')}</button>`;
        tr.querySelector('[data-cancel]').onclick = async () => { try { await call('cancelTransfer', sid); LP.toast(T('أُلغي طلب نقل الملكية')); LP.renderMySchools(host); } catch (e) { fail(e); } };
      } else {
        tr.innerHTML = `<button class="pbtn warn" data-tr>${T('نقل الملكية…')}</button>`;
        tr.querySelector('[data-tr]').onclick = () => startTransfer(info, () => LP.renderMySchools(host));
      }
    });
  };

  // ---------- طلب النقل (المالكة) ----------
  async function startTransfer(info, done) {
    let ms = []; try { ms = (await call('members', info.sid)).filter(m => m.role !== 'owner'); } catch (e) { return fail(e); }
    if (!ms.length) { LP.toast(T('لا توجد عضوات في المدرسة بعد')); return; }
    const d = box(`<h3>⚠️ ${T('نقل ملكية «{s}»', { s: esc(info.name) })}</h3>
      <p>${T('اختاري العضوة التي ستصبح مالكة المدرسة:')}</p>
      <select id="trWho">${ms.map(m => `<option value="${esc(m.id)}">${esc(m.name || m.email)}${m.email ? ' — ' + esc(m.email) : ''}</option>`).join('')}</select>
      <div class="tr-warn">• ${T('لا يتغير شيء الآن: يُرسل طلب، ويجب أن توافق هي بنفسها وتؤكد بكلمة مرور حسابها.')}<br>
        • ${T('بعد موافقتها تصبح هي المالكة بكل الصلاحيات، وتصبحين أنتِ «معلمة».')}<br>
        • ${T('لا يمكن التراجع بعد الموافقة إلا إذا أعادت لكِ الملكية.')}<br>
        • ${T('يُلغى الطلب تلقائياً بعد 7 أيام إن لم توافق.')}</div>
      <label>${T('للتأكيد اكتبي اسم المدرسة:')} <b>${esc(info.name)}</b></label>
      <input id="trName" autocomplete="off">
      <div class="gdlg-row"><button class="warn" id="trGo" disabled>${T('إرسال طلب النقل')}</button><button id="trNo">${T('إلغاء')}</button></div>`);
    const nm = d.querySelector('#trName'), go = d.querySelector('#trGo');
    nm.oninput = () => { go.disabled = nm.value.trim() !== String(info.name).trim(); };
    d.querySelector('#trNo').onclick = () => d.remove();
    go.onclick = async () => {
      const uid = d.querySelector('#trWho').value, m = ms.find(x => x.id === uid);
      go.disabled = true;
      try { await call('requestTransfer', info.sid, uid, m.name || m.email); d.remove(); LP.toast(T('أُرسل الطلب إلى {w} — تنتقل الملكية بعد موافقتها', { w: m.name || m.email }), null, null, 6000); done && done(); }
      catch (e) { fail(e); go.disabled = false; }
    };
    setTimeout(() => nm.focus(), 50);
  }

  // ---------- موافقة المالكة الجديدة ----------
  async function checkIncoming() {
    const list = LP.schools ? LP.schools().map(s => s.sid) : [];
    if (!list.length || document.querySelector('.tr-dlg')) return;
    let inc = []; try { inc = await call('pendingForMe', list); } catch { return; }
    for (const p of inc) await askAccept(p);
  }
  function askAccept(p) {
    return new Promise(async (resolve) => {
      const who = await api.schoolWho().catch(() => null) || {};
      const d = box(`<h3>👑 ${T('طلب تسلّم ملكية مدرسة')}</h3>
        <p>${T('تطلب منكِ «{b}» تسلّم ملكية «{s}».', { b: esc(p.by), s: esc(p.name) })}</p>
        <div class="tr-warn">• ${T('ستصبحين المالكة بكل الصلاحيات (الأعضاء، الأدوار، الرمز، حذف المدرسة).')}<br>• ${T('وتصبح المالكة الحالية «معلمة».')}<br>• ${T('ينتهي الطلب بعد {d} أيام.', { d: days(p.at) })}</div>
        ${who.google ? `<p class="tnote">${T('للتأكيد سيُفتح المتصفح لتسجيل الدخول بحساب Google نفسه.')}</p>` : `<label>${T('للتأكيد اكتبي كلمة مرور حسابكِ السحابي:')}</label><input type="password" id="trPw" autocomplete="current-password">`}
        <div class="gdlg-row"><button class="pri" id="trOk">${T('موافقة وتسلّم الملكية')}</button><button id="trNo2">${T('رفض')}</button><button id="trLater">${T('لاحقاً')}</button></div>`);
      const end = () => { d.remove(); resolve(); };
      d.querySelector('#trLater').onclick = end;
      d.querySelector('#trNo2').onclick = async () => { try { await call('declineTransfer', p.sid); LP.toast(T('تم رفض الطلب')); } catch (e) { fail(e); } end(); };
      d.querySelector('#trOk').onclick = async () => {
        const pw = who.google ? '' : d.querySelector('#trPw').value;
        if (!who.google && !pw) { d.querySelector('#trPw').focus(); return; }
        const b = d.querySelector('#trOk'); b.disabled = true;
        const r = await api.schoolReauth(pw);
        if (!r || !r.ok) { b.disabled = false; LP.toast(T(r && r.err === 'badpw' ? 'كلمة المرور غير صحيحة' : r && r.err === 'mismatch' ? 'هذا ليس نفس الحساب' : 'تعذّر التحقق من الحساب'), null, null, 5000); return; }
        try {
          await call('acceptTransfer', p.sid);
          const info = await call('info', p.sid); await LP.schoolSaved(info);
          LP.toast(T('أصبحتِ مالكة «{s}» 👑', { s: p.name }), null, null, 6000);
        } catch (e) { fail(e); }
        end();
      };
    });
  }
  LP.checkTransfers = checkIncoming;
  document.addEventListener('lp-auth', (e) => { if (e.detail && e.detail.user) setTimeout(checkIncoming, 6000); });
  document.addEventListener('lp-ctx', () => setTimeout(checkIncoming, 3000));
})();
