// نسخة تجريبية: شريط الأيام المتبقية، وشاشة القفل عند الانتهاء، ورسالة «تحديث جاهز»
(() => {
  const api = window.api;
  const T = (s, v) => I18N.t(s, v);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const pill = document.createElement('button'); pill.id = 'trialPill'; pill.style.display = 'none';
  const bar = document.getElementById('bar'); if (bar) bar.prepend(pill);
  let lockEl = null;
  async function refresh() {
    const st = await api.updState().catch(() => null); if (!st) return;
    if (st.trial && !st.locked) {
      pill.style.display = ''; pill.className = st.daysLeft <= 3 ? 'warn' : '';
      pill.textContent = '🧪 ' + (st.daysLeft > 0 ? T('نسخة تجريبية — تبقى {n} يوماً', { n: st.daysLeft }) : T('نسخة تجريبية — اليوم آخر يوم'));
      pill.title = T('تنتهي في {d}. التحديثات تمدد المدة تلقائياً.', { d: st.expires });
    } else pill.style.display = 'none';
    if (st.locked) lock(st); else if (lockEl) { lockEl.remove(); lockEl = null; }
    if (st.ready) readyToast(st.ready);
  }
  pill.onclick = () => checkNow(true);
  function lock(st) {
    if (!lockEl) { lockEl = document.createElement('div'); lockEl.id = 'trialLock'; document.body.appendChild(lockEl); }
    lockEl.innerHTML = `<div class="tl-card"><div class="tl-ic">⏳</div>
      <h2>${T(st.message ? 'هذه النسخة متوقفة' : 'انتهت فترة التجربة لهذه النسخة')}</h2>
      <p>${st.message ? esc(st.message) : T('شكراً لتجربتكِ عارض الدروس. اتصلي بالإنترنت واضغطي «التحقق من التحديث» للحصول على النسخة الأحدث.')}</p>
      <p class="tl-v">${T('النسخة {v}', { v: esc(st.version) })}</p>
      <button class="pri" id="tlCheck">🔄 ${T('التحقق من التحديث')}</button><p class="tl-msg" id="tlMsg"></p>
      <p class="tl-note">${T('بياناتكِ محفوظة في مجلد «بيانات» ولا تُحذف.')}</p></div>`;
    lockEl.querySelector('#tlCheck').onclick = async () => {
      const m = lockEl.querySelector('#tlMsg'); m.textContent = '⏳ ' + T('جارٍ التحقق…');
      const r = await api.updCheck().catch(() => ({ err: 'net' }));
      if (r.ready) { m.textContent = T('تم تنزيل النسخة {v} — جارٍ إعادة التشغيل…', { v: r.ready.version }); setTimeout(() => api.updRestart(), 1500); }
      else if (r.state && !r.state.locked) refresh();
      else m.textContent = T(r.err === 'net' ? 'لا يوجد اتصال بالإنترنت' : r.upToDate ? 'لا توجد نسخة أحدث بعد' : 'تعذّر التحقق، حاولي لاحقاً');
    };
  }
  let told = '';
  function readyToast(rd) {
    if (!rd || told === rd.version) return; told = rd.version;
    LP.toast(T('النسخة {v} جاهزة', { v: rd.version }) + (rd.notes ? ' — ' + rd.notes : ''), T('إعادة التشغيل الآن'), () => api.updRestart(), 30000);
  }
  async function checkNow(manual) {
    if (manual) LP.toast('⏳ ' + T('جارٍ التحقق من التحديث…'));
    const r = await api.updCheck().catch(() => ({ err: 'net' }));
    if (r.ready) readyToast(r.ready);
    else if (manual) LP.toast(T(r.upToDate ? 'لديكِ أحدث نسخة ✓' : r.err === 'nocfg' ? 'التحديث التلقائي غير مُعدّ في هذه النسخة' : r.err === 'net' ? 'لا يوجد اتصال بالإنترنت' : 'تعذّر التحقق، حاولي لاحقاً'));
    refresh();
  }
  LP.checkUpdate = checkNow;
  api.onUpdReady((rd) => readyToast(rd));
  refresh(); setInterval(refresh, 30 * 60e3);
  setTimeout(() => api.updGood(), 20000);   // البرنامج يعمل ← تُعتمد هذه النسخة
})();
