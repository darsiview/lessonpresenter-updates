// التحديث التلقائي الصغير + فترة التجربة
// latest.json (في GitHub): { version, zip, sha256, sig, notes, expires, block: { "1.26.0": "رسالة" } }
// التوقيع (ed25519) على «version|sha256» بمفتاح سري لا يملكه غير صاحبة البرنامج؛ و expires يُعدَّل يدوياً للتمديد.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PUB = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA/rTPzBIgGdNpzxbsZ9DhdyKChIYC8F1rtAy14BsBI+M=
-----END PUBLIC KEY-----`;
let CFG = {}; try { CFG = require('./update-config.json'); } catch {}
let TRIAL = null; try { TRIAL = require('./trial.json'); } catch {}
const VER = require('./package.json').version;
const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
let ROOT = '', log = () => {};
const stF = () => path.join(ROOT, 'update-state.json');
const base = () => path.join(ROOT, 'app-updates');
const rd = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const wr = (f, o) => { try { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(o)); } catch {} };
function init(root, logger) { ROOT = root; if (logger) log = logger; touch(); setInterval(touch, 10 * 60e3).unref(); }
// آخر وقت رآه البرنامج (إرجاع ساعة الجهاز لا يمدد التجربة)
function touch() { const st = rd(stF(), {}); st.lastSeen = Math.max(st.lastSeen || 0, Date.now()); wr(stF(), st); }
const endOf = (d) => d ? Date.parse(d + 'T23:59:59') || 0 : 0;
function trialState() {
  const st = rd(stF(), {}), block = (st.block || {})[VER];
  if (!TRIAL) return { trial: false, version: VER, locked: !!block, message: block || '' };
  const now = Math.max(Date.now(), st.lastSeen || 0), exp = Math.max(endOf(TRIAL.expires), endOf(st.remoteExpires));
  const d0 = new Date(now); d0.setHours(0, 0, 0, 0);
  const e0 = new Date(exp); e0.setHours(0, 0, 0, 0);
  const daysLeft = Math.round((e0 - d0) / 864e5);          // 0 = اليوم آخر يوم
  const ed = `${e0.getFullYear()}-${String(e0.getMonth() + 1).padStart(2, '0')}-${String(e0.getDate()).padStart(2, '0')}`;
  return { trial: true, version: VER, expires: ed, daysLeft, locked: now > exp || !!block, message: block || '' };
}
function verify(ver, sha, sig) {
  try { return crypto.verify(null, Buffer.from(`${ver}|${sha}`), crypto.createPublicKey(PUB), Buffer.from(String(sig || ''), 'base64')); } catch { return false; }
}
let busy = null, ready = null;
async function check() {
  if (busy) return busy;
  busy = (async () => {
    if (!CFG.latest) return { err: 'nocfg' };
    let j;
    try {
      const r = await fetch(CFG.latest + (CFG.latest.includes('?') ? '&' : '?') + 't=' + Date.now(), { signal: AbortSignal.timeout(20000), cache: 'no-store' });
      if (!r.ok) return { err: 'http' + r.status };
      j = await r.json();
    } catch (e) { return { err: 'net' }; }
    const st = rd(stF(), {}); if (j.expires) st.remoteExpires = j.expires; st.block = j.block || {}; st.checked = Date.now(); wr(stF(), st);
    if (!j.version || cmp(j.version, VER) <= 0) return { upToDate: true, version: VER };
    const dir = path.join(base(), j.version);
    if (fs.existsSync(path.join(dir, '.ok'))) { setCurrent(j.version); ready = { version: j.version, notes: j.notes || '' }; return { ready }; }
    let buf;
    try {
      const r = await fetch(new URL(j.zip, CFG.latest).href, { signal: AbortSignal.timeout(180000) });
      if (!r.ok) return { err: 'http' + r.status };
      buf = Buffer.from(await r.arrayBuffer());
    } catch { return { err: 'net' }; }
    const sha = crypto.createHash('sha256').update(buf).digest('hex');
    if (sha !== String(j.sha256).toLowerCase() || !verify(j.version, sha, j.sig)) { log('update rejected: bad hash/signature ' + j.version); return { err: 'sig' }; }
    const tmp = dir + '.tmp';
    try {
      fs.rmSync(tmp, { recursive: true, force: true });
      const files = require('./xlsx').unzip(buf);
      for (const [name, data] of Object.entries(files)) {
        if (name.endsWith('/') || name.includes('..')) continue;
        const f = path.join(tmp, name); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, data);
      }
      const pv = rd(path.join(tmp, 'package.json'), {}).version;
      if (pv !== j.version || !fs.existsSync(path.join(tmp, 'main.js'))) throw new Error('bad package ' + pv);
      fs.writeFileSync(path.join(tmp, '.ok'), String(Date.now()));
      fs.rmSync(dir, { recursive: true, force: true }); fs.renameSync(tmp, dir);
    } catch (e) { log('update extract failed: ' + (e.message || e)); try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {} return { err: 'extract' }; }
    setCurrent(j.version); cleanup(j.version);
    log('update ready ' + j.version);
    ready = { version: j.version, notes: j.notes || '' };
    return { ready };
  })();
  try { return await busy; } finally { busy = null; }
}
function setCurrent(ver) { wr(path.join(base(), 'current.json'), { ver, tries: 0 }); }
// نبقي النسخة الجديدة والنسخة العاملة الآن فقط
function cleanup(keep) {
  const running = process.env.LP_BOOT_FROM ? path.basename(process.env.LP_BOOT_FROM) : '';
  try { for (const d of fs.readdirSync(base())) { if (d === 'current.json' || d === keep || d === running) continue; fs.rmSync(path.join(base(), d), { recursive: true, force: true }); } } catch {}
}
// البرنامج فتح بنجاح ← نصفّر عدّاد المحاولات
function markGood() { const f = path.join(base(), 'current.json'), c = rd(f, null); if (c && c.tries) { c.tries = 0; wr(f, c); } }
module.exports = { init, trialState, check, markGood, getReady: () => ready, VER, hasConfig: () => !!CFG.latest };
