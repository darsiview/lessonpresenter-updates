// خزنة الحسابات: دخولات مايكروسوفت وقوقل (الجلسة + كلمات المرور) تنتقل مع المعلمة بين الأجهزة.
// تشفير من طرف إلى طرف: مفتاح الخزنة (VK) لا يُرفع إلا مقفلاً بكلمة مرور المعلمة، فلا يقرؤه أحد غيرها — ولا صاحبة المشروع.
// users/{uid}/vault/key  → VK مقفلاً بـ PBKDF2(كلمة المرور)
// users/{uid}/vault/pw   → كلمات المرور (مشفّرة بـ VK)
// users/{uid}/vault/sess → ملفات الدخول (cookies) لمواقع مايكروسوفت وقوقل (مشفّرة بـ VK)
const crypto = require('crypto');
const { session } = require('electron');
const cloud = require('./cloud');
const store = require('./store');

let CFG = {}; try { CFG = require('./cloud-config.json'); } catch {}
const FS = process.env.LP_FB_FS || 'https://firestore.googleapis.com/v1';
const docs = () => `${FS}/projects/${CFG.projectId}/databases/(default)/documents`;
const ITER = 310000;
// مواقع الحسابات التي تُنقل دخولاتها
const SITES = /(^|\.)(microsoftonline\.com|live\.com|microsoft\.com|microsoft365\.com|office\.com|office\.net|office365\.com|sharepoint\.com|onedrive\.com|officeapps\.live\.com|cloud\.microsoft|google\.com|google\.com\.sa|youtube\.com)$/i;

let cur = null;          // { id, uid, vk: Buffer, items: [] }

// ---------- التشفير ----------
const enc = (key, obj) => {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const d = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final(), c.getAuthTag()]);
  return { iv: iv.toString('base64'), d: d.toString('base64') };
};
const dec = (key, e) => {
  const raw = Buffer.from(e.d, 'base64'), c = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64'));
  c.setAuthTag(raw.subarray(raw.length - 16));
  return JSON.parse(Buffer.concat([c.update(raw.subarray(0, raw.length - 16)), c.final()]).toString('utf8'));
};
const kdf = (pw, salt, it) => crypto.pbkdf2Sync(String(pw), Buffer.from(salt, 'base64'), it || ITER, 32, 'sha256');

// ---------- Firestore ----------
async function req(method, path, body) {
  const res = await fetch(`${docs()}/${path}`, { method, signal: AbortSignal.timeout(15000), headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + await cloud.idToken() }, body: body ? JSON.stringify(body) : undefined });
  if (res.status === 404) return null;
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new cloud.CloudErr('cfail', JSON.stringify(j.error || res.status));
  return j;
}
const str = (f, k) => f && f[k] && f[k].stringValue;
const num = (f, k) => f && f[k] ? +(f[k].integerValue || 0) : 0;
async function getDoc(name) { const d = await req('GET', `users/${cur.uid}/vault/${name}`); return d && d.fields; }
const putDoc = (name, fields) => req('PATCH', `users/${cur.uid}/vault/${name}`, { fields });

// ---------- النسخة المحلية (داخل ملف المعلمة المشفّر، ولا تُزامَن لأنها تبدأ بـ _) ----------
const prof = () => (cur ? store.profiles.get(cur.id) : {});
const saveLocal = (p) => cur && store.profiles.patch(cur.id, p, { meta: true });

function begin(id, uid) {
  if (cur && cur.id === id && cur.uid === uid) return cur;
  cur = { id, uid, vk: null, items: [] };
  const p = prof();
  if (p._vk) { try { cur.vk = Buffer.from(p._vk, 'base64'); } catch {} }
  if (Array.isArray(p._vpw)) cur.items = p._vpw;
  return cur;
}
function end() { cur = null; }
const ready = () => !!(cur && cur.vk);
const enabled = () => prof().vaultOn !== false;

// فتح الخزنة بكلمة المرور (أو إنشاؤها أول مرة). إن تغيّرت كلمة المرور من مكان آخر نعيد قفل مفتاح هذا الجهاز بها
function unwrap(f, password) {
  try { return Buffer.from(dec(kdf(password, str(f, 's'), num(f, 'it')), { iv: str(f, 'iv'), d: str(f, 'd') }).k, 'base64'); } catch { return null; }
}
async function openWithPassword(password) {
  if (!cur || !password || !cloud.session()) return false;
  const f = await getDoc('key');
  let vk = f ? unwrap(f, password) : null;
  if (!vk) {
    vk = cur.vk || crypto.randomBytes(32);
    const salt = crypto.randomBytes(16).toString('base64');
    const w = enc(kdf(password, salt), { k: vk.toString('base64') });
    await putDoc('key', { s: { stringValue: salt }, it: { integerValue: String(ITER) }, iv: { stringValue: w.iv }, d: { stringValue: w.d } });
  }
  setVk(vk);
  await pullPasswords();
  return true;
}
function setVk(vk) {
  if (!cur || !vk) return;
  cur.vk = Buffer.isBuffer(vk) ? vk : Buffer.from(String(vk), 'base64');
  saveLocal({ _vk: cur.vk.toString('base64') });
}
const vkB64 = () => (cur && cur.vk ? cur.vk.toString('base64') : null);

// ---------- كلمات المرور ----------
async function pullPasswords() {
  if (!ready() || !cloud.session()) return cur ? cur.items : [];
  try {
    const f = await getDoc('pw');
    if (f) { const o = dec(cur.vk, { iv: str(f, 'iv'), d: str(f, 'd') }); cur.items = Array.isArray(o.items) ? o.items : []; saveLocal({ _vpw: cur.items }); }
  } catch {}
  return cur.items;
}
async function pushPasswords() {
  if (!ready()) return;
  saveLocal({ _vpw: cur.items });
  if (!cloud.session()) return;
  const e = enc(cur.vk, { items: cur.items });
  await putDoc('pw', { iv: { stringValue: e.iv }, d: { stringValue: e.d }, t: { integerValue: String(Date.now()) } }).catch(() => {});
}
function credsFor(site) {
  if (!cur || !enabled()) return null;
  const list = cur.items.filter(i => i.site === site).sort((a, b) => (b.t || 0) - (a.t || 0));
  return list[0] || null;
}
async function savePassword(site, user, pass) {
  if (!ready() || !user || !pass) return false;
  cur.items = cur.items.filter(i => !(i.site === site && i.user.toLowerCase() === user.toLowerCase()));
  cur.items.push({ site, user, pass, t: Date.now() });
  await pushPasswords();
  return true;
}
const known = (site, user, pass) => !!(cur && cur.items.some(i => i.site === site && i.user.toLowerCase() === String(user).toLowerCase() && i.pass === pass));
async function forget(site, user) {
  if (!cur) return;
  cur.items = cur.items.filter(i => !(i.site === site && (!user || i.user === user)));
  await pushPasswords();
}
const list = () => (cur ? cur.items.map(i => ({ site: i.site, user: i.user, t: i.t })) : []);

// ---------- الجلسات (ملفات الدخول) ----------
let lastHash = '';
async function saveSession(partition) {
  if (!ready() || !enabled() || !cloud.session()) return false;
  const all = await session.fromPartition(partition).cookies.get({});
  const keep = all.filter(c => SITES.test(String(c.domain || '').replace(/^\./, '')));
  const h = crypto.createHash('sha256').update(JSON.stringify(keep.map(c => [c.domain, c.name, c.value]))).digest('hex');
  if (h === lastHash && keep.length) return true;
  const e = enc(cur.vk, { cookies: keep, at: Date.now() });
  if (e.d.length > 900000) return false;                          // أكبر من حد المستند: نتجاهل (نادر جداً)
  const t = Date.now();
  await putDoc('sess', { iv: { stringValue: e.iv }, d: { stringValue: e.d }, t: { integerValue: String(t) } });
  lastHash = h; saveLocal({ _sessAt: t });
  return true;
}
async function restoreSession(partition) {
  if (!ready() || !enabled() || !cloud.session()) return 0;
  const f = await getDoc('sess'); if (!f) return 0;
  const t = num(f, 't');
  if (t && t <= (prof()._sessAt || 0)) return 0;                  // نسخة هذا الجهاز أحدث أو نفسها
  let o; try { o = dec(cur.vk, { iv: str(f, 'iv'), d: str(f, 'd') }); } catch { return 0; }
  const ses = session.fromPartition(partition); let n = 0;
  for (const c of o.cookies || []) {
    const host = String(c.domain || '').replace(/^\./, '');
    const d = { url: `${c.secure ? 'https' : 'http'}://${host}${c.path || '/'}`, name: c.name, value: c.value, path: c.path, secure: c.secure, httpOnly: c.httpOnly };
    if (!c.hostOnly && !/^__Host-/.test(c.name)) d.domain = c.domain;
    if (c.expirationDate) d.expirationDate = c.expirationDate;
    if (c.sameSite && c.sameSite !== 'unspecified') d.sameSite = c.sameSite;
    try { await ses.cookies.set(d); n++; } catch {}
  }
  saveLocal({ _sessAt: t });
  return n;
}
// مسح الخزنة كاملة من السحابة (من الإعدادات)
async function wipeCloud() {
  if (!cur || !cloud.session()) return;
  for (const n of ['pw', 'sess']) await req('DELETE', `users/${cur.uid}/vault/${n}`).catch(() => {});
  cur.items = []; saveLocal({ _vpw: [], _sessAt: 0 });
}

module.exports = { begin, end, ready, enabled, openWithPassword, setVk, vkB64, pullPasswords, credsFor, savePassword, known, forget, list, saveSession, restoreSession, wipeCloud };
