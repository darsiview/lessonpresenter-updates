# مساعد ويندوز لعارض الدروس: يعرض البرامج المثبتة وينقل التركيز إلى النوافذ المفتوحة.
# يستقبل أوامر سطراً سطراً على stdin بالشكل: id|command|argument
# ويرد بسطر: id|json
$ErrorActionPreference = 'SilentlyContinue'
$utf8 = New-Object System.Text.UTF8Encoding $false
[Console]::OutputEncoding = $utf8
[Console]::InputEncoding = $utf8

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;
public static class LPWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
  [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int idx);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int attr, out int v, int size);

  static string Title(IntPtr h) { StringBuilder sb = new StringBuilder(512); GetWindowText(h, sb, 512); return sb.ToString(); }
  static string Cls(IntPtr h) { StringBuilder sb = new StringBuilder(256); GetClassName(h, sb, 256); return sb.ToString(); }
  static bool Cloaked(IntPtr h) { int v = 0; try { DwmGetWindowAttribute(h, 14, out v, 4); } catch { } return v != 0; }
  static bool IsAppWindow(IntPtr h) {
    if (!IsWindowVisible(h) || Cloaked(h)) return false;
    if (GetWindow(h, 4) != IntPtr.Zero) return false;            // له مالك = نافذة فرعية
    if ((GetWindowLong(h, -20) & 0x80) != 0) return false;        // WS_EX_TOOLWINDOW
    return Title(h).Length > 0;
  }
  static List<IntPtr> AppWindows() {
    List<IntPtr> list = new List<IntPtr>();
    EnumProc cb = delegate(IntPtr h, IntPtr l) { if (IsAppWindow(h)) list.Add(h); return true; };
    EnumWindows(cb, IntPtr.Zero);
    GC.KeepAlive(cb);
    return list;
  }

  // النافذة الأمامية: hwnd \t path \t title \t class
  public static string Fg() {
    IntPtr h = GetForegroundWindow();
    if (h == IntPtr.Zero) return "";
    return h.ToInt64() + "\t" + PathOf(h.ToInt64()) + "\t" + Title(h) + "\t" + Cls(h);
  }
  // أول نافذة برنامج لهذا المسار (أو 0)
  public static long Find(string path) {
    foreach (IntPtr h in AppWindows())
      if (string.Equals(PathOf(h.ToInt64()), path, StringComparison.OrdinalIgnoreCase)) return h.ToInt64();
    return 0;
  }
  // مسارات البرامج التي لها نوافذ مفتوحة الآن
  public static string[] OpenPaths() {
    Dictionary<string, bool> set = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
    foreach (IntPtr h in AppWindows()) { string p = PathOf(h.ToInt64()); if (p.Length > 0) set[p] = true; }
    string[] arr = new string[set.Count]; set.Keys.CopyTo(arr, 0); return arr;
  }
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hh, uint f);
  // مقياس الشاشة (125% / 150%): بدون هذا يكبّر ويندوز إحداثيات النافذة مرة ثانية فيظهر العرض أكبر من مكانه
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  public static void Dpi() {
    try { SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch { try { SetProcessDPIAware(); } catch { } }
  }
  [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr h, int idx, int v);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  // وضع نافذة عرض باوربوينت خلف نافذة البرنامج تماماً، بدون إطار
  public static bool Place(long hw, int x, int y, int w, int hh, long after) {
    Dpi();
    IntPtr h = new IntPtr(hw);
    int st = GetWindowLong(h, -16);
    int ns = st & ~0x00C00000 & ~0x00040000;          // بدون شريط عنوان وبدون حواف
    if (ns != st) SetWindowLong(h, -16, ns);
    int ex = GetWindowLong(h, -20);
    int nex = (ex | 0x80 | 0x08000000) & ~0x40000;     // لا يظهر في شريط المهام، ولا يأخذ التركيز أبداً
    if (nex != ex) SetWindowLong(h, -20, nex);
    // FRAMECHANGED فقط عندما تغيّر شكل النافذة فعلاً (وإلا يعيد ويندوز رسمها بلا داعٍ)
    uint fl = 0x0010 | 0x0040; if (ns != st || nex != ex) fl |= 0x0020;
    return SetWindowPos(h, after == 0 ? new IntPtr(1) : new IntPtr(after), x, y, w, hh, fl);
  }
  public static bool Show(long hw, int cmd) { return ShowWindow(new IntPtr(hw), cmd); }
  // التأكد أن نافذة العرض ظاهرة وتحت نافذة البرنامج مباشرة (لا يدخل بينهما وورد أو غيره)
  // 0 = في مكانها، 1 = أُعيد ترتيبها، 2 = كانت مصغّرة أو مخفية فأُرجعت، -1 = النافذة غير موجودة
  public static int Keep(long hw, long own) {
    IntPtr h = new IntPtr(hw), o = new IntPtr(own);
    if (!IsWindow(h)) return -1;
    int r = 0;
    if (IsIconic(h) || !IsWindowVisible(h)) { ShowWindow(h, 9); r = 2; }
    IntPtr n = GetWindow(o, 2);
    while (n != IntPtr.Zero && n != h && !IsWindowVisible(n)) n = GetWindow(n, 2);
    if (n != h) { SetWindowPos(h, o, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010); if (r == 0) r = 1; }
    return r;
  }
  [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr p, EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  // نافذة «Security Alert» لأوفيس: نجيب عليها تلقائياً (OK مع الحماية، أو تمكين المحتوى الخارجي ثم OK)
  public static int alertsHandled = 0;
  public static void StartAlertWatch(bool enable, int seconds) {
    System.Threading.Thread t = new System.Threading.Thread(delegate() {
      DateTime end = DateTime.Now.AddSeconds(seconds);
      while (DateTime.Now < end) {
        try { if (HandleAlert(enable)) { alertsHandled++; System.Threading.Thread.Sleep(800); } } catch { }
        System.Threading.Thread.Sleep(250);
      }
    });
    t.IsBackground = true; t.Start();
  }
  static bool HandleAlert(bool enable) {
    List<IntPtr> tops = new List<IntPtr>();
    EnumProc cb = delegate(IntPtr hh, IntPtr lp) { if (IsWindowVisible(hh)) tops.Add(hh); return true; };
    EnumWindows(cb, IntPtr.Zero); GC.KeepAlive(cb);
    foreach (IntPtr h in tops) {
      string t = Title(h);
      bool sec = t.IndexOf("Security", StringComparison.OrdinalIgnoreCase) >= 0 || t.IndexOf("الأمان") >= 0 || t.IndexOf("Sécurité", StringComparison.OrdinalIgnoreCase) >= 0;
      bool dlg = Cls(h) == "#32770" || t.IndexOf("Office Security", StringComparison.OrdinalIgnoreCase) >= 0 || t.IndexOf("خيارات الأمان") >= 0;
      if (!sec || !dlg || !PathOf(h.ToInt64()).ToLower().EndsWith("powerpnt.exe")) continue;
      List<IntPtr> kids = new List<IntPtr>();
      EnumProc cb2 = delegate(IntPtr ch, IntPtr lq) { kids.Add(ch); return true; };
      EnumChildWindows(h, cb2, IntPtr.Zero); GC.KeepAlive(cb2);
      List<IntPtr> radios = new List<IntPtr>(); IntPtr ok = IntPtr.Zero, firstPush = IntPtr.Zero;
      foreach (IntPtr c in kids) {
        if (Cls(c) != "Button") continue;
        int st = GetWindowLong(c, -16) & 0xF;
        if (st == 4 || st == 9) radios.Add(c);
        else if (st == 1) ok = c;
        else if (st == 0 && firstPush == IntPtr.Zero) firstPush = c;
        string bt = Title(c).Replace("&", "");
        if ((st == 0 || st == 1) && (bt == "OK" || bt == "موافق")) ok = c;
      }
      if (enable && radios.Count >= 2) { SendMessage(radios[radios.Count - 1], 0x00F5, IntPtr.Zero, IntPtr.Zero); System.Threading.Thread.Sleep(150); }
      if (ok == IntPtr.Zero) ok = firstPush;
      if (ok != IntPtr.Zero) { SendMessage(ok, 0x00F5, IntPtr.Zero, IntPtr.Zero); return true; }
      // ليست نافذة عادية: نضغط Enter (OK)
      PostMessage(h, 0x0100, new IntPtr(0x0D), IntPtr.Zero); PostMessage(h, 0x0101, new IntPtr(0x0D), IntPtr.Zero);
      return true;
    }
    return false;
  }
  // تشخيص: كل نوافذ باوربوينت (الظاهرة والمخفية والفرعية) لنعرف أين نافذة العرض
  public static string Diag() {
    StringBuilder sb = new StringBuilder();
    List<IntPtr> all = new List<IntPtr>();
    EnumProc cb = delegate(IntPtr hh, IntPtr lp) { all.Add(hh); return true; };
    EnumWindows(cb, IntPtr.Zero); GC.KeepAlive(cb);
    foreach (IntPtr h in all) {
      if (!PathOf(h.ToInt64()).ToLower().EndsWith("powerpnt.exe")) continue;
      RECT r; GetWindowRect(h, out r);
      sb.Append(h.ToInt64() + " [" + Cls(h) + "] vis=" + IsWindowVisible(h) + " '" + Title(h) + "' " + (r.R - r.L) + "x" + (r.B - r.T) + "\n");
      List<IntPtr> kids = new List<IntPtr>();
      EnumProc cb2 = delegate(IntPtr ch, IntPtr lq) { kids.Add(ch); return true; };
      EnumChildWindows(h, cb2, IntPtr.Zero); GC.KeepAlive(cb2);
      int n = 0;
      foreach (IntPtr c in kids) { if (n++ > 12) break; sb.Append("    child " + c.ToInt64() + " [" + Cls(c) + "] vis=" + IsWindowVisible(c) + "\n"); }
    }
    return sb.ToString();
  }
  // نافذة عرض الشرائح لباوربوينت: الفئة screenClass، ونفضّل التي تحمل اسم الملف، ونتجاهل النوافذ المعروفة سابقاً
  public static long FindShow(string name, string known) {
    List<IntPtr> all = new List<IntPtr>();
    EnumProc cb = delegate(IntPtr hh, IntPtr lp) { if (IsWindowVisible(hh)) all.Add(hh); return true; };
    EnumWindows(cb, IntPtr.Zero); GC.KeepAlive(cb);
    string[] skip = (known ?? "").Split(',');
    long best = 0, byTitle = 0;
    foreach (IntPtr h in all) {
      if (Array.IndexOf(skip, h.ToInt64().ToString()) >= 0) continue;
      string c = Cls(h), t = Title(h);
      bool isPpt = PathOf(h.ToInt64()).ToLower().EndsWith("powerpnt.exe") || t.IndexOf("PowerPoint", StringComparison.OrdinalIgnoreCase) >= 0;
      if (!isPpt) continue;
      if (c == "PPTFrameClass" || c == "#32770" || c.StartsWith("NUI") || c.StartsWith("Mso")) continue;   // المحرّر والنوافذ الحوارية
      bool show = c == "screenClass" || t.IndexOf("Slide Show", StringComparison.OrdinalIgnoreCase) >= 0 || t.IndexOf("عرض الشرائح") >= 0 || t.IndexOf("Diaporama", StringComparison.OrdinalIgnoreCase) >= 0;
      bool named = name.Length > 0 && t.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0;
      if (show && named) return h.ToInt64();
      if (show && best == 0) best = h.ToInt64();
      if (named && byTitle == 0) byTitle = h.ToInt64();
    }
    return best != 0 ? best : byTitle;
  }
  public static bool Alive(long hw) { IntPtr h = new IntPtr(hw); return IsWindow(h) && IsWindowVisible(h); }
  public static string Desc(string path) {
    try { string d = FileVersionInfo.GetVersionInfo(path).FileDescription; return d == null ? "" : d.Trim(); } catch { return ""; }
  }

  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] static extern void keybd_event(byte k, byte s, uint f, UIntPtr e);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint a, bool i, uint pid);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, uint f, StringBuilder s, ref uint n);

  public static bool Focus(long hw) {
    IntPtr h = new IntPtr(hw);
    if (IsIconic(h)) ShowWindowAsync(h, 9);
    keybd_event(0x12, 0, 0, UIntPtr.Zero);
    keybd_event(0x12, 0, 2, UIntPtr.Zero);
    BringWindowToTop(h);
    bool ok = SetForegroundWindow(h);
    if (!ok || GetForegroundWindow() != h) {
      // طريقة بديلة: تصغير ثم استعادة تجعل ويندوز يُظهر النافذة في المقدمة
      ShowWindow(h, 6);
      ShowWindow(h, 9);
      SetForegroundWindow(h);
      ok = GetForegroundWindow() == h;
    }
    return ok;
  }

  public static string PathOf(long hw) {
    uint pid;
    GetWindowThreadProcessId(new IntPtr(hw), out pid);
    IntPtr p = OpenProcess(0x1000, false, pid);
    if (p == IntPtr.Zero) return "";
    StringBuilder sb = new StringBuilder(1024);
    uint n = 1024;
    string r = QueryFullProcessImageName(p, 0, sb, ref n) ? sb.ToString() : "";
    CloseHandle(p);
    return r;
  }
}

// التقاط عجلة الفأرة (وحركة الإصبعين على لوحة اللمس) أثناء عمل الكشّاف على كل الشاشة
public static class LPWheel {
  delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);
  [DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc fn, IntPtr hMod, uint tid);
  [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int n, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] static extern int GetMessage(out MSG m, IntPtr h, uint a, uint b);
  [DllImport("user32.dll")] static extern bool PostThreadMessage(uint tid, uint msg, IntPtr w, IntPtr l);
  [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int x; public int y; }
  static int acc = 0;
  static uint tid = 0;
  static IntPtr hook = IntPtr.Zero;
  static LowLevelMouseProc proc;
  static System.Threading.Thread th;
  static IntPtr Hook(int n, IntPtr w, IntPtr l) {
    if (n >= 0 && w.ToInt32() == 0x020A && (GetAsyncKeyState(0x10) & 0x8000) == 0) {   // عجلة بدون Shift
      int data = Marshal.ReadInt32(l, 8);
      short delta = (short)((data >> 16) & 0xFFFF);
      System.Threading.Interlocked.Add(ref acc, delta);
      return new IntPtr(1);       // لا نمررها للبرنامج تحت الكشّاف
    }
    return CallNextHookEx(hook, n, w, l);
  }
  public static bool Start() {
    if (th != null) return true;
    th = new System.Threading.Thread(() => {
      tid = GetCurrentThreadId();
      proc = Hook;
      hook = SetWindowsHookEx(14, proc, GetModuleHandle(null), 0);
      MSG m;
      while (GetMessage(out m, IntPtr.Zero, 0, 0) > 0) { }
      if (hook != IntPtr.Zero) UnhookWindowsHookEx(hook);
      hook = IntPtr.Zero;
    });
    th.IsBackground = true;
    th.Start();
    return true;
  }
  public static bool Stop() {
    if (th == null) return true;
    PostThreadMessage(tid, 0x0012, IntPtr.Zero, IntPtr.Zero);
    th = null;
    System.Threading.Interlocked.Exchange(ref acc, 0);
    return true;
  }
  public static int Take() { return System.Threading.Interlocked.Exchange(ref acc, 0); }
}
"@
try { [LPWin]::Dpi() } catch {}   # إحداثيات بالبكسل الحقيقي مهما كان مقياس الشاشة

# ---------- باوربوينت ----------
$global:pptApp = $null
$global:shows = @{}
function Get-Ppt {
  if ($null -ne $global:pptApp) { try { $null = $global:pptApp.Version; return $global:pptApp } catch { $global:pptApp = $null } }
  $global:pptApp = New-Object -ComObject PowerPoint.Application
  return $global:pptApp
}
# نسخة مؤقتة من الملف: الملفات المنزّلة من الإنترنت تُفتح في «العرض المحمي» فيرفض باوربوينت فتحها برمجياً
function Safe-Copy([string]$file) {
  $dir = Join-Path $env:TEMP ('LP-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $tmp = Join-Path $dir ([IO.Path]::GetFileName($file))
  [IO.File]::WriteAllBytes($tmp, [IO.File]::ReadAllBytes($file))
  return $tmp
}
function Find-ShowHwnd($win, [string]$base, [string]$known, [int]$tries) {
  for ($i = 0; $i -lt $tries; $i++) {
    $h = 0
    try { $h = [long]$win.HWND } catch {}
    if ($h -ne 0) { return @{ hwnd = $h; how = 'com'; tries = $i } }
    $h = [LPWin]::FindShow($base, $known)
    if ($h -ne 0) { return @{ hwnd = $h; how = 'find'; tries = $i } }
    Start-Sleep -Milliseconds 150
  }
  return @{ hwnd = 0; how = 'none'; tries = $tries }
}
function Ppt-Open([string]$arg) {
  $pa = $arg.Split([char]'|')
  $file = $pa[0]; $enable = ($pa.Length -gt 1 -and $pa[1] -eq '1')
  [LPWin]::StartAlertWatch($enable, 120)
  $app = Get-Ppt
  $src = $file
  try { $src = Safe-Copy $file } catch {}
  $pres = $app.Presentations.Open($src, -1, 0, 0)       # للقراءة فقط، بدون نافذة
  $base = [IO.Path]::GetFileNameWithoutExtension([string]$pres.Name)
  $known = (@($global:shows.Values | ForEach-Object { $_.hwnd }) -join ',')
  $ss = $pres.SlideShowSettings
  $ss.ShowScrollbar = 0
  $ss.LoopUntilStopped = 0
  $ss.ShowWithAnimation = -1
  $ss.ShowWithNarration = -1
  $ss.RangeType = 1
  # المحاولة ١: ملء الشاشة (نافذته مستقلة دائماً، ثم يضعها البرنامج داخل إطاره)
  $t0 = Get-Date
  $ss.ShowType = 1
  try { $ss.ShowPresenterView = 0 } catch {}
  $win = $ss.Run()
  $tRun = [int]((Get-Date) - $t0).TotalMilliseconds
  $f = Find-ShowHwnd $win $base $known 120
  $mode = 'full'
  $diag1 = $null
  if ($f.hwnd -eq 0) {
    # المحاولة ٢: عرض داخل نافذة
    $diag1 = [LPWin]::Diag()
    try {
      try { $win.View.Exit() } catch {}
      Start-Sleep -Milliseconds 600
      $ss2 = $null
      try { $ss2 = $pres.SlideShowSettings; $null = $ss2.ShowType } catch { $ss2 = $null }
      if ($null -eq $ss2) { try { $pres.Close() } catch {}; $pres = $app.Presentations.Open($src, -1, 0, 0); $ss2 = $pres.SlideShowSettings }
      try { $ss2.ShowType = 2 } catch {}
      $win = $ss2.Run()
      $f = Find-ShowHwnd $win $base $known 80
      $mode = 'window'
    } catch { $f = @{ hwnd = 0; how = 'err2: ' + [string]$_.Exception.Message; tries = 0 } }
  }
  $id = [guid]::NewGuid().ToString('N').Substring(0, 10)
  $global:shows[$id] = @{ pres = $pres; win = $win; hwnd = $f.hwnd; tmp = $src }
  $r = @{ id = $id; hwnd = $f.hwnd; how = $f.how; mode = $mode; alerts = [LPWin]::alertsHandled; media = $enable; tries = $f.tries; runMs = $tRun; totalMs = [int]((Get-Date) - $t0).TotalMilliseconds; count = [int]$pres.Slides.Count; name = [string]$pres.Name; base = $base }
  if ($f.hwnd -eq 0) { $r.diag = [LPWin]::Diag(); $r.diag1 = $diag1 }
  return $r
}
# بديل: تحويل الشرائح إلى صور (عند تعذّر عرضها داخل البرنامج)
function Ppt-Export([string]$arg) {
  $a = $arg.Split([char]'|')
  $file = $a[0]; $dir = $a[1]
  [LPWin]::StartAlertWatch(($a.Length -gt 2 -and $a[2] -eq '1'), 120)
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $src = $file
  try { $src = Safe-Copy $file } catch {}
  $pres = $null
  for ($k = 0; $k -lt 4 -and $null -eq $pres; $k++) {
    try { $app = Get-Ppt; $pres = $app.Presentations.Open($src, -1, 0, 0) }
    catch { if ($k -eq 3) { throw }; $global:pptApp = $null; Start-Sleep -Milliseconds 1500 }
  }
  try {
    $n = [int]$pres.Slides.Count
    $w = [double]$pres.PageSetup.SlideWidth; $h = [double]$pres.PageSetup.SlideHeight
    $outW = 1920; $outH = [int][Math]::Round(1920 * $h / $w)
    for ($i = 1; $i -le $n; $i++) { $pres.Slides.Item($i).Export((Join-Path $dir ("s$i.png")), 'PNG', $outW, $outH) }
    return @{ dir = $dir; count = $n }
  } finally {
    try { $pres.Close() } catch {}
    try { if ($src -ne $file) { Remove-Item -LiteralPath ([IO.Path]::GetDirectoryName($src)) -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
    try { if ($global:pptApp.Presentations.Count -eq 0 -and $global:shows.Count -eq 0) { $global:pptApp.Quit(); $global:pptApp = $null } } catch {}
  }
}
# تحويل تدريجي: يُفتح العرض مرة واحدة، ثم تُصدَّر الشرائح واحدة واحدة (والبرنامج يعرض ما جهز منها)
$global:exps = @{}
function Ppt-XOpen([string]$arg) {
  $a = $arg.Split([char]'|')
  $file = $a[0]; $dir = $a[1]
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $e = $global:exps[$dir]
  if ($null -ne $e) { return @{ count = [int]$e.pres.Slides.Count; w = $e.w; h = $e.h } }
  [LPWin]::StartAlertWatch(($a.Length -gt 2 -and $a[2] -eq '1'), 120)
  $src = $file
  try { $src = Safe-Copy $file } catch {}
  $pres = $null
  for ($k = 0; $k -lt 4 -and $null -eq $pres; $k++) {
    try { $app = Get-Ppt; $pres = $app.Presentations.Open($src, -1, 0, 0) }
    catch { if ($k -eq 3) { throw }; $global:pptApp = $null; Start-Sleep -Milliseconds 1500 }
  }
  $w = [double]$pres.PageSetup.SlideWidth; $h = [double]$pres.PageSetup.SlideHeight
  $outW = 1920; $outH = [int][Math]::Round(1920 * $h / $w)
  $global:exps[$dir] = @{ pres = $pres; src = $src; file = $file; w = $outW; h = $outH }
  return @{ count = [int]$pres.Slides.Count; w = $outW; h = $outH }
}
function Ppt-XPart([string]$arg) {
  $a = $arg.Split([char]'|')
  $dir = $a[0]; $i = [int]$a[1]
  $e = $global:exps[$dir]
  if ($null -eq $e) { throw 'noexp' }
  $tmp = Join-Path $dir ("t$i.png"); $out = Join-Path $dir ("s$i.png")
  $e.pres.Slides.Item($i).Export($tmp, 'PNG', $e.w, $e.h)
  Move-Item -LiteralPath $tmp -Destination $out -Force
  return $true
}
function Ppt-XClose([string]$dir) {
  $e = $global:exps[$dir]
  if ($null -eq $e) { return $true }
  try { $e.pres.Close() } catch {}
  try { if ($e.src -ne $e.file) { Remove-Item -LiteralPath ([IO.Path]::GetDirectoryName($e.src)) -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
  $global:exps.Remove($dir)
  try { if ($global:pptApp.Presentations.Count -eq 0 -and $global:shows.Count -eq 0) { $global:pptApp.Quit(); $global:pptApp = $null } } catch {}
  return $true
}
function Ppt-Get([string]$id) { $s = $global:shows[$id]; if ($null -eq $s) { throw 'noshow' }; return $s }
function Ppt-State([string]$id) {
  $s = Ppt-Get $id
  $v = $s.win.View
  $st = [int]$v.State
  $pos = 0; try { $pos = [int]$v.CurrentShowPosition } catch {}
  $slide = 0; try { $slide = [int]$v.Slide.SlideIndex } catch {}
  $click = 0; try { $click = [int]$v.GetClickIndex() } catch {}
  return @{ state = $st; pos = $pos; slide = $slide; click = $click; count = [int]$s.pres.Slides.Count }
}
function Ppt-Close([string]$id) {
  $s = $global:shows[$id]
  if ($null -eq $s) { return $true }
  try { $s.win.View.Exit() } catch {}
  try { $s.pres.Close() } catch {}
  try { if ($s.tmp -and $s.tmp.StartsWith($env:TEMP)) { Remove-Item -LiteralPath ([IO.Path]::GetDirectoryName($s.tmp)) -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
  $global:shows.Remove($id)
  try { if ($global:pptApp.Presentations.Count -eq 0 -and $global:shows.Count -eq 0 -and $global:exps.Count -eq 0) { $global:pptApp.Quit(); $global:pptApp = $null } } catch {}
  return $true
}

function Get-InstalledApps {
  $list = New-Object System.Collections.ArrayList
  $seen = @{}
  $sh = New-Object -ComObject WScript.Shell
  $dirs = @(
    (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'),
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs')
  )
  $skip = 'uninstall|unins|إزالة|readme|read me|help|documentation|license|website|release notes|changelog'
  foreach ($d in $dirs) {
    if (-not (Test-Path -LiteralPath $d)) { continue }
    foreach ($f in (Get-ChildItem -LiteralPath $d -Recurse -Filter '*.lnk')) {
      $n = $f.BaseName
      if ($n -match $skip) { continue }
      $k = $n.ToLowerInvariant()
      if ($seen.ContainsKey($k)) { continue }
      $t = ''
      try { $t = $sh.CreateShortcut($f.FullName).TargetPath } catch {}
      if ($t -and ($t -match '\.(txt|pdf|html?|url|chm|rtf)$')) { continue }
      $seen[$k] = 1
      [void]$list.Add([pscustomobject]@{ name = $n; lnk = $f.FullName; target = $t; aumid = '' })
    }
  }
  try {
    foreach ($a in (Get-StartApps)) {
      if ($a.AppID -notlike '*!*') { continue }
      $k = $a.Name.ToLowerInvariant()
      if ($seen.ContainsKey($k)) { continue }
      $seen[$k] = 1
      [void]$list.Add([pscustomobject]@{ name = $a.Name; lnk = ''; target = ''; aumid = $a.AppID })
    }
  } catch {}
  return ,$list.ToArray()
}

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  $parts = $line.Split([char[]]@([char]'|'), 3)
  if ($parts.Length -lt 2) { continue }
  $id = $parts[0]; $cmd = $parts[1]; $arg = ''
  if ($parts.Length -gt 2) { $arg = $parts[2] }
  $res = $null
  try {
    switch ($cmd) {
      'ping'  { $res = 'pong' }
      'focus' { $res = [LPWin]::Focus([long]$arg) }
      'paths' {
        $res = @{}
        foreach ($h in $arg.Split([char]',')) { if ($h) { $res[$h] = [LPWin]::PathOf([long]$h) } }
      }
      'apps'  { $res = Get-InstalledApps }
      'fg'    { $res = [LPWin]::Fg() }
      'find'  { $res = [LPWin]::Find($arg) }
      'open'  { $res = [string[]][LPWin]::OpenPaths() }
      'alive' { $res = [LPWin]::Alive([long]$arg) }
      'desc'  { $res = [LPWin]::Desc($arg) }
      'place' { $a = $arg.Split([char]','); $res = [LPWin]::Place([long]$a[0], [int]$a[1], [int]$a[2], [int]$a[3], [int]$a[4], [long]$a[5]) }
      'show'  { $a = $arg.Split([char]','); $res = [LPWin]::Show([long]$a[0], [int]$a[1]) }
      'wheelstart' { $res = [LPWheel]::Start() }
      'wheelstop'  { $res = [LPWheel]::Stop() }
      'wheeltake'  { $res = [LPWheel]::Take() }
      'pptcheck' { $res = [bool](Test-Path 'Registry::HKEY_CLASSES_ROOT\PowerPoint.Application\CLSID') }
      'pptopen'  { $res = Ppt-Open $arg }
      'pptnext'  { (Ppt-Get $arg).win.View.Next(); $res = Ppt-State $arg }
      'pptprev'  { (Ppt-Get $arg).win.View.Previous(); $res = Ppt-State $arg }
      'pptgoto'  { $a = $arg.Split([char]','); (Ppt-Get $a[0]).win.View.GotoSlide([int]$a[1]); $res = Ppt-State $a[0] }
      'pptfirst' { (Ppt-Get $arg).win.View.First(); $res = Ppt-State $arg }
      'pptstate' { $res = Ppt-State $arg }
      'pptclose' { $res = Ppt-Close $arg }
      'keep'     { $a = $arg.Split([char]','); $res = [LPWin]::Keep([long]$a[0], [long]$a[1]) }
      'pptpointer' { $a = $arg.Split([char]','); $v = (Ppt-Get $a[0]).win.View; $v.PointerType = [int]$a[1]; if ($a.Length -gt 2 -and $a[2] -ne '') { $v.PointerColor.RGB = [int]$a[2] }; $res = $true }
      'ppterase' { (Ppt-Get $arg).win.View.EraseDrawing(); $res = $true }
      'pptexport' { $res = Ppt-Export $arg }
      'pptxopen'  { $res = Ppt-XOpen $arg }
      'pptxpart'  { $res = Ppt-XPart $arg }
      'pptxclose' { $res = Ppt-XClose $arg }
    }
  } catch { if ($cmd -eq 'pptopen' -or $cmd -eq 'pptexport' -or $cmd -eq 'pptxopen' -or $cmd -eq 'pptxpart') { $res = @{ err = [string]$_.Exception.Message } } else { $res = $null } }
  $json = 'null'
  if ($null -ne $res) { $json = ConvertTo-Json -InputObject $res -Compress -Depth 4 }
  if (-not $json) { $json = 'null' }
  [Console]::Out.WriteLine("$id|$json")
  [Console]::Out.Flush()
}
