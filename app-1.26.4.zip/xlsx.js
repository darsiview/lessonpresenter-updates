// كتابة ملف إكسل (.xlsx) بسيط بلا مكتبات: أوراق فيها صفوف (نصوص وأرقام)، باتجاه من اليمين لليسار عند الحاجة
const zlib = require('zlib');
const CRC = (() => { const t = new Int32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; } return t; })();
const crc32 = (b) => { let c = -1; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function zip(files) {
  const parts = [], cen = []; let off = 0;
  for (const [name, data0] of files) {
    const data = Buffer.isBuffer(data0) ? data0 : Buffer.from(data0, 'utf8'), nm = Buffer.from(name, 'utf8');
    const comp = zlib.deflateRawSync(data), crc = crc32(data);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8);
    h.writeUInt32LE(0, 10); h.writeUInt32LE(crc, 14); h.writeUInt32LE(comp.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(nm.length, 26); h.writeUInt16LE(0, 28);
    parts.push(h, nm, comp);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10);
    c.writeUInt32LE(0, 12); c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(data.length, 24); c.writeUInt16LE(nm.length, 28);
    c.writeUInt32LE(off, 42); cen.push(c, nm);
    off += 30 + nm.length + comp.length;
  }
  const cd = Buffer.concat(cen), e = Buffer.alloc(22);
  e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(files.length, 8); e.writeUInt16LE(files.length, 10); e.writeUInt32LE(cd.length, 12); e.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, e]);
}
const x = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
const col = (i) => { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
// sheets: [{ name, rows: [[...]], widths?: [..], boldRows?: [index] }]
function build(sheets, rtl) {
  const names = new Set(); const files = [];
  const sn = sheets.map((s, i) => { let n = String(s.name || 'Sheet' + (i + 1)).replace(/[\\/?*[\]:]/g, '-').slice(0, 31) || 'Sheet' + (i + 1); while (names.has(n)) n = n.slice(0, 28) + ' ' + i; names.add(n); return n; });
  files.push(['[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`]);
  files.push(['_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`]);
  files.push(['xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sn.map((n, i) => `<sheet name="${x(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`]);
  files.push(['xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`]);
  files.push(['xl/styles.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="12"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF3C4"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`]);
  sheets.forEach((s, i) => {
    const bold = new Set(s.boldRows || []);
    const rows = (s.rows || []).map((r, ri) => `<row r="${ri + 1}">${r.map((v, ci) => {
      if (v === null || v === undefined || v === '') return '';
      const ref = col(ci) + (ri + 1), st = bold.has(ri) ? ' s="1"' : '';
      return typeof v === 'number' && isFinite(v) ? `<c r="${ref}"${st}><v>${v}</v></c>` : `<c r="${ref}" t="inlineStr"${st}><is><t xml:space="preserve">${x(v)}</t></is></c>`;
    }).join('')}</row>`).join('');
    const w = (s.widths || []).map((wd, ci) => `<col min="${ci + 1}" max="${ci + 1}" width="${wd}" customWidth="1"/>`).join('');
    files.push([`xl/worksheets/sheet${i + 1}.xml`, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"${rtl ? ' rightToLeft="1"' : ''}/></sheetViews>${w ? `<cols>${w}</cols>` : ''}<sheetData>${rows}</sheetData></worksheet>`]);
  });
  return zip(files);
}
// ---------- القراءة ----------
function unzip(buf) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error('not a zip');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = {};
  for (let i = 0; i < n; i++) {
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nl).toString('utf8');
    const ds = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.slice(ds, ds + csize);
    out[name.replace(/^\/+/, '')] = method === 8 ? zlib.inflateRawSync(raw) : raw;
    p += 46 + nl + xl + cl;
  }
  return out;
}
const unx = (s) => String(s).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, d) => String.fromCharCode(+d)).replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/&amp;/g, '&');
const texts = (xml) => { let t = ''; xml.replace(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g, (_, v) => { t += unx(v); }); return t; };
const colIdx = (ref) => { const m = /^([A-Z]+)/.exec(ref); let n = 0; for (const ch of m ? m[1] : 'A') n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
// كل الأوراق: [{ name, rows: [[...]] }]
function readBook(buf) {
  const z = unzip(buf), g = (k) => z[k] ? z[k].toString('utf8') : '';
  const ss = []; g('xl/sharedStrings.xml').replace(/<si>([\s\S]*?)<\/si>/g, (_, si) => { ss.push(texts(si)); });
  const rels = {}; g('xl/_rels/workbook.xml.rels').replace(/<Relationship\b[^>]*>/g, (r) => { const id = /Id="([^"]+)"/.exec(r), t = /Target="([^"]+)"/.exec(r); if (id && t) rels[id[1]] = t[1]; });
  const sheets = [];
  g('xl/workbook.xml').replace(/<sheet\b[^>]*>/g, (sh) => {
    const nm = /name="([^"]*)"/.exec(sh), rid = /r:id="([^"]+)"/.exec(sh) || /id="([^"]+)"/.exec(sh);
    let t = rid && rels[rid[1]] || ''; t = t.replace(/^\/?(xl\/)?/, 'xl/');
    sheets.push({ name: nm ? unx(nm[1]) : 'Sheet', path: t });
  });
  if (!sheets.length) Object.keys(z).filter(k => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort().forEach((k, i) => sheets.push({ name: 'Sheet' + (i + 1), path: k }));
  return sheets.map(sh => {
    const rows = [];
    g(sh.path).replace(/<row\b[^>]*>([\s\S]*?)<\/row>/g, (rw, inner) => {
      const rn = /\br="(\d+)"/.exec(rw); const r = []; let ci = 0;
      inner.replace(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g, (_, attrs, body) => {
        const ref = /r="([A-Z]+\d+)"/.exec(attrs); if (ref) ci = colIdx(ref[1]);
        const t = (/t="([^"]+)"/.exec(attrs) || [])[1]; body = body || '';
        let v = (/<v>([\s\S]*?)<\/v>/.exec(body) || [])[1];
        let val = '';
        if (t === 's') val = ss[+v] ?? ''; else if (t === 'inlineStr') val = texts(body); else if (v !== undefined) val = unx(v);
        r[ci++] = val;
      });
      const idx = rn ? +rn[1] - 1 : rows.length; rows[idx] = Array.from(r, x => x ?? '');
    });
    return { name: sh.name, rows: Array.from(rows, x => x || []) };
  });
}
const readXlsx = (buf) => (readBook(buf)[0] || { rows: [] }).rows;
const writeXlsx = (rows, o = {}) => build([{ name: o.name || 'Sheet1', rows, widths: o.widths, boldRows: [0] }], !!o.rtl);
module.exports = { unzip, build, zip, readBook, readXlsx, writeXlsx };
